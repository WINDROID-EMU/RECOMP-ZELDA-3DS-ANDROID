#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_Fishing_UpdateGroupFishes_001141F4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_address_taken_0019846C_0019846C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Fishing_UpdateEffects_001BFB74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Fishing_HandleOwnerDialog_001C3558(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_sin_idx8_002CFCA0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_002d4a10_002D4A10(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_Init_002E5724(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_direct_target_00316D74_00316D74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossVa_Spark_0031F5A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ChangeCameraStatus_00320D7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_ChangeStatus_00320DA0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ShrinkWindow_SetVal_00338CD8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_cos_idx8_00338F60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_ShouldAdvance_00346964(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Fishing_SpawnDustSplash_00346AB4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Interface_ChangeAlpha_0034BE04(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_TitleCard_InitBossName_00354248(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003542c4_003542C4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetRuntimeFlag200_0035AF04(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b0a0_0035B0A0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b164_0035B164(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b2d0_0035B2D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_SetBGM_003655D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CutsceneContext_StartUnskippable_00367374(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CutsceneContext_StartSkippable_00367494(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_Atan2F_003675F8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererGlobalState_Init_0036788C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_StaticInitGuard_TryAcquire_003679B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_CameraSetAtEye_00367B14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_set_byte_1b6_00367C48(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_clear_byte_1b6_00367C54(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_StartTextbox_00367C7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_CreateSubCamera_00367D74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_ProjectPos_00368CC0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Runtime_SignedDivMod32_00368D94(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_GetInputDirYaw_00368FEC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Matrix_RotateX_00369014(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ClearCamera_0036963C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_GetChoiceIndex_00369F3C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SpawnAsChild_0036AA20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_GetLastFrame_0036AE14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_GetCamera_0036C5BC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToF_0036E168(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetCsActionWithHaltedActors_0036E980(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_QueueSeqCmd_0036EC40(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlaySfxWithScaledGain_0036EF10(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0036fadc_0036FADC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_ApproachZeroF_0036FC20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToSUpdateRate_00370084(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_MorphToLoop_00370350(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_OnePointCutscene_Init_00371808(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroFloat_00371E50(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_MessageContext_ResetDisplay_003725E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_CosF_Core_00372674(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SinF_003727F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_ApproachF_00373500(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_transform_mtx3x4_vec3_003735AC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Matrix_RotateY_003735E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_OnFrameImpl_003736FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_CenteredFloat_003738A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_MorphToPlayOnce_00374A58(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlaySoundGeneral_0037547C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_Atan2S_003758B0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroOne_003759D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToS_00375A18(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlayActorSound2_00375BCC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_Change_00375c08_00375C08(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_GetState_003769D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossVa_BodyIntro_00394E8C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Fishing_UpdateOwner_003B5AE0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Fishing_UpdateLure_003D1040(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_address_taken_0019846C_0019846C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0019846CU:
        goto block_0019846C;
    case 0x0019848CU:
        goto block_0019848C;
    case 0x001984A4U:
        goto block_001984A4;
    case 0x001984ACU:
        goto block_001984AC;
    case 0x001984D8U:
        goto block_001984D8;
    case 0x0019850CU:
        goto block_0019850C;
    case 0x0019851CU:
        goto block_0019851C;
    case 0x00198528U:
        goto block_00198528;
    case 0x0019853CU:
        goto block_0019853C;
    case 0x0019854CU:
        goto block_0019854C;
    case 0x0019855CU:
        goto block_0019855C;
    case 0x001985A4U:
        goto block_001985A4;
    case 0x001985B0U:
        goto block_001985B0;
    case 0x001985D0U:
        goto block_001985D0;
    case 0x001985E0U:
        goto block_001985E0;
    case 0x001985F0U:
        goto block_001985F0;
    case 0x0019861CU:
        goto block_0019861C;
    case 0x00198640U:
        goto block_00198640;
    case 0x00198664U:
        goto block_00198664;
    case 0x0019867CU:
        goto block_0019867C;
    case 0x0019869CU:
        goto block_0019869C;
    case 0x001986B4U:
        goto block_001986B4;
    case 0x001986C8U:
        goto block_001986C8;
    case 0x001986E0U:
        goto block_001986E0;
    case 0x001986ECU:
        goto block_001986EC;
    case 0x00198700U:
        goto block_00198700;
    case 0x00198718U:
        goto block_00198718;
    case 0x00198790U:
        goto block_00198790;
    case 0x001987A8U:
        goto block_001987A8;
    case 0x001987B4U:
        goto block_001987B4;
    case 0x001987C4U:
        goto block_001987C4;
    case 0x001987D0U:
        goto block_001987D0;
    case 0x001987DCU:
        goto block_001987DC;
    case 0x001987E8U:
        goto block_001987E8;
    case 0x001987F4U:
        goto block_001987F4;
    case 0x00198834U:
        goto block_00198834;
    case 0x0019884CU:
        goto block_0019884C;
    case 0x0019885CU:
        goto block_0019885C;
    case 0x001988CCU:
        goto block_001988CC;
    case 0x001988E4U:
        goto block_001988E4;
    case 0x001988F4U:
        goto block_001988F4;
    case 0x00198900U:
        goto block_00198900;
    case 0x00198914U:
        goto block_00198914;
    case 0x00198924U:
        goto block_00198924;
    case 0x00198944U:
        goto block_00198944;
    case 0x0019894CU:
        goto block_0019894C;
    case 0x001989E0U:
        goto block_001989E0;
    case 0x001989ECU:
        goto block_001989EC;
    case 0x00198A34U:
        goto block_00198A34;
    case 0x00198A4CU:
        goto block_00198A4C;
    case 0x00198A5CU:
        goto block_00198A5C;
    case 0x00198A68U:
        goto block_00198A68;
    case 0x00198A7CU:
        goto block_00198A7C;
    case 0x00198A88U:
        goto block_00198A88;
    case 0x00198A90U:
        goto block_00198A90;
    case 0x00198A98U:
        goto block_00198A98;
    case 0x00198AACU:
        goto block_00198AAC;
    case 0x00198AC0U:
        goto block_00198AC0;
    case 0x00198AD0U:
        goto block_00198AD0;
    case 0x00198ADCU:
        goto block_00198ADC;
    case 0x00198AE8U:
        goto block_00198AE8;
    case 0x00198B00U:
        goto block_00198B00;
    case 0x00198B10U:
        goto block_00198B10;
    case 0x00198B1CU:
        goto block_00198B1C;
    case 0x00198B2CU:
        goto block_00198B2C;
    case 0x00198B38U:
        goto block_00198B38;
    case 0x00198B48U:
        goto block_00198B48;
    case 0x00198B54U:
        goto block_00198B54;
    case 0x00198B6CU:
        goto block_00198B6C;
    case 0x00198B78U:
        goto block_00198B78;
    case 0x00198B84U:
        goto block_00198B84;
    case 0x00198B9CU:
        goto block_00198B9C;
    case 0x00198BACU:
        goto block_00198BAC;
    case 0x00198BB8U:
        goto block_00198BB8;
    case 0x00198BE0U:
        goto block_00198BE0;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0019846C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019846CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019846CU);
        }
        {
            const uint32_t firstAddress = r13 - 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0019846CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0019846CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0019846CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0019846CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0019846CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0019846CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0019846CU,
                                           firstAddress + 24U);
            }
            r13 = r13 - 28U;
        }
        {
            r4 = r0;
        }
        {
            r7 = r1;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00198480U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00198480U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00198480U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00198480U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000054U;
            r13 = r13 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019848CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019848CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019848C;
    }
block_0019848C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019848CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019848CU);
        }
        {
            r9 = r0;
        }
        {
            const uint32_t updatedAddress = 0x00198498U + 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198490U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000148U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + r7;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198498U, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001984A4U;
            const Oot3dWholeAotFlow callFlow = Oot3dAotCallExternal(context, 0x00372224U, frame, state, commitState, reloadState);
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001984A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001984A4;
    }
block_001984A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001984A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001984A4U);
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001984ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001984ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001984AC;
    }
block_001984AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001984ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001984ACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001984ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000A00U;
            r6 = r4 + operand;
        }
        {
            const uint32_t address = 0x001984BCU + 944U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001984B4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001984BCU, address);
            }
        }
        {
            r0 = 0x00000014U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001984C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x98U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001984C8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000800U;
            r5 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x001984DCU + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001984D4U, address);
            }
            switch (value) {
            case 0x0019846CU:
                goto block_0019846C;
            case 0x0019848CU:
                goto block_0019848C;
            case 0x001984A4U:
                goto block_001984A4;
            case 0x001984ACU:
                goto block_001984AC;
            case 0x001984D8U:
                goto block_001984D8;
            case 0x0019850CU:
                goto block_0019850C;
            case 0x0019851CU:
                goto block_0019851C;
            case 0x00198528U:
                goto block_00198528;
            case 0x0019853CU:
                goto block_0019853C;
            case 0x0019854CU:
                goto block_0019854C;
            case 0x0019855CU:
                goto block_0019855C;
            case 0x001985A4U:
                goto block_001985A4;
            case 0x001985B0U:
                goto block_001985B0;
            case 0x001985D0U:
                goto block_001985D0;
            case 0x001985E0U:
                goto block_001985E0;
            case 0x001985F0U:
                goto block_001985F0;
            case 0x0019861CU:
                goto block_0019861C;
            case 0x00198640U:
                goto block_00198640;
            case 0x00198664U:
                goto block_00198664;
            case 0x0019867CU:
                goto block_0019867C;
            case 0x0019869CU:
                goto block_0019869C;
            case 0x001986B4U:
                goto block_001986B4;
            case 0x001986C8U:
                goto block_001986C8;
            case 0x001986E0U:
                goto block_001986E0;
            case 0x001986ECU:
                goto block_001986EC;
            case 0x00198700U:
                goto block_00198700;
            case 0x00198718U:
                goto block_00198718;
            case 0x00198790U:
                goto block_00198790;
            case 0x001987A8U:
                goto block_001987A8;
            case 0x001987B4U:
                goto block_001987B4;
            case 0x001987C4U:
                goto block_001987C4;
            case 0x001987D0U:
                goto block_001987D0;
            case 0x001987DCU:
                goto block_001987DC;
            case 0x001987E8U:
                goto block_001987E8;
            case 0x001987F4U:
                goto block_001987F4;
            case 0x00198834U:
                goto block_00198834;
            case 0x0019884CU:
                goto block_0019884C;
            case 0x0019885CU:
                goto block_0019885C;
            case 0x001988CCU:
                goto block_001988CC;
            case 0x001988E4U:
                goto block_001988E4;
            case 0x001988F4U:
                goto block_001988F4;
            case 0x00198900U:
                goto block_00198900;
            case 0x00198914U:
                goto block_00198914;
            case 0x00198924U:
                goto block_00198924;
            case 0x00198944U:
                goto block_00198944;
            case 0x0019894CU:
                goto block_0019894C;
            case 0x001989E0U:
                goto block_001989E0;
            case 0x001989ECU:
                goto block_001989EC;
            case 0x00198A34U:
                goto block_00198A34;
            case 0x00198A4CU:
                goto block_00198A4C;
            case 0x00198A5CU:
                goto block_00198A5C;
            case 0x00198A68U:
                goto block_00198A68;
            case 0x00198A7CU:
                goto block_00198A7C;
            case 0x00198A88U:
                goto block_00198A88;
            case 0x00198A90U:
                goto block_00198A90;
            case 0x00198A98U:
                goto block_00198A98;
            case 0x00198AACU:
                goto block_00198AAC;
            case 0x00198AC0U:
                goto block_00198AC0;
            case 0x00198AD0U:
                goto block_00198AD0;
            case 0x00198ADCU:
                goto block_00198ADC;
            case 0x00198AE8U:
                goto block_00198AE8;
            case 0x00198B00U:
                goto block_00198B00;
            case 0x00198B10U:
                goto block_00198B10;
            case 0x00198B1CU:
                goto block_00198B1C;
            case 0x00198B2CU:
                goto block_00198B2C;
            case 0x00198B38U:
                goto block_00198B38;
            case 0x00198B48U:
                goto block_00198B48;
            case 0x00198B54U:
                goto block_00198B54;
            case 0x00198B6CU:
                goto block_00198B6C;
            case 0x00198B78U:
                goto block_00198B78;
            case 0x00198B84U:
                goto block_00198B84;
            case 0x00198B9CU:
                goto block_00198B9C;
            case 0x00198BACU:
                goto block_00198BAC;
            case 0x00198BB8U:
                goto block_00198BB8;
            case 0x00198BE0U:
                goto block_00198BE0;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_001984D8;
    }
block_001984D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001984D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001984D8U);
        }
        goto block_00198A5C;
    }
block_0019850C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019850CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019850CU);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019851CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019851CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019851C;
    }
block_0019851C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019851CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019851CU);
        }
        {
            r0 = r7;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198528U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198528U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198528;
    }
block_00198528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198528U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198528U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019853CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019853CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019853C;
    }
block_0019853C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019853CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019853CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019853CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019854CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019854CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019854C;
    }
block_0019854C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019854CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019854CU);
        }
        {
            r2 = 0x00000008U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019855CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019855CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019855C;
    }
block_0019855C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019855CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019855CU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r9 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198564U, address);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00198568U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00198568U,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00198568U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000080U;
            r1 = r9 + operand;
        }
        {
            const uint32_t address = 0x0019857CU + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198574U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00198578U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00198578U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00198578U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00198580U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00198580U,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00198580U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00198588U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00198588U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00198588U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = 0x00198594U + 0x2DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019858CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198590U, address);
            }
        }
        {
            r0 = 0x00000096U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198598U, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001985A0U, address);
            }
        }
        goto block_001985A4;
    }
block_001985A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001985A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001985A4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x9CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001985A4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001985D0; }
        goto block_001985B0;
    }
block_001985B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001985B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001985B0U);
        }
        {
            const uint32_t updatedAddress = 0x001985B8U + 0x2C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001985B0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x001985BCU + 0x2C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001985B4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x001985C0U + 0x2C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001985B8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001985C0U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001985D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001985D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001985D0;
    }
block_001985D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001985D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001985D0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x001985DCU + 680U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001985D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001985E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001985E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001985E0;
    }
block_001985E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001985E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001985E0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x001985ECU + 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001985E4U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            r0 = r4;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x001985F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001985F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001985F0;
    }
block_001985F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001985F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001985F0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001985F0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001985FCU + 656U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001985F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198604U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198608U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00198614U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019860CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00198618U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198610U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198614U, 0xEE010A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019861CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Matrix_RotateY_003735E8(frame, context, state, 0x003735E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019861CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019861C;
    }
block_0019861C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019861CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019861CU);
        }
        {
            const uint32_t address = 0x00198624U + 592U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019861CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000048U;
            r2 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00198624U, address);
            }
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00198628U, address);
            }
        }
        {
            const uint32_t address = 0x00198634U + 612U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019862CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00198634U, address);
            }
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198640U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198640U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198640;
    }
block_00198640:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198640U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198640U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198640U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198644U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00198650U + 588U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198648U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x00198654U + 588U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019864CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198650U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198664U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198664U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198664;
    }
block_00198664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198664U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x00198678U + 556U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198670U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000002A4U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019867CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019867CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019867C;
    }
block_0019867C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019867CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019867CU);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019867CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198680U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019868CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x000002A8U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019869CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019869CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019869C;
    }
block_0019869C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019869CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019869CU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r5 + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001986A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001986B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001986B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001986B4;
    }
block_001986B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001986B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001986B4U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r5 + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001986BCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000AB0U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001986C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001986C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001986C8;
    }
block_001986C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001986C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001986C8U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r5 + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001986D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000002B4U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001986E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001986E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001986E0;
    }
block_001986E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001986E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001986E0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x9CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001986E0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00198A5C; }
        goto block_001986EC;
    }
block_001986EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001986ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001986ECU);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001986F0U, address);
            }
        }
        {
            r0 = 0x00000087U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001986F8U, address);
            }
        }
        goto block_00198A5C;
    }
block_00198700:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198700U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198700U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0019870CU + 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198704U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00198710U + 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198708U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198718U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198718U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198718;
    }
block_00198718:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198718U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198718U);
        }
        {
            const uint32_t updatedAddress = 0x00198720U + 0x150U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198718U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00198724U + 376U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019871CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00198728U + 400U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198720U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198724U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00198730U + 0x180U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198728U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019872CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198730U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198734U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00198738U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019873CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00198748U + 364U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198740U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198744U, 0xEE700A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00198748U, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019874CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198750U, 0xEE700A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198754U, 0xEE700AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00198758U, address);
            }
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019875CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00198760U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198764U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198768U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00198774U + 328U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019876CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00198770U, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198774U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000A20U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019877CU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00198788U + 312U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198780U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00198784U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198790U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198790U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198790;
    }
block_00198790:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198790U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198790U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t address = 0x001987A4U + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019879CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001987A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001987A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001987A8;
    }
block_001987A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001987A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001987A8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x9CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001987A8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000078U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001987C4; }
        goto block_001987B4;
    }
block_001987B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001987B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001987B4U);
        }
        {
            const uint32_t updatedAddress = 0x001987BCU + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001987B4U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001987C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001987C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001987C4;
    }
block_001987C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001987C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001987C4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x9CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001987C4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_00198A5C; }
        goto block_001987D0;
    }
block_001987D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001987D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001987D0U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001987DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001987DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001987DC;
    }
block_001987DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001987DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001987DCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00198A5C; }
        goto block_001987E8;
    }
block_001987E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001987E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001987E8U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001987F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001987F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001987F4;
    }
block_001987F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001987F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001987F4U);
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r8 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001987FCU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001987FCU,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001987FCU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r9 = value9;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00198800U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00198800U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00198800U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r8 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00198808U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00198808U,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00198808U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r9 = value9;
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00198818U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00198818U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00198818U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019881CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019881CU,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0019881CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00198820U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00198820U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00198820U,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198828U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198834U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198834U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198834;
    }
block_00198834:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198834U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198834U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019883CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019884CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019884CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019884C;
    }
block_0019884C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019884CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019884CU);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019885CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019885CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019885C;
    }
block_0019885C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019885CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019885CU);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198860U, address);
            }
        }
        goto block_00198A5C;
    }
block_001988CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001988CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001988CCU);
        }
        {
            r2 = ~(0x00000000U);
        }
        {
            const uint32_t address = 0x001988D8U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001988D0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001988DCU + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001988D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001988E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001988E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001988E4;
    }
block_001988E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001988E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001988E4U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001988F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001988F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001988F4;
    }
block_001988F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001988F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001988F4U);
        }
        {
            r0 = r7;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198900U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198900U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198900;
    }
block_00198900:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198900U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198900U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198900U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198914U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198914U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198914;
    }
block_00198914:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198914U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198914U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198914U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198924U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198924U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198924;
    }
block_00198924:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198924U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198924U);
        }
        {
            r0 = 0x0000000BU;
        }
        {
            const uint32_t updatedAddress = r6 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198928U, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198930U, address);
            }
        }
        {
            r2 = 0x00000060U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198944U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198944U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198944;
    }
block_00198944:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198944U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198944U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198948U, address);
            }
        }
        goto block_0019894C;
    }
block_0019894C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019894CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019894CU);
        }
        {
            const uint32_t updatedAddress = 0x00198954U - 0xA4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019894CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00198958U - 160U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198950U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0019895CU + 664U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198954U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198958U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019895CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198960U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00198964U, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198968U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r0 = 0x00008000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198970U, 0xEE711AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x00198974U, address);
            }
        }
        {
            const uint32_t address = 0x00198980U - 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198978U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019897CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198980U, 0xEE300A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0019898CU + 620U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198984U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198988U, 0xEE300A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00198994U + 616U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019898CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00198990U, address);
            }
        }
        {
            const uint32_t address = r8 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198994U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198998U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019899CU, 0xEE300A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x001989A8U + 600U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001989A0U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001989A4U, address);
            }
        }
        {
            const uint32_t address = r8 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001989A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001989ACU, 0xEE300A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001989B0U, address);
            }
        }
        {
            const uint32_t address = r8 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001989B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001989B8U, address);
            }
        }
        {
            const uint32_t address = r8 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001989BCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001989C0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001989C4U, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001989C8U, address);
            }
        }
        {
            const uint32_t address = r8 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001989CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001989D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001989D4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000078U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00198A5C; }
        goto block_001989E0;
    }
block_001989E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001989E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001989E0U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001989ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001989ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001989EC;
    }
block_001989EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001989ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001989ECU);
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r8 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001989F4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001989F4U,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001989F4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r9 = value9;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001989F8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001989F8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001989F8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r8 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00198A00U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00198A00U,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00198A00U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r9 = value9;
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00198A10U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00198A10U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00198A10U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00198A14U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00198A14U,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00198A14U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00198A18U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00198A18U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00198A18U,
                                           firstAddress + 8U);
            }
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198A20U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198A24U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198A34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198A34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198A34;
    }
block_00198A34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198A34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198A34U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198A3CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198A4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198A4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198A4C;
    }
block_00198A4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198A4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198A4CU);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198A5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198A5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198A5C;
    }
block_00198A5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198A5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198A5CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198A5CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00198A7C; }
        goto block_00198A68;
    }
block_00198A68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198A68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198A68U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r2 = r2 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198A7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CameraSetAtEye_00367B14(frame, context, state, 0x00367B14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198A7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198A7C;
    }
block_00198A7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198A7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198A7CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198A7CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00198B1C; }
        goto block_00198A88;
    }
block_00198A88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198A88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198A88U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_00198B54; }
        goto block_00198A90;
    }
block_00198A90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198A90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198A90U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00198B00; }
        goto block_00198A98;
    }
block_00198A98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198A98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198A98U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x00198AA4U - 488U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198A9CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x00198AA8U + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198AA0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000A20U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198AACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198AACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198AAC;
    }
block_00198AAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198AACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198AACU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t address = 0x00198ABCU + 332U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198AB4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198AC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198AC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198AC0;
    }
block_00198AC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198AC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198AC0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r5 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198AC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198AD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198AD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198AD0;
    }
block_00198AD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198AD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198AD0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00198B00; }
        goto block_00198ADC;
    }
block_00198ADC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198ADCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198ADCU);
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198AE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0036fadc_0036FADC(frame, context, state, 0x0036FADCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198AE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198AE8;
    }
block_00198AE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198AE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198AE8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA30U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198AE8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000019U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xB7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198AF4U, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198AFCU, address);
            }
        }
        goto block_00198B00;
    }
block_00198B00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198B00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198B00U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x00198B0CU + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198B04U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000006CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198B10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198B10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198B10;
    }
block_00198B10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198B10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198B10U);
        }
        {
            const uint32_t operand = 0x00000054U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00198B14U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00198B14U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00198B14U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00198B14U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00198B18U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00198B18U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00198B18U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00198B18U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00198B18U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00198B18U,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00198B18U,
                                           firstAddress + 24U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
block_00198B1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198B1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198B1CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r5 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198B20U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198B2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198B2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198B2C;
    }
block_00198B2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198B2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198B2CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00198B00; }
        goto block_00198B38;
    }
block_00198B38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198B38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198B38U);
        }
        {
            r1 = 0x00000013U;
        }
        {
            const uint32_t address = 0x00198B44U - 720U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198B3CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198B48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198B48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198B48;
    }
block_00198B48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198B48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198B48U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198B4CU, address);
            }
        }
        goto block_00198B00;
    }
block_00198B54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198B54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198B54U);
        }
        {
            const uint32_t updatedAddress = 0x00198B5CU + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198B54U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r7;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198B58U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x0000001FU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x00198B68U + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198B60U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x00198B6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198B6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198B6C;
    }
block_00198B6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198B6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198B6CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198B6CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00198B84; }
        goto block_00198B78;
    }
block_00198B78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198B78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198B78U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA30U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198B78U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00198B00; }
        goto block_00198B84;
    }
block_00198B84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198B84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198B84U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r0 + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198B88U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x00198B94U + 0x84U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198B8CU, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00198B00; }
        goto block_00198B9C;
    }
block_00198B9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198B9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198B9CU);
        }
        {
            r1 = 0x00000008U;
        }
        {
            const uint32_t address = 0x00198BA8U - 820U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198BA0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198BACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198BACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198BAC;
    }
block_00198BAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198BACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198BACU);
        }
        {
            r1 = 0x00000008U;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198BB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198BB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198BB8;
    }
block_00198BB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198BB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198BB8U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = 0x00198BC8U + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00198BC0U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00198BC4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 140U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00198BC8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198BCCU, address);
            }
        }
        {
            r0 = 0x0000003CU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00198BD4U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00198BE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00198BE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00198BE0;
    }
block_00198BE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00198BE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00198BE0U);
        }
        {
        }
        {
        }
        goto block_00198B00;
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_direct_target_00316D74_00316D74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00316D74U:
        goto block_00316D74;
    case 0x002D01D0U:
        goto block_002D01D0;
    case 0x002D01E0U:
        goto block_002D01E0;
    case 0x002D01E8U:
        goto block_002D01E8;
    case 0x002D021CU:
        goto block_002D021C;
    case 0x002D0238U:
        goto block_002D0238;
    case 0x002D0244U:
        goto block_002D0244;
    case 0x00316D98U:
        goto block_00316D98;
    case 0x00316DB4U:
        goto block_00316DB4;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002D01D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D01D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D01D0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            r1 = 0x00000005U;
        }
        if (flags.Z()) {
            r0 = 0x0000007FU;
        }
        if (flags.Z()) { goto block_002D01E8; }
        goto block_002D01E0;
    }
block_002D01E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D01E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D01E0U);
        }
        if (!(flags.Z())) {
            r0 = 0x00000000U;
        }
        {
            r0 = r0;
        }
        goto block_002D01E8;
    }
block_002D01E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D01E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D01E8U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x002D01F4U + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D01ECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002D01F0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x002D01F0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002D01F0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002D01F0U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            r6 = r1;
        }
        {
            const uint32_t updatedAddress = 0x002D0200U + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D01F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x002D0204U + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D01FCU, address);
            }
            r5 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002D0200U, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x002D0204U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x002D0204U,
                                           firstAddress + 4U);
            }
        }
        {
            r4 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002D020CU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002D0210U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D0214U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002D0218U, 0xEE208A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        goto block_002D021C;
    }
block_002D021C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D021CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D021CU);
        }
        {
            const uint32_t updatedAddress = r5 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D021CU, address);
            }
            r0 = value;
        }
        {
            r1 = r6;
        }
        {
            const uint32_t operand = 0x00000000U;
            Oot3dAotSetAddFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r2 = r0 + operand;
        }
        if (!(flags.Z())) {
            r2 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x002D0238U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d4a10_002D4A10(frame, context, state, 0x002D4A10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002D0238U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002D0238;
    }
block_002D0238:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D0238U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D0238U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000010U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_002D021C; }
        goto block_002D0244;
    }
block_002D0244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D0244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D0244U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002D0244U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002D0244U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002D0248U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002D0248U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002D0248U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002D0248U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_00316D74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00316D74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00316D74U);
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000001FU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r0 + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00316D7CU, address);
            }
            r2 = value;
        }
        if (flags.Z()) {
            r1 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r2 = 0x00000000U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x234U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00316D8CU, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x237U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00316D90U, address);
            }
        }
        if (!(flags.Z())) { goto block_00316DB4; }
        goto block_00316D98;
    }
block_00316D98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00316D98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00316D98U);
        }
        {
            const uint32_t updatedAddress = 0x00316DA0U + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00316D98U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1B2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00316D9CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00316DA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1B1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00316DA4U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x1B1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00316DACU, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x1B2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00316DB0U, address);
            }
        }
        goto block_00316DB4;
    }
block_00316DB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00316DB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00316DB4U);
        }
        {
            r0 = 0x00000001U;
        }
        goto block_002D01D0;
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_CutsceneContext_StartUnskippable_00367374(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00367374U:
        goto block_00367374;
    case 0x00367384U:
        goto block_00367384;
    case 0x003673A4U:
        goto block_003673A4;
    case 0x003673ACU:
        goto block_003673AC;
    case 0x003673BCU:
        goto block_003673BC;
    case 0x003673C0U:
        goto block_003673C0;
    case 0x003673C8U:
        goto block_003673C8;
    case 0x003673D0U:
        goto block_003673D0;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00367374:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367374U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367374U);
        }
        {
            const uint32_t firstAddress = r13 - 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00367374U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00367374U,
                                           firstAddress + 4U);
            }
            r13 = r13 - 8U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367378U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003673D0; }
        goto block_00367384;
    }
block_00367384:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367384U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367384U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r4 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r4 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036738CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00367394U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367398U, address);
            }
            r1 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003673A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003673A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003673A4;
    }
block_003673A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003673A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003673A4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003673C8; }
        goto block_003673AC;
    }
block_003673AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003673ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003673ACU);
        }
        {
            const uint32_t updatedAddress = 0x003673B4U + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003673ACU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003673B0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000025U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003673C8; }
        goto block_003673BC;
    }
block_003673BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003673BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003673BCU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003673C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_byte_1b6_00367C48(frame, context, state, 0x00367C48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003673C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003673C0;
    }
block_003673C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003673C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003673C0U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003673C4U, address);
            }
        }
        goto block_003673C8;
    }
block_003673C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003673C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003673C8U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003673CCU, address);
            }
        }
        goto block_003673D0;
    }
block_003673D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003673D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003673D0U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003673D0U,
                                           firstAddress + 0U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003673D0U,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r13 = r13 + 8U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_CutsceneContext_StartSkippable_00367494(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r12 = state.R[12];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00367494U:
        goto block_00367494;
    case 0x003674B8U:
        goto block_003674B8;
    case 0x003674DCU:
        goto block_003674DC;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00367494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367494U);
        }
        {
            const uint32_t updatedAddress = 0x0036749CU + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367494U, address);
            }
            r2 = value;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r2 + r0;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0036749CU, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003674A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003674ACU, address);
            }
        }
        {
            r2 = r3;
        }
        {
            r0 = r3;
        }
        goto block_003674B8;
    }
block_003674B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003674B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003674B8U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r12 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003674C0U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r12 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000010U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003674D4U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_003674B8; }
        goto block_003674DC;
    }
block_003674DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003674DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003674DCU);
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_oot3d_set_byte_1b6_00367C48(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r6 = state.R[6];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00367C48U:
        goto block_00367C48;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00367C48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367C48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367C48U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1B6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00367C4CU, address);
            }
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Gameplay_CreateSubCamera_00367D74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00367D74U:
        goto block_00367D74;
    case 0x00367D88U:
        goto block_00367D88;
    case 0x00367D98U:
        goto block_00367D98;
    case 0x00367DA4U:
        goto block_00367DA4;
    case 0x00367DA8U:
        goto block_00367DA8;
    case 0x00367DD8U:
        goto block_00367DD8;
    case 0x00367DECU:
        goto block_00367DEC;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00367D74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367D74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367D74U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00367D74U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00367D74U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00367D74U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00367D74U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367D78U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r4 = 0x00000001U;
        }
        if (flags.Z()) { goto block_00367DA8; }
        goto block_00367D88;
    }
block_00367D88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367D88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367D88U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xA5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367D88U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r4 = 0x00000002U;
        }
        if (flags.Z()) { goto block_00367DA8; }
        goto block_00367D98;
    }
block_00367D98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367D98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367D98U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xA60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367D98U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00367DEC; }
        goto block_00367DA4;
    }
block_00367DA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367DA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367DA4U);
        }
        {
            r4 = 0x00000003U;
        }
        goto block_00367DA8;
    }
block_00367DA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367DA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367DA8U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 4U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 7U);
            r1 = operand - r1;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r5 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000364U;
            r12 = r1 + operand;
        }
        {
            r3 = r0;
        }
        {
            const uint32_t operand = 0x00000188U;
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r2 = r2 + operand;
        }
        {
            r0 = r12;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x00367DD0U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00367DD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_Init_002E5724(frame, context, state, 0x002E5724U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00367DD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00367DD8;
    }
block_00367DD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367DD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367DD8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367DD8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xACU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00367DE0U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00367DE8U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00367DE8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00367DE8U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00367DE8U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_00367DEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367DECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367DECU);
        }
        {
            r0 = ~(0x00000000U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00367DF0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00367DF0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00367DF0U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00367DF0U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0036E9B8U:
        goto block_0036E9B8;
    case 0x0036E9ECU:
        goto block_0036E9EC;
    case 0x0036E9F4U:
        goto block_0036E9F4;
    case 0x0036E9F8U:
        goto block_0036E9F8;
    case 0x0036E9FCU:
        goto block_0036E9FC;
    case 0x0036EA0CU:
        goto block_0036EA0C;
    case 0x0036EA28U:
        goto block_0036EA28;
    case 0x0036EA30U:
        goto block_0036EA30;
    case 0x0036EA34U:
        goto block_0036EA34;
    case 0x0036EA44U:
        goto block_0036EA44;
    case 0x0036EA4CU:
        goto block_0036EA4C;
    case 0x0036EA60U:
        goto block_0036EA60;
    case 0x0036EA7CU:
        goto block_0036EA7C;
    case 0x0036EA94U:
        goto block_0036EA94;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0036E9B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E9B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E9B8U);
        }
        {
            const uint32_t firstAddress = r13 - 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0036E9B8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0036E9B8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0036E9B8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0036E9B8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0036E9B8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0036E9B8U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0036E9B8U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0036E9B8U,
                                           firstAddress + 28U);
            }
            r13 = r13 - 32U;
        }
        {
            Oot3dAotSetAddFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x00000A00U;
            r7 = r0 + operand;
        }
        {
            r6 = r0;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036E9C8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r9 = r2;
        }
        {
            r8 = 0x00000000U;
        }
        {
            Oot3dAotSetAddFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036E9D8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r4 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036E9E0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0036E9F8; }
        goto block_0036E9EC;
    }
block_0036E9EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E9ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E9ECU);
        }
        {
            r1 = 0x00000100U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0036E9F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_ChangeStatus_00320DA0(frame, context, state, 0x00320DA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0036E9F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0036E9F4;
    }
block_0036E9F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E9F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E9F4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0036E9F4U, address);
            }
        }
        goto block_0036E9F8;
    }
block_0036E9F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E9F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E9F8U);
        }
        {
            r4 = 0x00000001U;
        }
        goto block_0036E9FC;
    }
block_0036E9FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E9FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E9FCU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036EA00U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0036EA34; }
        goto block_0036EA0C;
    }
block_0036EA0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036EA0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036EA0CU);
        }
        {
            Oot3dAotSetAddFlags(flags, r4, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036EA10U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (!(flags.Z())) {
            r0 = r4;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r5 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036EA1CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0036EA34; }
        goto block_0036EA28;
    }
block_0036EA28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036EA28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036EA28U);
        }
        {
            r1 = 0x00000100U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0036EA30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_ChangeStatus_00320DA0(frame, context, state, 0x00320DA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0036EA30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0036EA30;
    }
block_0036EA30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036EA30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036EA30U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0036EA30U, address);
            }
        }
        goto block_0036EA34;
    }
block_0036EA34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036EA34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036EA34U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0036E9FC; }
        goto block_0036EA44;
    }
block_0036EA44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036EA44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036EA44U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0036EA7C; }
        goto block_0036EA4C;
    }
block_0036EA4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036EA4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036EA4CU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0036EA50U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xA54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036EA54U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000007U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0036EA60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_ChangeStatus_00320DA0(frame, context, state, 0x00320DA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0036EA60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0036EA60;
    }
block_0036EA60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036EA60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036EA60U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xA54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036EA60U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xAAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0036EA68U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xA54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036EA6CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x96U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0036EA74U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0036EA78U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0036EA78U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0036EA78U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0036EA78U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0036EA78U,
                                           firstAddress + 16U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0036EA78U,
                                           firstAddress + 20U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0036EA78U,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0036EA78U,
                                           firstAddress + 28U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
block_0036EA7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036EA7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036EA7CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = r9;
        }
        {
            r1 = 0x000003FCU;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0036EA8CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0036EA94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OnePointCutscene_Init_00371808(frame, context, state, 0x00371808U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0036EA94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0036EA94;
    }
block_0036EA94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036EA94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036EA94U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0036EA94U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0036EA94U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0036EA94U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0036EA94U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0036EA94U,
                                           firstAddress + 16U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0036EA94U,
                                           firstAddress + 20U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0036EA94U,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0036EA94U,
                                           firstAddress + 28U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_BossVa_BodyIntro_00394E8C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00394E8CU:
        goto block_00394E8C;
    case 0x00394EC4U:
        goto block_00394EC4;
    case 0x00394EE4U:
        goto block_00394EE4;
    case 0x00394F04U:
        goto block_00394F04;
    case 0x00394F54U:
        goto block_00394F54;
    case 0x00394F64U:
        goto block_00394F64;
    case 0x00394F7CU:
        goto block_00394F7C;
    case 0x00394FACU:
        goto block_00394FAC;
    case 0x00394FF8U:
        goto block_00394FF8;
    case 0x00395008U:
        goto block_00395008;
    case 0x00395018U:
        goto block_00395018;
    case 0x00395020U:
        goto block_00395020;
    case 0x00395024U:
        goto block_00395024;
    case 0x00395034U:
        goto block_00395034;
    case 0x00395044U:
        goto block_00395044;
    case 0x003950D0U:
        goto block_003950D0;
    case 0x003950E0U:
        goto block_003950E0;
    case 0x003950F0U:
        goto block_003950F0;
    case 0x0039510CU:
        goto block_0039510C;
    case 0x0039512CU:
        goto block_0039512C;
    case 0x00395144U:
        goto block_00395144;
    case 0x00395150U:
        goto block_00395150;
    case 0x0039515CU:
        goto block_0039515C;
    case 0x0039516CU:
        goto block_0039516C;
    case 0x00395180U:
        goto block_00395180;
    case 0x00395190U:
        goto block_00395190;
    case 0x003951A0U:
        goto block_003951A0;
    case 0x003951A8U:
        goto block_003951A8;
    case 0x003951ACU:
        goto block_003951AC;
    case 0x003951BCU:
        goto block_003951BC;
    case 0x003951CCU:
        goto block_003951CC;
    case 0x00395254U:
        goto block_00395254;
    case 0x003952DCU:
        goto block_003952DC;
    case 0x00395314U:
        goto block_00395314;
    case 0x00395320U:
        goto block_00395320;
    case 0x00395338U:
        goto block_00395338;
    case 0x00395388U:
        goto block_00395388;
    case 0x003953B4U:
        goto block_003953B4;
    case 0x003953CCU:
        goto block_003953CC;
    case 0x00395438U:
        goto block_00395438;
    case 0x0039546CU:
        goto block_0039546C;
    case 0x00395498U:
        goto block_00395498;
    case 0x003954ACU:
        goto block_003954AC;
    case 0x003954B4U:
        goto block_003954B4;
    case 0x003954C4U:
        goto block_003954C4;
    case 0x0039550CU:
        goto block_0039550C;
    case 0x00395514U:
        goto block_00395514;
    case 0x0039552CU:
        goto block_0039552C;
    case 0x00395570U:
        goto block_00395570;
    case 0x00395594U:
        goto block_00395594;
    case 0x003955ACU:
        goto block_003955AC;
    case 0x003955C0U:
        goto block_003955C0;
    case 0x003955C8U:
        goto block_003955C8;
    case 0x003955D4U:
        goto block_003955D4;
    case 0x00395688U:
        goto block_00395688;
    case 0x00395690U:
        goto block_00395690;
    case 0x003956C0U:
        goto block_003956C0;
    case 0x003956D0U:
        goto block_003956D0;
    case 0x003956DCU:
        goto block_003956DC;
    case 0x003956FCU:
        goto block_003956FC;
    case 0x00395714U:
        goto block_00395714;
    case 0x0039573CU:
        goto block_0039573C;
    case 0x00395758U:
        goto block_00395758;
    case 0x00395764U:
        goto block_00395764;
    case 0x00395770U:
        goto block_00395770;
    case 0x00395780U:
        goto block_00395780;
    case 0x0039578CU:
        goto block_0039578C;
    case 0x00395798U:
        goto block_00395798;
    case 0x0039579CU:
        goto block_0039579C;
    case 0x003957A8U:
        goto block_003957A8;
    case 0x003957B8U:
        goto block_003957B8;
    case 0x003957C0U:
        goto block_003957C0;
    case 0x003957CCU:
        goto block_003957CC;
    case 0x003957D4U:
        goto block_003957D4;
    case 0x003957ECU:
        goto block_003957EC;
    case 0x003957FCU:
        goto block_003957FC;
    case 0x00395814U:
        goto block_00395814;
    case 0x0039586CU:
        goto block_0039586C;
    case 0x00395898U:
        goto block_00395898;
    case 0x003958A0U:
        goto block_003958A0;
    case 0x003958B8U:
        goto block_003958B8;
    case 0x003958C0U:
        goto block_003958C0;
    case 0x003958DCU:
        goto block_003958DC;
    case 0x003958F4U:
        goto block_003958F4;
    case 0x00395904U:
        goto block_00395904;
    case 0x00395914U:
        goto block_00395914;
    case 0x0039592CU:
        goto block_0039592C;
    case 0x00395958U:
        goto block_00395958;
    case 0x00395968U:
        goto block_00395968;
    case 0x00395980U:
        goto block_00395980;
    case 0x00395990U:
        goto block_00395990;
    case 0x003959A0U:
        goto block_003959A0;
    case 0x003959B8U:
        goto block_003959B8;
    case 0x003959C8U:
        goto block_003959C8;
    case 0x003959D8U:
        goto block_003959D8;
    case 0x00395A50U:
        goto block_00395A50;
    case 0x00395A68U:
        goto block_00395A68;
    case 0x00395A70U:
        goto block_00395A70;
    case 0x00395A7CU:
        goto block_00395A7C;
    case 0x00395A8CU:
        goto block_00395A8C;
    case 0x00395A98U:
        goto block_00395A98;
    case 0x00395ABCU:
        goto block_00395ABC;
    case 0x00395AECU:
        goto block_00395AEC;
    case 0x00395AFCU:
        goto block_00395AFC;
    case 0x00395B0CU:
        goto block_00395B0C;
    case 0x00395B24U:
        goto block_00395B24;
    case 0x00395B50U:
        goto block_00395B50;
    case 0x00395B5CU:
        goto block_00395B5C;
    case 0x00395B84U:
        goto block_00395B84;
    case 0x00395BA0U:
        goto block_00395BA0;
    case 0x00395BB8U:
        goto block_00395BB8;
    case 0x00395BD8U:
        goto block_00395BD8;
    case 0x00395BF4U:
        goto block_00395BF4;
    case 0x00395C0CU:
        goto block_00395C0C;
    case 0x00395C2CU:
        goto block_00395C2C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00394E8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00394E8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00394E8CU);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00394E8CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00394E8CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00394E8CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00394E8CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00394E8CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00394E8CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00394E8CU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00394E8CU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00394E8CU,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r8 = r1;
        }
        {
            const uint32_t operand = 0x00000F00U;
            r9 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00394EA4U + 0x3F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394E9CU, address);
            }
            r0 = value;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00394EA0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00394EA0U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394EA8U, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394EACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000031U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0xB0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00394EBCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00394EC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00394EC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00394EC4;
    }
block_00394EC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00394EC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00394EC4U);
        }
        {
            const uint32_t address = 0x00394ECCU + 984U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394EC4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x00394ED0U + 976U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394EC8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r6 = r4 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00394ED4U, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 932U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00394ED8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394EDCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00394EE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00394EE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00394EE4;
    }
block_00394EE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00394EE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00394EE4U);
        }
        {
            const uint32_t address = 0x00394EECU + 956U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394EE4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x00394EF0U + 0x3BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394EE8U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00394EECU, 0xEE008A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 936U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00394EF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394EF4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            const uint32_t operand = 0x00000005U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x00394F08U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394F00U, address);
            }
            switch (value) {
            case 0x00394E8CU:
                goto block_00394E8C;
            case 0x00394EC4U:
                goto block_00394EC4;
            case 0x00394EE4U:
                goto block_00394EE4;
            case 0x00394F04U:
                goto block_00394F04;
            case 0x00394F54U:
                goto block_00394F54;
            case 0x00394F64U:
                goto block_00394F64;
            case 0x00394F7CU:
                goto block_00394F7C;
            case 0x00394FACU:
                goto block_00394FAC;
            case 0x00394FF8U:
                goto block_00394FF8;
            case 0x00395008U:
                goto block_00395008;
            case 0x00395018U:
                goto block_00395018;
            case 0x00395020U:
                goto block_00395020;
            case 0x00395024U:
                goto block_00395024;
            case 0x00395034U:
                goto block_00395034;
            case 0x00395044U:
                goto block_00395044;
            case 0x003950D0U:
                goto block_003950D0;
            case 0x003950E0U:
                goto block_003950E0;
            case 0x003950F0U:
                goto block_003950F0;
            case 0x0039510CU:
                goto block_0039510C;
            case 0x0039512CU:
                goto block_0039512C;
            case 0x00395144U:
                goto block_00395144;
            case 0x00395150U:
                goto block_00395150;
            case 0x0039515CU:
                goto block_0039515C;
            case 0x0039516CU:
                goto block_0039516C;
            case 0x00395180U:
                goto block_00395180;
            case 0x00395190U:
                goto block_00395190;
            case 0x003951A0U:
                goto block_003951A0;
            case 0x003951A8U:
                goto block_003951A8;
            case 0x003951ACU:
                goto block_003951AC;
            case 0x003951BCU:
                goto block_003951BC;
            case 0x003951CCU:
                goto block_003951CC;
            case 0x00395254U:
                goto block_00395254;
            case 0x003952DCU:
                goto block_003952DC;
            case 0x00395314U:
                goto block_00395314;
            case 0x00395320U:
                goto block_00395320;
            case 0x00395338U:
                goto block_00395338;
            case 0x00395388U:
                goto block_00395388;
            case 0x003953B4U:
                goto block_003953B4;
            case 0x003953CCU:
                goto block_003953CC;
            case 0x00395438U:
                goto block_00395438;
            case 0x0039546CU:
                goto block_0039546C;
            case 0x00395498U:
                goto block_00395498;
            case 0x003954ACU:
                goto block_003954AC;
            case 0x003954B4U:
                goto block_003954B4;
            case 0x003954C4U:
                goto block_003954C4;
            case 0x0039550CU:
                goto block_0039550C;
            case 0x00395514U:
                goto block_00395514;
            case 0x0039552CU:
                goto block_0039552C;
            case 0x00395570U:
                goto block_00395570;
            case 0x00395594U:
                goto block_00395594;
            case 0x003955ACU:
                goto block_003955AC;
            case 0x003955C0U:
                goto block_003955C0;
            case 0x003955C8U:
                goto block_003955C8;
            case 0x003955D4U:
                goto block_003955D4;
            case 0x00395688U:
                goto block_00395688;
            case 0x00395690U:
                goto block_00395690;
            case 0x003956C0U:
                goto block_003956C0;
            case 0x003956D0U:
                goto block_003956D0;
            case 0x003956DCU:
                goto block_003956DC;
            case 0x003956FCU:
                goto block_003956FC;
            case 0x00395714U:
                goto block_00395714;
            case 0x0039573CU:
                goto block_0039573C;
            case 0x00395758U:
                goto block_00395758;
            case 0x00395764U:
                goto block_00395764;
            case 0x00395770U:
                goto block_00395770;
            case 0x00395780U:
                goto block_00395780;
            case 0x0039578CU:
                goto block_0039578C;
            case 0x00395798U:
                goto block_00395798;
            case 0x0039579CU:
                goto block_0039579C;
            case 0x003957A8U:
                goto block_003957A8;
            case 0x003957B8U:
                goto block_003957B8;
            case 0x003957C0U:
                goto block_003957C0;
            case 0x003957CCU:
                goto block_003957CC;
            case 0x003957D4U:
                goto block_003957D4;
            case 0x003957ECU:
                goto block_003957EC;
            case 0x003957FCU:
                goto block_003957FC;
            case 0x00395814U:
                goto block_00395814;
            case 0x0039586CU:
                goto block_0039586C;
            case 0x00395898U:
                goto block_00395898;
            case 0x003958A0U:
                goto block_003958A0;
            case 0x003958B8U:
                goto block_003958B8;
            case 0x003958C0U:
                goto block_003958C0;
            case 0x003958DCU:
                goto block_003958DC;
            case 0x003958F4U:
                goto block_003958F4;
            case 0x00395904U:
                goto block_00395904;
            case 0x00395914U:
                goto block_00395914;
            case 0x0039592CU:
                goto block_0039592C;
            case 0x00395958U:
                goto block_00395958;
            case 0x00395968U:
                goto block_00395968;
            case 0x00395980U:
                goto block_00395980;
            case 0x00395990U:
                goto block_00395990;
            case 0x003959A0U:
                goto block_003959A0;
            case 0x003959B8U:
                goto block_003959B8;
            case 0x003959C8U:
                goto block_003959C8;
            case 0x003959D8U:
                goto block_003959D8;
            case 0x00395A50U:
                goto block_00395A50;
            case 0x00395A68U:
                goto block_00395A68;
            case 0x00395A70U:
                goto block_00395A70;
            case 0x00395A7CU:
                goto block_00395A7C;
            case 0x00395A8CU:
                goto block_00395A8C;
            case 0x00395A98U:
                goto block_00395A98;
            case 0x00395ABCU:
                goto block_00395ABC;
            case 0x00395AECU:
                goto block_00395AEC;
            case 0x00395AFCU:
                goto block_00395AFC;
            case 0x00395B0CU:
                goto block_00395B0C;
            case 0x00395B24U:
                goto block_00395B24;
            case 0x00395B50U:
                goto block_00395B50;
            case 0x00395B5CU:
                goto block_00395B5C;
            case 0x00395B84U:
                goto block_00395B84;
            case 0x00395BA0U:
                goto block_00395BA0;
            case 0x00395BB8U:
                goto block_00395BB8;
            case 0x00395BD8U:
                goto block_00395BD8;
            case 0x00395BF4U:
                goto block_00395BF4;
            case 0x00395C0CU:
                goto block_00395C0C;
            case 0x00395C2CU:
                goto block_00395C2C;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_00394F04;
    }
block_00394F04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00394F04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00394F04U);
        }
        goto block_00395AEC;
    }
block_00394F54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00394F54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00394F54U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394F54U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00394F5CU, address);
            }
        }
        if (!(flags.Z())) { goto block_00395B0C; }
        goto block_00394F64;
    }
block_00394F64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00394F64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00394F64U);
        }
        {
            const uint32_t updatedAddress = 0x00394F6CU + 0x340U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394F64U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x000000FEU;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00394F6CU, address);
            }
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00394F74U, address);
            }
        }
        goto block_00395B0C;
    }
block_00394F7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00394F7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00394F7CU);
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r8 + operand;
        }
        {
            r1 = 0x000000DCU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x262U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00394F84U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x263U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00394F88U, address);
            }
        }
        {
            r1 = 0x000000BEU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x264U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00394F90U, address);
            }
        }
        {
            r1 = 0x000000D2U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x265U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00394F98U, address);
            }
        }
        {
            r2 = 0x00000008U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00394FACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00394FACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00394FAC;
    }
block_00394FAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00394FACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00394FACU);
        }
        {
            const uint32_t updatedAddress = 0x00394FB4U + 0x2FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394FACU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00394FB8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00394FBCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00394FC8U + 0x2ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394FC0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00394FCCU + 752U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394FC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00394FC8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00394FCCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00394FD8U + 0x2E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394FD0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00394FD4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00394FD8U, address);
            }
        }
        {
            const uint32_t address = r0 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00394FDCU, address);
            }
        }
        {
            const uint32_t operand = 0x000002B8U;
            r1 = r2 - operand;
        }
        {
            const uint32_t address = r0 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00394FE4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00394FE8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00394FF0U, address);
            }
        }
        goto block_00395AEC;
    }
block_00394FF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00394FF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00394FF8U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395008U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395008U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395008;
    }
block_00395008:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395008U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395008U);
        }
        {
            const uint32_t updatedAddress = 0x00395010U + 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395008U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039500CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00395024; }
        goto block_00395018;
    }
block_00395018:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395018U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395018U);
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395020U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395020U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395020;
    }
block_00395020:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395020U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395020U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395020U, address);
            }
        }
        goto block_00395024;
    }
block_00395024:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395024U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395024U);
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395034U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395034U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395034;
    }
block_00395034:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395034U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395034U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395034U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395044U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395044U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395044;
    }
block_00395044:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395044U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395044U);
        }
        {
            const uint32_t updatedAddress = 0x0039504CU + 0x278U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395044U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x00395050U + 624U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395048U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r1 + operand;
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395050U, address);
            }
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395054U, address);
            }
        }
        {
            const uint32_t address = 0x00395060U + 616U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395058U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0039505CU, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395060U, address);
            }
        }
        {
            const uint32_t address = 0x0039506CU + 608U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395064U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395068U, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0039506CU, address);
            }
        }
        {
            const uint32_t address = r5 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395070U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r1 + operand;
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0039507CU, address);
            }
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395080U, address);
            }
        }
        {
            const uint32_t address = r5 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395084U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395088U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0039508CU, address);
            }
        }
        {
            const uint32_t address = r5 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395090U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395094U, address);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r1 = r1 - operand;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0039509CU, address);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003950A0U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003950A0U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003950A0U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000048U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003950ACU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003950ACU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003950ACU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003950B0U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003950B0U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003950B0U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003950B8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003950B8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003950B8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003950BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003950C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003950C8U, address);
            }
        }
        goto block_00395AEC;
    }
block_003950D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003950D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003950D0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003950D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003950D8U, address);
            }
        }
        if (!(flags.Z())) { goto block_00395B0C; }
        goto block_003950E0;
    }
block_003950E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003950E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003950E0U);
        }
        {
            r2 = 0x00000068U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003950F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003950F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003950F0;
    }
block_003950F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003950F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003950F0U);
        }
        {
            const uint32_t updatedAddress = 0x003950F8U + 0x1B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003950F0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003950F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003950FCU, address);
            }
        }
        {
            r0 = 0x0000002DU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395104U, address);
            }
        }
        goto block_00395AEC;
    }
block_0039510C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0039510CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0039510CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039510CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0039511CU + 0x190U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395114U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395118U, address);
            }
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395120U, address);
            }
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0039512CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0039512CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0039512C;
    }
block_0039512C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0039512CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0039512CU);
        }
        {
            const uint32_t updatedAddress = 0x00395134U + 0x19CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039512CU, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = 0x00395140U + 0x194U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395138U, address);
            }
            r1 = value;
        }
        if ((flags.N()) != (flags.V())) {
            r0 = r4;
        }
        if ((flags.N()) != (flags.V())) {
            ++context.Stats.DirectCalls;
            r14 = 0x00395144U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395144U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395144;
    }
block_00395144:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395144U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395144U);
        }
        {
        }
        {
        }
        goto block_00395AEC;
    }
block_00395150:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395150U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395150U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0039515CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetRuntimeFlag200_0035AF04(frame, context, state, 0x0035AF04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0039515CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0039515C;
    }
block_0039515C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0039515CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0039515CU);
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0039516CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0039516CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0039516C;
    }
block_0039516C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0039516CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0039516CU);
        }
        {
            const uint32_t updatedAddress = 0x00395174U + 0x138U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039516CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395170U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395178U, address);
            }
        }
        goto block_00395AEC;
    }
block_00395180:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395180U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395180U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395190U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395190U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395190;
    }
block_00395190:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395190U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395190U);
        }
        {
            const uint32_t updatedAddress = 0x00395198U + 0x114U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395190U, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395194U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003951AC; }
        goto block_003951A0;
    }
block_003951A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003951A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003951A0U);
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003951A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003951A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003951A8;
    }
block_003951A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003951A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003951A8U);
        }
        {
            const uint32_t updatedAddress = r10 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003951A8U, address);
            }
        }
        goto block_003951AC;
    }
block_003951AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003951ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003951ACU);
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003951BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003951BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003951BC;
    }
block_003951BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003951BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003951BCU);
        }
        {
            const uint32_t updatedAddress = r10 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003951BCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003951CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003951CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003951CC;
    }
block_003951CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003951CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003951CCU);
        }
        {
            const uint32_t updatedAddress = 0x003951D4U + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003951CCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x003951D8U + 232U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003951D0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x003951DCU + 0xFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003951D4U, address);
            }
            r6 = value;
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r1 + operand;
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003951DCU, address);
            }
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003951E0U, address);
            }
        }
        {
            const uint32_t address = 0x003951ECU + 220U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003951E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r11 = r8 + operand;
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003951ECU, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003951F0U, address);
            }
        }
        {
            const uint32_t address = 0x003951FCU + 208U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003951F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000138U;
            r7 = r6 + operand;
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003951FCU, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395200U, address);
            }
        }
        {
            const uint32_t address = r5 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395204U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r1 + operand;
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395210U, address);
            }
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395214U, address);
            }
        }
        {
            const uint32_t address = r5 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395218U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r11 = r11 + operand;
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395220U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395224U, address);
            }
        }
        {
            const uint32_t address = r5 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395228U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0039522CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r1 = r1 - operand;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395234U, address);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00395238U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00395238U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00395238U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000048U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00395244U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00395244U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00395244U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00395248U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00395248U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00395248U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0039524CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0039524CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0039524CU,
                                           firstAddress + 8U);
            }
        }
        {
            r5 = 0x0000000FU;
        }
        goto block_00395254;
    }
block_00395254:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395254U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395254U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395254U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039525CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r6 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r5, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395268U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039526CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395270U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00395274U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395278U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r0 = r7 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00395280U, 0xEE700A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395284U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395288U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0039528CU, 0xEE311A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = r2;
            r1 = r1 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        goto block_003952DC;
    }
block_003952DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003952DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003952DCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003952DCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003952E0U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003952E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r12;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003952ECU, address);
            }
            r12 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t operand = r12;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x003952FCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003952FCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003952FCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003952FCU,
                                           firstAddress + 12U);
            }
        }
        {
            r2 = r8;
        }
        {
            r3 = 0x000000BAU;
        }
        {
            r1 = r4;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395314U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395314U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395314;
    }
block_00395314:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395314U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395314U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_00395254; }
        goto block_00395320;
    }
block_00395320:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395320U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395320U);
        }
        {
            r0 = 0x00000087U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395324U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395328U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395330U, address);
            }
        }
        goto block_00395AEC;
    }
block_00395338:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395338U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395338U);
        }
        {
            const uint32_t updatedAddress = 0x00395340U + 0x2E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395338U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00395344U + 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039533CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00395348U - 160U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395340U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x0039534CU + 752U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395344U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395348U, address);
            }
        }
        {
            const uint32_t address = 0x00395354U + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039534CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00395358U + 744U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395350U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395354U, address);
            }
        }
        {
            const uint32_t address = 0x00395360U + 716U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395358U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0039535CU, address);
            }
        }
        {
            const uint32_t address = 0x00395368U + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395360U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395368U, address);
            }
        }
        {
            const uint32_t address = 0x00395374U + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039536CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395370U, address);
            }
        }
        {
            const uint32_t address = 0x0039537CU + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395374U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395378U, address);
            }
        }
        {
            const uint32_t address = 0x00395384U + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039537CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395388U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395388U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395388;
    }
block_00395388:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395388U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395388U);
        }
        {
            const uint32_t updatedAddress = 0x00395390U + 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395388U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395390U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395394U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395398U, address);
            }
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0039539CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0039539CU,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0039539CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003953A0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003953A0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003953A0U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003953A4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003953ACU, address);
            }
        }
        if (!(flags.Z())) { goto block_00395AEC; }
        goto block_003953B4;
    }
block_003953B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003953B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003953B4U);
        }
        {
            const uint32_t updatedAddress = 0x003953BCU - 0x110U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003953B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003953B8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003953C0U, address);
            }
        }
        {
            r0 = 0x0000005AU;
        }
        goto block_003954AC;
    }
block_003953CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003953CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003953CCU);
        }
        {
            const uint32_t updatedAddress = 0x003953D4U - 0x110U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003953CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003953D8U + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003953D0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000018U;
            r1 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003953D8U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003953DCU, address);
            }
        }
        {
            const uint32_t address = 0x003953E8U + 616U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003953E0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003953E4U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003953E8U, address);
            }
        }
        {
            const uint32_t address = 0x003953F4U + 608U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003953ECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003953F0U, address);
            }
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003953F4U, address);
            }
        }
        {
            const uint32_t address = 0x00395400U + 600U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003953F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r1 - operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395404U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395408U, address);
            }
        }
        {
            const uint32_t address = 0x00395414U + 584U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039540CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395410U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395414U, address);
            }
        }
        {
            const uint32_t address = 0x00395420U + 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395418U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0039541CU, address);
            }
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395420U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0039542CU - 0x180U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395424U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0039542CU, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        goto block_0039550C;
    }
block_00395438:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395438U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395438U);
        }
        {
            const uint32_t updatedAddress = 0x00395440U + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395438U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00395444U + 532U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039543CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00395448U - 416U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395440U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x0039544CU + 496U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395444U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395448U, address);
            }
        }
        {
            const uint32_t address = 0x00395454U + 520U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039544CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00395458U + 488U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395450U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395454U, address);
            }
        }
        {
            const uint32_t address = 0x00395460U + 512U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395458U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0039545CU, address);
            }
        }
        {
            const uint32_t address = 0x00395468U + 476U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395460U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0039546CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0039546CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0039546C;
    }
block_0039546C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0039546CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0039546CU);
        }
        {
            const uint32_t updatedAddress = 0x00395474U + 0x1D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039546CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395474U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395478U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0039547CU, address);
            }
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00395480U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00395480U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00395480U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00395484U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00395484U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00395484U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395488U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395490U, address);
            }
        }
        if (!(flags.Z())) { goto block_00395AEC; }
        goto block_00395498;
    }
block_00395498:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395498U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395498U);
        }
        {
            const uint32_t updatedAddress = 0x003954A0U - 0x1F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395498U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039549CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003954A4U, address);
            }
        }
        {
            r0 = 0x0000003CU;
        }
        goto block_003954AC;
    }
block_003954AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003954ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003954ACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003954ACU, address);
            }
        }
        goto block_00395AEC;
    }
block_003954B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003954B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003954B4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003954B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003954BCU, address);
            }
        }
        if (!(flags.Z())) { goto block_00395AFC; }
        goto block_003954C4;
    }
block_003954C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003954C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003954C4U);
        }
        {
            const uint32_t updatedAddress = 0x003954CCU + 0x198U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003954C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003954D0U + 392U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003954C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r1 = r0 - operand;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003954D0U, address);
            }
        }
        {
            const uint32_t address = 0x003954DCU + 396U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003954D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003954D8U, address);
            }
        }
        {
            const uint32_t address = 0x003954E4U + 380U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003954DCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003954E0U, address);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003954E4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003954E4U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003954E4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000048U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003954F0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003954F0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003954F0U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003954F4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003954F4U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003954F4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            r0 = 0x00000008U;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003954FCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003954FCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003954FCU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = 0x00395508U - 0x25CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395500U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395504U, address);
            }
        }
        {
            r0 = 0x0000001EU;
        }
        goto block_0039550C;
    }
block_0039550C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0039550CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0039550CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0039550CU, address);
            }
        }
        goto block_00395AFC;
    }
block_00395514:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395514U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395514U);
        }
        {
            const uint32_t updatedAddress = 0x0039551CU + 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395514U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00395520U + 332U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395518U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x00395524U - 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039551CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x00395528U + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395520U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0039552CU + 324U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395524U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0039552CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0039552CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0039552C;
    }
block_0039552C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0039552CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0039552CU);
        }
        {
            const uint32_t updatedAddress = 0x00395534U + 0x114U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039552CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00395538U + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395530U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395538U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0039553CU, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00395540U, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395544U, address);
            }
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00395548U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00395548U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00395548U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t address = 0x00395554U + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039554CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00395550U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00395550U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00395550U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r1 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395554U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00395558U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0039555CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395560U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395568U, address);
            }
        }
        if (!(flags.Z())) { goto block_00395AEC; }
        goto block_00395570;
    }
block_00395570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395570U);
        }
        {
            const uint32_t updatedAddress = 0x00395578U - 0x2CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395570U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395574U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0039557CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00395588U + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395580U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395584U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r9 + 0xF6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0039558CU, address);
            }
        }
        goto block_00395AEC;
    }
block_00395594:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395594U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395594U);
        }
        {
            r6 = 0x0000000AU;
        }
        {
            const uint32_t address = 0x003955A0U + 220U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395598U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x003955A4U + 196U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039559CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r11 = r6;
        }
        {
            const uint32_t operand = 0x00003200U;
            r5 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00003100U;
            r10 = r8 + operand;
        }
        goto block_003955AC;
    }
block_003955AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003955ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003955ACU);
        }
        {
            const uint32_t updatedAddress = 0x003955B4U + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003955ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r6;
            r7 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r7 - 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003955B4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003956D0; }
        goto block_003955C0;
    }
block_003955C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003955C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003955C0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00395688; }
        goto block_003955C8;
    }
block_003955C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003955C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003955C8U);
        }
        {
            const uint32_t updatedAddress = 0x003955D0U + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003955C8U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003955D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003955D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003955D4;
    }
block_003955D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003955D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003955D4U);
        }
        {
            const uint32_t updatedAddress = r10 + 0xFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x003955D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0xFEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x003955D8U, address);
            }
        }
        {
            r0 = 0x00000073U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x003955E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003955E4U, address);
            }
        }
        {
            r0 = 0x00000041U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003955ECU, address);
            }
        }
        {
            r0 = 0x00000064U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003955F4U, address);
            }
        }
        {
            r0 = 0x00000078U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003955FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395600U, address);
            }
        }
        {
            r0 = 0x00000046U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395608U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xF94U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039560CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x00000002U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xF94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395618U, address);
            }
        }
        goto block_003956C0;
    }
block_00395688:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395688U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395688U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003956C0; }
        goto block_00395690;
    }
block_00395690:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395690U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395690U);
        }
        {
            frame.Guest.vfp[0] = r6;
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = 0x00000002U;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003956A0U, faultAddress);
            }
        }
        {
            r3 = 0x0000008CU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003956A8U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = 0x00000006U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003956C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BossVa_Spark_0031F5A8(frame, context, state, 0x0031F5A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003956C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003956C0;
    }
block_003956C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003956C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003956C0U);
        }
        {
            const uint32_t updatedAddress = r7 - 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003956C0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = r7 - 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003956CCU, address);
            }
        }
        goto block_003956D0;
    }
block_003956D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003956D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003956D0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003955AC; }
        goto block_003956DC;
    }
block_003956DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003956DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003956DCU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000F00U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003956E4U, address);
            }
        }
        {
            r3 = 0x00000032U;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000280U;
        }
        {
            const uint32_t operand = 0x000000F6U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003956FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToS_00375A18(frame, context, state, 0x00375A18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003956FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003956FC;
    }
block_003956FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003956FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003956FCU);
        }
        {
            const uint32_t updatedAddress = 0x00395704U - 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003956FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00395708U - 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395700U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x0039570CU + 764U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395704U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x00395710U - 208U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395708U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00395714U - 164U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039570CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395714U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395714U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395714;
    }
block_00395714:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395714U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395714U);
        }
        {
            const uint32_t updatedAddress = 0x0039571CU - 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395714U, address);
            }
            r5 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r6 = r5 + operand;
        }
        {
            const uint32_t address = r5 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039571CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395720U, address);
            }
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00395724U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00395724U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00395724U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00395728U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00395728U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00395728U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039572CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00395738U + 0x2D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395730U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00395764; }
        goto block_0039573C;
    }
block_0039573C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0039573CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0039573CU);
        }
        {
            const uint32_t updatedAddress = 0x00395744U + 0x2CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039573CU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            r2 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r1 + r8;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395748U, address);
            }
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395758U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395758U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395758;
    }
block_00395758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395758U);
        }
        {
        }
        {
        }
        goto block_003957FC;
    }
block_00395764:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395764U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395764U);
        }
        {
            const uint32_t updatedAddress = 0x0039576CU + 0x2A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395764U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_003957FC; }
        goto block_00395770;
    }
block_00395770:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395770U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395770U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x0039577CU + 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395774U, address);
            }
            r1 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395780U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_QueueSeqCmd_0036EC40(frame, context, state, 0x0036EC40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395780U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395780;
    }
block_00395780:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395780U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395780U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0039578CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b164_0035B164(frame, context, state, 0x0035B164U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0039578CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0039578C;
    }
block_0039578C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0039578CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0039578CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_003957FC; }
        goto block_00395798;
    }
block_00395798:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395798U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395798U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0039579CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b0a0_0035B0A0(frame, context, state, 0x0035B0A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0039579CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0039579C;
    }
block_0039579C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0039579CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0039579CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        {
        }
        if (!(flags.Z())) { goto block_003957FC; }
        goto block_003957A8;
    }
block_003957A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003957A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003957A8U);
        }
        {
            const uint32_t updatedAddress = 0x003957B0U + 0x26CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003957A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003957ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003957EC; }
        goto block_003957B8;
    }
block_003957B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003957B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003957B8U);
        }
        {
            const uint32_t updatedAddress = 0x003957C0U + 0x25CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003957B8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003957C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003957C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003957C0;
    }
block_003957C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003957C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003957C0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_003957EC; }
        goto block_003957CC;
    }
block_003957CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003957CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003957CCU);
        }
        {
            const uint32_t updatedAddress = 0x003957D4U + 0x24CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003957CCU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003957D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003957D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003957D4;
    }
block_003957D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003957D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003957D4U);
        }
        {
            const uint32_t updatedAddress = 0x003957DCU + 0x248U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003957D4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x003957E0U + 0x248U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003957D8U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x003957E8U + 0x234U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003957E0U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_003957EC;
    }
block_003957EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003957ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003957ECU);
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = 0x003957F8U + 0x234U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003957F0U, address);
            }
            r0 = value;
        }
        {
            r1 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003957FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003542c4_003542C4(frame, context, state, 0x003542C4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003957FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003957FC;
    }
block_003957FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003957FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003957FCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003957FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0xF6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395800U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00010000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0039580CU, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_003958C0; }
        goto block_00395814;
    }
block_00395814:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395814U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395814U);
        }
        {
            const uint32_t updatedAddress = 0x0039581CU - 0x570U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395814U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00395820U + 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395818U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00395824U - 460U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039581CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r6 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395820U, address);
            }
        }
        {
            const uint32_t address = r5 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395824U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395828U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x00395834U + 512U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039582CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00395834U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00395840U - 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395838U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0039583CU, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395840U, address);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00395848U, address);
            }
        }
        {
            const uint32_t address = 0x00395854U - 520U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039584CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00395850U, address);
            }
        }
        {
            const uint32_t address = 0x0039585CU + 476U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395854U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00395858U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00395864U + 0x1D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039585CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395860U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000040U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00395898; }
        goto block_0039586C;
    }
block_0039586C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0039586CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0039586CU);
        }
        {
            r3 = 0x00000040U;
        }
        {
            r2 = 0x00000100U;
        }
        {
            r1 = 0x000000B4U;
        }
        {
            const uint32_t updatedAddress = 0x00395880U + 0x1C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395878U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0039587CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0039587CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0039587CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r8 + operand;
        }
        {
            r3 = 0x000000C8U;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395888U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x0000024CU;
            r1 = r1 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395898U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TitleCard_InitBossName_00354248(frame, context, state, 0x00354248U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395898U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395898;
    }
block_00395898:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395898U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395898U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003958A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003958A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003958A0;
    }
block_003958A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003958A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003958A0U);
        }
        {
            const uint32_t updatedAddress = 0x003958A8U - 0x5D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003958A0U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = 0x003958B4U - 0x5E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003958ACU, address);
            }
            r1 = value;
        }
        if ((flags.N()) != (flags.V())) {
            r0 = r4;
        }
        if ((flags.N()) != (flags.V())) {
            ++context.Stats.DirectCalls;
            r14 = 0x003958B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003958B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003958B8;
    }
block_003958B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003958B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003958B8U);
        }
        {
            r0 = 0x0000003CU;
        }
        goto block_003954AC;
    }
block_003958C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003958C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003958C0U);
        }
        {
            const uint32_t address = 0x003958C8U + 380U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003958C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t address = r5 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003958C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003958D4U - 0x2B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003958CCU, address);
            }
            r5 = value;
        }
        {
            const uint32_t address = 0x003958D8U + 368U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003958D0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003958D4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003958DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003958DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003958DC;
    }
block_003958DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003958DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003958DCU);
        }
        {
            const uint32_t address = 0x003958E4U + 360U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003958DCU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003958E0U, 0xEE200A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003958E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003958E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003958F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003958F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003958F4;
    }
block_003958F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003958F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003958F4U);
        }
        {
            const uint32_t address = 0x003958FCU + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003958F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003958F8U, 0xEE400A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003958FCU, address);
            }
        }
        goto block_00395AEC;
    }
block_00395904:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395904U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395904U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395904U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0039590CU, address);
            }
        }
        if (!(flags.Z())) { goto block_00395AFC; }
        goto block_00395914;
    }
block_00395914:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395914U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395914U);
        }
        {
            const uint32_t updatedAddress = 0x0039591CU - 0x670U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395914U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x0000000BU;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0039591CU, address);
            }
        }
        {
            r0 = 0x00000044U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395924U, address);
            }
        }
        goto block_00395AFC;
    }
block_0039592C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0039592CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0039592CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00395934U, faultAddress);
            }
        }
        {
            const uint32_t address = 0x00395940U - 744U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395938U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x00395944U - 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039593CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00395948U - 736U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395940U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x0000008CU;
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395958U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BossVa_Spark_0031F5A8(frame, context, state, 0x0031F5A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395958U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395958;
    }
block_00395958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395958U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395958U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395960U, address);
            }
        }
        if (!(flags.Z())) { goto block_00395AEC; }
        goto block_00395968;
    }
block_00395968:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395968U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395968U);
        }
        {
            const uint32_t updatedAddress = 0x00395970U - 0x6C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395968U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0039596CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395974U, address);
            }
        }
        {
            r0 = 0x0000000BU;
        }
        goto block_003954AC;
    }
block_00395980:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395980U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395980U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395980U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395988U, address);
            }
        }
        if (!(flags.Z())) { goto block_00395AFC; }
        goto block_00395990;
    }
block_00395990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395990U);
        }
        {
            const uint32_t updatedAddress = 0x00395998U - 0x6ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395990U, address);
            }
            r6 = value;
        }
        {
            r0 = r8;
        }
        {
            const uint32_t updatedAddress = r6 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395998U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003959A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCamera_0036963C(frame, context, state, 0x0036963CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003959A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003959A0;
    }
block_003959A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003959A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003959A0U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003959A8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003959B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003959B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003959B8;
    }
block_003959B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003959B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003959B8U);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003959C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003959C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003959C8;
    }
block_003959C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003959C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003959C8U);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003959D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003959D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003959D8;
    }
block_003959D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003959D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003959D8U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003959D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003959E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003959ECU + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003959E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003959E8U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 | 0x00000040U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xFAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003959F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003959F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00008000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003959FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395A00U, address);
            }
        }
        goto block_00395AEC;
    }
block_00395A50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395A50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395A50U);
        }
        {
            const uint32_t updatedAddress = 0x00395A58U - 0x7A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395A50U, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395A54U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395A5CU, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00395A8C; }
        goto block_00395A68;
    }
block_00395A68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395A68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395A68U);
        }
        {
            r1 = ~(0x00000000U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395A70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395A70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395A70;
    }
block_00395A70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395A70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395A70U);
        }
        {
            r6 = r0;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395A7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_byte_1b6_00367C48(frame, context, state, 0x00367C48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395A7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395A7C;
    }
block_00395A7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395A7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395A7CU);
        }
        {
            const uint32_t address = 0x00395A84U + 436U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395A7CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t address = r6 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395A84U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395A88U, address);
            }
        }
        goto block_00395A8C;
    }
block_00395A8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395A8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395A8CU);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395A98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395A98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395A98;
    }
block_00395A98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395A98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395A98U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x00395AA4U - 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395A9CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00395AACU, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00395AB8U - 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395AB0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395ABCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395ABCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395ABC;
    }
block_00395ABC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395ABCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395ABCU);
        }
        {
            const uint32_t address = 0x00395AC4U + 376U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395ABCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x00395AC8U - 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395AC0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r4 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00395AC4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395AC8U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395AD0U, address);
            }
        }
        {
            r0 = 0x00000026U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395AD8U, address);
            }
        }
        {
            r0 = 0x00000080U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395AE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00395AECU + 0x154U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395AE4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xF90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395AE8U, address);
            }
        }
        goto block_00395AEC;
    }
block_00395AEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395AECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395AECU);
        }
        {
            const uint32_t updatedAddress = 0x00395AF4U - 0x848U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395AECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395AF0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00395B0C; }
        goto block_00395AFC;
    }
block_00395AFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395AFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395AFCU);
        }
        {
            const uint32_t updatedAddress = 0x00395B04U + 0x140U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395AFCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x00395B08U - 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395B00U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395B0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySfxWithScaledGain_0036EF10(frame, context, state, 0x0036EF10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395B0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395B0C;
    }
block_00395B0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395B0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395B0CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0xB4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395B0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000000E4U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0xB4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395B1CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395B24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395B24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395B24;
    }
block_00395B24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395B24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395B24U);
        }
        {
            const uint32_t address = 0x00395B2CU + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395B24U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x00395B30U - 0x884U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395B28U, address);
            }
            r4 = value;
        }
        {
            r1 = 0x00000096U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00395B30U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00395B34U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0xB2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00395B40U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395B44U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00395C2C; }
        goto block_00395B50;
    }
block_00395B50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395B50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395B50U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395B50U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00395C2C; }
        goto block_00395B5C;
    }
block_00395B5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395B5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395B5CU);
        }
        {
            const uint32_t updatedAddress = 0x00395B64U - 0x51CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395B5CU, address);
            }
            r6 = value;
        }
        {
            const uint32_t address = 0x00395B68U + 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395B60U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x00395B6CU + 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395B64U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t operand = 0x00000018U;
            r5 = r6 - operand;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r6 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395B74U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395B78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r0 = r6 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395B84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395B84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395B84;
    }
block_00395B84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395B84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395B84U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000030U;
            r7 = r6 - operand;
        }
        {
            const uint32_t address = r6 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395B90U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395B94U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r7 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395BA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395BA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395BA0;
    }
block_00395BA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395BA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395BA0U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r6 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395BA8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395BACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r7 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395BB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395BB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395BB8;
    }
block_00395BB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395BB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395BB8U);
        }
        {
            const uint32_t operand = 0x0000003CU;
            r6 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r5 = r7 + operand;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r6 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395BC8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395BCCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r7 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395BD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395BD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395BD8;
    }
block_00395BD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395BD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395BD8U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x0000000CU;
            r7 = r7 + operand;
        }
        {
            const uint32_t address = r6 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395BE4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395BE8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r7 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395BF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395BF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395BF4;
    }
block_00395BF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395BF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395BF4U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r6 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395BFCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395C00U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r7 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00395C0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00395C0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00395C0C;
    }
block_00395C0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395C0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395C0CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00395C0CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r3 = r7 - operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00395C18U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00395C18U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t operand = 0x00000000U;
            r2 = r7 + operand;
        }
        {
            r0 = r8;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00395C24U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00395C24U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00395C24U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00395C24U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00395C24U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00395C24U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00395C24U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00395C24U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x00395C24U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r14 = value14;
            r13 = r13 + 36U;
        }
        return Oot3dAotBranch(0x00367B14U);
    }
block_00395C2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00395C2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00395C2CU);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00395C30U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00395C30U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00395C34U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00395C34U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00395C34U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00395C34U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00395C34U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00395C34U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00395C34U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00395C34U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00395C34U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Fishing_UpdateOwner_003B5AE0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003B5AE0U:
        goto block_003B5AE0;
    case 0x003B5B0CU:
        goto block_003B5B0C;
    case 0x003B5B14U:
        goto block_003B5B14;
    case 0x003B5B1CU:
        goto block_003B5B1C;
    case 0x003B5B40U:
        goto block_003B5B40;
    case 0x003B5B84U:
        goto block_003B5B84;
    case 0x003B5B90U:
        goto block_003B5B90;
    case 0x003B5B9CU:
        goto block_003B5B9C;
    case 0x003B5BA8U:
        goto block_003B5BA8;
    case 0x003B5BBCU:
        goto block_003B5BBC;
    case 0x003B5BD4U:
        goto block_003B5BD4;
    case 0x003B5BDCU:
        goto block_003B5BDC;
    case 0x003B5BE8U:
        goto block_003B5BE8;
    case 0x003B5C00U:
        goto block_003B5C00;
    case 0x003B5C14U:
        goto block_003B5C14;
    case 0x003B5C2CU:
        goto block_003B5C2C;
    case 0x003B5C34U:
        goto block_003B5C34;
    case 0x003B5C40U:
        goto block_003B5C40;
    case 0x003B5C60U:
        goto block_003B5C60;
    case 0x003B5C6CU:
        goto block_003B5C6C;
    case 0x003B5C70U:
        goto block_003B5C70;
    case 0x003B5C84U:
        goto block_003B5C84;
    case 0x003B5C9CU:
        goto block_003B5C9C;
    case 0x003B5CA0U:
        goto block_003B5CA0;
    case 0x003B5CB4U:
        goto block_003B5CB4;
    case 0x003B5D00U:
        goto block_003B5D00;
    case 0x003B5D0CU:
        goto block_003B5D0C;
    case 0x003B5D20U:
        goto block_003B5D20;
    case 0x003B5D2CU:
        goto block_003B5D2C;
    case 0x003B5D78U:
        goto block_003B5D78;
    case 0x003B5D90U:
        goto block_003B5D90;
    case 0x003B5DA4U:
        goto block_003B5DA4;
    case 0x003B5DACU:
        goto block_003B5DAC;
    case 0x003B5DB4U:
        goto block_003B5DB4;
    case 0x003B5DB8U:
        goto block_003B5DB8;
    case 0x003B5DC4U:
        goto block_003B5DC4;
    case 0x003B5DD4U:
        goto block_003B5DD4;
    case 0x003B5DE8U:
        goto block_003B5DE8;
    case 0x003B5DF4U:
        goto block_003B5DF4;
    case 0x003B5E24U:
        goto block_003B5E24;
    case 0x003B5E30U:
        goto block_003B5E30;
    case 0x003B5E40U:
        goto block_003B5E40;
    case 0x003B5E78U:
        goto block_003B5E78;
    case 0x003B5E84U:
        goto block_003B5E84;
    case 0x003B5EA4U:
        goto block_003B5EA4;
    case 0x003B5EB8U:
        goto block_003B5EB8;
    case 0x003B5F44U:
        goto block_003B5F44;
    case 0x003B5F48U:
        goto block_003B5F48;
    case 0x003B5F8CU:
        goto block_003B5F8C;
    case 0x003B5F98U:
        goto block_003B5F98;
    case 0x003B5FCCU:
        goto block_003B5FCC;
    case 0x003B5FD0U:
        goto block_003B5FD0;
    case 0x003B5FECU:
        goto block_003B5FEC;
    case 0x003B5FFCU:
        goto block_003B5FFC;
    case 0x003B6004U:
        goto block_003B6004;
    case 0x003B602CU:
        goto block_003B602C;
    case 0x003B6038U:
        goto block_003B6038;
    case 0x003B6044U:
        goto block_003B6044;
    case 0x003B6074U:
        goto block_003B6074;
    case 0x003B6078U:
        goto block_003B6078;
    case 0x003B6094U:
        goto block_003B6094;
    case 0x003B60A0U:
        goto block_003B60A0;
    case 0x003B60B0U:
        goto block_003B60B0;
    case 0x003B60B8U:
        goto block_003B60B8;
    case 0x003B60E8U:
        goto block_003B60E8;
    case 0x003B60ECU:
        goto block_003B60EC;
    case 0x003B6100U:
        goto block_003B6100;
    case 0x003B6110U:
        goto block_003B6110;
    case 0x003B611CU:
        goto block_003B611C;
    case 0x003B6128U:
        goto block_003B6128;
    case 0x003B6134U:
        goto block_003B6134;
    case 0x003B6140U:
        goto block_003B6140;
    case 0x003B6174U:
        goto block_003B6174;
    case 0x003B619CU:
        goto block_003B619C;
    case 0x003B61D0U:
        goto block_003B61D0;
    case 0x003B61D4U:
        goto block_003B61D4;
    case 0x003B61E8U:
        goto block_003B61E8;
    case 0x003B61F0U:
        goto block_003B61F0;
    case 0x003B6200U:
        goto block_003B6200;
    case 0x003B621CU:
        goto block_003B621C;
    case 0x003B6228U:
        goto block_003B6228;
    case 0x003B623CU:
        goto block_003B623C;
    case 0x003B6250U:
        goto block_003B6250;
    case 0x003B6268U:
        goto block_003B6268;
    case 0x003B62B8U:
        goto block_003B62B8;
    case 0x003B62BCU:
        goto block_003B62BC;
    case 0x003B62D8U:
        goto block_003B62D8;
    case 0x003B62E0U:
        goto block_003B62E0;
    case 0x003B62F4U:
        goto block_003B62F4;
    case 0x003B6300U:
        goto block_003B6300;
    case 0x003B6314U:
        goto block_003B6314;
    case 0x003B632CU:
        goto block_003B632C;
    case 0x003B6344U:
        goto block_003B6344;
    case 0x003B6378U:
        goto block_003B6378;
    case 0x003B6380U:
        goto block_003B6380;
    case 0x003B63B4U:
        goto block_003B63B4;
    case 0x003B63DCU:
        goto block_003B63DC;
    case 0x003B6400U:
        goto block_003B6400;
    case 0x003B6430U:
        goto block_003B6430;
    case 0x003B643CU:
        goto block_003B643C;
    case 0x003B6478U:
        goto block_003B6478;
    case 0x003B6480U:
        goto block_003B6480;
    case 0x003B6488U:
        goto block_003B6488;
    case 0x003B6490U:
        goto block_003B6490;
    case 0x003B6498U:
        goto block_003B6498;
    case 0x003B64A0U:
        goto block_003B64A0;
    case 0x003B64A8U:
        goto block_003B64A8;
    case 0x003B64BCU:
        goto block_003B64BC;
    case 0x003B64CCU:
        goto block_003B64CC;
    case 0x003B64D8U:
        goto block_003B64D8;
    case 0x003B6518U:
        goto block_003B6518;
    case 0x003B651CU:
        goto block_003B651C;
    case 0x003B6528U:
        goto block_003B6528;
    case 0x003B655CU:
        goto block_003B655C;
    case 0x003B6568U:
        goto block_003B6568;
    case 0x003B6588U:
        goto block_003B6588;
    case 0x003B65B8U:
        goto block_003B65B8;
    case 0x003B65D4U:
        goto block_003B65D4;
    case 0x003B65F4U:
        goto block_003B65F4;
    case 0x003B662CU:
        goto block_003B662C;
    case 0x003B6674U:
        goto block_003B6674;
    case 0x003B6684U:
        goto block_003B6684;
    case 0x003B6698U:
        goto block_003B6698;
    case 0x003B66B4U:
        goto block_003B66B4;
    case 0x003B66C0U:
        goto block_003B66C0;
    case 0x003B66E0U:
        goto block_003B66E0;
    case 0x003B66E8U:
        goto block_003B66E8;
    case 0x003B66F0U:
        goto block_003B66F0;
    case 0x003B6700U:
        goto block_003B6700;
    case 0x003B670CU:
        goto block_003B670C;
    case 0x003B6720U:
        goto block_003B6720;
    case 0x003B6730U:
        goto block_003B6730;
    case 0x003B6740U:
        goto block_003B6740;
    case 0x003B674CU:
        goto block_003B674C;
    case 0x003B678CU:
        goto block_003B678C;
    case 0x003B6794U:
        goto block_003B6794;
    case 0x003B67A8U:
        goto block_003B67A8;
    case 0x003B67B4U:
        goto block_003B67B4;
    case 0x003B67C0U:
        goto block_003B67C0;
    case 0x003B67F4U:
        goto block_003B67F4;
    case 0x003B6804U:
        goto block_003B6804;
    case 0x003B6864U:
        goto block_003B6864;
    case 0x003B686CU:
        goto block_003B686C;
    case 0x003B68B0U:
        goto block_003B68B0;
    case 0x003B68BCU:
        goto block_003B68BC;
    case 0x003B68C4U:
        goto block_003B68C4;
    case 0x003B68CCU:
        goto block_003B68CC;
    case 0x003B68D4U:
        goto block_003B68D4;
    case 0x003B68DCU:
        goto block_003B68DC;
    case 0x003B68E8U:
        goto block_003B68E8;
    case 0x003B68F0U:
        goto block_003B68F0;
    case 0x003B68FCU:
        goto block_003B68FC;
    case 0x003B6908U:
        goto block_003B6908;
    case 0x003B6924U:
        goto block_003B6924;
    case 0x003B6928U:
        goto block_003B6928;
    case 0x003B6934U:
        goto block_003B6934;
    case 0x003B6948U:
        goto block_003B6948;
    case 0x003B6958U:
        goto block_003B6958;
    case 0x003B6964U:
        goto block_003B6964;
    case 0x003B6968U:
        goto block_003B6968;
    case 0x003B696CU:
        goto block_003B696C;
    case 0x003B6978U:
        goto block_003B6978;
    case 0x003B6984U:
        goto block_003B6984;
    case 0x003B6998U:
        goto block_003B6998;
    case 0x003B69D4U:
        goto block_003B69D4;
    case 0x003B6A1CU:
        goto block_003B6A1C;
    case 0x003B6A30U:
        goto block_003B6A30;
    case 0x003B6A4CU:
        goto block_003B6A4C;
    case 0x003B6AB4U:
        goto block_003B6AB4;
    case 0x003B6AD0U:
        goto block_003B6AD0;
    case 0x003B6AF4U:
        goto block_003B6AF4;
    case 0x003B6B0CU:
        goto block_003B6B0C;
    case 0x003B6B2CU:
        goto block_003B6B2C;
    case 0x003B6B38U:
        goto block_003B6B38;
    case 0x003B6B44U:
        goto block_003B6B44;
    case 0x003B6B74U:
        goto block_003B6B74;
    case 0x003B6B7CU:
        goto block_003B6B7C;
    case 0x003B6B88U:
        goto block_003B6B88;
    case 0x003B6B98U:
        goto block_003B6B98;
    case 0x003B6BA8U:
        goto block_003B6BA8;
    case 0x003B6BC0U:
        goto block_003B6BC0;
    case 0x003B6C00U:
        goto block_003B6C00;
    case 0x003B6C10U:
        goto block_003B6C10;
    case 0x003B6C1CU:
        goto block_003B6C1C;
    case 0x003B6C30U:
        goto block_003B6C30;
    case 0x003B6C40U:
        goto block_003B6C40;
    case 0x003B6C50U:
        goto block_003B6C50;
    case 0x003B6C5CU:
        goto block_003B6C5C;
    case 0x003B6C9CU:
        goto block_003B6C9C;
    case 0x003B6CD8U:
        goto block_003B6CD8;
    case 0x003B6CE4U:
        goto block_003B6CE4;
    case 0x003B6CECU:
        goto block_003B6CEC;
    case 0x003B6CF8U:
        goto block_003B6CF8;
    case 0x003B6D74U:
        goto block_003B6D74;
    case 0x003B6D7CU:
        goto block_003B6D7C;
    case 0x003B6D88U:
        goto block_003B6D88;
    case 0x003B6DBCU:
        goto block_003B6DBC;
    case 0x003B6DCCU:
        goto block_003B6DCC;
    case 0x003B6DE8U:
        goto block_003B6DE8;
    case 0x003B6E10U:
        goto block_003B6E10;
    case 0x003B6E24U:
        goto block_003B6E24;
    case 0x003B6E58U:
        goto block_003B6E58;
    case 0x003B6EA0U:
        goto block_003B6EA0;
    case 0x003B6EE0U:
        goto block_003B6EE0;
    case 0x003B6F44U:
        goto block_003B6F44;
    case 0x003B6F54U:
        goto block_003B6F54;
    case 0x003B6F5CU:
        goto block_003B6F5C;
    case 0x003B6F64U:
        goto block_003B6F64;
    case 0x003B6F6CU:
        goto block_003B6F6C;
    case 0x003B6F74U:
        goto block_003B6F74;
    case 0x003B6F80U:
        goto block_003B6F80;
    case 0x003B6F8CU:
        goto block_003B6F8C;
    case 0x003B6F98U:
        goto block_003B6F98;
    case 0x003B6FA4U:
        goto block_003B6FA4;
    case 0x003B6FB0U:
        goto block_003B6FB0;
    case 0x003B6FC0U:
        goto block_003B6FC0;
    case 0x003B6FF4U:
        goto block_003B6FF4;
    case 0x003B7004U:
        goto block_003B7004;
    case 0x003B7014U:
        goto block_003B7014;
    case 0x003B707CU:
        goto block_003B707C;
    case 0x003B7084U:
        goto block_003B7084;
    case 0x003B7090U:
        goto block_003B7090;
    case 0x003B70A0U:
        goto block_003B70A0;
    case 0x003B70B8U:
        goto block_003B70B8;
    case 0x003B70E0U:
        goto block_003B70E0;
    case 0x003B70ECU:
        goto block_003B70EC;
    case 0x003B7104U:
        goto block_003B7104;
    case 0x003B7110U:
        goto block_003B7110;
    case 0x003B7114U:
        goto block_003B7114;
    case 0x003B7118U:
        goto block_003B7118;
    case 0x003B7158U:
        goto block_003B7158;
    case 0x003B7168U:
        goto block_003B7168;
    case 0x003B71ACU:
        goto block_003B71AC;
    case 0x003B71BCU:
        goto block_003B71BC;
    case 0x003B71C4U:
        goto block_003B71C4;
    case 0x003B71D8U:
        goto block_003B71D8;
    case 0x003B7218U:
        goto block_003B7218;
    case 0x003B7224U:
        goto block_003B7224;
    case 0x003B7234U:
        goto block_003B7234;
    case 0x003B7240U:
        goto block_003B7240;
    case 0x003B7280U:
        goto block_003B7280;
    case 0x003B72A0U:
        goto block_003B72A0;
    case 0x003B72B4U:
        goto block_003B72B4;
    case 0x003B72DCU:
        goto block_003B72DC;
    case 0x003B72F4U:
        goto block_003B72F4;
    case 0x003B7308U:
        goto block_003B7308;
    case 0x003B7318U:
        goto block_003B7318;
    case 0x003B7338U:
        goto block_003B7338;
    case 0x003B7340U:
        goto block_003B7340;
    case 0x003B734CU:
        goto block_003B734C;
    case 0x003B7358U:
        goto block_003B7358;
    case 0x003B7368U:
        goto block_003B7368;
    case 0x003B7378U:
        goto block_003B7378;
    case 0x003B73C8U:
        goto block_003B73C8;
    case 0x003B73E4U:
        goto block_003B73E4;
    case 0x003B73F4U:
        goto block_003B73F4;
    case 0x003B7410U:
        goto block_003B7410;
    case 0x003B741CU:
        goto block_003B741C;
    case 0x003B7430U:
        goto block_003B7430;
    case 0x003B743CU:
        goto block_003B743C;
    case 0x003B7448U:
        goto block_003B7448;
    case 0x003B7450U:
        goto block_003B7450;
    case 0x003B7470U:
        goto block_003B7470;
    case 0x003B7484U:
        goto block_003B7484;
    case 0x003B74A4U:
        goto block_003B74A4;
    case 0x003B74B4U:
        goto block_003B74B4;
    case 0x003B74DCU:
        goto block_003B74DC;
    case 0x003B750CU:
        goto block_003B750C;
    case 0x003B7520U:
        goto block_003B7520;
    case 0x003B7530U:
        goto block_003B7530;
    case 0x003B753CU:
        goto block_003B753C;
    case 0x003B7550U:
        goto block_003B7550;
    case 0x003B75B4U:
        goto block_003B75B4;
    case 0x003B75C4U:
        goto block_003B75C4;
    case 0x003B75F4U:
        goto block_003B75F4;
    case 0x003B7600U:
        goto block_003B7600;
    case 0x003B760CU:
        goto block_003B760C;
    case 0x003B763CU:
        goto block_003B763C;
    case 0x003B765CU:
        goto block_003B765C;
    case 0x003B7664U:
        goto block_003B7664;
    case 0x003B7678U:
        goto block_003B7678;
    case 0x003B768CU:
        goto block_003B768C;
    case 0x003B76A4U:
        goto block_003B76A4;
    case 0x003B76B8U:
        goto block_003B76B8;
    case 0x003B76D0U:
        goto block_003B76D0;
    case 0x003B76ECU:
        goto block_003B76EC;
    case 0x003B76F8U:
        goto block_003B76F8;
    case 0x003B772CU:
        goto block_003B772C;
    case 0x003B773CU:
        goto block_003B773C;
    case 0x003B774CU:
        goto block_003B774C;
    case 0x003B7758U:
        goto block_003B7758;
    case 0x003B776CU:
        goto block_003B776C;
    case 0x003B778CU:
        goto block_003B778C;
    case 0x003B77ACU:
        goto block_003B77AC;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003B5AE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5AE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5AE0U);
        }
        {
            const uint32_t firstAddress = r13 - 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x003B5AE0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003B5AE0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x003B5AE0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003B5AE0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003B5AE0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r7)) {
                return Oot3dAotMemoryFault(context, 0x003B5AE0U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r8)) {
                return Oot3dAotMemoryFault(context, 0x003B5AE0U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r9)) {
                return Oot3dAotMemoryFault(context, 0x003B5AE0U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r10)) {
                return Oot3dAotMemoryFault(context, 0x003B5AE0U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r11)) {
                return Oot3dAotMemoryFault(context, 0x003B5AE0U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003B5AE0U,
                                           firstAddress + 40U);
            }
            r13 = r13 - 44U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t updatedAddress = 0x003B5AF0U + 0x3E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5AE8U, address);
            }
            r8 = value;
        }
        {
            r13 -= 56U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 44U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 48U, frame.Guest.vfp[28])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 48U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 52U, frame.Guest.vfp[29])) {
                return Oot3dAotMemoryFault(context, 0x003B5AECU,
                                           firstAddress + 52U);
            }
        }
        {
            const uint32_t operand = 0x000000BCU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5AF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5AF8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5AFCU, address);
            }
            r7 = value;
        }
        {
            const uint32_t address = 0x003B5B08U + 976U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5B00U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003B5B40; }
        goto block_003B5B0C;
    }
block_003B5B0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5B0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5B0CU);
        }
        {
            const uint32_t operand = 0x000000A8U;
            r0 = r8 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5B14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5B14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5B14;
    }
block_003B5B14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5B14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5B14U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003B5B40; }
        goto block_003B5B1C;
    }
block_003B5B1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5B1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5B1CU);
        }
        {
            const uint32_t updatedAddress = 0x003B5B24U + 0x3C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5B1CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = 0x003B5B2CU + 944U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5B24U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x003B5B30U + 944U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5B28U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003B5B2CU, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B5B30U, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x003B5B34U, address);
            }
        }
        {
            const uint32_t operand = 0x000000A8U;
            r0 = r8 + operand;
        }
        {
            r0 = r0;
        }
        goto block_003B5B40;
    }
block_003B5B40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5B40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5B40U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5B44U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5B48U, address);
            }
            r9 = value;
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x84U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5B50U, address);
            }
        }
        {
            r3 = 0x00000028U;
        }
        {
            const uint32_t updatedAddress = r9 + 0xD0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5B58U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5B60U, address);
            }
        }
        {
            const uint32_t address = r9 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5B64U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r9 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5B68U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B5B74U + 0x374U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5B6CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5B70U, 0xEE600AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5B74U, 0xEE400A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003B5B9C; }
        goto block_003B5B84;
    }
block_003B5B84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5B84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5B84U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000088U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5B90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5B90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5B90;
    }
block_003B5B90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5B90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5B90U);
        }
        {
        }
        {
        }
        goto block_003B5BA8;
    }
block_003B5B9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5B9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5B9CU);
        }
        {
            r1 = 0x000000C8U;
        }
        {
            const uint32_t operand = 0x00000088U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5BA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5BA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5BA8;
    }
block_003B5BA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5BA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5BA8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5BA8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0xD0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5BACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5BB0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000230U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5BBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5BBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5BBC;
    }
block_003B5BBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5BBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5BBCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5BBCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5BC0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r5 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x000008A0U;
            r5 = r5 + operand;
        }
        if (!(flags.Z())) { goto block_003B5BE8; }
        goto block_003B5BD4;
    }
block_003B5BD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5BD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5BD4U);
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5BDCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5BDCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5BDC;
    }
block_003B5BDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5BDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5BDCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_003B5C00; }
        goto block_003B5BE8;
    }
block_003B5BE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5BE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5BE8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5BE8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5BECU, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5BF4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003B5BF8U, address);
            }
        }
        goto block_003B5C14;
    }
block_003B5C00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5C00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5C00U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5C00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5C04U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 | 0x00000021U;
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5C0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003B5C10U, address);
            }
        }
        goto block_003B5C14;
    }
block_003B5C14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5C14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5C14U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5C14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5C18U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B5C24U + 0x2C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5C1CU, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_003B5C40; }
        goto block_003B5C2C;
    }
block_003B5C2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5C2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5C2CU);
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5C34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5C34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5C34;
    }
block_003B5C34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5C34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5C34U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r1 = 0x00000000U;
        }
        if (flags.Z()) { goto block_003B5C70; }
        goto block_003B5C40;
    }
block_003B5C40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5C40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5C40U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5C40U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5C44U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5C48U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r0;
            r0 = r1 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B5C5CU + 0x294U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5C54U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003B5C6C; }
        goto block_003B5C60;
    }
block_003B5C60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5C60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5C60U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 14U);
            r0 = operand - r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003B5C70; }
        goto block_003B5C6C;
    }
block_003B5C6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5C6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5C6CU);
        }
        {
            r1 = r0;
        }
        goto block_003B5C70;
    }
block_003B5C70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5C70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5C70U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5C70U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B5C7CU + 0x278U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5C74U, address);
            }
            r3 = value;
        }
        {
            r2 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x000001BCU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5C84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5C84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5C84;
    }
block_003B5C84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5C84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5C84U);
        }
        {
            const uint32_t operand = 0x00005000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xB4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5C88U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xBF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5C8CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r4 = r4 + operand;
        }
        {
            const uint32_t value = r0 & 0x0000001FU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003B5CB4; }
        goto block_003B5C9C;
    }
block_003B5C9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5C9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5C9CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5CA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5CA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5CA0;
    }
block_003B5CA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5CA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5CA0U);
        }
        {
            const uint32_t updatedAddress = 0x003B5CA8U + 0x250U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5CA0U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            r0 = 0x00000006U;
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r4 + 0xBAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5CB0U, address);
            }
        }
        goto block_003B5CB4;
    }
block_003B5CB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5CB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5CB4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5CB4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x003B5CC0U + 0x23CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5CB8U, address);
            }
            r1 = value;
        }
        {
            r5 = 0x00000001U;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5CC8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5CCCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5CD0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0xBAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5CDCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5CE0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x003B5CECU + 0x214U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5CE4U, address);
            }
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r8 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5CF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x5U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5CF4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003B5D90; }
        goto block_003B5D00;
    }
block_003B5D00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5D00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5D00U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x16U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D00U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003B5D90; }
        goto block_003B5D0C;
    }
block_003B5D0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5D0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5D0CU);
        }
        {
            const uint32_t updatedAddress = r8 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D0CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r8 + 0x4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D14U, address);
            }
            r0 = value;
        }
        if ((flags.N()) == (flags.V())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003B5D90; }
        goto block_003B5D20;
    }
block_003B5D20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5D20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5D20U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D20U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003B5DAC; }
        goto block_003B5D2C;
    }
block_003B5D2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5D2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5D2CU);
        }
        {
            const uint32_t updatedAddress = 0x003B5D34U + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D2CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D34U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D38U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r1 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D3CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5D40U, 0xEE301A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D44U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D48U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B5D54U + 0x1B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D4CU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5D50U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D54U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5D58U, 0xEE700AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5D5CU, 0xEE211A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5D60U, 0xEE001A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5D64U, 0xEE001AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5D68U, 0xEEB10AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003B5DAC; }
        goto block_003B5D78;
    }
block_003B5D78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5D78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5D78U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003B5D78U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003B5D84U + 0x188U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D7CU, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t updatedAddress = r8 + 0x5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003B5D88U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5D90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5D90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5D90;
    }
block_003B5D90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5D90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5D90U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D90U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xED8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5D98U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            r0 = r0 | 0x00001000U;
        }
        if (flags.Z()) { goto block_003B5DB4; }
        goto block_003B5DA4;
    }
block_003B5DA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5DA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5DA4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003B5DB8; }
        goto block_003B5DAC;
    }
block_003B5DAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5DACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5DACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xED8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5DACU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00001000U);
        }
        goto block_003B5DB4;
    }
block_003B5DB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5DB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5DB4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xED8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5DB4U, address);
            }
        }
        goto block_003B5DB8;
    }
block_003B5DB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5DB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5DB8U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5DB8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003B5DE8; }
        goto block_003B5DC4;
    }
block_003B5DC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5DC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5DC4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            r0 = r0 & 0x000000FFU;
            Oot3dAotSetLogicalFlags(flags, r0, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            const uint32_t updatedAddress = r8 + 0x3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5DCCU, address);
            }
        }
        if (!(flags.Z())) { goto block_003B5DE8; }
        goto block_003B5DD4;
    }
block_003B5DD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5DD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5DD4U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x2AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5DD4U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r1 = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5DE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5DE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5DE8;
    }
block_003B5DE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5DE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5DE8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5DE8U, address);
            }
            r0 = value;
        }
        {
            r1 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5DF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Fishing_HandleOwnerDialog_001C3558(frame, context, state, 0x001C3558U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5DF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5DF4;
    }
block_003B5DF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5DF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5DF4U);
        }
        {
            const uint32_t updatedAddress = 0x003B5DFCU + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5DF4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003B5E00U + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5DF8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 248U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B5DFCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E00U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003B5E08U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E0CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x003B5E1CU + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E14U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E18U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003B5E30; }
        goto block_003B5E24;
    }
block_003B5E24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5E24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5E24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E24U, address);
            }
            r0 = value;
        }
        {
            r1 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5E30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Fishing_UpdateLure_003D1040(frame, context, state, 0x003D1040U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5E30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5E30;
    }
block_003B5E30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5E30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5E30U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E30U, address);
            }
            r0 = value;
        }
        {
            r1 = r7;
        }
        {
            const uint32_t updatedAddress = r0 + 0xC28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E38U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5E40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Fishing_UpdateEffects_001BFB74(frame, context, state, 0x001BFB74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5E40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5E40;
    }
block_003B5E40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5E40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5E40U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E40U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B5E4CU + 0xC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E44U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B5E50U + 0xD0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E48U, address);
            }
            r11 = value;
        }
        {
            const uint32_t address = 0x003B5E54U + 196U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E4CU, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E50U, address);
            }
            r10 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t address = 0x003B5E60U + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E58U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x003B5E64U + 192U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E5CU, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x003B5E68U + 192U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E60U, address);
            }
            frame.Guest.vfp[29] = value;
        }
        {
            const uint32_t address = 0x003B5E6CU + 192U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E64U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x003B5E70U + 192U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E68U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t address = 0x003B5E74U + 192U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E6CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x003B5E78U + 192U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E70U, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5E74U, address);
            }
        }
        goto block_003B5E78;
    }
block_003B5E78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5E78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5E78U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x30U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E78U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003B62BC; }
        goto block_003B5E84;
    }
block_003B5E84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5E84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5E84U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x32U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E84U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B5E90U + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5E88U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000018U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5E94U, address);
            }
        }
        {
            r1 = r4;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5EA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProjectPos_00368CC0(frame, context, state, 0x00368CC0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5EA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5EA4;
    }
block_003B5EA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5EA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5EA4U);
        }
        {
            const uint32_t address = r4 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5EA4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5EA8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5EACU, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_003B6004; }
        goto block_003B5EB8;
    }
block_003B5EB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5EB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5EB8U);
        }
        {
            const uint32_t address = r4 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5EB8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x003B5EC4U + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5EBCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5EC0U, 0xEEF00AE0U};
            frame.Guest.vfp[1] = frame.Guest.vfp[1] & 0x7FFFFFFFU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5EC4U, 0xEE301A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5EC8U, 0xEEF40AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        goto block_003B5F44;
    }
block_003B5F44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5F44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5F44U);
        }
        if (flags.C()) { goto block_003B6004; }
        goto block_003B5F48;
    }
block_003B5F48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5F48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5F48U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5F4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003B5F58U + 0x3F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5F50U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            r0 = 0x00000002U;
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B5F60U, address);
            }
        }
        {
            const uint32_t address = r4 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5F64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5F68U, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r4 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B5F70U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = 0x003B5F80U + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5F78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B5F7CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5F80U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003B62BC; }
        goto block_003B5F8C;
    }
block_003B5F8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5F8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5F8CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x30U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5F8CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003B60B0; }
        goto block_003B5F98;
    }
block_003B5F98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5F98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5F98U);
        }
        {
            const uint32_t address = r4 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5F98U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r10 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5F9CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r10 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5FA0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B5FACU + 0x3ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5FA4U, address);
            }
            r6 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5FA8U, 0xEE700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5FACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5FB0U, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5FB4U, 0xEE201AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5FB8U, 0xEE001A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5FBCU, 0xEEB18AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003B5FEC; }
        goto block_003B5FCC;
    }
block_003B5FCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5FCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5FCCU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5FD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Atan2F_003675F8(frame, context, state, 0x003675F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5FD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5FD0;
    }
block_003B5FD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5FD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5FD0U);
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B5FD0U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5FD4U, 0xEE3C0A48U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[24], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[22];
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B5FE4U, 0xEE200A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B5FECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B5FECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B5FEC;
    }
block_003B5FEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5FECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5FECU);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5FECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B5FF0U, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003B60A0; }
        goto block_003B5FFC;
    }
block_003B5FFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B5FFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B5FFCU);
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[22];
        }
        goto block_003B602C;
    }
block_003B6004:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6004U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6004U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6008U, address);
            }
        }
        {
            const uint32_t address = r4 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B600CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6010U, 0xEE300A4BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6014U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6018U, 0xEEB40AE9U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C()) || (flags.Z())) {
            const uint32_t address = r4 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003B6020U, address);
            }
        }
        if (!(flags.C()) || (flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6024U, address);
            }
        }
        goto block_003B62BC;
    }
block_003B602C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B602CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B602CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B602CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FEU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003B6094; }
        goto block_003B6038;
    }
block_003B6038:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6038U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6038U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6038U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000064U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_003B6094; }
        goto block_003B6044;
    }
block_003B6044:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6044U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6044U);
        }
        {
            const uint32_t address = r4 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6044U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6048U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B604CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6050U, 0xEE700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6054U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6058U, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B605CU, 0xEE201AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6060U, 0xEE001A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6064U, 0xEEB18AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003B6094; }
        goto block_003B6074;
    }
block_003B6074:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6074U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6074U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6078U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Atan2F_003675F8(frame, context, state, 0x003675F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6078U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6078;
    }
block_003B6078:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6078U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6078U);
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6078U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B607CU, 0xEE3C0A48U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[24], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B608CU, 0xEE200A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6094U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6094U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6094;
    }
block_003B6094:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6094U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6094U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x130U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6094U, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003B602C; }
        goto block_003B60A0;
    }
block_003B60A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B60A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B60A0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[26];
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        goto block_003B62B8;
    }
block_003B60B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B60B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B60B0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003B62BC; }
        goto block_003B60B8;
    }
block_003B60B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B60B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B60B8U);
        }
        {
            const uint32_t address = r4 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B60B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r10 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B60BCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r10 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B60C0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B60C4U, 0xEE700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B60C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B60CCU, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B60D0U, 0xEE201AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B60D4U, 0xEE001A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B60D8U, 0xEEB11AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[2];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r11, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003B6100; }
        goto block_003B60E8;
    }
block_003B60E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B60E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B60E8U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B60ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Atan2S_003758B0(frame, context, state, 0x003758B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B60ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B60EC;
    }
block_003B60EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B60ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B60ECU);
        }
        {
            r1 = r0;
        }
        {
            r3 = 0x00000300U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6100U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6100U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6100;
    }
block_003B6100:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6100U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6100U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6100U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6104U, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003B6228; }
        goto block_003B6110;
    }
block_003B6110:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6110U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6110U);
        }
        {
            const uint32_t updatedAddress = 0x003B6118U + 0x244U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6110U, address);
            }
            r8 = value;
        }
        {
            const uint32_t address = 0x003B611CU + 580U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6114U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x003B6120U + 564U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6118U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        goto block_003B611C;
    }
block_003B611C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B611CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B611CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B611CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FEU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003B621C; }
        goto block_003B6128;
    }
block_003B6128:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6128U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6128U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6128U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000064U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_003B621C; }
        goto block_003B6134;
    }
block_003B6134:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6134U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6134U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1A9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6134U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003B6174; }
        goto block_003B6140;
    }
block_003B6140:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6140U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6140U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6144U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B614CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6150U, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6158U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B615CU, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6164U, 0xEE000AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6168U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_003B619C;
    }
block_003B6174:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6174U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6174U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6174U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B617CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6184U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6188U, 0xEE690A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6190U, 0xEE100AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6194U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_003B619C;
    }
block_003B619C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B619CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B619CU);
        }
        {
            const uint32_t address = r4 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B619CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B61A0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B61A4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r6 = r0 & 0x000000FFU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B61ACU, 0xEE700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B61B0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B61B4U, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B61B8U, 0xEE201AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B61BCU, 0xEE001A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B61C0U, 0xEEB18AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r11, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003B61E8; }
        goto block_003B61D0;
    }
block_003B61D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B61D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B61D0U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B61D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Atan2S_003758B0(frame, context, state, 0x003758B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B61D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B61D4;
    }
block_003B61D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B61D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B61D4U);
        }
        {
            r1 = r0;
        }
        {
            r3 = 0x00000300U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B61E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B61E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B61E8;
    }
block_003B61E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B61E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B61E8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003B621C; }
        goto block_003B61F0;
    }
block_003B61F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B61F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B61F0U);
        }
        {
            const uint32_t updatedAddress = 0x003B61F8U + 0x16CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B61F0U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003B621C; }
        goto block_003B6200;
    }
block_003B6200:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6200U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6200U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        if ((flags.C()) && !(flags.Z())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[23];
        }
        {
            const uint32_t operand = 0x0000002CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B621CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B621CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B621C;
    }
block_003B621C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B621CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B621CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x130U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B621CU, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003B611C; }
        goto block_003B6228;
    }
block_003B6228:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6228U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6228U);
        }
        {
            r3 = 0x00000050U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B623CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B623CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B623C;
    }
block_003B623C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B623CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B623CU);
        }
        {
            const uint32_t updatedAddress = 0x003B6244U - 0x370U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B623CU, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6240U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003B624CU + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6244U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6248U, address);
            }
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6250U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6250U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6250;
    }
block_003B6250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6250U);
        }
        {
            r5 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x32U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6254U, address);
            }
            r0 = value;
        }
        {
            r8 = r1;
        }
        {
            r0 = Oot3dAotLsl(r0, 12U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6268U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6268U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6268;
    }
block_003B6268:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6268U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6268U);
        }
        {
            const uint32_t updatedAddress = r7 + 0xA98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6268U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003B6274U + 248U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B626CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6270U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6274U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6278U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            const uint32_t operand = 0x0000002CU;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6284U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6288U, 0xEE700AA1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B628CU, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r8;
        }
        {
            const uint32_t address = r6 + 164U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6294U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6298U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B629CU, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r5;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B62A4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B62A8U, 0xEE400A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[23];
        }
        {
            const uint32_t address = r4 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003B62B0U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[29];
        }
        goto block_003B62B8;
    }
block_003B62B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B62B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B62B8U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B62BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B62BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B62BC;
    }
block_003B62BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B62BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B62BCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B62BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000040U;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000067U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r13 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B62D0U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_003B5E78; }
        goto block_003B62D8;
    }
block_003B62D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B62D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B62D8U);
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B62E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Fishing_UpdateGroupFishes_001141F4(frame, context, state, 0x001141F4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B62E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B62E0;
    }
block_003B62E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B62E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B62E0U);
        }
        {
            const uint32_t updatedAddress = 0x003B62E8U - 0x414U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B62E0U, address);
            }
            r4 = value;
        }
        {
            const uint32_t address = 0x003B62ECU + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B62E4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B62E8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003B6344; }
        goto block_003B62F4;
    }
block_003B62F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B62F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B62F4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B62F4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003B6344; }
        goto block_003B6300;
    }
block_003B6300:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6300U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6300U);
        }
        {
            const uint32_t address = r9 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6300U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B630CU + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6304U, address);
            }
            r2 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003B6344; }
        goto block_003B6314;
    }
block_003B6314:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6314U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6314U);
        }
        {
            const uint32_t address = r9 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6314U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B6320U - 0x418U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6318U, address);
            }
            r2 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B631CU, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_003B6344; }
        goto block_003B632C;
    }
block_003B632C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B632CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B632CU);
        }
        {
            const uint32_t address = r9 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003B632CU, address);
            }
        }
        {
            const uint32_t address = r9 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003B6330U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6334U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r1 = 0x0000000AU;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003B6340U, address);
            }
        }
        goto block_003B6344;
    }
block_003B6344:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6344U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6344U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6344U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        goto block_003B6378;
    }
block_003B6378:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6378U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6378U);
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003B643C; }
        goto block_003B6380;
    }
block_003B6380:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6380U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6380U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = 0x003B638CU + 0x484U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6384U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r9 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6388U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B6394U - 0x48CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B638CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6394U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B639CU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B63A0U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B63A4U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r3, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_003B643C; }
        goto block_003B63B4;
    }
block_003B63B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B63B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B63B4U);
        }
        {
            const uint32_t updatedAddress = r0 - 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B63B4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r9 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B63B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00A80000U;
            r2 = r3 - operand;
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B63C4U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B63C8U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B63CCU, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_003B643C; }
        goto block_003B63DC;
    }
block_003B63DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B63DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B63DCU);
        }
        {
            const uint32_t updatedAddress = r0 - 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B63DCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r9 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B63E0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B63E8U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B63ECU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B63F0U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003B643C; }
        goto block_003B6400;
    }
block_003B6400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6400U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6404U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003B6410U + 0x404U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6408U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B6414U + 0x404U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B640CU, address);
            }
            r2 = value;
        }
        {
            r0 = 0x00000014U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6414U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003B6418U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x003B6428U + 0x3F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6420U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6430U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6430U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6430;
    }
block_003B6430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6430U);
        }
        {
            r1 = 0x00000014U;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B643CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_SetBGM_003655D0(frame, context, state, 0x003655D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B643CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B643C;
    }
block_003B643C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B643CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B643CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B643CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B6448U + 0x3E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6440U, address);
            }
            r6 = value;
        }
        {
            const uint32_t address = 0x003B644CU + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6444U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6450U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6454U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003B6460U + 964U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6458U, address);
            }
            frame.Guest.vfp[28] = value;
        }
        {
            const uint32_t address = 0x003B6464U + 964U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B645CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x003B6468U + 964U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6460U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x003B646CU + 968U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6464U, address);
            }
            frame.Guest.vfp[27] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r11 = ~(0x00000004U);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r5 = r6 - operand;
        }
        if (flags.Z()) { goto block_003B6794; }
        goto block_003B6478;
    }
block_003B6478:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6478U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6478U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003B68BC; }
        goto block_003B6480;
    }
block_003B6480:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6480U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6480U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003B651C; }
        goto block_003B6488;
    }
block_003B6488:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6488U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6488U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003B66E0; }
        goto block_003B6490;
    }
block_003B6490:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6490U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6490U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003B7084; }
        goto block_003B6498;
    }
block_003B6498:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6498U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6498U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003B7084; }
        goto block_003B64A0;
    }
block_003B64A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B64A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B64A0U);
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B64A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B64A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B64A8;
    }
block_003B64A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B64A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B64A8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B64A8U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B64BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B64BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B64BC;
    }
block_003B64BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B64BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B64BCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B64BCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B64CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B64CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B64CC;
    }
block_003B64CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B64CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B64CCU);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B64D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B64D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B64D8;
    }
block_003B64D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B64D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B64D8U);
        }
        {
            const uint32_t address = r0 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B64D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B64DCU, address);
            }
        }
        {
            const uint32_t address = r0 + 144U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B64E0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B64E4U, address);
            }
        }
        {
            const uint32_t address = r0 + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B64E8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B64ECU, address);
            }
        }
        {
            const uint32_t address = r0 + 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B64F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B64F4U, address);
            }
        }
        {
            const uint32_t address = r0 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B64F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B64FCU, address);
            }
        }
        {
            const uint32_t address = r0 + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6500U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t address = r6 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6508U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B650CU, address);
            }
        }
        {
            r0 = 0x0000000CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6518U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Interface_ChangeAlpha_0034BE04(frame, context, state, 0x0034BE04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6518U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6518;
    }
block_003B6518:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6518U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6518U);
        }
        {
            const uint32_t address = r4 + 264U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003B6518U, address);
            }
        }
        goto block_003B651C;
    }
block_003B651C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B651CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B651CU);
        }
        {
            const uint32_t updatedAddress = 0x003B6524U + 0x314U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B651CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6520U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6528U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ShrinkWindow_SetVal_00338CD8(frame, context, state, 0x00338CD8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6528U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6528;
    }
block_003B6528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6528U);
        }
        {
            const uint32_t updatedAddress = 0x003B6530U + 0x30CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6528U, address);
            }
            r10 = value;
        }
        {
            const uint32_t address = r9 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B652CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r10 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6530U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6534U, 0xEE700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 140U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003B6538U, address);
            }
        }
        {
            const uint32_t address = r10 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B653CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r9 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6540U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6544U, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6548U, 0xEE201AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 148U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B654CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6550U, 0xEE001A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6554U, 0xEEB18AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B655CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Atan2F_003675F8(frame, context, state, 0x003675F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B655CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B655C;
    }
block_003B655C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B655CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B655CU);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6568U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Matrix_RotateY_003735E8(frame, context, state, 0x003735E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6568U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6568;
    }
block_003B6568:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6568U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6568U);
        }
        {
            const uint32_t address = r13 + 164U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003B6568U, address);
            }
        }
        {
            const uint32_t address = 0x003B6574U + 716U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B656CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = r13 + 168U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003B6570U, address);
            }
        }
        {
            const uint32_t address = r13 + 172U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x003B6574U, address);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000054U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6588U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6588U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6588;
    }
block_003B6588:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6588U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6588U);
        }
        {
            const uint32_t address = r13 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6588U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B658CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6590U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6594U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[17] = frame.Guest.vfp[23];
        }
        if (flags.Z()) {
            frame.Guest.vfp[17] = frame.Guest.vfp[22];
        }
        {
            const uint32_t updatedAddress = 0x003B65ACU + 0x284U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B65A4U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B65A8U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r10 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B65ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B65B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B65B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B65B8;
    }
block_003B65B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B65B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B65B8U);
        }
        {
            const uint32_t address = r4 + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B65B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003B65C4U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B65BCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r6 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B65C4U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r10 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B65CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B65D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B65D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B65D4;
    }
block_003B65D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B65D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B65D4U);
        }
        {
            const uint32_t address = r13 + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B65D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B65D8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r6 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B65E0U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B65E4U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r10 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B65ECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B65F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B65F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B65F4;
    }
block_003B65F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B65F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B65F4U);
        }
        {
            const uint32_t address = r4 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B65F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000000A4U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000054U;
            r1 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6600U, 0xEEB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        {
            const uint32_t address = r13 + 164U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6604U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6608U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t address = 0x003B6618U + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6610U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x003B661CU + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6614U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000098U;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 168U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B661CU, address);
            }
        }
        {
            const uint32_t address = 0x003B6628U + 552U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6620U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 172U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6624U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B662CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B662CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B662C;
    }
block_003B662C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B662CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B662CU);
        }
        {
            const uint32_t address = r13 + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B662CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r9 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6630U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x003B663CU + 536U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6634U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B6640U + 0x218U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6638U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B663CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[21];
        }
        {
            const uint32_t address = r13 + 152U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6644U, address);
            }
        }
        {
            const uint32_t address = r13 + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6648U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r9 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B664CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6650U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 156U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6654U, address);
            }
        }
        {
            const uint32_t address = r13 + 160U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6658U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r9 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B665CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6660U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[23];
        }
        {
            const uint32_t address = r13 + 160U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6668U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[28];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6674U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6674U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6674;
    }
block_003B6674:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6674U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6674U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6674U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6678U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000200U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000200U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003B6928; }
        goto block_003B6684;
    }
block_003B6684:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6684U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6684U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x14U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6684U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r4 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B668CU, address);
            }
            r1 = value;
        }
        if ((flags.N()) == (flags.V())) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003B6928; }
        goto block_003B6698;
    }
block_003B6698:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6698U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6698U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B66A4U, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000000U;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r4 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B66ACU, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003B66C0; }
        goto block_003B66B4;
    }
block_003B66B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B66B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B66B4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003B6908; }
        goto block_003B66C0;
    }
block_003B66C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B66C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B66C0U);
        }
        {
            const uint32_t updatedAddress = 0x003B66C8U + 0x14CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B66C0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B66CCU + 0x14CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B66C4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B66D0U + 0x18CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B66C8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003B66D0U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        goto block_003B6924;
    }
block_003B66E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B66E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B66E0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003B6B38; }
        goto block_003B66E8;
    }
block_003B66E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B66E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B66E8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003B7084; }
        goto block_003B66F0;
    }
block_003B66F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B66F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B66F0U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6700U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6700U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6700;
    }
block_003B6700:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6700U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6700U);
        }
        {
            r0 = r7;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B670CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B670CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B670C;
    }
block_003B670C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B670CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B670CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B670CU, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6720U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6720U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6720;
    }
block_003B6720:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6720U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6720U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6720U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6730U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6730U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6730;
    }
block_003B6730:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6730U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6730U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6730U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000005U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6740U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6740U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6740;
    }
block_003B6740:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6740U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6740U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B674CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B674CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B674C;
    }
block_003B674C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B674CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B674CU);
        }
        {
            const uint32_t address = r0 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B674CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B6758U + 0x108U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6750U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r5 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6754U, address);
            }
        }
        {
            const uint32_t address = r0 + 144U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6758U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = r5 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6760U, address);
            }
        }
        {
            const uint32_t address = r0 + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6764U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6768U, address);
            }
        }
        {
            const uint32_t address = r0 + 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B676CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6770U, address);
            }
        }
        {
            const uint32_t address = r0 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6774U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6778U, address);
            }
        }
        {
            const uint32_t address = r0 + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B677CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t address = r6 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6784U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B678CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B678CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B678C;
    }
block_003B678C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B678CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B678CU);
        }
        {
            r0 = 0x0000000BU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6790U, address);
            }
        }
        goto block_003B6794;
    }
block_003B6794:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6794U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6794U);
        }
        {
            const uint32_t address = r9 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003B6794U, address);
            }
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t address = r9 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003B679CU, address);
            }
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B67A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B67A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B67A8;
    }
block_003B67A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B67A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B67A8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_003B7084; }
        goto block_003B67B4;
    }
block_003B67B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B67B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B67B4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B67B4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B67C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B67C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B67C0;
    }
block_003B67C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B67C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B67C0U);
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B67C0U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B67C0U,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003B67C0U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B67C8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B67C8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x003B67C8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B67D0U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B67D0U,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003B67D0U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B67D8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B67D8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x003B67D8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r6;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003B67DCU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B67DCU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B67DCU,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003B67E0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B67E0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B67E0U,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B67E8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B67F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B67F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B67F4;
    }
block_003B67F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B67F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B67F4U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6804U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6804U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6804;
    }
block_003B6804:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6804U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6804U);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r7;
        }
        goto block_003B6864;
    }
block_003B6864:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6864U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6864U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6864U, address);
            }
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B686CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B686CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B686C;
    }
block_003B686C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B686CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B686CU);
        }
        {
            const uint32_t updatedAddress = 0x003B6874U - 0x518U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B686CU, address);
            }
            r0 = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003B6874U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003B6878U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B687CU, address);
            }
            r0 = value;
        }
        {
            r1 = r6;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6888U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6890U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6894U, 0xEE8A0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6898U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B689CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B68A4U, address);
            }
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B68B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_direct_target_00316D74_00316D74(frame, context, state, 0x00316D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B68B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B68B0;
    }
block_003B68B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B68B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B68B0U);
        }
        {
            const uint32_t updatedAddress = 0x003B68B8U + 0x484U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B68B0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r7;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003B68B4U, address);
            }
        }
        goto block_003B7084;
    }
block_003B68BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B68BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B68BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003B6C00; }
        goto block_003B68C4;
    }
block_003B68C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B68C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B68C4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000015U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003B6CD8; }
        goto block_003B68CC;
    }
block_003B68CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B68CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B68CCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000016U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003B6D88; }
        goto block_003B68D4;
    }
block_003B68D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B68D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B68D4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000064U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003B7084; }
        goto block_003B68DC;
    }
block_003B68DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B68DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B68DCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B68DCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003B7118; }
        goto block_003B68E8;
    }
block_003B68E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B68E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B68E8U);
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B68F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B68F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B68F0;
    }
block_003B68F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B68F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B68F0U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B68FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_byte_1b6_00367C48(frame, context, state, 0x00367C48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B68FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B68FC;
    }
block_003B68FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B68FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B68FCU);
        }
        {
        }
        {
        }
        goto block_003B7084;
    }
block_003B6908:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6908U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6908U);
        }
        {
            const uint32_t updatedAddress = 0x003B6910U - 0xFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6908U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B6914U - 0xFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B690CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B6918U + 0x428U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6910U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003B6918U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        goto block_003B6924;
    }
block_003B6924:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6924U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6924U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6928U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6928U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6928;
    }
block_003B6928:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6928U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6928U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6928U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_003B696C; }
        goto block_003B6934;
    }
block_003B6934:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6934U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6934U);
        }
        {
            const uint32_t updatedAddress = 0x003B693CU + 0x408U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6934U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            r0 = ~(0x00000000U);
        }
        if ((flags.N()) != (flags.V())) { goto block_003B6968; }
        goto block_003B6948;
    }
block_003B6948:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6948U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6948U);
        }
        {
            const uint32_t updatedAddress = 0x003B6950U + 0x3F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6948U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003B696C; }
        goto block_003B6958;
    }
block_003B6958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6958U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x14U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6958U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003B696C; }
        goto block_003B6964;
    }
block_003B6964:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6964U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6964U);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_003B6968;
    }
block_003B6968:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6968U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6968U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6968U, address);
            }
        }
        goto block_003B696C;
    }
block_003B696C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B696CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B696CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B696CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6970U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6978U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6978U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6978;
    }
block_003B6978:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6978U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6978U);
        }
        {
            r8 = r0;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6984U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_byte_1b6_00367C48(frame, context, state, 0x00367C48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6984U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6984;
    }
block_003B6984:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6984U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6984U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x14U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6984U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t address = r7 + 432U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B698CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t address = r8 + 208U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6990U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003B6AB4; }
        goto block_003B6998;
    }
block_003B6998:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6998U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6998U);
        }
        {
            const uint32_t address = r13 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6998U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B699CU, 0xEE600A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B69A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B69A4U, 0xEE400A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B69A8U, 0xEEB10AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x003B69B4U + 920U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B69ACU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B69B0U, 0xEE208A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = 0x003B69C4U + 908U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B69BCU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t address = r4 + 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B69C4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B69C8U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B69D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_clear_byte_1b6_00367C54(frame, context, state, 0x00367C54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B69D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B69D4;
    }
block_003B69D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B69D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B69D4U);
        }
        {
            const uint32_t address = r6 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B69D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B69D8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B69DCU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B69E0U, 0xEE301A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B69E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B69E8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B69ECU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B69F0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B69F4U, 0xEE700AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B69F8U, 0xEE211A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B69FCU, 0xEE001A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A00U, 0xEE001AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A04U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A08U, 0xEEB10AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A0CU, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            const uint32_t address = r4 + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A14U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.C())) { goto block_003B6A4C; }
        goto block_003B6A1C;
    }
block_003B6A1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6A1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6A1CU);
        }
        {
            const uint32_t address = r4 + 192U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A1CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A20U, 0xEEB40AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = r4 + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A28U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003B6A4C; }
        goto block_003B6A30;
    }
block_003B6A30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6A30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6A30U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A30U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A34U, 0xEE710A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A38U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A3CU, 0xEEC00A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A40U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A44U, 0xEE311A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A48U, 0xEE010A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        goto block_003B6A4C;
    }
block_003B6A4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6A4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6A4CU);
        }
        {
            const uint32_t address = r8 + 208U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A4CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x003B6A58U + 764U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A50U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A54U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A58U, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A5CU, 0xEE380AAAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[17], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 208U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003B6A60U, address);
            }
        }
        {
            const uint32_t address = r10 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A64U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r13 + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A6CU, 0xEE080A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A70U, 0xEE311A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A74U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 152U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003B6A78U, address);
            }
        }
        {
            const uint32_t address = r10 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A7CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r13 + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A80U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A84U, 0xEE711A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[24];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A8CU, 0xEE011A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6A90U, 0xEE710A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 156U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003B6A94U, address);
            }
        }
        {
            const uint32_t address = r10 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A98U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r13 + 160U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6A9CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6AA0U, 0xEE311A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6AA4U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x003B6AB0U + 680U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6AA8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 160U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003B6AACU, address);
            }
        }
        {
            const uint32_t address = r4 + 248U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6AB0U, address);
            }
        }
        goto block_003B6AB4;
    }
block_003B6AB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6AB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6AB4U);
        }
        {
            const uint32_t address = r13 + 164U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003B6AB4U, address);
            }
        }
        {
            const uint32_t address = r13 + 168U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003B6AB8U, address);
            }
        }
        {
            const uint32_t address = r13 + 172U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x003B6ABCU, address);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000054U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6AD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6AD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6AD0;
    }
block_003B6AD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6AD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6AD0U);
        }
        {
            const uint32_t address = r13 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6AD0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6AD4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x003B6AE0U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6AD8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6ADCU, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            const uint32_t updatedAddress = 0x003B6AE8U + 0x278U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6AE0U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6AE4U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r13 + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6AECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6AF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6AF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6AF4;
    }
block_003B6AF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6AF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6AF4U);
        }
        {
            const uint32_t address = r4 + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6AF4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6B00U, 0xEE201A0CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[24], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6B04U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6B0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6B0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6B0C;
    }
block_003B6B0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6B0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6B0CU);
        }
        {
            const uint32_t address = r13 + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6B0CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6B10U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6B18U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6B1CU, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r13 + 160U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6B24U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6B2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6B2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6B2C;
    }
block_003B6B2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6B2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6B2CU);
        }
        {
        }
        {
        }
        goto block_003B7084;
    }
block_003B6B38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6B38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6B38U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6B38U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6B44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6B44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6B44;
    }
block_003B6B44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6B44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6B44U);
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B6B44U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B6B44U,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003B6B44U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B6B4CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B6B4CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x003B6B4CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B6B54U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B6B54U,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003B6B54U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B6B5CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B6B5CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x003B6B5CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r6;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003B6B60U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B6B60U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B6B60U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003B6B64U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B6B64U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B6B64U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6B68U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003B6B98; }
        goto block_003B6B74;
    }
block_003B6B74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6B74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6B74U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6B74U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6B7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6B7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6B7C;
    }
block_003B6B7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6B7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6B7CU);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6B88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_byte_1b6_00367C48(frame, context, state, 0x00367C48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6B88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6B88;
    }
block_003B6B88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6B88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6B88U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6B88U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6B98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6B98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6B98;
    }
block_003B6B98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6B98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6B98U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6BA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6BA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6BA8;
    }
block_003B6BA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6BA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6BA8U);
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003B6BACU, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003B6BB8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6BC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_direct_target_00316D74_00316D74(frame, context, state, 0x00316D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6BC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6BC0;
    }
block_003B6BC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6BC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6BC0U);
        }
        {
            const uint32_t updatedAddress = 0x003B6BC8U + 0x174U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6BC0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B6BCCU + 0x198U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6BC4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r7;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003B6BC8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003B6BD4U - 0x878U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6BCCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r9;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x003B6BD0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6BD4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6BDCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6BE4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6BE8U, 0xEE880A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[17], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6BECU, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6BF0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6BF8U, address);
            }
        }
        goto block_003B7084;
    }
block_003B6C00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6C00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6C00U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6C10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6C10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6C10;
    }
block_003B6C10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6C10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6C10U);
        }
        {
            r0 = r7;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6C1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6C1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6C1C;
    }
block_003B6C1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6C1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6C1CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6C1CU, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6C30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6C30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6C30;
    }
block_003B6C30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6C30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6C30U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6C30U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6C40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6C40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6C40;
    }
block_003B6C40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6C40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6C40U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6C40U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000005U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6C50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6C50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6C50;
    }
block_003B6C50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6C50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6C50U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6C5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6C5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6C5C;
    }
block_003B6C5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6C5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6C5CU);
        }
        {
            const uint32_t address = r0 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6C5CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B6C68U + 0x100U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6C60U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r5 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6C64U, address);
            }
        }
        {
            const uint32_t address = r0 + 144U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6C68U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = r5 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6C70U, address);
            }
        }
        {
            const uint32_t address = r0 + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6C74U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6C78U, address);
            }
        }
        {
            const uint32_t address = r0 + 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6C7CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6C80U, address);
            }
        }
        {
            const uint32_t address = r0 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6C84U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6C88U, address);
            }
        }
        {
            const uint32_t address = r0 + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6C8CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t address = r6 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6C94U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6C9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6C9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6C9C;
    }
block_003B6C9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6C9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6C9CU);
        }
        {
            r0 = 0x00000015U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6CA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003B6CACU - 0x950U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6CA4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003B6CB0U + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6CA8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 260U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6CACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6CB0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6CB8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6CC0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6CC4U, 0xEE8E0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[28], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6CC8U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6CCCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6CD4U, address);
            }
        }
        goto block_003B6CD8;
    }
block_003B6CD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6CD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6CD8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6CD8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003B7084; }
        goto block_003B6CE4;
    }
block_003B6CE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6CE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6CE4U);
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6CECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_ShouldAdvance_00346964(frame, context, state, 0x00346964U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6CECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6CEC;
    }
block_003B6CEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6CECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6CECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_003B7084; }
        goto block_003B6CF8;
    }
block_003B6CF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6CF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6CF8U);
        }
        {
            r0 = 0x00000016U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6CFCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003B6D08U - 0x9ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6D00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003B6D0CU + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6D04U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = 0x0000001CU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6D0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6D14U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6D1CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6D20U, 0xEE800A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6D24U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6D28U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6D30U, address);
            }
        }
        {
            r0 = r7;
        }
        goto block_003B6D74;
    }
block_003B6D74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6D74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6D74U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6D74U, address);
            }
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6D7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6D7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6D7C;
    }
block_003B6D7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6D7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6D7CU);
        }
        {
            const uint32_t address = r4 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003B6D7CU, address);
            }
        }
        {
        }
        goto block_003B7084;
    }
block_003B6D88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6D88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6D88U);
        }
        {
            const uint32_t updatedAddress = 0x003B6D90U - 0xA34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6D88U, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6D8CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6D90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6D98U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6DA0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6DA4U, 0xEE8A0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6DA8U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6DACU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003B6DCC; }
        goto block_003B6DBC;
    }
block_003B6DBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6DBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6DBCU);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x003B6DC8U + 0x3A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6DC0U, address);
            }
            r1 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6DCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_QueueSeqCmd_0036EC40(frame, context, state, 0x0036EC40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6DCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6DCC;
    }
block_003B6DCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6DCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6DCCU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[27];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r4 + 0xBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6DD8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003B6DE4U + 0x390U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6DDCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003B6DE8U + 904U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6DE0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6DE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6DE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6DE8;
    }
block_003B6DE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6DE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6DE8U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6DE8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x003B6DF4U + 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6DECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6DFCU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6E00U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x003B6E0CU + 880U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E04U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6E08U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6E10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Matrix_RotateY_003735E8(frame, context, state, 0x003735E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6E10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6E10;
    }
block_003B6E10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6E10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6E10U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E10U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xBF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E14U, address);
            }
            r0 = value;
        }
        {
            r0 = Oot3dAotLsl(r0, 12U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6E24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6E24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6E24;
    }
block_003B6E24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6E24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6E24U);
        }
        {
            const uint32_t address = r13 + 164U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6E24U, address);
            }
        }
        {
            const uint32_t address = r4 + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E28U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003B6E34U + 844U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E2CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 168U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6E30U, address);
            }
        }
        {
            const uint32_t address = r13 + 172U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003B6E34U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E38U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x000000A4U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000054U;
            r1 = r13 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6E48U, 0x0E300A4CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[24], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000098U;
            r0 = r13 + operand;
        }
        if (flags.Z()) {
            const uint32_t address = r13 + 168U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6E50U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6E58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6E58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6E58;
    }
block_003B6E58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6E58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6E58U);
        }
        {
            const uint32_t address = r9 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E58U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E5CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B6E68U + 0x31CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E60U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003B6E6CU + 796U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E64U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6E68U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6E6CU, address);
            }
        }
        {
            const uint32_t address = r9 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E70U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E74U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6E78U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6E7CU, address);
            }
        }
        {
            const uint32_t address = r9 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E80U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 160U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E84U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6E88U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[23];
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6E90U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = 0x003B6EA0U + 0x2ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6E98U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6EA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6EA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6EA0;
    }
block_003B6EA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6EA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6EA0U);
        }
        {
            const uint32_t address = r4 + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6EA0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003B6EACU + 744U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6EA4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x003B6EB0U + 736U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6EA8U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6EACU, 0xEE300A68U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x000000A4U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000054U;
            r1 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 164U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6EB8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6EBCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t address = 0x003B6ECCU + 716U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6EC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) {
            const uint32_t address = r13 + 168U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003B6EC8U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = r13 + 172U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6ECCU, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t address = r13 + 168U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x003B6ED0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003B6EDCU - 0x17CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6ED4U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t address = r13 + 172U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x003B6ED8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6EE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6EE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6EE0;
    }
block_003B6EE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6EE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6EE0U);
        }
        {
            const uint32_t address = r5 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6EE0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r9 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6EE4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r9 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6EECU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6EF0U, address);
            }
        }
        {
            const uint32_t address = r5 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6EF4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r9 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6EF8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6EFCU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6F00U, address);
            }
        }
        {
            const uint32_t address = r5 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6F04U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r9 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6F08U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6F0CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6F10U, address);
            }
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003B6F14U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B6F14U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B6F14U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003B6F18U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B6F18U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B6F18U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6F1CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r6 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6F20U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6F28U, 0x0E300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x003B6F34U + 616U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6F2CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (!(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B6F30U, 0x1E300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B6F34U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6F38U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003B7084; }
        goto block_003B6F44;
    }
block_003B6F44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6F44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6F44U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            r8 = r0;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6F54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6F54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6F54;
    }
block_003B6F54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6F54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6F54U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003B6F6C; }
        goto block_003B6F5C;
    }
block_003B6F5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6F5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6F5CU);
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6F64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6F64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6F64;
    }
block_003B6F64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6F64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6F64U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003B7084; }
        goto block_003B6F6C;
    }
block_003B6F6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6F6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6F6CU);
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6F74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_ShouldAdvance_00346964(frame, context, state, 0x00346964U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6F74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6F74;
    }
block_003B6F74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6F74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6F74U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_003B7084; }
        goto block_003B6F80;
    }
block_003B6F80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6F80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6F80U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6F80U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6F8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6F8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6F8C;
    }
block_003B6F8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6F8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6F8CU);
        }
        {
            r8 = r0;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6F98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_ResetDisplay_003725E0(frame, context, state, 0x003725E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6F98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6F98;
    }
block_003B6F98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6F98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6F98U);
        }
        {
            r0 = r7;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6FA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetChoiceIndex_00369F3C(frame, context, state, 0x00369F3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6FA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6FA4;
    }
block_003B6FA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6FA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6FA4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_003B6FC0; }
        goto block_003B6FB0;
    }
block_003B6FB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6FB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6FB0U);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6FB4U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x13U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B6FBCU, address);
            }
        }
        goto block_003B6FC0;
    }
block_003B6FC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6FC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6FC0U);
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003B6FC0U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B6FC0U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B6FC0U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r8 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003B6FC8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B6FC8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B6FC8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r0 = r8 + operand;
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003B6FD0U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B6FD0U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B6FD0U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003B6FD4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B6FD4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B6FD4U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r8 + operand;
        }
        {
            const uint32_t firstAddress = r6;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003B6FDCU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B6FDCU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B6FDCU,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003B6FE0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B6FE0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B6FE0U,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B6FE8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B6FF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B6FF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B6FF4;
    }
block_003B6FF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B6FF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B6FF4U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7004U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7004U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7004;
    }
block_003B7004:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7004U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7004U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7004U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7014U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7014U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7014;
    }
block_003B7014:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7014U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7014U);
        }
        {
            const uint32_t updatedAddress = 0x003B701CU - 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7014U, address);
            }
            r1 = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003B701CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003B7020U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + r9;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x003B7024U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7028U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7030U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7038U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B703CU, 0xEE880A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[17], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7040U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7044U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003B7050U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003B7054U, address);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B705CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7060U, 0xEE8A0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7064U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7068U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B7070U, address);
            }
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B707CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_direct_target_00316D74_00316D74(frame, context, state, 0x00316D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B707CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B707C;
    }
block_003B707C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B707CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B707CU);
        }
        {
            const uint32_t updatedAddress = 0x003B7084U - 0x348U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B707CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r7;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003B7080U, address);
            }
        }
        goto block_003B7084;
    }
block_003B7084:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7084U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7084U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7084U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003B7118; }
        goto block_003B7090;
    }
block_003B7090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7090U);
        }
        {
            const uint32_t updatedAddress = 0x003B7098U - 0x338U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7090U, address);
            }
            r3 = value;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r3 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B70A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CameraSetAtEye_00367B14(frame, context, state, 0x00367B14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B70A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B70A0;
    }
block_003B70A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B70A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B70A0U);
        }
        {
            const uint32_t address = 0x003B70A8U - 856U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B70A0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[29];
        }
        {
            const uint32_t updatedAddress = 0x003B70B0U + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B70A8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B70B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B70B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B70B8;
    }
block_003B70B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B70B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B70B8U);
        }
        {
            const uint32_t updatedAddress = r7 + 0xA98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B70B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B70BCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B70C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B70C4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B70CCU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B70D0U, 0xEE700A88U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B70D4U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.C()) && !(flags.Z())) { goto block_003B7218; }
        goto block_003B70E0;
    }
block_003B70E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B70E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B70E0U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B70ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_direct_target_00316D74_00316D74(frame, context, state, 0x00316D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B70ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B70EC;
    }
block_003B70EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B70ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B70ECU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xEU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B70ECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = ~(0x000000B1U);
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x000032C0U;
            r1 = r0 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + r7;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B70FCU, address);
            }
        }
        if (!(flags.Z())) { goto block_003B7110; }
        goto block_003B7104;
    }
block_003B7104:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7104U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7104U);
        }
        {
            const uint32_t updatedAddress = 0x003B710CU - 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7104U, address);
            }
            r1 = value;
        }
        {
            r0 = ~(0x0000002DU);
        }
        {
            const uint32_t updatedAddress = r1 + r7;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B710CU, address);
            }
        }
        goto block_003B7110;
    }
block_003B7110:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7110U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7110U);
        }
        {
            r0 = 0x00000001U;
        }
        goto block_003B7114;
    }
block_003B7114:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7114U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7114U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B7114U, address);
            }
        }
        goto block_003B7118;
    }
block_003B7118:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7118U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7118U);
        }
        {
            const uint32_t updatedAddress = r7 + 0xA98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7118U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r9 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B711CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003B7128U + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7120U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B712CU + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7124U, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7128U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B712CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7134U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7138U, 0xEE700AEDU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[27], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B713CU, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7144U, 0x3E300A2DU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[27], frame.Guest.fpscr));
        }
        if (!(flags.C())) {
            const uint32_t address = r9 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7148U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (!(flags.C())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B714CU, 0x3EF40AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        if (!(flags.C())) {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_003B72B4; }
        goto block_003B7158;
    }
block_003B7158:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7158U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7158U);
        }
        {
            const uint32_t address = r9 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7158U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003B72B4; }
        goto block_003B7168;
    }
block_003B7168:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7168U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7168U);
        }
        goto block_003B71AC;
    }
block_003B71AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B71ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B71ACU);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B71ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xBF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B71B0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003B72B4; }
        goto block_003B71BC;
    }
block_003B71BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B71BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B71BCU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B71C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B71C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B71C4;
    }
block_003B71C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B71C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B71C4U);
        }
        {
            const uint32_t address = r9 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B71C4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B71C8U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B71CCU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B71D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B71D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B71D8;
    }
block_003B71D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B71D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B71D8U);
        }
        {
            const uint32_t address = r9 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B71D8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B71DCU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B71E8U, address);
            }
        }
        {
            const uint32_t address = r9 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B71ECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B71F0U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B71F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B71F8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[26];
        }
        {
            const uint32_t updatedAddress = r0 + 0xC28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7200U, address);
            }
            r6 = value;
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x003B7204U, address);
            }
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B7208U, address);
            }
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003B720CU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        goto block_003B7234;
    }
block_003B7218:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7218U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7218U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7224U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_direct_target_00316D74_00316D74(frame, context, state, 0x00316D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7224U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7224;
    }
block_003B7224:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7224U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7224U);
        }
        {
            const uint32_t updatedAddress = 0x003B722CU - 0x4F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7224U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r1 + r7;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B722CU, address);
            }
        }
        goto block_003B7114;
    }
block_003B7234:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7234U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7234U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x24U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7234U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003B72A0; }
        goto block_003B7240;
    }
block_003B7240:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7240U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7240U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B7244U, address);
            }
        }
        {
            const uint32_t operand = 0x00000048U;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = 0x003B7254U + 776U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B724CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003B7250U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B7250U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B7250U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003B7258U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B7258U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B7258U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003B725CU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B725CU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B725CU,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003B7260U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B7260U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B7260U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x0000003CU;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B726CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B726CU,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003B726CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B7270U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B7270U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x003B7270U,
                                           firstAddress + 8U);
            }
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r6 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B7278U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7280U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7280U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7280;
    }
block_003B7280:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7280U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7280U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7280U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x003B7290U + 720U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7288U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x25U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B728CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7290U, 0xEE290A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x003B7294U, address);
            }
        }
        {
            const uint32_t address = r6 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B7298U, address);
            }
        }
        goto block_003B72B4;
    }
block_003B72A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B72A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B72A0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000040U;
            r6 = r6 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005AU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_003B7234; }
        goto block_003B72B4;
    }
block_003B72B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B72B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B72B4U);
        }
        {
            const uint32_t updatedAddress = r7 + 0xA98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B72B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r9 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B72B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003B72C4U + 672U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B72BCU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B72C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B72C4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B72CCU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B72D0U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_003B73F4; }
        goto block_003B72DC;
    }
block_003B72DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B72DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B72DCU);
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B72E0U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B72E4U, 0xEE700AE8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B72E8U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003B73F4; }
        goto block_003B72F4;
    }
block_003B72F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B72F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B72F4U);
        }
        {
            const uint32_t address = r9 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B72F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B7300U + 0x268U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B72F8U, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) != (flags.V())) { goto block_003B73F4; }
        goto block_003B7308;
    }
block_003B7308:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7308U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7308U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7308U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xBF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B730CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000003U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003B73F4; }
        goto block_003B7318;
    }
block_003B7318:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7318U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7318U);
        }
        {
            const uint32_t operand = 0x00000028U;
            r8 = r9 + operand;
        }
        {
            const uint32_t address = 0x003B7324U + 584U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B731CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x003B7328U + 584U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7320U, address);
            }
            frame.Guest.vfp[28] = value;
        }
        {
            const uint32_t address = 0x003B732CU + 564U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7324U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x003B7330U + 580U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7328U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t address = 0x003B7334U + 580U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B732CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000048U;
            r9 = r13 + operand;
        }
        goto block_003B7338;
    }
block_003B7338:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7338U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7338U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7340U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7340U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7340;
    }
block_003B7340:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7340U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7340U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7340U, 0xEE30BA08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[22], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B734CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B734CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B734C;
    }
block_003B734C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B734CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B734CU);
        }
        {
            frame.Guest.vfp[23] = frame.Guest.vfp[0];
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7358U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7358U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7358;
    }
block_003B7358:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7358U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7358U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7358U, 0xEE200A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B735CU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[23];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7368U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7368U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7368;
    }
block_003B7368:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7368U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7368U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7368U, 0xEE200A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B736CU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[27];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7378U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7378U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7378;
    }
block_003B7378:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7378U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7378U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7378U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B737CU, address);
            }
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003B7380U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003B7380U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B7380U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x003B7384U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003B7384U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B7384U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r13 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7388U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B738CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7390U, 0xEE000A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B7394U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0xA98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7398U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B739CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B73A0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B73A8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B73ACU, address);
            }
        }
        {
            const uint32_t address = r13 + 80U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B73B0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B73B4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B73B8U, 0xEE000A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B73BCU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[28];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B73C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B73C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B73C8;
    }
block_003B73C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B73C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B73C8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B73C8U, 0xEE300A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r13 + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B73CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000048U;
            r2 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xC28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B73D8U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B73E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Fishing_SpawnDustSplash_00346AB4(frame, context, state, 0x00346AB4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B73E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B73E4;
    }
block_003B73E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B73E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B73E4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r6 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r6 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_003B7338; }
        goto block_003B73F4;
    }
block_003B73F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B73F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B73F4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B73F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0xFU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B7400U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7404U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003B7484; }
        goto block_003B7410;
    }
block_003B7410:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7410U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7410U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B741CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B741CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B741C;
    }
block_003B741C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B741CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B741CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7420U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x003B742CU + 0x150U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7424U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r1, Oot3dAotLsl(r0, 20U), static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003B7484; }
        goto block_003B7430;
    }
block_003B7430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7430U);
        }
        {
            r0 = 0x000000C8U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B7434U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B743CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B743CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B743C;
    }
block_003B743C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B743CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B743CU);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003B7470; }
        goto block_003B7448;
    }
block_003B7448:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7448U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7448U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7450U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7450U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7450;
    }
block_003B7450:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7450U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7450U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7450U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = 0x003B745CU + 0x124U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7454U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000005U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B7460U, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + r7;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B7468U, address);
            }
        }
        goto block_003B7484;
    }
block_003B7470:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7470U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7470U);
        }
        {
            const uint32_t updatedAddress = 0x003B7478U + 0x108U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7470U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B7478U, address);
            }
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r1 + r7;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003B7480U, address);
            }
        }
        goto block_003B7484;
    }
block_003B7484:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7484U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7484U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7484U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003B7490U + 244U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7488U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[26];
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x003B74A0U + 0xE8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7498U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B749CU, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B74A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B74A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B74A4;
    }
block_003B74A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B74A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B74A4U);
        }
        {
            const uint32_t address = r4 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B74A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B74A8U, 0xEEF40AE9U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[19],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003B74DC; }
        goto block_003B74B4;
    }
block_003B74B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B74B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B74B4U);
        }
        {
            const uint32_t updatedAddress = 0x003B74BCU + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B74B4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x003B74C0U + 204U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B74B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003B74C4U + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B74BCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B74C0U, 0xEE000AACU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = 0x003B74D8U + 0xC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B74D0U, address);
            }
            r0 = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = 0x003B74DCU + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B74D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B74DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B74DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B74DC;
    }
block_003B74DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B74DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B74DCU);
        }
        {
            const uint32_t address = r4 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B74DCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003B74E8U + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B74E0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B74ECU + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B74E4U, address);
            }
            r6 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B74E8U, 0xEE380AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[17], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r6 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B74F0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B74F4U, 0xEEB40AE9U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[21];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        if (!(flags.C())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B750CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B750CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B750C;
    }
block_003B750C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B750CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B750CU);
        }
        {
            const uint32_t address = r6 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B750CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x003B7518U + 0x8CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7510U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003B7530; }
        goto block_003B7520;
    }
block_003B7520:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7520U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7520U);
        }
        {
            const uint32_t updatedAddress = 0x003B7528U + 0x80U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7520U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r4 + 80U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7524U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = r6 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7530U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySfxWithScaledGain_0036EF10(frame, context, state, 0x0036EF10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7530U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7530;
    }
block_003B7530:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7530U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7530U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7530U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003B75B4; }
        goto block_003B753C;
    }
block_003B753C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B753CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B753CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x003B7548U + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7540U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003B754CU + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7544U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x003B7550U + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7548U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7550U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7550U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7550;
    }
block_003B7550:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7550U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7550U);
        }
        {
        }
        {
        }
        goto block_003B75C4;
    }
block_003B75B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B75B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B75B4U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x003B75C0U - 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B75B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003B75C4U - 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B75BCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B75C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B75C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B75C4;
    }
block_003B75C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B75C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B75C4U);
        }
        {
            const uint32_t address = r4 + 76U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B75C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00003200U;
            r0 = r7 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B75CCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003B75D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003B75D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003B75DCU, address);
            }
        }
        {
            const uint32_t address = r4 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B75E0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B75E4U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t value = r0 & 0x000000FFU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_003B778C; }
        goto block_003B75F4;
    }
block_003B75F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B75F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B75F4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B75F4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7600U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7600U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7600;
    }
block_003B7600:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7600U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7600U);
        }
        {
            const uint32_t address = 0x003B7608U + 436U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7600U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B760CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_GetInputDirYaw_00368FEC(frame, context, state, 0x00368FECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B760CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B760C;
    }
block_003B760C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B760CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B760CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x003B761CU + 420U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7614U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B761CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7620U, 0xEE009A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7624U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7628U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003B778C; }
        goto block_003B763C;
    }
block_003B763C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B763CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B763CU);
        }
        {
            const uint32_t updatedAddress = 0x003B7644U + 0x18CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B763CU, address);
            }
            r8 = value;
        }
        {
            const uint32_t address = 0x003B7648U - 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7640U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t address = 0x003B764CU + 376U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7644U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x003B7650U + 376U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7648U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x003B7654U + 376U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B764CU, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x003B7658U + 380U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7650U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            r9 = 0x00000005U;
        }
        {
            const uint32_t operand = 0x00000048U;
            r10 = r13 + operand;
        }
        goto block_003B765C;
    }
block_003B765C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B765CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B765CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7664U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7664U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7664;
    }
block_003B7664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7664U);
        }
        {
            const uint32_t address = r7 + 440U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7664U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7668U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B766CU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B7678U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B7678U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B7678;
    }
block_003B7678:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7678U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7678U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7678U, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B767CU, 0xEE300A6BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B7680U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B768CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B768CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B768C;
    }
block_003B768C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B768CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B768CU);
        }
        {
            const uint32_t address = r7 + 448U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B768CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7690U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003B7698U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r8, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003B776C; }
        goto block_003B76A4;
    }
block_003B76A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B76A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B76A4U);
        }
        {
            const uint32_t updatedAddress = 0x003B76ACU + 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B76A4U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000048U;
            r1 = r13 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B76B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProjectPos_00368CC0(frame, context, state, 0x00368CC0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B76B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B76B8;
    }
block_003B76B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B76B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B76B8U);
        }
        {
            const uint32_t address = r13 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B76B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B76BCU, 0xEEB40AE9U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            const uint32_t operand = 0x00000001U;
            r0 = r6 - operand;
        }
        if (!(flags.C())) {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r6 = value;
        }
        if (!(flags.C())) { goto block_003B776C; }
        goto block_003B76D0;
    }
block_003B76D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B76D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B76D0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B76D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xC28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B76D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003B76D8U, address);
            }
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003B76DCU, address);
            }
        }
        {
            const uint32_t operand = 0x00000780U;
            r11 = r0 + operand;
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x003B76E4U, address);
            }
        }
        {
            r0 = 0x0000001EU;
        }
        goto block_003B76EC;
    }
block_003B76EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B76ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B76ECU);
        }
        {
            const uint32_t updatedAddress = r11 + 0x24U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B76ECU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003B7758; }
        goto block_003B76F8;
    }
block_003B76F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B76F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B76F8U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x003B76F8U, address);
            }
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003B76FCU,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003B76FCU,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B76FCU,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x003B7704U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003B7704U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B7704U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r11 + operand;
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003B770CU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B770CU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B770CU,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003B7710U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003B7710U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003B7710U,
                                           firstAddress + 8U);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t address = r11 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x003B7718U, address);
            }
        }
        {
            const uint32_t address = r11 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003B771CU, address);
            }
        }
        {
            const uint32_t address = r11 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x003B7720U, address);
            }
        }
        {
            r0 = r13;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B772CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Matrix_RotateY_003735E8(frame, context, state, 0x003735E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B772CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B772C;
    }
block_003B772C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B772CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B772CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r13;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B773CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Matrix_RotateX_00369014(frame, context, state, 0x00369014U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B773CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B773C;
    }
block_003B773C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B773CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B773CU);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r11 + operand;
        }
        {
            const uint32_t operand = 0x00000030U;
            r2 = r13 + operand;
        }
        {
            r1 = r13;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B774CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B774CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B774C;
    }
block_003B774C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B774CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B774CU);
        }
        {
        }
        {
        }
        goto block_003B776C;
    }
block_003B7758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B7758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B7758U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000040U;
            r11 = r11 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000082U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_003B76EC; }
        goto block_003B776C;
    }
block_003B776C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B776CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B776CU);
        }
        {
            const uint32_t address = r4 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B776CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r6 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003B7774U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r6 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003B765C; }
        goto block_003B778C;
    }
block_003B778C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B778CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B778CU);
        }
        {
            const uint32_t updatedAddress = 0x003B7794U - 0xF80U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B778CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B7798U - 0xF80U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7790U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B779CU + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7794U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x003B77A0U + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003B7798U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003B779CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003B77ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003B77ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003B77AC;
    }
block_003B77AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003B77ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003B77ACU);
        }
        {
            const uint32_t operand = 0x000000BCU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 48U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 48U);
            }
            frame.Guest.vfp[28] = value12;
            uint32_t value13 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 52U, &value13)) {
                return Oot3dAotMemoryFault(context, 0x003B77B0U,
                                           firstAddress + 52U);
            }
            frame.Guest.vfp[29] = value13;
            r13 += 56U;
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003B77B8U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003B77B8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003B77B8U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003B77B8U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003B77B8U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003B77B8U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003B77B8U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x003B77B8U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003B77B8U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
