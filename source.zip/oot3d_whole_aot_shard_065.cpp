#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_FUN_001317dc_001317DC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossGanondrof_Death_0013BB74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossFd_Update_001EC834(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossMo_Update_001EDBB0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_sin_idx8_002CFCA0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ChangeCameraStatus_00320D7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_cos_idx8_00338F60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0033b11c_0033B11C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsHahen_Spawn_0035AE24(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsKFire_Spawn_0035AEA0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetRuntimeFlag200_0035AF04(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035af20_0035AF20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b0a0_0035B0A0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b164_0035B164(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b3b0_0035B3B0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035d8d8_0035D8D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00365768_00365768(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003658b8_003658B8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CutsceneContext_StartUnskippable_00367374(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003673d8_003673D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CutsceneContext_StartSkippable_00367494(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_CameraSetAtEye_00367B14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_set_byte_1b6_00367C48(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_clear_byte_1b6_00367C54(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00367c60_00367C60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_StartTextbox_00367C7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_CreateSubCamera_00367D74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetPlayerKnockbackLarge_00368FC0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelHandle_HideMesh_0036932C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SpawnAsChild_0036AA20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_GetLastFrame_0036AE14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_GetCamera_0036C5BC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetCsActionWithHaltedActors_0036E980(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Flags_SetClear_0036EC14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_QueueSeqCmd_0036EC40(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_ApproachZeroF_0036FC20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossFd_SpawnEmber_0036FDE0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToSUpdateRate_00370084(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_MorphToLoop_00370350(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroFloat_00371E50(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelHandle_ShowMesh_0037266C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_CosF_Core_00372674(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SinF_003727F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_MaterialAnimation_Init_00372D94(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_ApproachF_00373500(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_transform_mtx3x4_vec3_003735AC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Matrix_RotateY_003735E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_OnFrameImpl_003736FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_CenteredFloat_003738A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Spawn_003738D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSs_SpawnSurfaceImpact_003741E4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Kill_00374428(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlaySoundGeneral_0037547C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_get_flag_22a0_0037571C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroOne_003759D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlayActorSound2_00375BCC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_Change_00375c08_00375C08(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Flags_SetSwitch_00375C10(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetAC_00376168(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetAT_003761F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetOC_003762A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_MoveForward_00376864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0049fa78_0049FA78(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_BossGanondrof_Death_0013BB74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0013BB74U:
        goto block_0013BB74;
    case 0x0013BBA4U:
        goto block_0013BBA4;
    case 0x0013BBB0U:
        goto block_0013BBB0;
    case 0x0013BBD4U:
        goto block_0013BBD4;
    case 0x0013BBECU:
        goto block_0013BBEC;
    case 0x0013BBF8U:
        goto block_0013BBF8;
    case 0x0013BC04U:
        goto block_0013BC04;
    case 0x0013BC70U:
        goto block_0013BC70;
    case 0x0013BC90U:
        goto block_0013BC90;
    case 0x0013BC9CU:
        goto block_0013BC9C;
    case 0x0013BCACU:
        goto block_0013BCAC;
    case 0x0013BCB8U:
        goto block_0013BCB8;
    case 0x0013BCCCU:
        goto block_0013BCCC;
    case 0x0013BCDCU:
        goto block_0013BCDC;
    case 0x0013BDE0U:
        goto block_0013BDE0;
    case 0x0013BDF0U:
        goto block_0013BDF0;
    case 0x0013BDF8U:
        goto block_0013BDF8;
    case 0x0013BE00U:
        goto block_0013BE00;
    case 0x0013BE04U:
        goto block_0013BE04;
    case 0x0013BE14U:
        goto block_0013BE14;
    case 0x0013BE20U:
        goto block_0013BE20;
    case 0x0013BE2CU:
        goto block_0013BE2C;
    case 0x0013BE50U:
        goto block_0013BE50;
    case 0x0013BE74U:
        goto block_0013BE74;
    case 0x0013BE80U:
        goto block_0013BE80;
    case 0x0013BE90U:
        goto block_0013BE90;
    case 0x0013BE9CU:
        goto block_0013BE9C;
    case 0x0013BEA8U:
        goto block_0013BEA8;
    case 0x0013BEC8U:
        goto block_0013BEC8;
    case 0x0013BED0U:
        goto block_0013BED0;
    case 0x0013BED4U:
        goto block_0013BED4;
    case 0x0013BEF4U:
        goto block_0013BEF4;
    case 0x0013BF10U:
        goto block_0013BF10;
    case 0x0013BF24U:
        goto block_0013BF24;
    case 0x0013BF38U:
        goto block_0013BF38;
    case 0x0013BF6CU:
        goto block_0013BF6C;
    case 0x0013C020U:
        goto block_0013C020;
    case 0x0013C028U:
        goto block_0013C028;
    case 0x0013C038U:
        goto block_0013C038;
    case 0x0013C070U:
        goto block_0013C070;
    case 0x0013C088U:
        goto block_0013C088;
    case 0x0013C0A8U:
        goto block_0013C0A8;
    case 0x0013C0D4U:
        goto block_0013C0D4;
    case 0x0013C0F0U:
        goto block_0013C0F0;
    case 0x0013C140U:
        goto block_0013C140;
    case 0x0013C158U:
        goto block_0013C158;
    case 0x0013C16CU:
        goto block_0013C16C;
    case 0x0013C180U:
        goto block_0013C180;
    case 0x0013C194U:
        goto block_0013C194;
    case 0x0013C1A4U:
        goto block_0013C1A4;
    case 0x0013C1CCU:
        goto block_0013C1CC;
    case 0x0013C1F0U:
        goto block_0013C1F0;
    case 0x0013C1F4U:
        goto block_0013C1F4;
    case 0x0013C1F8U:
        goto block_0013C1F8;
    case 0x0013C200U:
        goto block_0013C200;
    case 0x0013C278U:
        goto block_0013C278;
    case 0x0013C294U:
        goto block_0013C294;
    case 0x0013C2A0U:
        goto block_0013C2A0;
    case 0x0013C2B0U:
        goto block_0013C2B0;
    case 0x0013C2D8U:
        goto block_0013C2D8;
    case 0x0013C2DCU:
        goto block_0013C2DC;
    case 0x0013C30CU:
        goto block_0013C30C;
    case 0x0013C34CU:
        goto block_0013C34C;
    case 0x0013C39CU:
        goto block_0013C39C;
    case 0x0013C3B8U:
        goto block_0013C3B8;
    case 0x0013C3CCU:
        goto block_0013C3CC;
    case 0x0013C3E0U:
        goto block_0013C3E0;
    case 0x0013C3ECU:
        goto block_0013C3EC;
    case 0x0013C400U:
        goto block_0013C400;
    case 0x0013C418U:
        goto block_0013C418;
    case 0x0013C428U:
        goto block_0013C428;
    case 0x0013C45CU:
        goto block_0013C45C;
    case 0x0013C470U:
        goto block_0013C470;
    case 0x0013C484U:
        goto block_0013C484;
    case 0x0013C498U:
        goto block_0013C498;
    case 0x0013C4A4U:
        goto block_0013C4A4;
    case 0x0013C4ECU:
        goto block_0013C4EC;
    case 0x0013C500U:
        goto block_0013C500;
    case 0x0013C510U:
        goto block_0013C510;
    case 0x0013C51CU:
        goto block_0013C51C;
    case 0x0013C528U:
        goto block_0013C528;
    case 0x0013C55CU:
        goto block_0013C55C;
    case 0x0013C568U:
        goto block_0013C568;
    case 0x0013C570U:
        goto block_0013C570;
    case 0x0013C57CU:
        goto block_0013C57C;
    case 0x0013C5A8U:
        goto block_0013C5A8;
    case 0x0013C5D0U:
        goto block_0013C5D0;
    case 0x0013C5DCU:
        goto block_0013C5DC;
    case 0x0013C5E8U:
        goto block_0013C5E8;
    case 0x0013C5ECU:
        goto block_0013C5EC;
    case 0x0013C5F4U:
        goto block_0013C5F4;
    case 0x0013C5FCU:
        goto block_0013C5FC;
    case 0x0013C628U:
        goto block_0013C628;
    case 0x0013C638U:
        goto block_0013C638;
    case 0x0013C648U:
        goto block_0013C648;
    case 0x0013C670U:
        goto block_0013C670;
    case 0x0013C674U:
        goto block_0013C674;
    case 0x0013C6A4U:
        goto block_0013C6A4;
    case 0x0013C6ACU:
        goto block_0013C6AC;
    case 0x0013C6D8U:
        goto block_0013C6D8;
    case 0x0013C6E0U:
        goto block_0013C6E0;
    case 0x0013C700U:
        goto block_0013C700;
    case 0x0013C734U:
        goto block_0013C734;
    case 0x0013C750U:
        goto block_0013C750;
    case 0x0013C764U:
        goto block_0013C764;
    case 0x0013C77CU:
        goto block_0013C77C;
    case 0x0013C7E0U:
        goto block_0013C7E0;
    case 0x0013C7E4U:
        goto block_0013C7E4;
    case 0x0013C7ECU:
        goto block_0013C7EC;
    case 0x0013C818U:
        goto block_0013C818;
    case 0x0013C824U:
        goto block_0013C824;
    case 0x0013C830U:
        goto block_0013C830;
    case 0x0013C838U:
        goto block_0013C838;
    case 0x0013C840U:
        goto block_0013C840;
    case 0x0013C87CU:
        goto block_0013C87C;
    case 0x0013C88CU:
        goto block_0013C88C;
    case 0x0013C8A0U:
        goto block_0013C8A0;
    case 0x0013C8C4U:
        goto block_0013C8C4;
    case 0x0013C8CCU:
        goto block_0013C8CC;
    case 0x0013C8FCU:
        goto block_0013C8FC;
    case 0x0013C910U:
        goto block_0013C910;
    case 0x0013C91CU:
        goto block_0013C91C;
    case 0x0013C924U:
        goto block_0013C924;
    case 0x0013C940U:
        goto block_0013C940;
    case 0x0013C95CU:
        goto block_0013C95C;
    case 0x0013C978U:
        goto block_0013C978;
    case 0x0013C994U:
        goto block_0013C994;
    case 0x0013C9B0U:
        goto block_0013C9B0;
    case 0x0013C9CCU:
        goto block_0013C9CC;
    case 0x0013C9E4U:
        goto block_0013C9E4;
    case 0x0013C9F8U:
        goto block_0013C9F8;
    case 0x0013CA04U:
        goto block_0013CA04;
    case 0x0013CA28U:
        goto block_0013CA28;
    case 0x0013CA34U:
        goto block_0013CA34;
    case 0x0013CA3CU:
        goto block_0013CA3C;
    case 0x0013CA48U:
        goto block_0013CA48;
    case 0x0013CA50U:
        goto block_0013CA50;
    case 0x0013CA54U:
        goto block_0013CA54;
    case 0x0013CA68U:
        goto block_0013CA68;
    case 0x0013CA70U:
        goto block_0013CA70;
    case 0x0013CA80U:
        goto block_0013CA80;
    case 0x0013CA88U:
        goto block_0013CA88;
    case 0x0013CAA8U:
        goto block_0013CAA8;
    case 0x0013CAC4U:
        goto block_0013CAC4;
    case 0x0013CAD0U:
        goto block_0013CAD0;
    case 0x0013CAD4U:
        goto block_0013CAD4;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0013BB74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BB74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BB74U);
        }
        {
            const uint32_t firstAddress = r13 - 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0013BB74U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0013BB74U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0013BB74U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0013BB74U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0013BB74U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0013BB74U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0013BB74U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0013BB74U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0013BB74U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0013BB74U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0013BB74U,
                                           firstAddress + 40U);
            }
            r13 = r13 - 44U;
        }
        {
            r4 = r0;
        }
        {
            r11 = 0x00000000U;
        }
        {
            r6 = r11;
        }
        {
            r13 -= 48U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0013BB84U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013BB84U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0013BB84U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0013BB84U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0013BB84U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0013BB84U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0013BB84U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0013BB84U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x0013BB84U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x0013BB84U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x0013BB84U,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x0013BB84U,
                                           firstAddress + 44U);
            }
        }
        {
            const uint32_t operand = 0x00000054U;
            r13 = r13 - operand;
        }
        {
            r1 = r11;
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BB90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BB98U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BB9CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BBA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BBA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BBA4;
    }
block_0013BBA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BBA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BBA4U);
        }
        {
            r7 = r0;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BBB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BBB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BBB0;
    }
block_0013BBB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BBB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BBB0U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r5 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0013BBBCU + 0x3F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BBB4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BBB8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000005BU;
            r1 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BBCCU, address);
            }
        }
        if (!(flags.C())) { goto block_0013BBF8; }
        goto block_0013BBD4;
    }
block_0013BBD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BBD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BBD4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = 0x0013BBE0U + 0x3D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BBD8U, address);
            }
            r2 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BBDCU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0013BC04; }
        goto block_0013BBEC;
    }
block_0013BBEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BBECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BBECU);
        }
        {
            const uint32_t updatedAddress = 0x0013BBF4U + 0x3C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BBECU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0013BC04; }
        goto block_0013BBF8;
    }
block_0013BBF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BBF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BBF8U);
        }
        {
            const uint32_t updatedAddress = 0x0013BC00U + 0x3C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BBF8U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BC04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BC04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BC04;
    }
block_0013BC04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BC04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BC04U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC04U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000300U;
            r9 = r4 + operand;
        }
        {
            const uint32_t address = 0x0013BC14U + 944U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC0CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r9 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC14U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013BC1CU, address);
            }
        }
        {
            const uint32_t operand = 0x000003B0U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013BC24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC28U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x0013BC34U + 916U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC2CU, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t address = 0x0013BC38U + 916U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC30U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013BC3CU, address);
            }
        }
        {
            const uint32_t address = 0x0013BC48U + 904U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC40U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x0013BC4CU + 904U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC44U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x0013BC50U + 904U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC48U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0013BC54U + 904U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC4CU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x0013BC58U + 904U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC50U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x0013BC5CU + 904U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC54U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x0013BC60U + 904U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC58U, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            const uint32_t operand = 0x000003A4U;
            r1 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000400U;
            r10 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013BC68U, address);
            }
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x0013BC74U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC6CU, address);
            }
            switch (value) {
            case 0x0013BB74U:
                goto block_0013BB74;
            case 0x0013BBA4U:
                goto block_0013BBA4;
            case 0x0013BBB0U:
                goto block_0013BBB0;
            case 0x0013BBD4U:
                goto block_0013BBD4;
            case 0x0013BBECU:
                goto block_0013BBEC;
            case 0x0013BBF8U:
                goto block_0013BBF8;
            case 0x0013BC04U:
                goto block_0013BC04;
            case 0x0013BC70U:
                goto block_0013BC70;
            case 0x0013BC90U:
                goto block_0013BC90;
            case 0x0013BC9CU:
                goto block_0013BC9C;
            case 0x0013BCACU:
                goto block_0013BCAC;
            case 0x0013BCB8U:
                goto block_0013BCB8;
            case 0x0013BCCCU:
                goto block_0013BCCC;
            case 0x0013BCDCU:
                goto block_0013BCDC;
            case 0x0013BDE0U:
                goto block_0013BDE0;
            case 0x0013BDF0U:
                goto block_0013BDF0;
            case 0x0013BDF8U:
                goto block_0013BDF8;
            case 0x0013BE00U:
                goto block_0013BE00;
            case 0x0013BE04U:
                goto block_0013BE04;
            case 0x0013BE14U:
                goto block_0013BE14;
            case 0x0013BE20U:
                goto block_0013BE20;
            case 0x0013BE2CU:
                goto block_0013BE2C;
            case 0x0013BE50U:
                goto block_0013BE50;
            case 0x0013BE74U:
                goto block_0013BE74;
            case 0x0013BE80U:
                goto block_0013BE80;
            case 0x0013BE90U:
                goto block_0013BE90;
            case 0x0013BE9CU:
                goto block_0013BE9C;
            case 0x0013BEA8U:
                goto block_0013BEA8;
            case 0x0013BEC8U:
                goto block_0013BEC8;
            case 0x0013BED0U:
                goto block_0013BED0;
            case 0x0013BED4U:
                goto block_0013BED4;
            case 0x0013BEF4U:
                goto block_0013BEF4;
            case 0x0013BF10U:
                goto block_0013BF10;
            case 0x0013BF24U:
                goto block_0013BF24;
            case 0x0013BF38U:
                goto block_0013BF38;
            case 0x0013BF6CU:
                goto block_0013BF6C;
            case 0x0013C020U:
                goto block_0013C020;
            case 0x0013C028U:
                goto block_0013C028;
            case 0x0013C038U:
                goto block_0013C038;
            case 0x0013C070U:
                goto block_0013C070;
            case 0x0013C088U:
                goto block_0013C088;
            case 0x0013C0A8U:
                goto block_0013C0A8;
            case 0x0013C0D4U:
                goto block_0013C0D4;
            case 0x0013C0F0U:
                goto block_0013C0F0;
            case 0x0013C140U:
                goto block_0013C140;
            case 0x0013C158U:
                goto block_0013C158;
            case 0x0013C16CU:
                goto block_0013C16C;
            case 0x0013C180U:
                goto block_0013C180;
            case 0x0013C194U:
                goto block_0013C194;
            case 0x0013C1A4U:
                goto block_0013C1A4;
            case 0x0013C1CCU:
                goto block_0013C1CC;
            case 0x0013C1F0U:
                goto block_0013C1F0;
            case 0x0013C1F4U:
                goto block_0013C1F4;
            case 0x0013C1F8U:
                goto block_0013C1F8;
            case 0x0013C200U:
                goto block_0013C200;
            case 0x0013C278U:
                goto block_0013C278;
            case 0x0013C294U:
                goto block_0013C294;
            case 0x0013C2A0U:
                goto block_0013C2A0;
            case 0x0013C2B0U:
                goto block_0013C2B0;
            case 0x0013C2D8U:
                goto block_0013C2D8;
            case 0x0013C2DCU:
                goto block_0013C2DC;
            case 0x0013C30CU:
                goto block_0013C30C;
            case 0x0013C34CU:
                goto block_0013C34C;
            case 0x0013C39CU:
                goto block_0013C39C;
            case 0x0013C3B8U:
                goto block_0013C3B8;
            case 0x0013C3CCU:
                goto block_0013C3CC;
            case 0x0013C3E0U:
                goto block_0013C3E0;
            case 0x0013C3ECU:
                goto block_0013C3EC;
            case 0x0013C400U:
                goto block_0013C400;
            case 0x0013C418U:
                goto block_0013C418;
            case 0x0013C428U:
                goto block_0013C428;
            case 0x0013C45CU:
                goto block_0013C45C;
            case 0x0013C470U:
                goto block_0013C470;
            case 0x0013C484U:
                goto block_0013C484;
            case 0x0013C498U:
                goto block_0013C498;
            case 0x0013C4A4U:
                goto block_0013C4A4;
            case 0x0013C4ECU:
                goto block_0013C4EC;
            case 0x0013C500U:
                goto block_0013C500;
            case 0x0013C510U:
                goto block_0013C510;
            case 0x0013C51CU:
                goto block_0013C51C;
            case 0x0013C528U:
                goto block_0013C528;
            case 0x0013C55CU:
                goto block_0013C55C;
            case 0x0013C568U:
                goto block_0013C568;
            case 0x0013C570U:
                goto block_0013C570;
            case 0x0013C57CU:
                goto block_0013C57C;
            case 0x0013C5A8U:
                goto block_0013C5A8;
            case 0x0013C5D0U:
                goto block_0013C5D0;
            case 0x0013C5DCU:
                goto block_0013C5DC;
            case 0x0013C5E8U:
                goto block_0013C5E8;
            case 0x0013C5ECU:
                goto block_0013C5EC;
            case 0x0013C5F4U:
                goto block_0013C5F4;
            case 0x0013C5FCU:
                goto block_0013C5FC;
            case 0x0013C628U:
                goto block_0013C628;
            case 0x0013C638U:
                goto block_0013C638;
            case 0x0013C648U:
                goto block_0013C648;
            case 0x0013C670U:
                goto block_0013C670;
            case 0x0013C674U:
                goto block_0013C674;
            case 0x0013C6A4U:
                goto block_0013C6A4;
            case 0x0013C6ACU:
                goto block_0013C6AC;
            case 0x0013C6D8U:
                goto block_0013C6D8;
            case 0x0013C6E0U:
                goto block_0013C6E0;
            case 0x0013C700U:
                goto block_0013C700;
            case 0x0013C734U:
                goto block_0013C734;
            case 0x0013C750U:
                goto block_0013C750;
            case 0x0013C764U:
                goto block_0013C764;
            case 0x0013C77CU:
                goto block_0013C77C;
            case 0x0013C7E0U:
                goto block_0013C7E0;
            case 0x0013C7E4U:
                goto block_0013C7E4;
            case 0x0013C7ECU:
                goto block_0013C7EC;
            case 0x0013C818U:
                goto block_0013C818;
            case 0x0013C824U:
                goto block_0013C824;
            case 0x0013C830U:
                goto block_0013C830;
            case 0x0013C838U:
                goto block_0013C838;
            case 0x0013C840U:
                goto block_0013C840;
            case 0x0013C87CU:
                goto block_0013C87C;
            case 0x0013C88CU:
                goto block_0013C88C;
            case 0x0013C8A0U:
                goto block_0013C8A0;
            case 0x0013C8C4U:
                goto block_0013C8C4;
            case 0x0013C8CCU:
                goto block_0013C8CC;
            case 0x0013C8FCU:
                goto block_0013C8FC;
            case 0x0013C910U:
                goto block_0013C910;
            case 0x0013C91CU:
                goto block_0013C91C;
            case 0x0013C924U:
                goto block_0013C924;
            case 0x0013C940U:
                goto block_0013C940;
            case 0x0013C95CU:
                goto block_0013C95C;
            case 0x0013C978U:
                goto block_0013C978;
            case 0x0013C994U:
                goto block_0013C994;
            case 0x0013C9B0U:
                goto block_0013C9B0;
            case 0x0013C9CCU:
                goto block_0013C9CC;
            case 0x0013C9E4U:
                goto block_0013C9E4;
            case 0x0013C9F8U:
                goto block_0013C9F8;
            case 0x0013CA04U:
                goto block_0013CA04;
            case 0x0013CA28U:
                goto block_0013CA28;
            case 0x0013CA34U:
                goto block_0013CA34;
            case 0x0013CA3CU:
                goto block_0013CA3C;
            case 0x0013CA48U:
                goto block_0013CA48;
            case 0x0013CA50U:
                goto block_0013CA50;
            case 0x0013CA54U:
                goto block_0013CA54;
            case 0x0013CA68U:
                goto block_0013CA68;
            case 0x0013CA70U:
                goto block_0013CA70;
            case 0x0013CA80U:
                goto block_0013CA80;
            case 0x0013CA88U:
                goto block_0013CA88;
            case 0x0013CAA8U:
                goto block_0013CAA8;
            case 0x0013CAC4U:
                goto block_0013CAC4;
            case 0x0013CAD0U:
                goto block_0013CAD0;
            case 0x0013CAD4U:
                goto block_0013CAD4;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_0013BC70;
    }
block_0013BC70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BC70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BC70U);
        }
        goto block_0013C1F8;
    }
block_0013BC90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BC90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BC90U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC94U, address);
            }
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BC9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BC9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BC9C;
    }
block_0013BC9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BC9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BC9CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BC9CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BCACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BCACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BCAC;
    }
block_0013BCAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BCACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BCACU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BCACU, address);
            }
            r0 = value;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BCB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BCB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BCB8;
    }
block_0013BCB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BCB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BCB8U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BCB8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BCBCU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BCCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BCCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BCCC;
    }
block_0013BCCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BCCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BCCCU);
        }
        {
            const uint32_t updatedAddress = r9 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BCCCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BCD0U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000007U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BCDCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BCDCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BCDC;
    }
block_0013BCDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BCDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BCDCU);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r9 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BCE0U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0013BCF0U + 764U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BCE8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x234U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BCECU, address);
            }
        }
        {
            const uint32_t address = r8 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BCF0U, address);
            }
        }
        {
            r0 = 0x0000004BU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BCF8U, address);
            }
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BD00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0013BD04U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0013BD04U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0013BD04U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t operand = 0x00000080U;
            r1 = r7 + operand;
        }
        {
            const uint32_t address = 0x0013BD14U + 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BD0CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0013BD10U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0013BD10U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0013BD10U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BD14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0013BD18U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0013BD18U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0013BD18U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0013BD1CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0013BD1CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0013BD1CU,
                                           firstAddress + 8U);
            }
        }
        {
            r0 = 0x000000E1U;
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BD24U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 980U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0013BD28U, address);
            }
        }
        {
            const uint32_t address = r4 + 984U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0013BD2CU, address);
            }
        }
        {
            const uint32_t address = r4 + 708U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BD30U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BD34U, 0xEE701A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 988U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0013BD38U, address);
            }
        }
        {
            const uint32_t address = r4 + 1004U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0013BD3CU, address);
            }
        }
        {
            const uint32_t address = r4 + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BD40U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BD44U, 0xEE311A6AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 1008U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0013BD48U, address);
            }
        }
        {
            const uint32_t address = r4 + 1012U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BD4CU, address);
            }
        }
        {
            const uint32_t address = r7 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BD50U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BD54U, 0xEE322A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[4], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BD58U, 0xEEB02AC2U};
            frame.Guest.vfp[4] = frame.Guest.vfp[4] & 0x7FFFFFFFU;
        }
        {
            const uint32_t address = r4 + 956U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[4])) {
                return Oot3dAotMemoryFault(context, 0x0013BD5CU, address);
            }
        }
        {
            const uint32_t address = r7 + 144U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BD60U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BD64U, 0xEE322A4AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[4], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BD68U, 0xEEB02AC2U};
            frame.Guest.vfp[4] = frame.Guest.vfp[4] & 0x7FFFFFFFU;
        }
        {
            const uint32_t address = r4 + 960U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[4])) {
                return Oot3dAotMemoryFault(context, 0x0013BD6CU, address);
            }
        }
        {
            const uint32_t address = r7 + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BD70U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BD74U, 0xEE721A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[4], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BD78U, 0xEEF01AE1U};
            frame.Guest.vfp[3] = frame.Guest.vfp[3] & 0x7FFFFFFFU;
        }
        {
            const uint32_t address = r4 + 964U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0013BD7CU, address);
            }
        }
        {
            const uint32_t address = r7 + 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BD80U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BD84U, 0xEE710AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BD88U, 0xEEF00AE0U};
            frame.Guest.vfp[1] = frame.Guest.vfp[1] & 0x7FFFFFFFU;
        }
        {
            const uint32_t address = r4 + 968U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0013BD8CU, address);
            }
        }
        {
            const uint32_t address = r7 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BD90U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BD94U, 0xEE700AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BD98U, 0xEEF00AE0U};
            frame.Guest.vfp[1] = frame.Guest.vfp[1] & 0x7FFFFFFFU;
        }
        {
            const uint32_t address = r4 + 972U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0013BD9CU, address);
            }
        }
        {
            const uint32_t address = r7 + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BDA0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BDA4U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BDA8U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            const uint32_t address = r4 + 976U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BDACU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r10 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0013BDB4U, address);
            }
        }
        {
            const uint32_t address = r4 + 1000U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0013BDB8U, address);
            }
        }
        {
            const uint32_t address = r4 + 996U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BDBCU, address);
            }
        }
        {
            const uint32_t address = r4 + 992U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BDC0U, address);
            }
        }
        {
            const uint32_t address = 0x0013BDCCU + 552U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BDC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r10 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BDC8U, address);
            }
        }
        {
            const uint32_t address = r4 + 1020U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BDCCU, address);
            }
        }
        {
            const uint32_t address = r4 + 1016U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BDD0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BDD4U, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BDDCU, address);
            }
        }
        goto block_0013BDE0;
    }
block_0013BDE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BDE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BDE0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BDE0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0013BDECU + 524U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BDE4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0013BE04; }
        goto block_0013BDF0;
    }
block_0013BDF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BDF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BDF0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0013BE80; }
        goto block_0013BDF8;
    }
block_0013BDF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BDF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BDF8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013BED4; }
        goto block_0013BE00;
    }
block_0013BE00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BE00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BE00U);
        }
        goto block_0013BED0;
    }
block_0013BE04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BE04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BE04U);
        }
        {
            const uint32_t address = r4 + 632U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BE04U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BE0CU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BE14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BE14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BE14;
    }
block_0013BE14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BE14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BE14U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0013BED4; }
        goto block_0013BE20;
    }
block_0013BE20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BE20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BE20U);
        }
        {
            r1 = 0x00000011U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BE2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BE2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BE2C;
    }
block_0013BE2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BE2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BE2CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r7 = 0x00000001U;
        }
        {
            r1 = 0x00000011U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BE3CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BE40U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 632U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BE44U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x234U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0013BE48U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BE50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BE50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BE50;
    }
block_0013BE50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BE50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BE50U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x0013BE5CU + 400U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BE54U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = 0x00000011U;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BE68U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BE74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BE74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BE74;
    }
block_0013BE74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BE74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BE74U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0013BE74U, address);
            }
        }
        {
        }
        goto block_0013BED4;
    }
block_0013BE80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BE80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BE80U);
        }
        {
            const uint32_t address = r4 + 632U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BE80U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BE88U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BE90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BE90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BE90;
    }
block_0013BE90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BE90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BE90U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0013BED0; }
        goto block_0013BE9C;
    }
block_0013BE9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BE9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BE9CU);
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BEA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BEA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BEA8;
    }
block_0013BEA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BEA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BEA8U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BEB4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BEB8U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 632U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BEBCU, address);
            }
        }
        {
            const uint32_t address = 0x0013BEC8U + 308U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BEC0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BEC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BEC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BEC8;
    }
block_0013BEC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BEC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BEC8U);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BECCU, address);
            }
        }
        goto block_0013BED0;
    }
block_0013BED0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BED0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BED0U);
        }
        {
            r6 = 0x00000001U;
        }
        goto block_0013BED4;
    }
block_0013BED4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BED4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BED4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BED4U, address);
            }
            r0 = value;
        }
        {
            r1 = ~(0x00000063U);
        }
        {
            const uint32_t updatedAddress = 0x0013BEE4U + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BEDCU, address);
            }
            r3 = value;
        }
        {
            r2 = 0x00000005U;
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r1);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t operand = 0x000000BEU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BEF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BEF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BEF4;
    }
block_0013BEF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BEF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BEF4U);
        }
        {
            const uint32_t address = r4 + 708U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BEF4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0013BF00U + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BEF8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x000003DCU;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BF04U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[23];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BF10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BF10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BF10;
    }
block_0013BF10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BF10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BF10U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x0000002CU;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BF24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BF24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BF24;
    }
block_0013BF24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BF24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BF24U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BF24U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013BF30U + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BF28U, address);
            }
            r1 = value;
        }
        {
            const int32_t left = static_cast<int16_t>(
                r0 >> 0U);
            const int32_t right = static_cast<int16_t>(
                r1 >> 0U);
            r0 = static_cast<uint32_t>(left * right);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BF38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BF38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BF38;
    }
block_0013BF38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BF38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BF38U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BF38U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BF3CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BF40U, address);
            }
        }
        {
            const uint32_t address = r4 + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BF44U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 1004U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BF48U, address);
            }
        }
        {
            const uint32_t address = r4 + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BF4CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013BF50U, 0xEE300A6AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 1008U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BF54U, address);
            }
        }
        {
            const uint32_t address = r4 + 708U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BF58U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 1012U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BF5CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BF60U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0013C1F8; }
        goto block_0013BF6C;
    }
block_0013BF6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BF6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BF6CU);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t address = 0x0013BF78U + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BF70U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BF74U, address);
            }
        }
        {
            const uint32_t address = r4 + 640U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BF78U, address);
            }
        }
        {
            const uint32_t address = 0x0013BF84U + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BF7CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0013BF88U + 0x8CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BF80U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 984U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BF84U, address);
            }
        }
        {
            const uint32_t address = 0x0013BF90U + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BF88U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BF8CU, address);
            }
        }
        {
            r0 = 0x0000004BU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BF94U, address);
            }
        }
        {
            const uint32_t address = r8 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BF98U, address);
            }
        }
        {
            const uint32_t address = 0x0013BFA4U + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BF9CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r11 = 0x00000001U;
        }
        {
            const uint32_t address = r8 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013BFA4U, address);
            }
        }
        {
            r0 = 0x00000002U;
        }
        {
            r6 = r11;
        }
        goto block_0013C020;
    }
block_0013C020:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C020U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C020U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x234U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C020U, address);
            }
        }
        goto block_0013C200;
    }
block_0013C028:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C028U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C028U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C028U, address);
            }
            r0 = value;
        }
        {
            r7 = 0x00000004U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013C088; }
        goto block_0013C038;
    }
block_0013C038:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C038U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C038U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C038U, address);
            }
            r6 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = 0x00004000U;
        }
        {
            r3 = 0x00000029U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0013C048U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0013C048U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0013C04CU, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C050U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C054U, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = 0x0013C060U - 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C058U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0013C064U + 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C05CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0013C068U + 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C060U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x0000006DU;
        }
        {
            r1 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C070U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C070U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C070;
    }
block_0013C070:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C070U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C070U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x128U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0013C070U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x234U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0013C074U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0013C080U + 0x2F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C078U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C07CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C088U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C088U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C088;
    }
block_0013C088:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C088U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C088U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C088U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013C094U - 0x8CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C08CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000000C8U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C094U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C098U, address);
            }
            r0 = value;
        }
        {
            const int32_t left = static_cast<int16_t>(
                r0 >> 0U);
            const int32_t right = static_cast<int16_t>(
                r1 >> 0U);
            r0 = static_cast<uint32_t>(left * right);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C0A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C0A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C0A8;
    }
block_0013C0A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C0A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C0A8U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C0A8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C0ACU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0013C0B8U + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C0B0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C0B4U, address);
            }
        }
        {
            const uint32_t address = r4 + 644U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C0B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C0BCU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 644U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C0C0U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C0C4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C0D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C0D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C0D4;
    }
block_0013C0D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C0D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C0D4U);
        }
        {
            const uint32_t address = r4 + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C0D4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C0D8U, 0xEE20BA20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[22], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 644U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C0DCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C0E0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C0F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C0F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C0F0;
    }
block_0013C0F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C0F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C0F0U);
        }
        {
            const uint32_t address = r4 + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C0F0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0013C0FCU + 624U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C0F4U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x0013C100U - 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C0F8U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C0FCU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C100U, 0xEE7B0A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[22], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0013C10CU - 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C104U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x0013C110U + 616U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C108U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x000003D8U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C114U, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 932U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0013C118U, address);
            }
        }
        {
            const uint32_t address = r4 + 984U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C11CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 936U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0013C120U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r4 + 940U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C128U, address);
            }
        }
        {
            const uint32_t address = r4 + 944U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0013C12CU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[23];
        }
        {
            const uint32_t address = r4 + 948U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x0013C134U, address);
            }
        }
        {
            const uint32_t address = r4 + 952U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0013C138U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C140U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C140U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C140;
    }
block_0013C140:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C140U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C140U);
        }
        {
            const uint32_t address = 0x0013C148U + 564U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C140U, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0013C150U + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C148U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[26];
        }
        {
            const uint32_t operand = 0x00000280U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C158U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C158U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C158;
    }
block_0013C158:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C158U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C158U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C16CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C16CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C16C;
    }
block_0013C16C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C16CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C16CU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[26];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x0000002CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C180U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C180U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C180;
    }
block_0013C180:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C180U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C180U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            const uint32_t operand = 0x00000030U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C194U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C194U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C194;
    }
block_0013C194:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C194U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C194U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C194U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r6 = 0x00000001U;
        }
        if (!(flags.Z())) { goto block_0013C1F4; }
        goto block_0013C1A4;
    }
block_0013C1A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C1A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C1A4U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0013C1A4U, address);
            }
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0013C1A8U, address);
            }
        }
        {
            r0 = 0x0000004BU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C1B0U, address);
            }
        }
        {
            r0 = 0x00000005U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x234U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C1C0U, address);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C1CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C1CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C1CC;
    }
block_0013C1CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C1CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C1CCU);
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0013C1CCU, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0013C1D0U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0013C1D4U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C1DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x56U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C1E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0013C1ECU + 0x198U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C1E4U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C1F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C1F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C1F0;
    }
block_0013C1F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C1F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C1F0U);
        }
        {
            r6 = 0x00000002U;
        }
        goto block_0013C1F4;
    }
block_0013C1F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C1F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C1F4U);
        }
        {
            r11 = 0x00000001U;
        }
        goto block_0013C1F8;
    }
block_0013C1F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C1F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C1F8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0013C910; }
        goto block_0013C200;
    }
block_0013C200:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C200U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C200U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        {
            const uint32_t address = 0x0013C20CU - 544U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C204U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        if (flags.C()) {
            r1 = 0x00000000U;
        }
        {
            r8 = 0x00000014U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C21CU, address);
            }
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0013C220U, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C224U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0013C228U, address);
            }
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0013C22CU, address);
            }
        }
        {
            const uint32_t address = 0x0013C238U + 336U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C230U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C234U, address);
            }
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0013C238U, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0013C23CU, address);
            }
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C240U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C244U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C248U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C24CU, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C250U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C254U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C258U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C25CU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00003200U;
            r7 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C268U, address);
            }
        }
        if (flags.C()) {
            const uint32_t updatedAddress = r0 + 0x237U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013C26CU, address);
            }
        }
        if (flags.C()) {
            const uint32_t updatedAddress = r7 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0013C270U, address);
            }
        }
        if (flags.C()) { goto block_0013C88C; }
        goto block_0013C278;
    }
block_0013C278:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C278U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C278U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C278U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0013C284U + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C27CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0013C288U + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C280U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r1 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C28CU, address);
            }
        }
        if (!(flags.Z())) { goto block_0013C6E0; }
        goto block_0013C294;
    }
block_0013C294:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C294U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C294U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x237U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C294U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013C638; }
        goto block_0013C2A0;
    }
block_0013C2A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C2A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C2A0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x237U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013C2A8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C2B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C2B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C2B0;
    }
block_0013C2B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C2B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C2B0U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C2B0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C2C0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C2C4U, 0xEE300A0CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[24], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C2C8U, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0013C5F4; }
        goto block_0013C2D8;
    }
block_0013C2D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C2D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C2D8U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C2DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C2DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C2DC;
    }
block_0013C2DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C2DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C2DCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C2DCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C2ECU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C2F0U, 0xEE300A0CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[24], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C2F4U, 0xEE600A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C2FCU, 0xEE000A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C300U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_0013C628;
    }
block_0013C30C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C30CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C30CU);
        }
        {
            const uint32_t address = 0x0013C314U + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C30CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0013C310U, address);
            }
        }
        {
            const uint32_t address = r4 + 932U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C314U, address);
            }
        }
        {
            const uint32_t address = 0x0013C320U + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C318U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 936U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0013C31CU, address);
            }
        }
        {
            const uint32_t address = r4 + 940U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0013C320U, address);
            }
        }
        {
            const uint32_t address = r4 + 944U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C324U, address);
            }
        }
        {
            const uint32_t address = 0x0013C330U + 104U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C328U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r11 = 0x00000001U;
        }
        {
            const uint32_t address = r4 + 948U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C330U, address);
            }
        }
        {
            const uint32_t address = 0x0013C33CU - 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C334U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r6 = 0x00000002U;
        }
        {
            const uint32_t address = r4 + 952U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C33CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C340U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0013C200; }
        goto block_0013C34C;
    }
block_0013C34C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C34CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C34CU);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r9 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C350U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x56U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C358U, address);
            }
        }
        {
            r0 = 0x0000003CU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C360U, address);
            }
        }
        goto block_0013C200;
    }
block_0013C39C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C39CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C39CU);
        }
        {
            const uint32_t address = 0x0013C3A4U - 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C39CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r11 = 0x00000001U;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            r6 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x000003A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C3B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C3B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C3B8;
    }
block_0013C3B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C3B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C3B8U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            const uint32_t operand = 0x000003ACU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C3CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C3CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C3CC;
    }
block_0013C3CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C3CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C3CCU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0013C3DCU + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C3D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000003B4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C3E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C3E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C3E0;
    }
block_0013C3E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C3E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C3E0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C3E0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0013C200; }
        goto block_0013C3EC;
    }
block_0013C3EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C3ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C3ECU);
        }
        {
            const uint32_t operand = 0x00000174U;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C3F0U, address);
            }
        }
        {
            r0 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r9 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C3F8U, address);
            }
        }
        goto block_0013C5EC;
    }
block_0013C400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C400U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C400U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0013C40CU + 936U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C404U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r11 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000E1U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r6 = 0x0000000AU;
        }
        if (!(flags.Z())) { goto block_0013C45C; }
        goto block_0013C418;
    }
block_0013C418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C418U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x0013C424U + 0x394U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C41CU, address);
            }
            r1 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C428U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_QueueSeqCmd_0036EC40(frame, context, state, 0x0036EC40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C428U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C428;
    }
block_0013C428:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C428U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C428U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = ~(0x00000000U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013C434U, address);
            }
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0013C438U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0013C438U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0013C438U,
                                           firstAddress + 8U);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            r3 = r1;
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C444U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C448U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x0013C454U + 872U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C44CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0013C458U - 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C450U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x0000005DU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C45CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Spawn_003738D0(frame, context, state, 0x003738D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C45CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C45C;
    }
block_0013C45C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C45CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C45CU);
        }
        {
            const uint32_t address = 0x0013C464U - 232U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C45CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x000003A8U;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C470U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C470U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C470;
    }
block_0013C470:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C470U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C470U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            const uint32_t operand = 0x000003ACU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C484U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C484U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C484;
    }
block_0013C484:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C484U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C484U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0013C494U + 796U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C48CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000003B4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C498U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C498U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C498;
    }
block_0013C498:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C498U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C498U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C498U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013C200; }
        goto block_0013C4A4;
    }
block_0013C4A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C4A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C4A4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C4A4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C4A8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C4ACU, address);
            }
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r7 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0013C4B4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0013C4B4U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0013C4B4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0013C4B8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0013C4B8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0013C4B8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r0 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C4C0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0013C4C4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0013C4C4U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0013C4C4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0013C4C8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0013C4C8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0013C4C8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C4D0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0013C4D4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0013C4D4U,
                                           firstAddress + 4U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0013C4D4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r7 = value7;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0013C4D8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0013C4D8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0013C4D8U,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r9 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C4E0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C4E4U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C4ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C4ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C4EC;
    }
block_0013C4EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C4ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C4ECU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r9 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C4F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C4F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C4F8U, address);
            }
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C500U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C500U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C500;
    }
block_0013C500:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C500U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C500U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C500U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C510U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C510U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C510;
    }
block_0013C510:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C510U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C510U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C51CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b164_0035B164(frame, context, state, 0x0035B164U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C51CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C51C;
    }
block_0013C51C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C51CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C51CU);
        }
        {
            const uint32_t address = 0x0013C524U + 668U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C51CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t value = r0 ^ 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0013C568; }
        goto block_0013C528;
    }
block_0013C528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C528U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0013C530U, faultAddress);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            r3 = r2;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0013C540U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0013C544U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C548U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C54CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x0013C558U - 492U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C550U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x0000005FU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C55CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Spawn_003738D0(frame, context, state, 0x003738D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C55CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C55C;
    }
block_0013C55C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C55CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C55CU);
        }
        {
        }
        {
        }
        goto block_0013C5A8;
    }
block_0013C568:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C568U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C568U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C570U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b0a0_0035B0A0(frame, context, state, 0x0035B0A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C570U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C570;
    }
block_0013C570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C570U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0013C5A8; }
        goto block_0013C57C;
    }
block_0013C57C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C57CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C57CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = 0x0013C588U - 540U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C580U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[5] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C588U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            r3 = 0x00000000U;
        }
        {
            frame.Guest.vfp[4] = frame.Guest.vfp[1];
        }
        {
            r2 = 0x00008000U;
        }
        {
            const uint32_t address = 0x0013C5A4U + 544U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C59CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C5A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035af20_0035AF20(frame, context, state, 0x0035AF20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C5A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C5A8;
    }
block_0013C5A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C5A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C5A8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C5A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x128U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C5ACU, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x26EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C5B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C5B8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x1A6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C5BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C5C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013C5CCU + 0x1FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C5C4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C5C8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C5D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_SetClear_0036EC14(frame, context, state, 0x0036EC14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C5D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C5D0;
    }
block_0013C5D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C5D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C5D0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C5D0U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000022U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C5DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_SetSwitch_00375C10(frame, context, state, 0x00375C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C5DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C5DC;
    }
block_0013C5DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C5DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C5DCU);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C5E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetRuntimeFlag200_0035AF04(frame, context, state, 0x0035AF04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C5E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C5E8;
    }
block_0013C5E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C5E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C5E8U);
        }
        {
            r0 = 0x00000007U;
        }
        goto block_0013C5EC;
    }
block_0013C5EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C5ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C5ECU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x234U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C5ECU, address);
            }
        }
        goto block_0013C200;
    }
block_0013C5F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C5F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C5F4U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C5FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C5FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C5FC;
    }
block_0013C5FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C5FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C5FCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C5FCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C60CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C610U, 0xEE300A0CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[24], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C614U, 0xEE600A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C61CU, 0xEE100A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C620U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_0013C628;
    }
block_0013C628:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C628U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C628U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C628U, address);
            }
        }
        {
            r0 = 0x00000028U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C630U, address);
            }
        }
        goto block_0013C6E0;
    }
block_0013C638:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C638U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C638U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[25];
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x237U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013C640U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C648U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C648U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C648;
    }
block_0013C648:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C648U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C648U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C648U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C658U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C65CU, 0xEE300A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C660U, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[25];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0013C6A4; }
        goto block_0013C670;
    }
block_0013C670:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C670U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C670U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C674U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C674U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C674;
    }
block_0013C674:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C674U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C674U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C674U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C684U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C688U, 0xEE300A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C68CU, 0xEE600A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C694U, 0xEE000A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C698U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_0013C6D8;
    }
block_0013C6A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C6A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C6A4U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C6ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C6ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C6AC;
    }
block_0013C6AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C6ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C6ACU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C6ACU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C6BCU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C6C0U, 0xEE300A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C6C4U, 0xEE600A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C6CCU, 0xEE100A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C6D0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_0013C6D8;
    }
block_0013C6D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C6D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C6D8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C6D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0013C6DCU, address);
            }
        }
        goto block_0013C6E0;
    }
block_0013C6E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C6E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C6E0U);
        }
        {
            const uint32_t address = 0x0013C6E8U + 212U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C6E0U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x0013C6ECU - 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C6E4U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x0013C6F0U + 220U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C6E8U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x0013C6F4U + 220U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C6ECU, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x0013C6F8U + 220U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C6F0U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x0013C6FCU + 220U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C6F4U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x0013C700U + 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C6F8U, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            r7 = 0x00000000U;
        }
        goto block_0013C700;
    }
block_0013C700:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C700U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C700U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C700U, address);
            }
            r8 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0013C70CU + 0xD0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C704U, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r8 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t leftValue = r1;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r1, 2U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 31U);
            r1 = r2 - operand;
        }
        {
            const uint32_t operand = 0x00000000U;
            r1 = operand - r1;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 3U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C72CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C734U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C734U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C734;
    }
block_0013C734:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C734U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C734U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 1U);
            r0 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r8 = r4 + operand;
        }
        {
            const uint32_t address = r8 + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C73CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C740U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C744U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C750U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C750U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C750;
    }
block_0013C750:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C750U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C750U);
        }
        {
            const uint32_t address = r8 + 716U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C750U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C754U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C758U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C764U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C764U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C764;
    }
block_0013C764:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C764U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C764U);
        }
        {
            const uint32_t address = r8 + 720U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C764U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C76CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C770U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0013C774U, address);
            }
        }
        if (!(flags.Z())) { goto block_0013C7E4; }
        goto block_0013C77C;
    }
block_0013C77C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C77CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C77CU);
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0013C77CU, address);
            }
        }
        {
            const uint32_t address = r13 + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C780U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C784U, 0xEE390A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C788U, 0xEE790AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[19], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C78CU, 0xEE201AAAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C790U, 0xEE600A8BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0013C794U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C798U, 0xEE201A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C79CU, 0xEE200A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0013C7A0U, address);
            }
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0013C7A4U, address);
            }
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0013C7A8U, address);
            }
        }
        goto block_0013C7E0;
    }
block_0013C7E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C7E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C7E0U);
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C7E0U, address);
            }
        }
        goto block_0013C7E4;
    }
block_0013C7E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C7E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C7E4U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[25];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C7ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C7ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C7EC;
    }
block_0013C7EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C7ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C7ECU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C7ECU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = 0x0000000FU;
        }
        {
            const uint32_t operand = 0x00000020U;
            r3 = r13 + operand;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000038U;
            r1 = r13 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0013C808U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0013C808U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C80CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000002CU;
            r2 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C818U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsKFire_Spawn_0035AEA0(frame, context, state, 0x0035AEA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C818U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C818;
    }
block_0013C818:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C818U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C818U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C824U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C824U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C824;
    }
block_0013C824:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C824U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C824U);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0013C838; }
        goto block_0013C830;
    }
block_0013C830:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C830U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C830U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013C87C; }
        goto block_0013C838;
    }
block_0013C838:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C838U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C838U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C840U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C840U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C840;
    }
block_0013C840:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C840U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C840U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C840U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = 0x00000007U;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            r1 = ~(0x00000000U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0013C860U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0013C860U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0013C860U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0013C860U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x0000002CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0013C868U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C86CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000014U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000038U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C87CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsHahen_Spawn_0035AE24(frame, context, state, 0x0035AE24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C87CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C87C;
    }
block_0013C87C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C87CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C87CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r7 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r7 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0013C700; }
        goto block_0013C88C;
    }
block_0013C88C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C88CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C88CU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t address = 0x0013C898U + 580U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C890U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r5 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013C898U, address);
            }
        }
        if (!(flags.Z())) { goto block_0013C8C4; }
        goto block_0013C8A0;
    }
block_0013C8A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C8A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C8A0U);
        }
        {
            const uint32_t address = r4 + 672U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C8A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0013C8ACU + 564U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C8A4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C8A8U, 0xEE311A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C8ACU, 0xEE001A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0013C8B8U + 556U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C8B0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C8B4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 668U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0013C8B8U, address);
            }
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C8BCU, address);
            }
        }
        goto block_0013C8FC;
    }
block_0013C8C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C8C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C8C4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) { goto block_0013C8FC; }
        goto block_0013C8CC;
    }
block_0013C8CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C8CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C8CCU);
        }
        {
            const uint32_t address = r4 + 672U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C8CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0013C8D8U + 520U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C8D0U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x0013C8DCU + 524U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C8D4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = 0x0013C8E0U + 0x20CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C8D8U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C8DCU, 0xEE711AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C8E0U, 0xEE300A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C8E4U, 0xEE610AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t address = r4 + 668U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0013C8F0U, address);
            }
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C8F4U, address);
            }
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t address = r4 + 484U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0013C8F8U, address);
            }
        }
        goto block_0013C8FC;
    }
block_0013C8FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C8FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C8FCU);
        }
        {
            const uint32_t address = r4 + 672U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C8FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = 0x0013C910U + 464U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C908U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013C90CU, address);
            }
        }
        goto block_0013C910;
    }
block_0013C910:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C910U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C910U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C910U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0013C9F8; }
        goto block_0013C91C;
    }
block_0013C91C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C91CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C91CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r11, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013C9E4; }
        goto block_0013C924;
    }
block_0013C924:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C924U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C924U);
        }
        {
            const uint32_t address = r4 + 956U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C924U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r10 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C928U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x000003A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C930U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 992U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C934U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C938U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C940U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C940U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C940;
    }
block_0013C940:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C940U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C940U);
        }
        {
            const uint32_t address = r4 + 960U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C940U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r10 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C944U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x000003A8U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C94CU, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 996U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C950U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 984U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C954U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C95CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C95CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C95C;
    }
block_0013C95C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C95CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C95CU);
        }
        {
            const uint32_t address = r4 + 964U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C95CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r10 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C960U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x000003ACU;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C968U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 1000U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C96CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 988U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C970U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C978U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C978U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C978;
    }
block_0013C978:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C978U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C978U);
        }
        {
            const uint32_t address = r4 + 968U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C978U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r10 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C97CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x000003B0U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C984U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 1016U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C988U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 1004U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C98CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C994U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C994U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C994;
    }
block_0013C994:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C994U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C994U);
        }
        {
            const uint32_t address = r4 + 972U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C994U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r10 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C998U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x000003B4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C9A0U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 1020U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C9A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 1008U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C9A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C9B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C9B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C9B0;
    }
block_0013C9B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C9B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C9B0U);
        }
        {
            const uint32_t address = r4 + 976U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C9B0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r10 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C9B4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x000003B8U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013C9BCU, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r10 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C9C0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 1012U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C9C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C9CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C9CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C9CC;
    }
block_0013C9CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C9CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C9CCU);
        }
        {
            const uint32_t address = 0x0013C9D4U + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C9CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r10 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C9D4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C9E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C9E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C9E4;
    }
block_0013C9E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C9E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C9E4U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C9E4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C9E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x000003A4U;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000003B0U;
            r2 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013C9F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CameraSetAtEye_00367B14(frame, context, state, 0x00367B14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013C9F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013C9F8;
    }
block_0013C9F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013C9F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013C9F8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x234U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013C9F8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0013CA70; }
        goto block_0013CA04;
    }
block_0013CA04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CA04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CA04U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r1 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0013CA10U + 0xE0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013CA08U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r0 + operand;
        }
        {
            r1 = ~(0x00000000U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013CA14U, address);
            }
            r5 = value;
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013CA18U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013CA1CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013CA20U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013CA28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013CA28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013CA28;
    }
block_0013CA28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CA28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CA28U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r6 = r0;
        }
        if ((flags.N()) == (flags.V())) { goto block_0013CA48; }
        goto block_0013CA34;
    }
block_0013CA34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CA34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CA34U);
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013CA3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_byte_1b6_00367C48(frame, context, state, 0x00367C48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013CA3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013CA3C;
    }
block_0013CA3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CA3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CA3CU);
        }
        {
            const uint32_t address = 0x0013CA44U + 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013CA3CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
        }
        goto block_0013CAD4;
    }
block_0013CA48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CA48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CA48U);
        }
        {
            r0 = r6;
        }
        if (!(flags.Z())) { goto block_0013CA80; }
        goto block_0013CA50;
    }
block_0013CA50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CA50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CA50U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013CA54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_clear_byte_1b6_00367C54(frame, context, state, 0x00367C54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013CA54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013CA54;
    }
block_0013CA54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CA54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CA54U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r0 = r6;
        }
        {
            const uint32_t address = r4 + 556U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013CA5CU, address);
            }
        }
        {
            const uint32_t address = r4 + 560U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013CA60U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013CA68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00367c60_00367C60(frame, context, state, 0x00367C60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013CA68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013CA68;
    }
block_0013CA68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CA68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CA68U);
        }
        {
            const uint32_t address = r4 + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013CA68U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013CA6CU, address);
            }
        }
        goto block_0013CA70;
    }
block_0013CA70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CA70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CA70U);
        }
        {
            const uint32_t operand = 0x00000054U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0013CA74U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0013CA74U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0013CA74U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0013CA74U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0013CA74U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0013CA74U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0013CA74U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0013CA74U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0013CA74U,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0013CA74U,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0013CA74U,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0013CA74U,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            r13 += 48U;
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0013CA7CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0013CA7CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0013CA7CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0013CA7CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0013CA7CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0013CA7CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0013CA7CU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0013CA7CU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0013CA7CU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_0013CA80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CA80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CA80U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013CA88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_clear_byte_1b6_00367C54(frame, context, state, 0x00367C54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013CA88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013CA88;
    }
block_0013CA88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CA88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CA88U);
        }
        {
            frame.Guest.vfp[0] = r5;
        }
        {
            const uint32_t address = 0x0013CA94U + 76U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013CA8CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x0000022CU;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013CA98U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013CA9CU, 0xEEC90A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013CAA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013CAA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013CAA8;
    }
block_0013CAA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CAA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CAA8U);
        }
        {
            frame.Guest.vfp[0] = r5;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000230U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013CAB4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013CAB8U, 0xEEC90A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013CAC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013CAC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013CAC4;
    }
block_0013CAC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CAC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CAC4U);
        }
        {
            const uint32_t address = r4 + 556U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013CAC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013CAD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00367c60_00367C60(frame, context, state, 0x00367C60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013CAD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013CAD0;
    }
block_0013CAD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CAD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CAD0U);
        }
        {
            const uint32_t address = r4 + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013CAD0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0013CAD4;
    }
block_0013CAD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013CAD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013CAD4U);
        }
        {
            const uint32_t address = r6 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013CAD4U, address);
            }
        }
        goto block_0013CA70;
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_BossFd_Update_001EC834(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001EC834U:
        goto block_001EC834;
    case 0x001EC880U:
        goto block_001EC880;
    case 0x001EC884U:
        goto block_001EC884;
    case 0x001EC8ACU:
        goto block_001EC8AC;
    case 0x001EC8ECU:
        goto block_001EC8EC;
    case 0x001EC8F8U:
        goto block_001EC8F8;
    case 0x001EC910U:
        goto block_001EC910;
    case 0x001EC99CU:
        goto block_001EC99C;
    case 0x001EC9A8U:
        goto block_001EC9A8;
    case 0x001EC9B4U:
        goto block_001EC9B4;
    case 0x001EC9C0U:
        goto block_001EC9C0;
    case 0x001EC9ECU:
        goto block_001EC9EC;
    case 0x001ECA0CU:
        goto block_001ECA0C;
    case 0x001ECA1CU:
        goto block_001ECA1C;
    case 0x001ECA28U:
        goto block_001ECA28;
    case 0x001ECA8CU:
        goto block_001ECA8C;
    case 0x001ECAA8U:
        goto block_001ECAA8;
    case 0x001ECACCU:
        goto block_001ECACC;
    case 0x001ECB14U:
        goto block_001ECB14;
    case 0x001ECB28U:
        goto block_001ECB28;
    case 0x001ECB40U:
        goto block_001ECB40;
    case 0x001ECB50U:
        goto block_001ECB50;
    case 0x001ECB78U:
        goto block_001ECB78;
    case 0x001ECB80U:
        goto block_001ECB80;
    case 0x001ECBC8U:
        goto block_001ECBC8;
    case 0x001ECBD4U:
        goto block_001ECBD4;
    case 0x001ECBF8U:
        goto block_001ECBF8;
    case 0x001ECC28U:
        goto block_001ECC28;
    case 0x001ECC3CU:
        goto block_001ECC3C;
    case 0x001ECC50U:
        goto block_001ECC50;
    case 0x001ECC68U:
        goto block_001ECC68;
    case 0x001ECC84U:
        goto block_001ECC84;
    case 0x001ECC90U:
        goto block_001ECC90;
    case 0x001ECC9CU:
        goto block_001ECC9C;
    case 0x001ECCE4U:
        goto block_001ECCE4;
    case 0x001ECCF0U:
        goto block_001ECCF0;
    case 0x001ECCF8U:
        goto block_001ECCF8;
    case 0x001ECD04U:
        goto block_001ECD04;
    case 0x001ECD10U:
        goto block_001ECD10;
    case 0x001ECD1CU:
        goto block_001ECD1C;
    case 0x001ECD98U:
        goto block_001ECD98;
    case 0x001ECDA8U:
        goto block_001ECDA8;
    case 0x001ECDB8U:
        goto block_001ECDB8;
    case 0x001ECE00U:
        goto block_001ECE00;
    case 0x001ECE0CU:
        goto block_001ECE0C;
    case 0x001ECE18U:
        goto block_001ECE18;
    case 0x001ECE24U:
        goto block_001ECE24;
    case 0x001ECE38U:
        goto block_001ECE38;
    case 0x001ECE54U:
        goto block_001ECE54;
    case 0x001ECE6CU:
        goto block_001ECE6C;
    case 0x001ECE80U:
        goto block_001ECE80;
    case 0x001ECEA8U:
        goto block_001ECEA8;
    case 0x001ECEB8U:
        goto block_001ECEB8;
    case 0x001ECEC4U:
        goto block_001ECEC4;
    case 0x001ECEF4U:
        goto block_001ECEF4;
    case 0x001ECF08U:
        goto block_001ECF08;
    case 0x001ECF10U:
        goto block_001ECF10;
    case 0x001ECF24U:
        goto block_001ECF24;
    case 0x001ECF48U:
        goto block_001ECF48;
    case 0x001ECF50U:
        goto block_001ECF50;
    case 0x001ECF64U:
        goto block_001ECF64;
    case 0x001ECF78U:
        goto block_001ECF78;
    case 0x001ECF84U:
        goto block_001ECF84;
    case 0x001ECF90U:
        goto block_001ECF90;
    case 0x001ECFA0U:
        goto block_001ECFA0;
    case 0x001ECFACU:
        goto block_001ECFAC;
    case 0x001ECFB8U:
        goto block_001ECFB8;
    case 0x001ECFE0U:
        goto block_001ECFE0;
    case 0x001ED008U:
        goto block_001ED008;
    case 0x001ED054U:
        goto block_001ED054;
    case 0x001ED060U:
        goto block_001ED060;
    case 0x001ED0D0U:
        goto block_001ED0D0;
    case 0x001ED118U:
        goto block_001ED118;
    case 0x001ED120U:
        goto block_001ED120;
    case 0x001ED190U:
        goto block_001ED190;
    case 0x001ED19CU:
        goto block_001ED19C;
    case 0x001ED1C4U:
        goto block_001ED1C4;
    case 0x001ED1C8U:
        goto block_001ED1C8;
    case 0x001ED1D0U:
        goto block_001ED1D0;
    case 0x001ED1E8U:
        goto block_001ED1E8;
    case 0x001ED1ECU:
        goto block_001ED1EC;
    case 0x001ED1F4U:
        goto block_001ED1F4;
    case 0x001ED21CU:
        goto block_001ED21C;
    case 0x001ED23CU:
        goto block_001ED23C;
    case 0x001ED260U:
        goto block_001ED260;
    case 0x001ED270U:
        goto block_001ED270;
    case 0x001ED280U:
        goto block_001ED280;
    case 0x001ED290U:
        goto block_001ED290;
    case 0x001ED2A0U:
        goto block_001ED2A0;
    case 0x001ED2B4U:
        goto block_001ED2B4;
    case 0x001ED2CCU:
        goto block_001ED2CC;
    case 0x001ED2D8U:
        goto block_001ED2D8;
    case 0x001ED338U:
        goto block_001ED338;
    case 0x001ED348U:
        goto block_001ED348;
    case 0x001ED354U:
        goto block_001ED354;
    case 0x001ED368U:
        goto block_001ED368;
    case 0x001ED3B0U:
        goto block_001ED3B0;
    case 0x001ED3BCU:
        goto block_001ED3BC;
    case 0x001ED3C8U:
        goto block_001ED3C8;
    case 0x001ED3D4U:
        goto block_001ED3D4;
    case 0x001ED404U:
        goto block_001ED404;
    case 0x001ED414U:
        goto block_001ED414;
    case 0x001ED424U:
        goto block_001ED424;
    case 0x001ED428U:
        goto block_001ED428;
    case 0x001ED430U:
        goto block_001ED430;
    case 0x001ED484U:
        goto block_001ED484;
    case 0x001ED494U:
        goto block_001ED494;
    case 0x001ED4A8U:
        goto block_001ED4A8;
    case 0x001ED4C0U:
        goto block_001ED4C0;
    case 0x001ED4C4U:
        goto block_001ED4C4;
    case 0x001ED4D4U:
        goto block_001ED4D4;
    case 0x001ED4DCU:
        goto block_001ED4DC;
    case 0x001ED4E8U:
        goto block_001ED4E8;
    case 0x001ED4F0U:
        goto block_001ED4F0;
    case 0x001ED4FCU:
        goto block_001ED4FC;
    case 0x001ED520U:
        goto block_001ED520;
    case 0x001ED528U:
        goto block_001ED528;
    case 0x001ED538U:
        goto block_001ED538;
    case 0x001ED53CU:
        goto block_001ED53C;
    case 0x001ED554U:
        goto block_001ED554;
    case 0x001ED55CU:
        goto block_001ED55C;
    case 0x001ED564U:
        goto block_001ED564;
    case 0x001ED56CU:
        goto block_001ED56C;
    case 0x001ED574U:
        goto block_001ED574;
    case 0x001ED57CU:
        goto block_001ED57C;
    case 0x001ED594U:
        goto block_001ED594;
    case 0x001ED5A4U:
        goto block_001ED5A4;
    case 0x001ED5BCU:
        goto block_001ED5BC;
    case 0x001ED5C4U:
        goto block_001ED5C4;
    case 0x001ED5D0U:
        goto block_001ED5D0;
    case 0x001ED5D8U:
        goto block_001ED5D8;
    case 0x001ED5E0U:
        goto block_001ED5E0;
    case 0x001ED5E4U:
        goto block_001ED5E4;
    case 0x001ED600U:
        goto block_001ED600;
    case 0x001ED64CU:
        goto block_001ED64C;
    case 0x001ED664U:
        goto block_001ED664;
    case 0x001ED67CU:
        goto block_001ED67C;
    case 0x001ED698U:
        goto block_001ED698;
    case 0x001ED6B0U:
        goto block_001ED6B0;
    case 0x001ED6C4U:
        goto block_001ED6C4;
    case 0x001ED6CCU:
        goto block_001ED6CC;
    case 0x001ED6D8U:
        goto block_001ED6D8;
    case 0x001ED6E0U:
        goto block_001ED6E0;
    case 0x001ED6ECU:
        goto block_001ED6EC;
    case 0x001ED704U:
        goto block_001ED704;
    case 0x001ED710U:
        goto block_001ED710;
    case 0x001ED718U:
        goto block_001ED718;
    case 0x001ED720U:
        goto block_001ED720;
    case 0x001ED724U:
        goto block_001ED724;
    case 0x001ED740U:
        goto block_001ED740;
    case 0x001ED758U:
        goto block_001ED758;
    case 0x001ED774U:
        goto block_001ED774;
    case 0x001ED78CU:
        goto block_001ED78C;
    case 0x001ED794U:
        goto block_001ED794;
    case 0x001ED7A0U:
        goto block_001ED7A0;
    case 0x001ED7B4U:
        goto block_001ED7B4;
    case 0x001ED7BCU:
        goto block_001ED7BC;
    case 0x001ED7C8U:
        goto block_001ED7C8;
    case 0x001ED7D0U:
        goto block_001ED7D0;
    case 0x001ED7D4U:
        goto block_001ED7D4;
    case 0x001ED7F0U:
        goto block_001ED7F0;
    case 0x001ED7FCU:
        goto block_001ED7FC;
    case 0x001ED804U:
        goto block_001ED804;
    case 0x001ED82CU:
        goto block_001ED82C;
    case 0x001ED850U:
        goto block_001ED850;
    case 0x001ED85CU:
        goto block_001ED85C;
    case 0x001ED860U:
        goto block_001ED860;
    case 0x001ED864U:
        goto block_001ED864;
    case 0x001ED870U:
        goto block_001ED870;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001EC834:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EC834U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EC834U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001EC834U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001EC834U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001EC834U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001EC834U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001EC834U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001EC834U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001EC834U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001EC834U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001EC834U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r5 = r0;
        }
        {
            const uint32_t operand = 0x00007C00U;
            r0 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r6 = r5 + operand;
        }
        {
            r13 -= 64U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 44U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 48U, frame.Guest.vfp[28])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 48U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 52U, frame.Guest.vfp[29])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 52U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 56U, frame.Guest.vfp[30])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 56U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 60U, frame.Guest.vfp[31])) {
                return Oot3dAotMemoryFault(context, 0x001EC844U,
                                           firstAddress + 60U);
            }
        }
        {
            const uint32_t operand = 0x00000034U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001EC84CU, address);
            }
        }
        {
            const uint32_t address = r0 + 836U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC850U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 124U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EC854U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x8EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC858U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EC860U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC864U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EC86CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x880U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC870U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC874U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x001EC880U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EC880U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EC880;
    }
block_001EC880:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EC880U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EC880U);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_001EC884;
    }
block_001EC884:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EC884U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EC884U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC890U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r2 = r2 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + 0xB0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001EC8A0U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_001EC884; }
        goto block_001EC8AC;
    }
block_001EC8AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EC8ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EC8ACU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x84U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC8ACU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r4 = 0x00000014U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x84U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EC8BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x98U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC8C0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EC8CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC8D0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EC8DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x8AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC8E0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000C8U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001ECA1C; }
        goto block_001EC8EC;
    }
block_001EC8EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EC8ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EC8ECU);
        }
        {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC8ECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001EC9EC; }
        goto block_001EC8F8;
    }
block_001EC8F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EC8F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EC8F8U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r3 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC8FCU, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x330U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC900U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x16U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC904U, address);
            }
            r2 = value;
        }
        {
            const uint32_t value = r2 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_001EC9EC; }
        goto block_001EC910;
    }
block_001EC910:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EC910U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EC910U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC910U, address);
            }
            r0 = value;
        }
        {
            r2 = r2 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001EC918U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC91CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r2 - operand;
        }
        {
            r1 = r1 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r5 + 0xB7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001EC928U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC92CU, address);
            }
            r7 = value;
        }
        {
            const uint32_t value = r7 & 0x00001000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00001000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000002U;
            r1 = r1 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0xB7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001EC938U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC93CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r1 = 0x00000002U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r5 + 0xB7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001EC948U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x330U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC94CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC950U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r3;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC958U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r1 + 0x12U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC95CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r3;
        }
        {
            frame.Guest.vfp[2] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EC968U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r3 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EC970U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EC974U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EC978U, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EC97CU, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001EC980U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC984U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001EC988U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r3 = r13 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC994U, address);
            }
            r1 = value;
        }
        if (flags.Z()) { goto block_001EC9B4; }
        goto block_001EC99C;
    }
block_001EC99C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EC99CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EC99CU);
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r12;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EC9A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSs_SpawnSurfaceImpact_003741E4(frame, context, state, 0x003741E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EC9A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EC9A8;
    }
block_001EC9A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EC9A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EC9A8U);
        }
        {
        }
        {
        }
        goto block_001EC9C0;
    }
block_001EC9B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EC9B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EC9B4U);
        }
        {
            r2 = 0x00000001U;
        }
        {
            r0 = r12;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EC9C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSs_SpawnSurfaceImpact_003741E4(frame, context, state, 0x003741E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EC9C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EC9C0;
    }
block_001EC9C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EC9C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EC9C0U);
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = 0x001EC9CCU + 0x36CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC9C4U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x001EC9D0U + 0x36CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC9C8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EC9CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x001EC9D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001EC9D4U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x001EC9E4U + 0x35CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC9DCU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EC9ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EC9ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EC9EC;
    }
block_001EC9EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EC9ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EC9ECU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EC9ECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r2 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000314U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r7 = r2;
        }
        {
            r8 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECA0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECA0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECA0C;
    }
block_001ECA0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECA0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECA0CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA0CU, address);
            }
            r0 = value;
        }
        {
            r2 = r7;
        }
        {
            r1 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECA1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAT_003761F0(frame, context, state, 0x003761F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECA1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECA1C;
    }
block_001ECA1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECA1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECA1CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA1CU, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECA28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_001317dc_001317DC(frame, context, state, 0x001317DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECA28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECA28;
    }
block_001ECA28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECA28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECA28U);
        }
        {
            const uint32_t address = r6 + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA28U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001ECA34U + 784U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA2CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001ECA38U + 792U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA30U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x001ECA3CU + 792U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA34U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECA38U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x001ECA44U + 776U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA3CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001ECA48U + 792U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA40U, address);
            }
            frame.Guest.vfp[28] = value;
        }
        {
            const uint32_t address = 0x001ECA4CU + 784U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA44U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r6 + 188U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECA48U, address);
            }
        }
        {
            const uint32_t address = 0x001ECA54U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA4CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 192U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECA50U, address);
            }
        }
        {
            const uint32_t address = r6 + 196U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA54U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECA58U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[28];
        }
        {
            const uint32_t address = r6 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECA60U, address);
            }
        }
        {
            const uint32_t address = r6 + 200U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECA68U, 0xEE300A68U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 200U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECA6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x8EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA70U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000010U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        if (flags.Z()) {
            const uint32_t address = 0x001ECA88U + 720U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA80U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000000D8U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECA8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECA8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECA8C;
    }
block_001ECA8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECA8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECA8CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x86U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA8CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001ECA98U + 716U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA90U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x001ECA9CU + 716U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA94U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) {
            const uint32_t address = r6 + 216U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECA9CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) {
            const uint32_t address = r6 + 220U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECAA0U, address);
            }
        }
        if (flags.Z()) { goto block_001ECACC; }
        goto block_001ECAA8;
    }
block_001ECAA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECAA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECAA8U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x8EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECAA8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[28];
        }
        {
            const uint32_t address = 0x001ECAB8U + 692U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECAB0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t value = r0 & 0x00000008U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000000DCU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECACCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECACCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECACC;
    }
block_001ECACC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECACCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECACCU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x8EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECACCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001ECAD8U + 664U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECAD0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001ECADCU + 664U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECAD4U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t value = r0 & 0x00000008U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t operand = 0x00000003U;
            r1 = r0 + operand;
        }
        if (flags.Z()) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        {
            const uint32_t value = r1 & 0x00000008U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) {
            frame.Guest.vfp[18] = frame.Guest.vfp[16];
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[18] = frame.Guest.vfp[1];
        }
        {
            const uint32_t operand = 0x00000006U;
            r0 = r0 + operand;
        }
        {
            const uint32_t value = r0 & 0x00000008U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[16] = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[28];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000000ECU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECB14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECB14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECB14;
    }
block_001ECB14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECB14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECB14U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[28];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x000008F0U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECB28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECB28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECB28;
    }
block_001ECB28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECB28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECB28U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[28];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000000F4U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECB40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECB40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECB40;
    }
block_001ECB40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECB40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECB40U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECB40U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001ECB4CU + 556U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECB44U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001ECDB8; }
        goto block_001ECB50;
    }
block_001ECB50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECB50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECB50U);
        }
        {
            const uint32_t updatedAddress = 0x001ECB58U + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECB50U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ECB5CU, address);
            }
        }
        {
            const uint32_t leftValue = r1;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r1, 2U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 31U);
            r1 = r2 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r1 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 3U);
            Oot3dAotSetAddFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 + operand;
        }
        if (!(flags.Z())) { goto block_001ECDB8; }
        goto block_001ECB78;
    }
block_001ECB78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECB78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECB78U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECB80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECB80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECB80;
    }
block_001ECB80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECB80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECB80U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECB80U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = 0x00000082U;
        }
        {
            r3 = 0x00000064U;
        }
        {
            const uint32_t address = 0x001ECB94U + 492U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECB8CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001ECBA0U, address);
            }
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001ECBA4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001ECBA4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001ECBA4U,
                                           firstAddress + 8U);
            }
        }
        {
            r3 = 0x000000ADU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECBACU, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = r5 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECBB0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECBB4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r2 + operand;
        }
        {
            r1 = r5;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECBC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECBC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECBC8;
    }
block_001ECBC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECBC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECBC8U);
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r0, 0U, 0U, flags.C());
            r8 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r8, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
        }
        if (flags.Z()) { goto block_001ECDB8; }
        goto block_001ECBD4;
    }
block_001ECBD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECBD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECBD4U);
        }
        {
            const uint32_t operand = 0x00002800U;
            r10 = r5 + operand;
        }
        {
            const uint32_t address = 0x001ECBE0U + 420U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECBD8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x001ECBE4U + 420U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECBDCU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x001ECBE8U + 420U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECBE0U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x001ECBECU + 420U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECBE4U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x001ECBF0U + 420U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECBE8U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            r9 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000124U;
            r10 = r10 + operand;
        }
        {
            r11 = 0x000000FFU;
        }
        goto block_001ECBF8;
    }
block_001ECBF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECBF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECBF8U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[24];
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECC04U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001ECC0CU, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ECC10U, address);
            }
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001ECC14U, address);
            }
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECC18U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ECC20U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECC28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECC28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECC28;
    }
block_001ECC28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECC28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECC28U);
        }
        {
            const uint32_t address = r8 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECC28U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECC2CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECC30U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECC3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECC3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECC3C;
    }
block_001ECC3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECC3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECC3CU);
        }
        {
            const uint32_t address = r8 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECC3CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECC40U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECC44U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECC50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECC50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECC50;
    }
block_001ECC50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECC50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECC50U);
        }
        {
            const uint32_t address = r8 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECC50U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r4 = r10;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECC58U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECC5CU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[23];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECC68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECC68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECC68;
    }
block_001ECC68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECC68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECC68U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECC68U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = 0x00000014U;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECC80U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        goto block_001ECC84;
    }
block_001ECC84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECC84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECC84U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECC84U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001ECD98; }
        goto block_001ECC90;
    }
block_001ECC90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECC90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECC90U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECC90U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001ECD98; }
        goto block_001ECC9C;
    }
block_001ECC9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECC9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECC9CU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ECCA4U, address);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001ECCA8U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001ECCA8U,
                                           firstAddress + 4U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001ECCA8U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r7 = value7;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r1 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECCB4U, 0xEE200A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001ECCB8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001ECCB8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001ECCB8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001ECCC0U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001ECCC0U,
                                           firstAddress + 4U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001ECCC0U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r7 = value7;
        }
        {
            const uint32_t operand = 0x00000010U;
            r1 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001ECCC8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001ECCC8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001ECCC8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001ECCD0U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001ECCD0U,
                                           firstAddress + 4U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001ECCD0U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r7 = value7;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001ECCD4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001ECCD4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001ECCD4U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r4 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECCD8U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECCE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECCE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECCE4;
    }
block_001ECCE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECCE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECCE4U);
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECCE4U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECCF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECCF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECCF0;
    }
block_001ECCF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECCF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECCF0U);
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECCF0U, address);
            }
        }
        {
            r7 = 0x00000000U;
        }
        goto block_001ECCF8;
    }
block_001ECCF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECCF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECCF8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECCF8U, address);
            }
            r0 = value;
        }
        {
            r1 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECD04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_HideMesh_0036932C(frame, context, state, 0x0036932CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECD04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECD04;
    }
block_001ECD04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECD04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECD04U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r7 = r7 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001ECCF8; }
        goto block_001ECD10;
    }
block_001ECD10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECD10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECD10U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECD10U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECD1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_ShowMesh_0037266C(frame, context, state, 0x0037266CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECD1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECD1C;
    }
block_001ECD1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECD1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECD1CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001ECD1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x3EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001ECD20U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x3DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001ECD24U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001ECD2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x43U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ECD30U, address);
            }
        }
        goto block_001ECDA8;
    }
block_001ECD98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECD98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECD98U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000006EU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t operand = 0x0000004CU;
            r4 = r4 + operand;
        }
        if ((flags.N()) != (flags.V())) { goto block_001ECC84; }
        goto block_001ECDA8;
    }
block_001ECDA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECDA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECDA8U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r9 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r9 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001ECBF8; }
        goto block_001ECDB8;
    }
block_001ECDB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECDB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECDB8U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[24];
        }
        {
            const uint32_t updatedAddress = 0x001ECDCCU + 0x37CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECDC4U, address);
            }
            r7 = value;
        }
        {
            const uint32_t address = 0x001ECDD0U + 880U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECDC8U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECDCCU, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ECDD0U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001ECDD4U, address);
            }
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECDD8U, address);
            }
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ECDDCU, address);
            }
        }
        {
            const uint32_t address = 0x001ECDE8U + 860U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECDE0U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x001ECDECU + 864U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECDE4U, address);
            }
            frame.Guest.vfp[29] = value;
        }
        {
            const uint32_t address = 0x001ECDF0U + 864U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECDE8U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x001ECDF4U + 864U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECDECU, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x001ECDF8U + 864U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECDF0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001ECDF4U, address);
            }
        }
        {
            r4 = 0x00000000U;
        }
        {
            r9 = 0x00000006U;
        }
        goto block_001ECE00;
    }
block_001ECE00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECE00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECE00U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x001ECE04U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECE0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECE0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECE0C;
    }
block_001ECE0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECE0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECE0CU);
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECE0CU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECE18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECE18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECE18;
    }
block_001ECE18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECE18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECE18U);
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECE18U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECE24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECE24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECE24;
    }
block_001ECE24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECE24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECE24U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECE24U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r8 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECE38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECE38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECE38;
    }
block_001ECE38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECE38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECE38U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 1U);
            r0 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r8 = r7 + operand;
        }
        {
            const uint32_t address = r8 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECE40U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECE44U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECE48U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[29];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECE54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECE54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECE54;
    }
block_001ECE54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECE54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECE54U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECE54U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECE58U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECE5CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECE60U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECE6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECE6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECE6C;
    }
block_001ECE6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECE6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECE6CU);
        }
        {
            const uint32_t address = r8 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECE6CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECE70U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECE74U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECE80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECE80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECE80;
    }
block_001ECE80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECE80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECE80U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECE80U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000010U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r9;
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = r5;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECEA0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECEA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BossFd_SpawnEmber_0036FDE0(frame, context, state, 0x0036FDE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECEA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECEA8;
    }
block_001ECEA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECEA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECEA8U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001ECE00; }
        goto block_001ECEB8;
    }
block_001ECEB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECEB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECEB8U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x86U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECEB8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001ED008; }
        goto block_001ECEC4;
    }
block_001ECEC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECEC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECEC4U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r6 + 252U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECEC8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[21] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x001ECED8U + 644U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECED0U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            r4 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECED8U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECEE0U, 0xEE010A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECEE4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r4, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001ED008; }
        goto block_001ECEF4;
    }
block_001ECEF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECEF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECEF4U);
        }
        {
            frame.Guest.vfp[25] = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = 0x001ECF00U + 0x264U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECEF8U, address);
            }
            r8 = value;
        }
        {
            const uint32_t address = 0x001ECF04U + 604U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECEFCU, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            const uint32_t address = 0x001ECF08U + 608U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECF00U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            r9 = 0x00000008U;
        }
        goto block_001ECF08;
    }
block_001ECF08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECF08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECF08U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[26];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECF10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECF10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECF10;
    }
block_001ECF10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECF10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECF10U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECF10U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r7 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECF24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECF24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECF24;
    }
block_001ECF24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECF24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECF24U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 1U);
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00001800U;
            r7 = r0 + operand;
        }
        {
            const uint32_t address = r7 + 468U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECF30U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECF34U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECF3CU, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r8, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001ECFE0; }
        goto block_001ECF48;
    }
block_001ECF48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECF48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECF48U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECF50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECF50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECF50;
    }
block_001ECF50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECF50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECF50U);
        }
        {
            const uint32_t address = r7 + 464U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECF50U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECF54U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECF58U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECF64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECF64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECF64;
    }
block_001ECF64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECF64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECF64U);
        }
        {
            const uint32_t address = r7 + 472U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECF64U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECF68U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECF6CU, address);
            }
        }
        {
            const uint32_t address = r6 + 248U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECF70U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECF78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECF78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECF78;
    }
block_001ECF78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECF78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECF78U);
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECF78U, address);
            }
        }
        {
            const uint32_t address = r6 + 248U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECF7CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECF84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECF84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECF84;
    }
block_001ECF84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECF84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECF84U);
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECF84U, address);
            }
        }
        {
            const uint32_t address = r6 + 248U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECF88U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECF90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECF90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECF90;
    }
block_001ECF90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECF90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECF90U);
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECF90U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x001ECF98U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECFA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECFA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECFA0;
    }
block_001ECFA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECFA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECFA0U);
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECFA0U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECFACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECFACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECFAC;
    }
block_001ECFAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECFACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECFACU);
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ECFACU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[25];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECFB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECFB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECFB8;
    }
block_001ECFB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECFB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECFB8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECFB8U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000010U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r9;
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = r5;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECFD8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ECFE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BossFd_SpawnEmber_0036FDE0(frame, context, state, 0x0036FDE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ECFE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ECFE0;
    }
block_001ECFE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ECFE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ECFE0U);
        }
        {
            const uint32_t address = r6 + 252U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ECFE0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECFE8U, 0xEE600A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECFF4U, 0xEE000A8BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ECFF8U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r4, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001ECF08; }
        goto block_001ED008;
    }
block_001ED008:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED008U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED008U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED008U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00002800U;
            r4 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000124U;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x001ED018U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED01CU, address);
            }
            r8 = value;
        }
        {
            r9 = 0x00000000U;
        }
        {
            const uint32_t address = 0x001ED02CU + 320U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED024U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x001ED030U + 320U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED028U, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            const uint32_t address = 0x001ED034U + 320U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED02CU, address);
            }
            frame.Guest.vfp[31] = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t address = 0x001ED03CU + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED034U, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            const uint32_t address = 0x001ED040U + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED038U, address);
            }
            frame.Guest.vfp[27] = value;
        }
        {
            const uint32_t address = 0x001ED044U + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED03CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x001ED048U + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED040U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x001ED04CU + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED044U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x001ED050U + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED048U, address);
            }
            frame.Guest.vfp[30] = value;
        }
        {
            r10 = r9;
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED050U, address);
            }
        }
        goto block_001ED054;
    }
block_001ED054:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED054U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED054U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED054U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001ED4C4; }
        goto block_001ED060;
    }
block_001ED060:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED060U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED060U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x35U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED060U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001ED068U, address);
            }
        }
        {
            const uint32_t address = r4 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED06CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED070U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED074U, 0xEE301A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001ED078U, address);
            }
        }
        {
            const uint32_t address = r4 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED07CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED080U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED084U, 0xEE300A02U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED088U, address);
            }
        }
        {
            const uint32_t address = r4 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED08CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r4 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED090U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED094U, 0xEE711AA2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[3], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001ED098U, address);
            }
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED09CU, address);
            }
            frame.Guest.vfp[6] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED0A0U, 0xEE700A83U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[6], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ED0A4U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED0A8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED0ACU, 0xEE720A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[4], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ED0B0U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED0B4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED0B8U, 0xEE720AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[5], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ED0BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x42U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED0C0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x43U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED0C4U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_001ED118; }
        goto block_001ED0D0;
    }
block_001ED0D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED0D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED0D0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            r1 = r1 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x42U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001ED0D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED0DCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x3FU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED0E0U, address);
            }
            r3 = value;
        }
        {
            const int32_t left = static_cast<int16_t>(
                r2 >> 0U);
            const int32_t right = static_cast<int16_t>(
                r1 >> 0U);
            r2 = static_cast<uint32_t>(left * right);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r2, 7U);
            r2 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001ED0ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x46U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED0F0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x40U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED0F4U, address);
            }
            r3 = value;
        }
        {
            const int32_t left = static_cast<int16_t>(
                r2 >> 0U);
            const int32_t right = static_cast<int16_t>(
                r1 >> 0U);
            r2 = static_cast<uint32_t>(left * right);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r2, 7U);
            r2 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x3DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001ED100U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x48U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED104U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x41U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED108U, address);
            }
            r3 = value;
        }
        {
            const int32_t left = static_cast<int16_t>(
                r2 >> 0U);
            const int32_t right = static_cast<int16_t>(
                r1 >> 0U);
            r1 = static_cast<uint32_t>(left * right);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 7U);
            r1 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x3EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001ED114U, address);
            }
        }
        goto block_001ED118;
    }
block_001ED118:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED118U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED118U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001ED190; }
        goto block_001ED120;
    }
block_001ED120:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED120U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED120U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED120U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED130U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001ED134U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001ED138U, address);
            }
        }
        goto block_001ED4C4;
    }
block_001ED190:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED190U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED190U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001ED1C8; }
        goto block_001ED19C;
    }
block_001ED19C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED19CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED19CU);
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED19CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x001ED1A8U + 0x470U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED1A0U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED1A8U, 0xEE700AABU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ED1B0U, address);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED1B4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED1B8U, 0xEE700AACU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ED1BCU, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001ED4C4; }
        goto block_001ED1C4;
    }
block_001ED1C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED1C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED1C4U);
        }
        goto block_001ED4C0;
    }
block_001ED1C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED1C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED1C8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001ED1EC; }
        goto block_001ED1D0;
    }
block_001ED1D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED1D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED1D0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED1D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000010U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t updatedAddress = r4 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED1E0U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_001ED4C4; }
        goto block_001ED1E8;
    }
block_001ED1E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED1E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED1E8U);
        }
        goto block_001ED4C0;
    }
block_001ED1EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED1ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED1ECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001ED4C4; }
        goto block_001ED1F4;
    }
block_001ED1F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED1F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED1F4U);
        }
        {
            const uint32_t address = r8 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED1F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0xB6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED1F8U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED1FCU, 0xEE301AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED200U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED208U, 0xEE700AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED20CU, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED210U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED214U, 0xEE700AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        if (!(flags.Z())) { goto block_001ED280; }
        goto block_001ED21C;
    }
block_001ED21C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED21CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED21CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED21CU, 0xEE211A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = 0x001ED228U + 0x3F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED220U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED224U, 0xEE001A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED228U, 0xEE001AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED22CU, 0xEEB10AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001ED280; }
        goto block_001ED23C;
    }
block_001ED23C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED23CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED23CU);
        }
        {
            r0 = 0x0000004BU;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[31];
        }
        {
            const uint32_t updatedAddress = r6 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED248U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x3AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED24CU, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED250U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000030U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED260U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetPlayerKnockbackLarge_00368FC0(frame, context, state, 0x00368FC0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED260U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED260;
    }
block_001ED260:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED260U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED260U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED260U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x46CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED264U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001ED280; }
        goto block_001ED270;
    }
block_001ED270:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED270U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED270U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED270U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED280U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035d8d8_0035D8D8(frame, context, state, 0x0035D8D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED280U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED280;
    }
block_001ED280:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED280U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED280U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED280U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED284U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001ED484; }
        goto block_001ED290;
    }
block_001ED290:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED290U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED290U);
        }
        {
            const uint32_t updatedAddress = 0x001ED298U + 0x388U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED290U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_001ED2B4; }
        goto block_001ED2A0;
    }
block_001ED2A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED2A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED2A0U);
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED2A0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED2A4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED2A8U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED2ACU, 0xEE300A8DU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[26], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED2B0U, address);
            }
        }
        goto block_001ED2B4;
    }
block_001ED2B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED2B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED2B4U);
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED2B4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED2B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED2BCU, 0xEE700AADU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[27], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED2C0U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C()) || (flags.Z())) { goto block_001ED2D8; }
        goto block_001ED2CC;
    }
block_001ED2CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED2CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED2CCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x35U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED2CCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_001ED4C4; }
        goto block_001ED2D8;
    }
block_001ED2D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED2D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED2D8U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED2DCU, address);
            }
        }
        {
            const uint32_t address = r4 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED2E0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r11 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED2E8U, 0xEE600A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED2ECU, 0xEE200A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ED2F0U, address);
            }
        }
        {
            const uint32_t address = r4 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED2F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED2F8U, 0xEE201A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED2FCU, 0xEE600AAAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001ED300U, address);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[24];
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x001ED308U, address);
            }
        }
        {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001ED30CU, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED310U, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001ED314U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ED318U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ED324U, address);
            }
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED328U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[30];
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001ED330U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED338U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED338U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED338;
    }
block_001ED338:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED338U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED338U);
        }
        {
            const uint32_t address = 0x001ED340U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED338U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED33CU, address);
            }
            r7 = value;
        }
        {
            r0 = 0x00000014U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED344U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        goto block_001ED348;
    }
block_001ED348:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED348U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED348U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED348U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001ED414; }
        goto block_001ED354;
    }
block_001ED354:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED354U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED354U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED354U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x86CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED35CU, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001ED414; }
        goto block_001ED368;
    }
block_001ED368:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED368U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED368U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED36CU, address);
            }
        }
        {
            const uint32_t firstAddress = r11;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001ED370U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001ED370U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001ED370U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r7 + operand;
        }
        {
            const uint32_t address = 0x001ED380U + 680U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED378U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001ED37CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001ED37CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001ED37CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r7 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001ED388U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001ED388U,
                                           firstAddress + 4U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001ED388U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r11 = value11;
        }
        {
            const uint32_t operand = 0x00000010U;
            r1 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED390U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001ED394U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001ED394U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001ED394U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r7 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001ED39CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001ED39CU,
                                           firstAddress + 4U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001ED39CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r11 = value11;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001ED3A0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001ED3A0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001ED3A0U,
                                           firstAddress + 8U);
            }
        }
        {
            r11 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001ED3A8U, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED3ACU, address);
            }
        }
        goto block_001ED3B0;
    }
block_001ED3B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED3B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED3B0U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED3B0U, address);
            }
            r0 = value;
        }
        {
            r1 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED3BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_HideMesh_0036932C(frame, context, state, 0x0036932CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED3BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED3BC;
    }
block_001ED3BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED3BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED3BCU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r11 = r11 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r11, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001ED3B0; }
        goto block_001ED3C8;
    }
block_001ED3C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED3C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED3C8U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED3C8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED3D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_ShowMesh_0037266C(frame, context, state, 0x0037266CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED3D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED3D4;
    }
block_001ED3D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED3D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED3D4U);
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r7 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED3D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x43U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001ED3DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001ED3E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x3DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001ED3E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x3EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001ED3E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x42U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001ED3ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED3F0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x86CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED3F4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED3F8U, address);
            }
            r11 = value;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED404U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED404U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED404;
    }
block_001ED404:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED404U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED404U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r11 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED408U, address);
            }
        }
        {
            const uint32_t address = r11 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001ED40CU, address);
            }
        }
        goto block_001ED428;
    }
block_001ED414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED414U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000006EU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t operand = 0x0000004CU;
            r7 = r7 + operand;
        }
        if ((flags.N()) != (flags.V())) { goto block_001ED348; }
        goto block_001ED424;
    }
block_001ED424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED424U);
        }
        {
            r7 = r10;
        }
        goto block_001ED428;
    }
block_001ED428:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED428U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED428U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001ED4C4; }
        goto block_001ED430;
    }
block_001ED430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED430U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED430U, address);
            }
            r0 = value;
        }
        {
            r12 = 0x00000008U;
        }
        {
            r11 = 0x000000A0U;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r1 = operand - r0;
        }
        {
            const uint32_t updatedAddress = r7 + 0x3FU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED440U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x3DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED444U, address);
            }
            r0 = value;
        }
        {
            r1 = Oot3dAotLsl(r1, 4U);
        }
        {
            const uint32_t operand = 0x000000FFU;
            r2 = operand - r0;
        }
        {
            const uint32_t updatedAddress = r7 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED450U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x3EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED454U, address);
            }
            r0 = value;
        }
        {
            r2 = Oot3dAotLsl(r2, 4U);
        }
        {
            const uint32_t operand = 0x000000FFU;
            r3 = operand - r0;
        }
        {
            const uint32_t updatedAddress = r7 + 0x41U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED460U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001ED464U, address);
            }
        }
        {
            r3 = Oot3dAotLsl(r3, 4U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x46U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001ED46CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001ED470U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x42U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001ED474U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x43U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x001ED478U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001ED47CU, address);
            }
        }
        goto block_001ED4C4;
    }
block_001ED484:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED484U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED484U);
        }
        {
            const uint32_t updatedAddress = 0x001ED48CU + 0x194U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED484U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001ED4A8; }
        goto block_001ED494;
    }
block_001ED494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED494U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x001ED4A0U + 396U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED498U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED4A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED4A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED4A8;
    }
block_001ED4A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED4A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED4A8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED4A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED4B8U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001ED4C4; }
        goto block_001ED4C0;
    }
block_001ED4C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED4C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED4C0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001ED4C0U, address);
            }
        }
        goto block_001ED4C4;
    }
block_001ED4C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED4C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED4C4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r9 = r9 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, 0x0000006EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x0000004CU;
            r4 = r4 + operand;
        }
        if ((flags.N()) != (flags.V())) { goto block_001ED054; }
        goto block_001ED4D4;
    }
block_001ED4D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED4D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED4D4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED4D4U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED4DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_22a0_0037571C(frame, context, state, 0x0037571CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED4DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED4DC;
    }
block_001ED4DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED4DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED4DCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if ((flags.N()) != (flags.V())) { goto block_001ED870; }
        goto block_001ED4E8;
    }
block_001ED4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED4E8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED4E8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED4F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_22a0_0037571C(frame, context, state, 0x0037571CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED4F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED4F0;
    }
block_001ED4F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED4F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED4F0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if ((flags.N()) == (flags.V())) { goto block_001ED870; }
        goto block_001ED4FC;
    }
block_001ED4FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED4FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED4FCU);
        }
        {
            const uint32_t updatedAddress = 0x001ED504U + 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED4FCU, address);
            }
            r4 = value;
        }
        {
            const uint32_t address = 0x001ED508U + 300U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED500U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r2 = 0x0000005AU;
        }
        {
            r3 = 0x0000003CU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED50CU, address);
            }
            r0 = value;
        }
        {
            r12 = 0x00000096U;
        }
        {
            r6 = ~(0x00000000U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001ED53C; }
        goto block_001ED520;
    }
block_001ED520:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED520U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED520U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001ED78C; }
        goto block_001ED528;
    }
block_001ED528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED528U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED528U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001ED534U + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED52CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000208U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001ED6C4; }
        goto block_001ED538;
    }
block_001ED538:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED538U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED538U);
        }
        goto block_001ED64C;
    }
block_001ED53C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED53CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED53CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED53CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001ED548U + 0xF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED540U, address);
            }
            r7 = value;
        }
        {
            const uint32_t address = 0x001ED54CU + 244U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED544U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r7, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = r7;
            r1 = r0 - operand;
        }
        if (flags.Z()) { goto block_001ED64C; }
        goto block_001ED554;
    }
block_001ED554:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED554U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED554U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001ED5BC; }
        goto block_001ED55C;
    }
block_001ED55C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED55CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED55CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000078U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001ED600; }
        goto block_001ED564;
    }
block_001ED564:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED564U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED564U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001ED594; }
        goto block_001ED56C;
    }
block_001ED56C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED56CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED56CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001ED5E4; }
        goto block_001ED574;
    }
block_001ED574:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED574U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED574U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001ED794; }
        goto block_001ED57C;
    }
block_001ED57C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED57CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED57CU);
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001ED580U, address);
            }
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001ED584U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001ED590U + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED588U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001ED58CU, address);
            }
        }
        goto block_001ED794;
    }
block_001ED594:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED594U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED594U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x0000000EU;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000E4U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001ED794; }
        goto block_001ED5A4;
    }
block_001ED5A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED5A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED5A4U);
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED5A8U, address);
            }
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001ED5ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001ED5B8U + 0x8CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED5B0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001ED5B4U, address);
            }
        }
        goto block_001ED794;
    }
block_001ED5BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED5BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED5BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000078U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001ED664; }
        goto block_001ED5C4;
    }
block_001ED5C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED5C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED5C4U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r1 - operand;
        }
        {
            const uint32_t operand = 0x0000001DU;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        if (flags.Z()) { goto block_001ED67C; }
        goto block_001ED5D0;
    }
block_001ED5D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED5D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED5D0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001ED698; }
        goto block_001ED5D8;
    }
block_001ED5D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED5D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED5D8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000134U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001ED794; }
        goto block_001ED5E0;
    }
block_001ED5E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED5E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED5E0U);
        }
        goto block_001ED6B0;
    }
block_001ED5E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED5E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED5E4U);
        }
        {
            const uint32_t address = 0x001ED5ECU + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED5E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED5ECU, address);
            }
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001ED5F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001ED5FCU + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED5F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001ED5F8U, address);
            }
        }
        goto block_001ED794;
    }
block_001ED600:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED600U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED600U);
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001ED604U, address);
            }
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001ED608U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001ED614U + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED60CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001ED610U, address);
            }
        }
        goto block_001ED794;
    }
block_001ED64C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED64CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED64CU);
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED650U, address);
            }
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001ED654U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001ED660U - 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED658U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001ED65CU, address);
            }
        }
        goto block_001ED794;
    }
block_001ED664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED664U);
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED668U, address);
            }
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001ED66CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001ED678U - 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED670U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x001ED674U, address);
            }
        }
        goto block_001ED794;
    }
block_001ED67C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED67CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED67CU);
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = 0x001ED688U - 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED680U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r0 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001ED684U, address);
            }
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001ED688U, address);
            }
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED690U, address);
            }
        }
        goto block_001ED794;
    }
block_001ED698:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED698U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED698U);
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[29])) {
                return Oot3dAotMemoryFault(context, 0x001ED69CU, address);
            }
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001ED6A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001ED6ACU - 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED6A4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001ED6A8U, address);
            }
        }
        goto block_001ED794;
    }
block_001ED6B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED6B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED6B0U);
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001ED6B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001ED6C0U - 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED6B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001ED6BCU, address);
            }
        }
        goto block_001ED794;
    }
block_001ED6C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED6C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED6C4U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001ED704; }
        goto block_001ED6CC;
    }
block_001ED6CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED6CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED6CCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = 0x001ED6D8U + 420U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED6D0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) { goto block_001ED724; }
        goto block_001ED6D8;
    }
block_001ED6D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED6D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED6D8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000104U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001ED740; }
        goto block_001ED6E0;
    }
block_001ED6E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED6E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED6E0U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x0000005EU;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        if (!(flags.Z())) { goto block_001ED794; }
        goto block_001ED6EC;
    }
block_001ED6EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED6ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED6ECU);
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001ED6F0U, address);
            }
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED6F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001ED700U - 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED6F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x001ED6FCU, address);
            }
        }
        goto block_001ED794;
    }
block_001ED704:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED704U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED704U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000047U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        if (flags.Z()) { goto block_001ED758; }
        goto block_001ED710;
    }
block_001ED710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED710U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001ED774; }
        goto block_001ED718;
    }
block_001ED718:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED718U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED718U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000E1U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001ED6B0; }
        goto block_001ED720;
    }
block_001ED720:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED720U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED720U);
        }
        goto block_001ED794;
    }
block_001ED724:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED724U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED724U);
        }
        {
            const uint32_t address = 0x001ED72CU + 340U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED724U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ED72CU, address);
            }
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED730U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001ED73CU - 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED734U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001ED738U, address);
            }
        }
        goto block_001ED794;
    }
block_001ED740:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED740U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED740U);
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001ED744U, address);
            }
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED748U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001ED754U - 0x110U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED74CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001ED750U, address);
            }
        }
        goto block_001ED794;
    }
block_001ED758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED758U);
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = 0x001ED764U - 0x120U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED75CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r0 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED760U, address);
            }
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001ED764U, address);
            }
        }
        {
            r0 = 0x00000046U;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED76CU, address);
            }
        }
        goto block_001ED794;
    }
block_001ED774:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED774U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED774U);
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001ED778U, address);
            }
        }
        {
            const uint32_t address = r0 + 472U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001ED77CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001ED788U - 0x144U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED780U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001ED784U, address);
            }
        }
        goto block_001ED794;
    }
block_001ED78C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED78CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED78CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001ED870; }
        goto block_001ED794;
    }
block_001ED794:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED794U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED794U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED794U, address);
            }
            r0 = value;
        }
        {
            r1 = ~(0x00000000U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED7A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED7A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED7A0;
    }
block_001ED7A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED7A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED7A0U);
        }
        {
            const uint32_t operand = 0x00004000U;
            r8 = r5 + operand;
        }
        {
            r7 = r0;
        }
        {
            const uint32_t updatedAddress = r8 + 0x9DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED7A8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001ED7C8; }
        goto block_001ED7B4;
    }
block_001ED7B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED7B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED7B4U);
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED7BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_byte_1b6_00367C48(frame, context, state, 0x00367C48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED7BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED7BC;
    }
block_001ED7BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED7BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED7BCU);
        }
        {
            const uint32_t address = r7 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001ED7BCU, address);
            }
        }
        {
        }
        goto block_001ED864;
    }
block_001ED7C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED7C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED7C8U);
        }
        {
            r0 = r7;
        }
        if (!(flags.Z())) { goto block_001ED7FC; }
        goto block_001ED7D0;
    }
block_001ED7D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED7D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED7D0U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED7D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_clear_byte_1b6_00367C54(frame, context, state, 0x00367C54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED7D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED7D4;
    }
block_001ED7D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED7D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED7D4U);
        }
        {
            const uint32_t operand = 0x00004800U;
            r5 = r5 + operand;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t address = r5 + 468U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED7DCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 460U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED7E0U, address);
            }
        }
        {
            const uint32_t address = r5 + 472U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED7E4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 464U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001ED7E8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED7F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00367c60_00367C60(frame, context, state, 0x00367C60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED7F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED7F0;
    }
block_001ED7F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED7F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED7F0U);
        }
        {
            const uint32_t address = r5 + 464U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED7F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
        }
        goto block_001ED860;
    }
block_001ED7FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED7FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED7FCU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED804U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_clear_byte_1b6_00367C54(frame, context, state, 0x00367C54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED804U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED804;
    }
block_001ED804:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED804U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED804U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x9DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED804U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00004800U;
            r6 = r5 + operand;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00004800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000001CCU;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED818U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED81CU, 0xEECE0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[28], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 468U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED820U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED82CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED82CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED82C;
    }
block_001ED82C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED82CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED82CU);
        }
        {
            const uint32_t updatedAddress = r8 + 0x9DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED82CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00004000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000009D0U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED83CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001ED840U, 0xEECE0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[28], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 472U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED844U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED850U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED850U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED850;
    }
block_001ED850:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED850U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED850U);
        }
        {
            const uint32_t address = r6 + 460U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED850U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001ED85CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00367c60_00367C60(frame, context, state, 0x00367C60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001ED85CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001ED85C;
    }
block_001ED85C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED85CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED85CU);
        }
        {
            const uint32_t address = r6 + 464U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED85CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_001ED860;
    }
block_001ED860:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED860U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED860U);
        }
        {
            const uint32_t address = r7 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001ED860U, address);
            }
        }
        goto block_001ED864;
    }
block_001ED864:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED864U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED864U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001ED864U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001ED86CU, address);
            }
        }
        goto block_001ED870;
    }
block_001ED870:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001ED870U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001ED870U);
        }
        {
            const uint32_t operand = 0x00000034U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 48U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 48U);
            }
            frame.Guest.vfp[28] = value12;
            uint32_t value13 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 52U, &value13)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 52U);
            }
            frame.Guest.vfp[29] = value13;
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 56U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 56U);
            }
            frame.Guest.vfp[30] = value14;
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 60U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001ED874U,
                                           firstAddress + 60U);
            }
            frame.Guest.vfp[31] = value15;
            r13 += 64U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001ED878U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001ED878U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001ED878U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001ED878U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001ED878U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001ED878U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001ED878U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001ED878U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001ED878U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_BossMo_Update_001EDBB0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001EDBB0U:
        goto block_001EDBB0;
    case 0x001EDBE4U:
        goto block_001EDBE4;
    case 0x001EDBF0U:
        goto block_001EDBF0;
    case 0x001EDC0CU:
        goto block_001EDC0C;
    case 0x001EDC14U:
        goto block_001EDC14;
    case 0x001EDC20U:
        goto block_001EDC20;
    case 0x001EDC28U:
        goto block_001EDC28;
    case 0x001EDC38U:
        goto block_001EDC38;
    case 0x001EDC70U:
        goto block_001EDC70;
    case 0x001EDC98U:
        goto block_001EDC98;
    case 0x001EDCD0U:
        goto block_001EDCD0;
    case 0x001EDCE4U:
        goto block_001EDCE4;
    case 0x001EDD00U:
        goto block_001EDD00;
    case 0x001EDD0CU:
        goto block_001EDD0C;
    case 0x001EDD2CU:
        goto block_001EDD2C;
    case 0x001EDD40U:
        goto block_001EDD40;
    case 0x001EDD58U:
        goto block_001EDD58;
    case 0x001EDD64U:
        goto block_001EDD64;
    case 0x001EDDA8U:
        goto block_001EDDA8;
    case 0x001EDDB0U:
        goto block_001EDDB0;
    case 0x001EDDBCU:
        goto block_001EDDBC;
    case 0x001EDDC4U:
        goto block_001EDDC4;
    case 0x001EDE08U:
        goto block_001EDE08;
    case 0x001EDE10U:
        goto block_001EDE10;
    case 0x001EDE1CU:
        goto block_001EDE1C;
    case 0x001EDE24U:
        goto block_001EDE24;
    case 0x001EDE8CU:
        goto block_001EDE8C;
    case 0x001EDEACU:
        goto block_001EDEAC;
    case 0x001EDED0U:
        goto block_001EDED0;
    case 0x001EDEDCU:
        goto block_001EDEDC;
    case 0x001EDEE8U:
        goto block_001EDEE8;
    case 0x001EDEF4U:
        goto block_001EDEF4;
    case 0x001EDEFCU:
        goto block_001EDEFC;
    case 0x001EDF04U:
        goto block_001EDF04;
    case 0x001EDF10U:
        goto block_001EDF10;
    case 0x001EDF1CU:
        goto block_001EDF1C;
    case 0x001EDF28U:
        goto block_001EDF28;
    case 0x001EDF98U:
        goto block_001EDF98;
    case 0x001EDFA4U:
        goto block_001EDFA4;
    case 0x001EDFA8U:
        goto block_001EDFA8;
    case 0x001EDFB0U:
        goto block_001EDFB0;
    case 0x001EDFC8U:
        goto block_001EDFC8;
    case 0x001EDFD8U:
        goto block_001EDFD8;
    case 0x001EDFE4U:
        goto block_001EDFE4;
    case 0x001EDFE8U:
        goto block_001EDFE8;
    case 0x001EE000U:
        goto block_001EE000;
    case 0x001EE010U:
        goto block_001EE010;
    case 0x001EE01CU:
        goto block_001EE01C;
    case 0x001EE060U:
        goto block_001EE060;
    case 0x001EE0B0U:
        goto block_001EE0B0;
    case 0x001EE0B8U:
        goto block_001EE0B8;
    case 0x001EE0C4U:
        goto block_001EE0C4;
    case 0x001EE108U:
        goto block_001EE108;
    case 0x001EE134U:
        goto block_001EE134;
    case 0x001EE150U:
        goto block_001EE150;
    case 0x001EE164U:
        goto block_001EE164;
    case 0x001EE188U:
        goto block_001EE188;
    case 0x001EE1A0U:
        goto block_001EE1A0;
    case 0x001EE1B8U:
        goto block_001EE1B8;
    case 0x001EE214U:
        goto block_001EE214;
    case 0x001EE258U:
        goto block_001EE258;
    case 0x001EE264U:
        goto block_001EE264;
    case 0x001EE26CU:
        goto block_001EE26C;
    case 0x001EE274U:
        goto block_001EE274;
    case 0x001EE2A8U:
        goto block_001EE2A8;
    case 0x001EE2ACU:
        goto block_001EE2AC;
    case 0x001EE30CU:
        goto block_001EE30C;
    case 0x001EE318U:
        goto block_001EE318;
    case 0x001EE36CU:
        goto block_001EE36C;
    case 0x001EE3C8U:
        goto block_001EE3C8;
    case 0x001EE3F4U:
        goto block_001EE3F4;
    case 0x001EE430U:
        goto block_001EE430;
    case 0x001EE44CU:
        goto block_001EE44C;
    case 0x001EE468U:
        goto block_001EE468;
    case 0x001EE478U:
        goto block_001EE478;
    case 0x001EE47CU:
        goto block_001EE47C;
    case 0x001EE4A4U:
        goto block_001EE4A4;
    case 0x001EE4B8U:
        goto block_001EE4B8;
    case 0x001EE4C4U:
        goto block_001EE4C4;
    case 0x001EE4D8U:
        goto block_001EE4D8;
    case 0x001EE4E8U:
        goto block_001EE4E8;
    case 0x001EE4F4U:
        goto block_001EE4F4;
    case 0x001EE540U:
        goto block_001EE540;
    case 0x001EE548U:
        goto block_001EE548;
    case 0x001EE558U:
        goto block_001EE558;
    case 0x001EE578U:
        goto block_001EE578;
    case 0x001EE588U:
        goto block_001EE588;
    case 0x001EE5C0U:
        goto block_001EE5C0;
    case 0x001EE5D0U:
        goto block_001EE5D0;
    case 0x001EE608U:
        goto block_001EE608;
    case 0x001EE614U:
        goto block_001EE614;
    case 0x001EE624U:
        goto block_001EE624;
    case 0x001EE630U:
        goto block_001EE630;
    case 0x001EE63CU:
        goto block_001EE63C;
    case 0x001EE648U:
        goto block_001EE648;
    case 0x001EE668U:
        goto block_001EE668;
    case 0x001EE68CU:
        goto block_001EE68C;
    case 0x001EE6CCU:
        goto block_001EE6CC;
    case 0x001EE6DCU:
        goto block_001EE6DC;
    case 0x001EE6E8U:
        goto block_001EE6E8;
    case 0x001EE744U:
        goto block_001EE744;
    case 0x001EE758U:
        goto block_001EE758;
    case 0x001EE794U:
        goto block_001EE794;
    case 0x001EE7ACU:
        goto block_001EE7AC;
    case 0x001EE7C0U:
        goto block_001EE7C0;
    case 0x001EE7E8U:
        goto block_001EE7E8;
    case 0x001EE828U:
        goto block_001EE828;
    case 0x001EE850U:
        goto block_001EE850;
    case 0x001EE870U:
        goto block_001EE870;
    case 0x001EE8C4U:
        goto block_001EE8C4;
    case 0x001EE8D0U:
        goto block_001EE8D0;
    case 0x001EE904U:
        goto block_001EE904;
    case 0x001EE90CU:
        goto block_001EE90C;
    case 0x001EE918U:
        goto block_001EE918;
    case 0x001EE928U:
        goto block_001EE928;
    case 0x001EE958U:
        goto block_001EE958;
    case 0x001EE970U:
        goto block_001EE970;
    case 0x001EE980U:
        goto block_001EE980;
    case 0x001EE984U:
        goto block_001EE984;
    case 0x001EE994U:
        goto block_001EE994;
    case 0x001EE9B0U:
        goto block_001EE9B0;
    case 0x001EE9C0U:
        goto block_001EE9C0;
    case 0x001EE9CCU:
        goto block_001EE9CC;
    case 0x001EE9DCU:
        goto block_001EE9DC;
    case 0x001EE9E8U:
        goto block_001EE9E8;
    case 0x001EE9FCU:
        goto block_001EE9FC;
    case 0x001EEA08U:
        goto block_001EEA08;
    case 0x001EEA28U:
        goto block_001EEA28;
    case 0x001EEA38U:
        goto block_001EEA38;
    case 0x001EEA44U:
        goto block_001EEA44;
    case 0x001EEA5CU:
        goto block_001EEA5C;
    case 0x001EEA9CU:
        goto block_001EEA9C;
    case 0x001EEAACU:
        goto block_001EEAAC;
    case 0x001EEAB4U:
        goto block_001EEAB4;
    case 0x001EEAC0U:
        goto block_001EEAC0;
    case 0x001EEAC8U:
        goto block_001EEAC8;
    case 0x001EEAD4U:
        goto block_001EEAD4;
    case 0x001EEAF4U:
        goto block_001EEAF4;
    case 0x001EEAFCU:
        goto block_001EEAFC;
    case 0x001EEB18U:
        goto block_001EEB18;
    case 0x001EEB20U:
        goto block_001EEB20;
    case 0x001EEB2CU:
        goto block_001EEB2C;
    case 0x001EEB34U:
        goto block_001EEB34;
    case 0x001EEB3CU:
        goto block_001EEB3C;
    case 0x001EEB44U:
        goto block_001EEB44;
    case 0x001EEB4CU:
        goto block_001EEB4C;
    case 0x001EEB50U:
        goto block_001EEB50;
    case 0x001EEB58U:
        goto block_001EEB58;
    case 0x001EEB78U:
        goto block_001EEB78;
    case 0x001EEB80U:
        goto block_001EEB80;
    case 0x001EEB88U:
        goto block_001EEB88;
    case 0x001EEB98U:
        goto block_001EEB98;
    case 0x001EEBB0U:
        goto block_001EEBB0;
    case 0x001EEBF0U:
        goto block_001EEBF0;
    case 0x001EEC04U:
        goto block_001EEC04;
    case 0x001EEC0CU:
        goto block_001EEC0C;
    case 0x001EEC18U:
        goto block_001EEC18;
    case 0x001EEC1CU:
        goto block_001EEC1C;
    case 0x001EEC30U:
        goto block_001EEC30;
    case 0x001EEC38U:
        goto block_001EEC38;
    case 0x001EEC40U:
        goto block_001EEC40;
    case 0x001EEC4CU:
        goto block_001EEC4C;
    case 0x001EEC5CU:
        goto block_001EEC5C;
    case 0x001EEC64U:
        goto block_001EEC64;
    case 0x001EEC78U:
        goto block_001EEC78;
    case 0x001EEC80U:
        goto block_001EEC80;
    case 0x001EEC94U:
        goto block_001EEC94;
    case 0x001EECA0U:
        goto block_001EECA0;
    case 0x001EECA8U:
        goto block_001EECA8;
    case 0x001EECACU:
        goto block_001EECAC;
    case 0x001EECC4U:
        goto block_001EECC4;
    case 0x001EECD8U:
        goto block_001EECD8;
    case 0x001EECECU:
        goto block_001EECEC;
    case 0x001EED00U:
        goto block_001EED00;
    case 0x001EED08U:
        goto block_001EED08;
    case 0x001EED14U:
        goto block_001EED14;
    case 0x001EED24U:
        goto block_001EED24;
    case 0x001EED2CU:
        goto block_001EED2C;
    case 0x001EED38U:
        goto block_001EED38;
    case 0x001EED40U:
        goto block_001EED40;
    case 0x001EED44U:
        goto block_001EED44;
    case 0x001EED5CU:
        goto block_001EED5C;
    case 0x001EED68U:
        goto block_001EED68;
    case 0x001EED70U:
        goto block_001EED70;
    case 0x001EED90U:
        goto block_001EED90;
    case 0x001EEDB0U:
        goto block_001EEDB0;
    case 0x001EEDBCU:
        goto block_001EEDBC;
    case 0x001EEDC0U:
        goto block_001EEDC0;
    case 0x001EEDC4U:
        goto block_001EEDC4;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001EDBB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDBB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDBB0U);
        }
        {
            const uint32_t firstAddress = r13 - 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001EDBB0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001EDBB0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001EDBB0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001EDBB0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001EDBB0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001EDBB0U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001EDBB0U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001EDBB0U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001EDBB0U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001EDBB0U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001EDBB0U,
                                           firstAddress + 40U);
            }
            r13 = r13 - 44U;
        }
        {
            r10 = r1;
        }
        {
            const uint32_t updatedAddress = 0x001EDBC0U + 0x370U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDBB8U, address);
            }
            r0 = value;
        }
        {
            r13 -= 64U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 44U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 48U, frame.Guest.vfp[28])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 48U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 52U, frame.Guest.vfp[29])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 52U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 56U, frame.Guest.vfp[30])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 56U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 60U, frame.Guest.vfp[31])) {
                return Oot3dAotMemoryFault(context, 0x001EDBBCU,
                                           firstAddress + 60U);
            }
        }
        {
            const uint32_t operand = 0x00000094U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDBC4U, address);
            }
            r4 = value;
        }
        {
            const uint32_t operand = 0x00007000U;
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EDBCCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDBD0U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDBD4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x001EDBD8U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r7, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001EDC38; }
        goto block_001EDBE4;
    }
block_001EDBE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDBE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDBE4U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x1ACU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDBE4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EDC38; }
        goto block_001EDBF0;
    }
block_001EDBF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDBF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDBF0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x1ACU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EDBF4U, address);
            }
        }
        {
            r4 = 0x00000000U;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r7 + 0x140U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x001EDC04U, address);
            }
        }
        if (!(flags.C()) || (flags.Z())) { goto block_001EDC28; }
        goto block_001EDC0C;
    }
block_001EDC0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDC0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDC0CU);
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EDC14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EDC14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EDC14;
    }
block_001EDC14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDC14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDC14U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000068U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EDC20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0049fa78_0049FA78(frame, context, state, 0x0049FA78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EDC20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EDC20;
    }
block_001EDC20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDC20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDC20U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC20U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x001EDC24U, address);
            }
        }
        goto block_001EDC28;
    }
block_001EDC28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDC28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDC28U);
        }
        {
            const uint32_t operand = 0x00000094U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 48U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 48U);
            }
            frame.Guest.vfp[28] = value12;
            uint32_t value13 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 52U, &value13)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 52U);
            }
            frame.Guest.vfp[29] = value13;
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 56U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 56U);
            }
            frame.Guest.vfp[30] = value14;
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 60U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001EDC2CU,
                                           firstAddress + 60U);
            }
            frame.Guest.vfp[31] = value15;
            r13 += 64U;
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001EDC34U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001EDC34U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001EDC34U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001EDC34U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001EDC34U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001EDC34U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001EDC34U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001EDC34U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001EDC34U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_001EDC38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDC38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDC38U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x124U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC38U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001EDC44U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC3CU, address);
            }
            frame.Guest.vfp[31] = value;
        }
        {
            const uint32_t address = 0x001EDC48U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC40U, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EDC44U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001EDC50U + 0x2E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC48U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001EDC54U + 748U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC4CU, address);
            }
            frame.Guest.vfp[30] = value;
        }
        {
            const uint32_t address = 0x001EDC58U + 748U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC50U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x001EDC5CU + 748U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC54U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC58U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001EDC60U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC64U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001EE164; }
        goto block_001EDC70;
    }
block_001EDC70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDC70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDC70U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC70U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001EDC7CU + 0x2D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC74U, address);
            }
            r5 = value;
        }
        {
            const uint32_t address = 0x001EDC80U + 720U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC78U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC7CU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x000001B0U;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC84U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000064U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000065U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001EDCD0; }
        goto block_001EDC98;
    }
block_001EDC98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDC98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDC98U);
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r1 + operand;
        }
        {
            const uint32_t address = 0x001EDCA4U + 692U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDC9CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001EDCA0U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001EDCA0U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001EDCA0U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t address = 0x001EDCACU + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDCA4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t firstAddress = r5;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001EDCA8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001EDCA8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001EDCA8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDCACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDCB0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDCB8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000064U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x001EDCCCU + 0x294U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDCC4U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x001EDCD0U + 644U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDCC8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EDCD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EDCD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EDCD0;
    }
block_001EDCD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDCD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDCD0U);
        }
        {
            const uint32_t updatedAddress = 0x001EDCD8U + 0x25CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDCD0U, address);
            }
            r9 = value;
        }
        {
            const uint32_t updatedAddress = 0x001EDCDCU + 0x288U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDCD4U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDCD8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001EDD0C; }
        goto block_001EDCE4;
    }
block_001EDCE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDCE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDCE4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[30];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EDCF0U, address);
            }
        }
        {
            const uint32_t address = 0x001EDCFCU + 620U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDCF4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r9 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EDD00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EDD00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EDD00;
    }
block_001EDD00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDD00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDD00U);
        }
        {
        }
        {
        }
        goto block_001EDD64;
    }
block_001EDD0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDD0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDD0CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDD0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDD10U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDD14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 532U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDD18U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDD1CU, 0xEE301AEFU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[31], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDD20U, 0xEEB40AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_001EDD58; }
        goto block_001EDD2C;
    }
block_001EDD2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDD2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDD2CU);
        }
        {
            const uint32_t address = 0x001EDD34U + 568U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDD2CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDD30U, 0xEE700AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDD34U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001EDD58; }
        goto block_001EDD40;
    }
block_001EDD40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDD40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDD40U);
        }
        {
            const uint32_t address = r4 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDD40U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x001EDD4CU + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDD44U, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) {
            r0 = 0x00000008U;
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EDD54U, address);
            }
        }
        goto block_001EDD58;
    }
block_001EDD58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDD58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDD58U);
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001EDD5CU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001EDD5CU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001EDD5CU,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001EDD60U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001EDD60U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001EDD60U,
                                           firstAddress + 8U);
            }
        }
        goto block_001EDD64;
    }
block_001EDD64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDD64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDD64U);
        }
        {
            const uint32_t address = 0x001EDD6CU + 524U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDD64U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = r5 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDD68U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x001EDD74U + 512U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDD6CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDD78U, 0xEE011A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDD7CU, 0xEE311A0FU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[30], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDD80U, 0xEEBD1AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[2];
        }
        {
            const uint32_t address = r5 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDD88U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDD90U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if ((flags.N()) != (flags.V())) {
            r0 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDD98U, 0xEE700A8FU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[30], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDD9CU, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[1];
        }
        if ((flags.N()) != (flags.V())) { goto block_001EDDB0; }
        goto block_001EDDA8;
    }
block_001EDDA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDDA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDDA8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000013U;
        }
        goto block_001EDDB0;
    }
block_001EDDB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDDB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDDB0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            r1 = 0x00000000U;
        }
        if ((flags.N()) != (flags.V())) { goto block_001EDDC4; }
        goto block_001EDDBC;
    }
block_001EDDBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDDBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDDBCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r1 = 0x00000013U;
        }
        goto block_001EDDC4;
    }
block_001EDDC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDDC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDDC4U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r6 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDDC8U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r5 = r0 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDDD8U, 0xEE011A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDDDCU, 0xEE311A0FU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[30], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDDE0U, 0xEEBD1AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[2];
        }
        {
            const uint32_t address = r6 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDDE8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDDF0U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if ((flags.N()) != (flags.V())) {
            r0 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDDF8U, 0xEE300A8FU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[30], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDDFCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        if ((flags.N()) != (flags.V())) { goto block_001EDE10; }
        goto block_001EDE08;
    }
block_001EDE08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDE08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDE08U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000013U;
        }
        goto block_001EDE10;
    }
block_001EDE10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDE10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDE10U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            r1 = 0x00000000U;
        }
        if ((flags.N()) != (flags.V())) { goto block_001EDE24; }
        goto block_001EDE1C;
    }
block_001EDE1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDE1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDE1CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r1 = 0x00000013U;
        }
        goto block_001EDE24;
    }
block_001EDE24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDE24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDE24U);
        }
        {
            const uint32_t updatedAddress = 0x001EDE2CU + 0x158U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDE24U, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r1 + operand;
        }
        {
            const uint32_t address = 0x001EDE34U + 328U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDE2CU, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r6 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r5 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EDE38U, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r6 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EDE40U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r5 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x84U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EDE48U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r6 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EDE50U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EDE58U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x78U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EDE60U, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x74U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EDE68U, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r6 + operand;
        }
        {
            const uint32_t address = 0x001EDE78U + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDE70U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x001EDE7CU + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDE74U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x001EDE80U + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDE78U, address);
            }
            frame.Guest.vfp[27] = value;
        }
        {
            const uint32_t address = 0x001EDE84U + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDE7CU, address);
            }
            frame.Guest.vfp[28] = value;
        }
        {
            const uint32_t address = 0x001EDE88U + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDE80U, address);
            }
            frame.Guest.vfp[29] = value;
        }
        {
            r4 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EDE88U, address);
            }
        }
        goto block_001EDE8C;
    }
block_001EDE8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDE8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDE8CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDE8CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 3U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r0 + operand;
        }
        {
            r0 = Oot3dAotLsl(r0, 8U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 9U);
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EDEACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EDEACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EDEAC;
    }
block_001EDEAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDEACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDEACU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDEACU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = r0 + 484U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDEBCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDEC0U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EDEC4U, 0xEE009A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r0, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EDF28; }
        goto block_001EDED0;
    }
block_001EDED0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDED0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDED0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDED0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r0, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EDFA4; }
        goto block_001EDEDC;
    }
block_001EDEDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDEDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDEDCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDEDCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r0, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EDF28; }
        goto block_001EDEE8;
    }
block_001EDEE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDEE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDEE8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x80U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDEE8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r0, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EDFA4; }
        goto block_001EDEF4;
    }
block_001EDEF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDEF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDEF4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r5, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EDF28; }
        goto block_001EDEFC;
    }
block_001EDEFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDEFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDEFCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r6, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EDFA4; }
        goto block_001EDF04;
    }
block_001EDF04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDF04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDF04U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDF04U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r0, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EDF28; }
        goto block_001EDF10;
    }
block_001EDF10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDF10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDF10U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDF10U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r0, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EDFA4; }
        goto block_001EDF1C;
    }
block_001EDF1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDF1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDF1CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDF1CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r0, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001EDF98; }
        goto block_001EDF28;
    }
block_001EDF28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDF28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDF28U);
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[17];
        }
        goto block_001EDFA8;
    }
block_001EDF98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDF98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDF98U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDF98U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r0, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001EDFA8; }
        goto block_001EDFA4;
    }
block_001EDFA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDFA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDFA4U);
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[17];
        }
        goto block_001EDFA8;
    }
block_001EDFA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDFA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDFA8U);
        }
        {
            const uint32_t updatedAddress = 0x001EDFB0U + 0x550U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDFA8U, address);
            }
            r3 = value;
        }
        {
            r0 = 0x00000000U;
        }
        goto block_001EDFB0;
    }
block_001EDFB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDFB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDFB0U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r1 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDFB4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r5;
            r2 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r4, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            frame.Guest.vfp[16] = frame.Guest.vfp[21];
        }
        if (flags.Z()) { goto block_001EDFE4; }
        goto block_001EDFC8;
    }
block_001EDFC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDFC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDFC8U);
        }
        {
            const uint32_t operand = r6;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r4, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            frame.Guest.vfp[20] = frame.Guest.vfp[21];
        }
        if (flags.Z()) { goto block_001EDFE4; }
        goto block_001EDFD8;
    }
block_001EDFD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDFD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDFD8U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000010U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_001EDFB0; }
        goto block_001EDFE4;
    }
block_001EDFE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDFE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDFE4U);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_001EDFE8;
    }
block_001EDFE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EDFE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EDFE8U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r1 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EDFECU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r5;
            r2 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r4, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            frame.Guest.vfp[16] = frame.Guest.vfp[22];
        }
        if (flags.Z()) { goto block_001EE01C; }
        goto block_001EE000;
    }
block_001EE000:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE000U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE000U);
        }
        {
            const uint32_t operand = r6;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r4, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            frame.Guest.vfp[20] = frame.Guest.vfp[22];
        }
        if (flags.Z()) { goto block_001EE01C; }
        goto block_001EE010;
    }
block_001EE010:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE010U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE010U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_001EDFE8; }
        goto block_001EE01C;
    }
block_001EE01C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE01CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE01CU);
        }
        {
            const uint32_t address = r9 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE01CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r9 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE020U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x001EE02CU + 0x4D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE024U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE028U, 0xEE68BA00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[23], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE02CU, 0xEE4ABA20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[23], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[23], frame.Guest.vfp[20], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[23];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r9 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE038U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 4U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 10U);
            r1 = r1 + operand;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[23] = frame.Guest.vfp[26];
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = operand - r0;
        }
        {
            r0 = Oot3dAotLsl(r0, 9U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 10U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000A00U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE060U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE060U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE060;
    }
block_001EE060:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE060U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE060U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE060U, 0xEE200A2BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = 0x001EE06CU + 0x49CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE064U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r11 = r4 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = Oot3dAotLsl(r11, 2U);
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE078U, 0xEE390A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE07CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE080U, 0xEE200A2DU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[27], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001EE084U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE088U, 0xEE200A0EU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[28], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE08CU, 0xEE20AA2EU};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[29], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            const uint32_t address = r13 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE094U, address);
            }
        }
        {
            const uint32_t address = r13 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EE098U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE09CU, 0xEEB4AA69U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[20], frame.Guest.vfp[19],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            frame.Guest.vfp[16] = frame.Guest.vfp[19];
        }
        if (flags.Z()) {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        if (flags.Z()) { goto block_001EE0C4; }
        goto block_001EE0B0;
    }
block_001EE0B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE0B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE0B0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE0B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE0B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE0B8;
    }
block_001EE0B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE0B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE0B8U);
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE0C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE0C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE0C4;
    }
block_001EE0C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE0C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE0C4U);
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x001EE0C4U, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001EE0C8U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE0CCU, 0xEEF10A48U};
            frame.Guest.vfp[1] = frame.Guest.vfp[16] ^ 0x80000000U;
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001EE0D0U, address);
            }
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001EE0D4U, address);
            }
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001EE0D8U, address);
            }
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE0DCU, address);
            }
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EE0E0U, address);
            }
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001EE0E4U, address);
            }
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001EE0E8U, address);
            }
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001EE0ECU, address);
            }
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE0F0U, address);
            }
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001EE0F4U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000058U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE108U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE108U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE108;
    }
block_001EE108:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE108U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE108U);
        }
        {
            const uint32_t updatedAddress = 0x001EE110U + 0x3FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE108U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r13 + 76U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE10CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r11, 2U);
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000190U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE11CU, address);
            }
        }
        {
            const uint32_t address = r13 + 80U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE120U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE124U, address);
            }
        }
        {
            const uint32_t address = r13 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE128U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE12CU, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_001EDE8C; }
        goto block_001EE134;
    }
block_001EE134:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE134U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE134U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = 0x001EE140U + 976U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE138U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x001EE144U + 976U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE13CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = 0x001EE148U - 0x1E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE140U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE150U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE150U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE150;
    }
block_001EE150:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE150U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE150U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t updatedAddress = 0x001EE164U + 0x3B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE15CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE164U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE164U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE164;
    }
block_001EE164:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE164U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE164U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000068U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r1 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00005800U;
            r0 = r10 + operand;
        }
        {
            const uint32_t operand = 0x000000F8U;
            r3 = r7 + operand;
        }
        {
            const uint32_t operand = 0x000003A8U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x000003B4U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001EE180U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE188U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033b11c_0033B11C(frame, context, state, 0x0033B11CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE188U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE188;
    }
block_001EE188:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE188U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE188U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE188U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x000003E8U;
        }
        {
            r2 = 0x00000005U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE1A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE1A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE1A0;
    }
block_001EE1A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE1A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE1A0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE1A0U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x000003E8U;
        }
        {
            r2 = 0x00000005U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000000C0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE1B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE1B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE1B8;
    }
block_001EE1B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE1B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE1B8U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r5 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xB4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE1BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xB4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE1C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE1C8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xD4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE1D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xB2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE1D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xB2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE1DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xC2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE1E0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000012CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0xC2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE1F0U, address);
            }
        }
        if ((flags.N()) == (flags.V())) {
            r0 = 0x00000000U;
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r5 + 0xC2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE1F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xC4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE1FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xC2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE200U, address);
            }
            r4 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x000007D0U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xC4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE20CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE214U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE214U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE214;
    }
block_001EE214:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE214U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE214U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[24];
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r7 + operand;
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[30];
        }
        {
            const uint32_t address = r0 + 452U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE220U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x001EE22CU + 0x2F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE224U, address);
            }
            r11 = value;
        }
        {
            const uint32_t updatedAddress = 0x001EE230U + 0x2F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE228U, address);
            }
            r6 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE22CU, 0xEE001A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r7 + operand;
        }
        {
            const uint32_t address = 0x001EE23CU - 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE234U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x001EE240U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE238U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x001EE244U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE23CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x001EE248U - 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE240U, address);
            }
            frame.Guest.vfp[30] = value;
        }
        {
            r4 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000258U;
            r8 = r11 + operand;
        }
        {
            r9 = 0x0000012CU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE250U, 0xEE310A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 592U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE254U, address);
            }
        }
        goto block_001EE258;
    }
block_001EE258:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE258U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE258U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE258U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000C8U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001EE36C; }
        goto block_001EE264;
    }
block_001EE264:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE264U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE264U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000C9U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001EE318; }
        goto block_001EE26C;
    }
block_001EE26C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE26CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE26CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000CDU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001EE2AC; }
        goto block_001EE274;
    }
block_001EE274:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE274U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE274U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xD6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE274U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[30];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x001EE28CU + 0x2A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE284U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r0 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r11 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE290U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000000ECU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE2A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE2A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE2A8;
    }
block_001EE2A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE2A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE2A8U);
        }
        goto block_001EE3C8;
    }
block_001EE2AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE2ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE2ACU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xC2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE2ACU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r1 = 0x000000DCU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            r2 = Oot3dAotAsr(r1, 5U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 31U);
            r1 = r2 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r1 = r1 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r7 + operand;
        }
        {
            const uint32_t address = r0 + 592U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE2E4U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r8 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE2ECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE2F4U, 0xEE401A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000000ECU;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[3];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE30CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE30CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE30C;
    }
block_001EE30C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE30CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE30CU);
        }
        {
        }
        {
        }
        goto block_001EE3C8;
    }
block_001EE318:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE318U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE318U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xC2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE318U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000000U;
            r1 = operand - r4;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r1 = r9 + operand;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r1, 5U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 31U);
            r1 = r2 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r1 = r1 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r7 + operand;
        }
        {
            const uint32_t address = r0 + 592U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE348U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r8 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE350U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE358U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 236U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE364U, address);
            }
        }
        goto block_001EE3C8;
    }
block_001EE36C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE36CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE36CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xC2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE36CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000000U;
            r1 = operand - r4;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r1 = r9 + operand;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r1, 5U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 31U);
            r1 = r2 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r1 = r1 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r7 + operand;
        }
        {
            const uint32_t address = r0 + 592U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE3A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r8 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE3A8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE3B0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r7 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000000ECU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE3C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE3C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE3C8;
    }
block_001EE3C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE3C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE3C8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xB4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE3C8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r4;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE3D4U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE3D8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE3DCU, 0xEE200A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE3E0U, 0xEE000AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE3E4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE3F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE3F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE3F4;
    }
block_001EE3F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE3F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE3F4U);
        }
        {
            const uint32_t address = r7 + 568U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE3F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE3FCU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 728U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE408U, address);
            }
        }
        {
            const uint32_t address = r0 + 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE40CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 244U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EE410U, address);
            }
        }
        {
            const uint32_t address = r0 + 240U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EE414U, address);
            }
        }
        {
            const uint32_t address = r0 + 736U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE418U, address);
            }
        }
        {
            const uint32_t address = r0 + 732U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE41CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000029U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001EE258; }
        goto block_001EE430;
    }
block_001EE430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE430U);
        }
        {
            frame.Guest.vfp[17] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = 0x001EE43CU + 216U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE434U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x001EE440U + 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE438U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000238U;
            r0 = r7 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE44CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE44CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE44C;
    }
block_001EE44C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE44CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE44CU);
        }
        {
            const uint32_t address = 0x001EE454U + 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE44CU, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r7 + operand;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            const uint32_t address = 0x001EE464U + 208U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE45CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x000001C4U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE468U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE468U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE468;
    }
block_001EE468:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE468U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE468U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE468U, address);
            }
            r2 = value;
        }
        {
            r1 = r10;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x001EE478U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE478U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE478;
    }
block_001EE478:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE478U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE478U);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_001EE47C;
    }
block_001EE47C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE47CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE47CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r1 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xD6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE488U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r2 = r2 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + 0xD6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001EE498U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001EE47C; }
        goto block_001EE4A4;
    }
block_001EE4A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE4A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE4A4U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE4A4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r3 = 0x000000C8U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            const uint32_t operand = 0x00000036U;
            r0 = r7 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE4B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE4B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE4B8;
    }
block_001EE4B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE4B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE4B8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE4B8U, address);
            }
            r0 = value;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE4C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_MoveForward_00376864(frame, context, state, 0x00376864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE4C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE4C4;
    }
block_001EE4C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE4C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE4C4U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = 0x001EE4D4U + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE4CCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x0000006CU;
            r0 = r7 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE4D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE4D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE4D8;
    }
block_001EE4D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE4D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE4D8U);
        }
        {
            const uint32_t address = 0x001EE4E0U + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE4D8U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r7 + operand;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE4E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003658b8_003658B8(frame, context, state, 0x003658B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE4E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE4E8;
    }
block_001EE4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE4E8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
        }
        if (flags.Z()) { goto block_001EE548; }
        goto block_001EE4F4;
    }
block_001EE4F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE4F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE4F4U);
        }
        {
            const uint32_t operand = 0x00000108U;
            r1 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r7 + operand;
        }
        goto block_001EE540;
    }
block_001EE540:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE540U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE540U);
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001EE540U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001EE540U,
                                           firstAddress + 4U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001EE540U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r4 = value4;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001EE544U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001EE544U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001EE544U,
                                           firstAddress + 8U);
            }
        }
        goto block_001EE548;
    }
block_001EE548:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE548U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE548U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xB4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE548U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001EE554U + 836U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE54CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t value = r0 & 0x00000007U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001EE5C0; }
        goto block_001EE558;
    }
block_001EE558:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE558U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE558U);
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r7 + operand;
        }
        {
            const uint32_t operand = 0x0000005CU;
            r0 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001EE560U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001EE560U,
                                           firstAddress + 4U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001EE560U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r4 = value4;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001EE564U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001EE564U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001EE564U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE568U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000C8U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t address = 0x001EE578U + 804U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE570U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if ((flags.N()) != (flags.V())) { goto block_001EE588; }
        goto block_001EE578;
    }
block_001EE578:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE578U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE578U);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = 0x00000F90U;
            r1 = r7 + operand;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001EE580U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001EE580U,
                                           firstAddress + 4U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001EE580U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r4 = value4;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001EE584U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001EE584U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001EE584U,
                                           firstAddress + 8U);
            }
        }
        goto block_001EE588;
    }
block_001EE588:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE588U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE588U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001EE58CU, address);
            }
        }
        {
            const uint32_t address = r7 + 508U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE590U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001EE59CU + 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE594U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r3 = 0x0000012CU;
        }
        {
            const uint32_t operand = 0x0000005CU;
            r1 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE5A0U, 0xEE600A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE5A4U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE5ACU, 0xEE600A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x001EE5BCU + 0x2E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE5B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r10;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE5B8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE5C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00365768_00365768(frame, context, state, 0x00365768U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE5C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE5C0;
    }
block_001EE5C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE5C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE5C0U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE5C4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001EE758; }
        goto block_001EE5D0;
    }
block_001EE5D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE5D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE5D0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE5DCU, address);
            }
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EE5E0U, address);
            }
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001EE5E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE5E8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x001EE5F4U + 692U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE5ECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001EE5F4U, address);
            }
        }
        {
            const uint32_t address = r13 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001EE5F8U, address);
            }
        }
        {
            const uint32_t address = r13 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001EE5FCU, address);
            }
        }
        {
            const uint32_t address = r13 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[30])) {
                return Oot3dAotMemoryFault(context, 0x001EE600U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE608U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE608U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE608;
    }
block_001EE608:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE608U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE608U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE614U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Matrix_RotateY_003735E8(frame, context, state, 0x003735E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE614U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE614;
    }
block_001EE614:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE614U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE614U);
        }
        {
            const uint32_t operand = 0x0000005CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000050U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE624U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE624U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE624;
    }
block_001EE624:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE624U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE624U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE624U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000C8U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001EE63C; }
        goto block_001EE630;
    }
block_001EE630:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE630U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE630U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000CBU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r4 = 0x00000026U;
        }
        if (!(flags.Z())) { goto block_001EE668; }
        goto block_001EE63C;
    }
block_001EE63C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE63CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE63CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000064U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r4 = 0x00000000U;
        }
        if ((flags.N()) == (flags.V())) { goto block_001EE668; }
        goto block_001EE648;
    }
block_001EE648:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE648U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE648U);
        }
        {
            const uint32_t updatedAddress = 0x001EE650U + 0x25CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE648U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x001EE654U + 0x25CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE64CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE650U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x001EE65CU + 0x258U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE654U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001EE658U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE668U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE668U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE668;
    }
block_001EE668:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE668U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE668U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r13 + 80U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE66CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r6 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r4 = r6 + operand;
        }
        {
            const uint32_t address = r4 + 456U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE678U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE67CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE680U, address);
            }
        }
        {
            const uint32_t address = 0x001EE68CU + 556U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE684U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE68CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE68CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE68C;
    }
block_001EE68C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE68CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE68CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0xA98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE68CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE690U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE694U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            const uint32_t updatedAddress = 0x001EE6A4U + 0x200U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE69CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE6A0U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE6A4U, 0xEE700ACAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE6A8U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE6ACU, address);
            }
        }
        {
            const uint32_t address = r4 + 464U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE6B0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE6B4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE6B8U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE6BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + r10;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE6C0U, address);
            }
            r4 = value;
        }
        {
            const uint32_t address = 0x001EE6CCU + 496U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE6C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE6CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE6CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE6CC;
    }
block_001EE6CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE6CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE6CCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE6CCU, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x000001C8U;
            r0 = r0 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        goto block_001EE6DC;
    }
block_001EE6DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE6DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE6DCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE6DCU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001EE744; }
        goto block_001EE6E8;
    }
block_001EE6E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE6E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE6E8U);
        }
        {
            r1 = 0x00000007U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001EE6ECU, address);
            }
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000044U;
            r1 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001EE6F8U, address);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001EE6FCU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001EE6FCU,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001EE6FCU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t firstAddress = r4;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001EE708U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001EE708U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001EE708U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000038U;
            r8 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001EE710U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001EE710U,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001EE710U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r9 = value9;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001EE714U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001EE714U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001EE714U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r1 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001EE71CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001EE71CU,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001EE71CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r9 = value9;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001EE720U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001EE720U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001EE720U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE724U, address);
            }
        }
        {
            const uint32_t address = r4 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001EE728U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE72CU, address);
            }
        }
        if (flags.Z()) {
            r0 = 0x000000FFU;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001EE734U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE738U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x25U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001EE73CU, address);
            }
        }
        goto block_001EE758;
    }
block_001EE744:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE744U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE744U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000040U;
            r4 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000118U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_001EE6DC; }
        goto block_001EE758;
    }
block_001EE758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE758U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xB6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE758U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE764U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE768U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0xB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE774U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x22AU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE778U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r7 + 0x22AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE784U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x229U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE788U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001EEA5C; }
        goto block_001EE794;
    }
block_001EE794:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE794U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE794U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r12 = r7 + operand;
        }
        {
            r4 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r12 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE79CU, address);
            }
            r1 = value;
        }
        {
            r8 = 0x00000005U;
        }
        {
            r2 = 0x00000016U;
        }
        {
            r3 = 0x00000015U;
        }
        goto block_001EE7AC;
    }
block_001EE7AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE7ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE7ACU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 4U);
            r6 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + r6;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE7B4U, address);
            }
            r6 = value;
        }
        {
            const uint32_t value = r6 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_001EE984; }
        goto block_001EE7C0;
    }
block_001EE7C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE7C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE7C0U);
        }
        {
            const uint32_t operand = 0x0000003AU;
            r0 = r1 - operand;
        }
        {
            const uint32_t operand = 0x0000003BU;
            r6 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x16U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE7C8U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000009U;
        }
        {
            r1 = r1 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001EE7D4U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r6 + 0x50U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE7D8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000050U;
            r1 = r6 + operand;
        }
        {
            r3 = r3 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001EE7E4U, address);
            }
        }
        goto block_001EE7E8;
    }
block_001EE7E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE7E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE7E8U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x50U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE7E8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0x5U));
            r2 = r2 - operand;
        }
        {
            r3 = r3 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001EE7F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x50U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE7F8U, address);
            }
            r3 = value;
        }
        {
            r3 = r3 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001EE800U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE804U, address);
            }
            r3 = value;
        }
        {
            r3 = r3 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001EE80CU, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r1 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE810U, address);
            }
            r6 = value;
        }
        {
            r3 = r1;
        }
        {
            const uint32_t operand = 0x000000A0U;
            r1 = r1 + operand;
        }
        {
            r6 = r6 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r3 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001EE820U, address);
            }
        }
        if (!(flags.Z())) { goto block_001EE7E8; }
        goto block_001EE828;
    }
block_001EE828:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE828U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE828U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE828U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r1 = r4 + operand;
        }
        {
            r2 = 0x00000024U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r1 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE838U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001EE840U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE844U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00020000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00020000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_001EE8C4; }
        goto block_001EE850;
    }
block_001EE850:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE850U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE850U);
        }
        {
            const uint32_t updatedAddress = 0x001EE858U + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE850U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x001EE85CU + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE854U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE858U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x001EE864U + 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE85CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001EE860U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE870U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE870U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE870;
    }
block_001EE870:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE870U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE870U);
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r5 + 0xCAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE874U, address);
            }
        }
        {
            r0 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xCCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE87CU, address);
            }
        }
        {
            const uint32_t address = r7 + 512U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x001EE880U, address);
            }
        }
        {
            r0 = 0x00000064U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xB0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE888U, address);
            }
        }
        {
            r0 = 0x0000003CU;
        }
        {
            const uint32_t updatedAddress = r5 + 0xD6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EE890U, address);
            }
        }
        goto block_001EE8D0;
    }
block_001EE8C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE8C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE8C4U);
        }
        {
            const uint32_t updatedAddress = 0x001EE8CCU + 0x2E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE8C4U, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r7 + 0x22AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001EE8CCU, address);
            }
        }
        goto block_001EE8D0;
    }
block_001EE8D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE8D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE8D0U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x001EE8DCU + 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE8D4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r7 + operand;
        }
        {
            const uint32_t address = 0x001EE8E4U + 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE8DCU, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            const uint32_t address = 0x001EE8E8U + 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE8E0U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r4 = r0 + operand;
        }
        {
            const uint32_t address = 0x001EE8F0U + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE8E8U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x001EE8F4U + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE8ECU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = r7 + 568U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x001EE8F0U, address);
            }
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00005000U;
            r8 = r10 + operand;
        }
        {
            const uint32_t operand = 0x0000005CU;
            r9 = r13 + operand;
        }
        {
            const uint32_t operand = 0x000001C8U;
            r4 = r4 + operand;
        }
        goto block_001EE904;
    }
block_001EE904:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE904U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE904U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE90CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE90CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE90C;
    }
block_001EE90C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE90CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE90CU);
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE90CU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[25];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE918U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE918U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE918;
    }
block_001EE918:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE918U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE918U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE918U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE91CU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE928U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE928U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE928;
    }
block_001EE928:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE928U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE928U);
        }
        {
            const uint32_t address = r13 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EE928U, address);
            }
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001EE92CU,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001EE92CU,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001EE92CU,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001EE930U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001EE930U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001EE930U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r13 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE934U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 80U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE938U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE93CU, 0xEE410A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EE940U, address);
            }
        }
        {
            const uint32_t address = r13 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE944U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE948U, 0xEE400A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[23];
        }
        {
            const uint32_t address = r13 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EE950U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE958U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE958U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE958;
    }
block_001EE958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE958U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EE958U, 0xEE300A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r8 + 0xC28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE95CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000050U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000005CU;
            r2 = r13 + operand;
        }
        {
            r0 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EE970U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003673d8_003673D8(frame, context, state, 0x003673D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EE970U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EE970;
    }
block_001EE970:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE970U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE970U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r6 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r6 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001EE904; }
        goto block_001EE980;
    }
block_001EE980:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE980U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE980U);
        }
        goto block_001EE9C0;
    }
block_001EE984:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE984U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE984U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 4U);
            r0 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE988U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EE9B0; }
        goto block_001EE994;
    }
block_001EE994:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE994U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE994U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 4U);
            r0 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE99CU, address);
            }
            r2 = value;
        }
        {
            r2 = r2 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001EE9A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x22AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001EE9A8U, address);
            }
        }
        goto block_001EE9C0;
    }
block_001EE9B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE9B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE9B0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001EE7AC; }
        goto block_001EE9C0;
    }
block_001EE9C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE9C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE9C0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE9C0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001EEA38; }
        goto block_001EE9CC;
    }
block_001EE9CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE9CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE9CCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE9CCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EEA38; }
        goto block_001EE9DC;
    }
block_001EE9DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE9DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE9DCU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE9DCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EE9FC; }
        goto block_001EE9E8;
    }
block_001EE9E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE9E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE9E8U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xB0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE9ECU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EEA38; }
        goto block_001EE9FC;
    }
block_001EE9FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EE9FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EE9FCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xCAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EE9FCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001EEA5C; }
        goto block_001EEA08;
    }
block_001EEA08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEA08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEA08U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r10 + operand;
        }
        {
            const uint32_t operand = 0x00000074U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r6 = r2;
        }
        {
            r4 = r1;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EEA28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EEA28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EEA28;
    }
block_001EEA28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEA28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEA28U);
        }
        {
            r2 = r6;
        }
        {
            r1 = r4;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EEA38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAT_003761F0(frame, context, state, 0x003761F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EEA38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EEA38;
    }
block_001EEA38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEA38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEA38U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xCAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEA38U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001EEA5C; }
        goto block_001EEA44;
    }
block_001EEA44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEA44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEA44U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r10 + operand;
        }
        {
            const uint32_t operand = 0x00000074U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EEA5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EEA5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EEA5C;
    }
block_001EEA5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEA5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEA5CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xBAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEA5CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[21];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xBAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EEA6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEA70U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EEA78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEA7CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000003U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EEA84U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEA88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xC0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EEA90U, address);
            }
        }
        {
            const uint32_t operand = 0x00000220U;
            r0 = r7 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EEA9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EEA9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EEA9C;
    }
block_001EEA9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEA9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEA9CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEA9CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEAA0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r7, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001EDC28; }
        goto block_001EEAAC;
    }
block_001EEAAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEAACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEAACU);
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EEAB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_22a0_0037571C(frame, context, state, 0x0037571CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EEAB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EEAB4;
    }
block_001EEAB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEAB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEAB4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if ((flags.N()) != (flags.V())) { goto block_001EDC28; }
        goto block_001EEAC0;
    }
block_001EEAC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEAC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEAC0U);
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EEAC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_22a0_0037571C(frame, context, state, 0x0037571CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EEAC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EEAC8;
    }
block_001EEAC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEAC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEAC8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if ((flags.N()) == (flags.V())) { goto block_001EDC28; }
        goto block_001EEAD4;
    }
block_001EEAD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEAD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEAD4U);
        }
        {
            const uint32_t updatedAddress = 0x001EEADCU - 0xBA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEAD4U, address);
            }
            r4 = value;
        }
        {
            const uint32_t address = 0x001EEAE0U + 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEAD8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x001EEAE4U + 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEADCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = 0x0000005AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEAE4U, address);
            }
            r0 = value;
        }
        {
            r3 = ~(0x00000000U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001EEB58; }
        goto block_001EEAF4;
    }
block_001EEAF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEAF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEAF4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001EED00; }
        goto block_001EEAFC;
    }
block_001EEAFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEAFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEAFCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEAFCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000140U;
            r12 = r1 + operand;
        }
        {
            const uint32_t address = 0x001EEB0CU + 200U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEB04U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r12, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = r12;
            r2 = r0 - operand;
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[31])) {
                return Oot3dAotMemoryFault(context, 0x001EEB10U, address);
            }
        }
        if (flags.Z()) { goto block_001EEB4C; }
        goto block_001EEB18;
    }
block_001EEB18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEB18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEB18U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001EEC78; }
        goto block_001EEB20;
    }
block_001EEB20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEB20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEB20U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000089U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = 0x001EEB2CU + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEB24U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (flags.Z()) { goto block_001EECC4; }
        goto block_001EEB2C;
    }
block_001EEB2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEB2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEB2CU);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001EEC4C; }
        goto block_001EEB34;
    }
block_001EEB34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEB34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEB34U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001EECAC; }
        goto block_001EEB3C;
    }
block_001EEB3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEB3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEB3CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000017U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001EED08; }
        goto block_001EEB44;
    }
block_001EEB44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEB44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEB44U);
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[30])) {
                return Oot3dAotMemoryFault(context, 0x001EEB44U, address);
            }
        }
        {
            const uint32_t address = 0x001EEB50U + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEB48U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_001EEB4C;
    }
block_001EEB4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEB4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEB4CU);
        }
        {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EEB4CU, address);
            }
        }
        goto block_001EEB50;
    }
block_001EEB50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEB50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEB50U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001EEB50U, address);
            }
        }
        goto block_001EED08;
    }
block_001EEB58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEB58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEB58U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEB58U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001EEB64U + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEB5CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t address = 0x001EEB68U + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEB60U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r12, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EEB68U, address);
            }
        }
        {
            const uint32_t operand = r12;
            r2 = r0 - operand;
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001EEB70U, address);
            }
        }
        if (flags.Z()) { goto block_001EEB50; }
        goto block_001EEB78;
    }
block_001EEB78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEB78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEB78U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001EEBF0; }
        goto block_001EEB80;
    }
block_001EEB80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEB80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEB80U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001EEC1C; }
        goto block_001EEB88;
    }
block_001EEB88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEB88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEB88U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EEB8CU, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = 0x001EEB98U + 80U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEB90U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) { goto block_001EEC38; }
        goto block_001EEB98;
    }
block_001EEB98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEB98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEB98U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000072U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EEBA0U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = 0x001EEBACU + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEBA4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EEBA8U, address);
            }
        }
        if (flags.Z()) { goto block_001EEB50; }
        goto block_001EEBB0;
    }
block_001EEBB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEBB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEBB0U);
        }
        goto block_001EED08;
    }
block_001EEBF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEBF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEBF0U);
        }
        {
            const uint32_t address = 0x001EEBF8U + 476U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEBF0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EEBF8U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x001EEBFCU, address);
            }
        }
        if (flags.Z()) { goto block_001EEB50; }
        goto block_001EEC04;
    }
block_001EEC04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEC04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEC04U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x0000008EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001EEC30; }
        goto block_001EEC0C;
    }
block_001EEC0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEC0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEC0CU);
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r2 - operand;
        }
        {
            const uint32_t operand = 0x000000C9U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        if (!(flags.Z())) { goto block_001EED08; }
        goto block_001EEC18;
    }
block_001EEC18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEC18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEC18U);
        }
        goto block_001EEC40;
    }
block_001EEC1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEC1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEC1CU);
        }
        {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EEC1CU, address);
            }
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x001EEC20U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EEC28U, address);
            }
        }
        goto block_001EED08;
    }
block_001EEC30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEC30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEC30U);
        }
        {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EEC30U, address);
            }
        }
        {
            const uint32_t address = 0x001EEC3CU + 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEC34U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_001EEC38;
    }
block_001EEC38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEC38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEC38U);
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EEC38U, address);
            }
        }
        goto block_001EEB50;
    }
block_001EEC40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEC40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEC40U);
        }
        {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EEC40U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001EEC44U, address);
            }
        }
        goto block_001EED08;
    }
block_001EEC4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEC4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEC4CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000A0U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EEC50U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001EEC54U, address);
            }
        }
        if (flags.Z()) { goto block_001EEB50; }
        goto block_001EEC5C;
    }
block_001EEC5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEC5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEC5CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000120U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001EED08; }
        goto block_001EEC64;
    }
block_001EEC64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEC64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEC64U);
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[31])) {
                return Oot3dAotMemoryFault(context, 0x001EEC64U, address);
            }
        }
        {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EEC68U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EEC70U, address);
            }
        }
        goto block_001EED08;
    }
block_001EEC78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEC78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEC78U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x000000E6U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001EECD8; }
        goto block_001EEC80;
    }
block_001EEC80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEC80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEC80U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000184U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[30])) {
                return Oot3dAotMemoryFault(context, 0x001EEC84U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EEC88U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001EEC8CU, address);
            }
        }
        if (flags.Z()) { goto block_001EED08; }
        goto block_001EEC94;
    }
block_001EEC94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEC94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEC94U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r2 - operand;
        }
        {
            const uint32_t operand = 0x000000C2U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        if (flags.Z()) { goto block_001EECEC; }
        goto block_001EECA0;
    }
block_001EECA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EECA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EECA0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000A2U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001EEC40; }
        goto block_001EECA8;
    }
block_001EECA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EECA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EECA8U);
        }
        goto block_001EED08;
    }
block_001EECAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EECACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EECACU);
        }
        {
            const uint32_t address = 0x001EECB4U + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EECACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[30])) {
                return Oot3dAotMemoryFault(context, 0x001EECB0U, address);
            }
        }
        {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EECB4U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EECBCU, address);
            }
        }
        goto block_001EED08;
    }
block_001EECC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EECC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EECC4U);
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EECC4U, address);
            }
        }
        {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001EECC8U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EECD0U, address);
            }
        }
        goto block_001EED08;
    }
block_001EECD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EECD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EECD8U);
        }
        {
            const uint32_t address = 0x001EECE0U + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EECD8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EECDCU, address);
            }
        }
        {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EECE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001EECE4U, address);
            }
        }
        goto block_001EED08;
    }
block_001EECEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EECECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EECECU);
        }
        {
            const uint32_t address = 0x001EECF4U + 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EECECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EECF0U, address);
            }
        }
        {
            const uint32_t address = r4 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EECF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001EECF8U, address);
            }
        }
        goto block_001EED08;
    }
block_001EED00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EED00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EED00U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001EDC28; }
        goto block_001EED08;
    }
block_001EED08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EED08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EED08U);
        }
        {
            r1 = ~(0x00000000U);
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EED14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EED14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EED14;
    }
block_001EED14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EED14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EED14U);
        }
        {
            r5 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EED18U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001EED38; }
        goto block_001EED24;
    }
block_001EED24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EED24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EED24U);
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EED2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_byte_1b6_00367C48(frame, context, state, 0x00367C48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EED2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EED2C;
    }
block_001EED2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EED2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EED2CU);
        }
        {
            const uint32_t address = r4 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EED2CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
        }
        goto block_001EEDC0;
    }
block_001EED38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EED38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EED38U);
        }
        {
            r0 = r5;
        }
        if (!(flags.Z())) { goto block_001EED68; }
        goto block_001EED40;
    }
block_001EED40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EED40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EED40U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EED44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_clear_byte_1b6_00367C54(frame, context, state, 0x00367C54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EED44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EED44;
    }
block_001EED44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EED44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EED44U);
        }
        {
            const uint32_t address = r4 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EED44U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EED4CU, address);
            }
        }
        {
            const uint32_t address = r4 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EED50U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001EED54U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EED5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00367c60_00367C60(frame, context, state, 0x00367C60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EED5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EED5C;
    }
block_001EED5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EED5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EED5CU);
        }
        {
            const uint32_t address = r4 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EED5CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EED60U, address);
            }
        }
        goto block_001EEDC4;
    }
block_001EED68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EED68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EED68U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EED70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_clear_byte_1b6_00367C54(frame, context, state, 0x00367C54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EED70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EED70;
    }
block_001EED70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EED70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EED70U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EED70U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r4 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EED74U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = 0x001EED84U + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EED7CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EED80U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EED84U, 0xEECC0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[24], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[2];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EED90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EED90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EED90;
    }
block_001EED90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EED90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EED90U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EED90U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r4 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EED94U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = 0x001EEDA4U + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EED9CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EEDA0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001EEDA4U, 0xEECC0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[24], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[2];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EEDB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EEDB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EEDB0;
    }
block_001EEDB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEDB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEDB0U);
        }
        {
            const uint32_t address = r4 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEDB0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001EEDBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00367c60_00367C60(frame, context, state, 0x00367C60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001EEDBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001EEDBC;
    }
block_001EEDBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEDBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEDBCU);
        }
        {
            const uint32_t address = r4 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEDBCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_001EEDC0;
    }
block_001EEDC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEDC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEDC0U);
        }
        {
            const uint32_t address = r5 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001EEDC0U, address);
            }
        }
        goto block_001EEDC4;
    }
block_001EEDC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001EEDC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001EEDC4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001EEDC4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001EEDCCU, address);
            }
        }
        goto block_001EDC28;
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_0035b3b0_0035B3B0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0035B3B0U:
        goto block_0035B3B0;
    case 0x0035B3D4U:
        goto block_0035B3D4;
    case 0x0035B3E4U:
        goto block_0035B3E4;
    case 0x0035B3ECU:
        goto block_0035B3EC;
    case 0x0035B3F4U:
        goto block_0035B3F4;
    case 0x0035B3FCU:
        goto block_0035B3FC;
    case 0x0035B400U:
        goto block_0035B400;
    case 0x0035B414U:
        goto block_0035B414;
    case 0x0035B424U:
        goto block_0035B424;
    case 0x0035B42CU:
        goto block_0035B42C;
    case 0x0035B450U:
        goto block_0035B450;
    case 0x0035B470U:
        goto block_0035B470;
    case 0x0035B47CU:
        goto block_0035B47C;
    case 0x0035B480U:
        goto block_0035B480;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0035B3B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B3B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B3B0U);
        }
        {
            const uint32_t firstAddress = r13 - 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0035B3B0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0035B3B0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0035B3B0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0035B3B0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0035B3B0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0035B3B0U,
                                           firstAddress + 20U);
            }
            r13 = r13 - 24U;
        }
        {
            r5 = r0;
        }
        {
            r0 = r1;
        }
        {
            r6 = r2;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0035B3C0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0035B3C0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0035B3C0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0035B3C0U,
                                           firstAddress + 12U);
            }
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[17] = frame.Guest.vfp[1];
        }
        {
            r1 = ~(0x00000000U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B3D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B3D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B3D4;
    }
block_0035B3D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B3D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B3D4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r7 = r0;
        }
        {
            const uint32_t operand = 0x00000400U;
            r4 = r5 + operand;
        }
        if ((flags.N()) == (flags.V())) { goto block_0035B3F4; }
        goto block_0035B3E4;
    }
block_0035B3E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B3E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B3E4U);
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B3ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_byte_1b6_00367C48(frame, context, state, 0x00367C48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B3ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B3EC;
    }
block_0035B3EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B3ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B3ECU);
        }
        {
            const uint32_t address = 0x0035B3F4U + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B3ECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0035B480;
    }
block_0035B3F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B3F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B3F4U);
        }
        {
            r0 = r7;
        }
        if (!(flags.Z())) { goto block_0035B424; }
        goto block_0035B3FC;
    }
block_0035B3FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B3FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B3FCU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B400U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_clear_byte_1b6_00367C54(frame, context, state, 0x00367C54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B400U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B400;
    }
block_0035B400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B400U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = r7;
        }
        {
            const uint32_t address = r4 + 424U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0035B408U, address);
            }
        }
        {
            const uint32_t address = r4 + 428U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0035B40CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B414U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00367c60_00367C60(frame, context, state, 0x00367C60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B414U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B414;
    }
block_0035B414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B414U);
        }
        {
            const uint32_t address = r4 + 428U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B414U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r7 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0035B418U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0035B41CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0035B41CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0035B41CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0035B41CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0035B420U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0035B420U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0035B420U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0035B420U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0035B420U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0035B420U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_0035B424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B424U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B42CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_clear_byte_1b6_00367C54(frame, context, state, 0x00367C54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B42CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B42C;
    }
block_0035B42C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B42CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B42CU);
        }
        {
            frame.Guest.vfp[1] = r6;
        }
        {
            const uint32_t address = 0x0035B438U + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B430U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0035B444U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0035B448U, 0xEEC80A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B450U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B450U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B450;
    }
block_0035B450:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B450U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B450U);
        }
        {
            frame.Guest.vfp[0] = r6;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000001ACU;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0035B460U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0035B464U, 0xEEC80A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B470U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B470U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B470;
    }
block_0035B470:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B470U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B470U);
        }
        {
            const uint32_t address = r4 + 424U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B470U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B47CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00367c60_00367C60(frame, context, state, 0x00367C60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B47CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B47C;
    }
block_0035B47C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B47CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B47CU);
        }
        {
            const uint32_t address = r4 + 428U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B47CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0035B480;
    }
block_0035B480:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B480U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B480U);
        }
        {
            const uint32_t address = r7 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0035B480U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0035B484U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0035B484U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0035B484U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0035B484U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0035B488U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0035B488U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0035B488U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0035B488U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0035B488U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0035B488U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_oot3d_clear_byte_1b6_00367C54(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r6 = state.R[6];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00367C54U:
        goto block_00367C54;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00367C54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367C54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367C54U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1B6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00367C58U, address);
            }
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_00367c60_00367C60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00367C60U:
        goto block_00367C60;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00367C60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367C60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367C60U);
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r0 + 208U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00367C64U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x34000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t address = 0x00367C74U + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367C6CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 208U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00367C70U, address);
            }
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
