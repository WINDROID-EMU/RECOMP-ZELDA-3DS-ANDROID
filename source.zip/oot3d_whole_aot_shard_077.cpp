#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_Camera_Data1_00239FD4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_Normal1_00239FD8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_Parallel1_00275678(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_002998b0_002998B0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_sin_idx8_002CFCA0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00331440_00331440(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00331480_00331480(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00331ae8_00331AE8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0033743c_0033743C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_ClampLERPScale_003375BC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00337624_00337624(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00337fdc_00337FDC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003380f0_003380F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003381e4_003381E4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_Vec3f_DistXYZ_00338A90(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_CalcAtDefault_00338AC8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_cos_idx8_00338F60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00340404_00340404(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_OLib_Vec3fToVecSphGeo_00342E8C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_BGCheckInfo_003553FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_TanF_003555D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_LERPCeilF_00355780(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_StaticInitGuard_TryAcquire_003679B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_LERPCeilVec3f_00367DF4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_OLib_Vec3fDistXZ_00367E60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_CalcSlopeYAdj_00367E88(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_GetHeight_00367EF0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Runtime_SignedDivMod32_00368D94(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_FAtan2F_003696EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_InCsMode_0036A7A0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BgCheck_EntityRaycastFloor9_00372300(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00372348_00372348(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003723c0_003723C0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_AddVecGeoToVec3f_00372448(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_OLib_Vec3fDiffToVecSphGeo_00372474(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_CosF_Core_00372674(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SinF_003727F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_transform_mtx3x4_vec3_003735AC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroOne_003759D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003a2f84_003A2F84(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003fb3e8_003FB3E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_Camera_Data1_00239FD4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00239FD4U:
        goto block_00239FD4;
    case 0x00239FD8U:
        goto block_00239FD8;
    case 0x0023A00CU:
        goto block_0023A00C;
    case 0x0023A160U:
        goto block_0023A160;
    case 0x0023A170U:
        goto block_0023A170;
    case 0x0023A188U:
        goto block_0023A188;
    case 0x0023A190U:
        goto block_0023A190;
    case 0x0023A198U:
        goto block_0023A198;
    case 0x0023A19CU:
        goto block_0023A19C;
    case 0x0023A1C4U:
        goto block_0023A1C4;
    case 0x0023A248U:
        goto block_0023A248;
    case 0x0023A280U:
        goto block_0023A280;
    case 0x0023A2B8U:
        goto block_0023A2B8;
    case 0x0023A2C0U:
        goto block_0023A2C0;
    case 0x0023A2CCU:
        goto block_0023A2CC;
    case 0x0023A310U:
        goto block_0023A310;
    case 0x0023A330U:
        goto block_0023A330;
    case 0x0023A33CU:
        goto block_0023A33C;
    case 0x0023A370U:
        goto block_0023A370;
    case 0x0023A3FCU:
        goto block_0023A3FC;
    case 0x0023A418U:
        goto block_0023A418;
    case 0x0023A454U:
        goto block_0023A454;
    case 0x0023A468U:
        goto block_0023A468;
    case 0x0023A494U:
        goto block_0023A494;
    case 0x0023A4BCU:
        goto block_0023A4BC;
    case 0x0023A4C0U:
        goto block_0023A4C0;
    case 0x0023A4E8U:
        goto block_0023A4E8;
    case 0x0023A514U:
        goto block_0023A514;
    case 0x0023A540U:
        goto block_0023A540;
    case 0x0023A574U:
        goto block_0023A574;
    case 0x0023A584U:
        goto block_0023A584;
    case 0x0023A5A0U:
        goto block_0023A5A0;
    case 0x0023A5C8U:
        goto block_0023A5C8;
    case 0x0023A5D0U:
        goto block_0023A5D0;
    case 0x0023A5E8U:
        goto block_0023A5E8;
    case 0x0023A608U:
        goto block_0023A608;
    case 0x0023A610U:
        goto block_0023A610;
    case 0x0023A628U:
        goto block_0023A628;
    case 0x0023A638U:
        goto block_0023A638;
    case 0x0023A64CU:
        goto block_0023A64C;
    case 0x0023A650U:
        goto block_0023A650;
    case 0x0023A658U:
        goto block_0023A658;
    case 0x0023A678U:
        goto block_0023A678;
    case 0x0023A690U:
        goto block_0023A690;
    case 0x0023A6B0U:
        goto block_0023A6B0;
    case 0x0023A6B4U:
        goto block_0023A6B4;
    case 0x0023A6D8U:
        goto block_0023A6D8;
    case 0x0023A6DCU:
        goto block_0023A6DC;
    case 0x0023A6E0U:
        goto block_0023A6E0;
    case 0x0023A720U:
        goto block_0023A720;
    case 0x0023A768U:
        goto block_0023A768;
    case 0x0023A76CU:
        goto block_0023A76C;
    case 0x0023A77CU:
        goto block_0023A77C;
    case 0x0023A788U:
        goto block_0023A788;
    case 0x0023A790U:
        goto block_0023A790;
    case 0x0023A798U:
        goto block_0023A798;
    case 0x0023A7A0U:
        goto block_0023A7A0;
    case 0x0023A80CU:
        goto block_0023A80C;
    case 0x0023A82CU:
        goto block_0023A82C;
    case 0x0023A850U:
        goto block_0023A850;
    case 0x0023A858U:
        goto block_0023A858;
    case 0x0023A864U:
        goto block_0023A864;
    case 0x0023A8A8U:
        goto block_0023A8A8;
    case 0x0023A8D8U:
        goto block_0023A8D8;
    case 0x0023A908U:
        goto block_0023A908;
    case 0x0023A918U:
        goto block_0023A918;
    case 0x0023A930U:
        goto block_0023A930;
    case 0x0023A944U:
        goto block_0023A944;
    case 0x0023A94CU:
        goto block_0023A94C;
    case 0x0023A96CU:
        goto block_0023A96C;
    case 0x0023A974U:
        goto block_0023A974;
    case 0x0023A984U:
        goto block_0023A984;
    case 0x0023A99CU:
        goto block_0023A99C;
    case 0x0023A9B8U:
        goto block_0023A9B8;
    case 0x0023A9BCU:
        goto block_0023A9BC;
    case 0x0023A9D4U:
        goto block_0023A9D4;
    case 0x0023A9ECU:
        goto block_0023A9EC;
    case 0x0023A9F0U:
        goto block_0023A9F0;
    case 0x0023AA1CU:
        goto block_0023AA1C;
    case 0x0023AA44U:
        goto block_0023AA44;
    case 0x0023AA60U:
        goto block_0023AA60;
    case 0x0023AA84U:
        goto block_0023AA84;
    case 0x0023AA9CU:
        goto block_0023AA9C;
    case 0x0023AADCU:
        goto block_0023AADC;
    case 0x0023AAFCU:
        goto block_0023AAFC;
    case 0x0023AB10U:
        goto block_0023AB10;
    case 0x0023AB14U:
        goto block_0023AB14;
    case 0x0023AB20U:
        goto block_0023AB20;
    case 0x0023AB58U:
        goto block_0023AB58;
    case 0x0023AB5CU:
        goto block_0023AB5C;
    case 0x0023AB80U:
        goto block_0023AB80;
    case 0x0023AB90U:
        goto block_0023AB90;
    case 0x0023AB9CU:
        goto block_0023AB9C;
    case 0x0023ABB4U:
        goto block_0023ABB4;
    case 0x0023ABC4U:
        goto block_0023ABC4;
    case 0x0023ABC8U:
        goto block_0023ABC8;
    case 0x0023ABE8U:
        goto block_0023ABE8;
    case 0x0023AC0CU:
        goto block_0023AC0C;
    case 0x0023AC1CU:
        goto block_0023AC1C;
    case 0x0023AC24U:
        goto block_0023AC24;
    case 0x0023AC28U:
        goto block_0023AC28;
    case 0x0023AC40U:
        goto block_0023AC40;
    case 0x0023AC58U:
        goto block_0023AC58;
    case 0x0023AC70U:
        goto block_0023AC70;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00239FD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00239FD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00239FD4U);
        }
        {
            r0 = r0;
        }
        goto block_00239FD8;
    }
block_00239FD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00239FD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00239FD8U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00000080U;
            r7 = r0 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000000DCU;
            r8 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r5 = r4 + operand;
        }
        {
            r13 -= 32U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t operand = 0x0000008CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00239FF8U, address);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A000U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A004U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A00CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_GetHeight_00367EF0(frame, context, state, 0x00367EF0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A00CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A00C;
    }
block_0023A00C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A00CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A00CU);
        }
        {
            const uint32_t operand = 0x00000100U;
            r6 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0023A018U + 0x330U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A010U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A014U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0023A020U + 0x330U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A018U, address);
            }
            r9 = value;
        }
        {
            const uint32_t address = 0x0023A024U + 808U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A01CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0023A028U + 812U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A020U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A028U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A02CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A030U, 0xEE801A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0023A03CU + 796U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A034U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 3U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A03CU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A040U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A044U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t address = 0x0023A054U + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A04CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xF0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A050U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A058U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A05CU, 0xEE601AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A064U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A068U, 0xEEB82AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A070U, 0xEE420A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[4], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A074U, 0xEE410A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0023A080U + 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A078U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A07CU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A084U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A088U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A08CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A090U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A098U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A09CU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A0A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A0A4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0ACU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0B0U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A0B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A0B8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0C0U, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0C8U, 0xEE000A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0CCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0023A0D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A0D8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0E0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A0E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A0E8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0F0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A0F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A0F8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A100U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A104U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A108U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A10CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A114U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A118U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A11CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A124U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A128U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A12CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A130U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A134U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0023A140U + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A138U, address);
            }
            r11 = value;
        }
        {
            r1 = r7;
        }
        {
            const uint32_t updatedAddress = r11 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A140U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A144U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A148U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A150U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A154U, address);
            }
        }
        {
            const uint32_t operand = 0x00000058U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A160U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A160U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A160;
    }
block_0023A160:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A160U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A160U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A160U, address);
            }
            r2 = value;
        }
        {
            r1 = r7;
        }
        {
            const uint32_t operand = 0x00000050U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A170U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A170U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A170;
    }
block_0023A170:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A170U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A170U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A170U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0023A17CU + 492U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A174U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r10 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0023A1C4; }
        goto block_0023A188;
    }
block_0023A188:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A188U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A188U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0023A19C; }
        goto block_0023A190;
    }
block_0023A190:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A190U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A190U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000019U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0023A248; }
        goto block_0023A198;
    }
block_0023A198:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A198U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A198U);
        }
        goto block_0023A1C4;
    }
block_0023A19C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A19CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A19CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A19CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A1A4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A1ACU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A1B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xCAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A1B4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A1BCU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 268U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A1C0U, address);
            }
        }
        goto block_0023A1C4;
    }
block_0023A1C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A1C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A1C4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A1C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A1C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A1CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A1D0U, address);
            }
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A1D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A1DCU, address);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A1E0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A1E4U, address);
            }
        }
        {
            const uint32_t address = r8 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A1E8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A1ECU, address);
            }
        }
        {
            const uint32_t address = r4 + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A1F0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A1F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A1F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A1FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A200U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A204U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A208U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A20CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A214U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A218U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A228U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A22CU, 0xEE201A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A234U, 0xDE510A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A238U, 0xCE410A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A23CU, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A244U, address);
            }
        }
        goto block_0023A248;
    }
block_0023A248:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A248U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A248U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A24CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A250U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A258U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A25CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0023A268U + 0x104U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A260U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A26CU, address);
            }
        }
        {
            const uint32_t address = r4 + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A270U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0023A2C0; }
        goto block_0023A280;
    }
block_0023A280:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A280U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A280U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A280U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A288U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A28CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A29CU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2A0U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2A8U, 0xDE100AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2ACU, 0xCE000AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2B0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_0023A2B8;
    }
block_0023A2B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A2B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A2B8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A2B8U, address);
            }
        }
        goto block_0023A370;
    }
block_0023A2C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A2C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A2C0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A2C0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0023A370; }
        goto block_0023A2CC;
    }
block_0023A2CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A2CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A2CCU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A2CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A2D4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2E0U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2E4U, 0xDE201A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2E8U, 0xCE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2F4U, 0xDE510A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2F8U, 0xCE000AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2FCU, 0xDEBD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A300U, 0xCEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0023A33C; }
        goto block_0023A310;
    }
block_0023A310:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A310U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A310U);
        }
        {
            const uint32_t updatedAddress = r8 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A310U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A314U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00007F00U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = r2;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0023A324U, address);
            }
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A330U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A330U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A330;
    }
block_0023A330:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A330U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A330U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A330U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = r2;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A338U, address);
            }
        }
        goto block_0023A33C;
    }
block_0023A33C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A33CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A33CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A33CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        goto block_0023A2B8;
    }
block_0023A370:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A370U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A370U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A370U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0023A37CU + 840U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A374U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xC6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A37CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r1 + 0xC8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A380U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A388U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A38CU, 0xEE600A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A390U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A394U, 0xEE60AA80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A39CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = 0x0023A3ACU + 0x310U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3A4U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3A8U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (flags.Z()) {
            frame.Guest.vfp[2] = frame.Guest.vfp[21];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3B0U, 0xEE600AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3B4U, 0xEE20BA80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[22], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x0023A3C4U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3BCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (!(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3C0U, 0x1EB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3C4U, 0x1E201A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 120U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0023A3C8U, address);
            }
        }
        {
            const uint32_t address = r4 + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3D0U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r5 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A3D4U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3D8U, 0xEE701A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3DCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3E0U, 0xEE219AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[18];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        {
            const uint32_t updatedAddress = r5 + 0x1AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3ECU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (!(flags.C())) {
            const uint32_t address = 0x0023A3F8U + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3F0U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0023A468; }
        goto block_0023A3FC;
    }
block_0023A3FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A3FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A3FCU);
        }
        {
            r0 = Oot3dAotLsl(r0, 1U);
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A408U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A40CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A410U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A418U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A418U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A418;
    }
block_0023A418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A418U);
        }
        {
            const uint32_t address = r4 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A418U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A41CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A42CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A434U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = Oot3dAotLsl(r0, 1U);
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A440U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A444U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A448U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A44CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A454U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A454U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A454;
    }
block_0023A454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A454U);
        }
        {
            const uint32_t address = r4 + 268U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A454U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x1AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A458U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A460U, address);
            }
        }
        goto block_0023A4C0;
    }
block_0023A468:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A468U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A468U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A468U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A474U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A47CU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A480U, 0xEE600AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A484U, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A488U, 0xEE000AC9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A48CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A494U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A494U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A494;
    }
block_0023A494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A494U);
        }
        {
            const uint32_t address = r4 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A494U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A498U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r4 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4A8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4ACU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A4B4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A4BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A4BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A4BC;
    }
block_0023A4BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A4BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A4BCU);
        }
        {
            const uint32_t address = r4 + 268U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A4BCU, address);
            }
        }
        goto block_0023A4C0;
    }
block_0023A4C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A4C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A4C0U);
        }
        {
            const uint32_t updatedAddress = 0x0023A4C8U - 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4C0U, address);
            }
            r9 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            const uint32_t address = r4 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4CCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4D8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A4E0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A4E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A4E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A4E8;
    }
block_0023A4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A4E8U);
        }
        {
            const uint32_t address = r4 + 268U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A4E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4ECU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[21];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r4 + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4FCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x98U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A500U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A508U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A50CU, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A514U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A514U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A514;
    }
block_0023A514:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A514U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A514U);
        }
        {
            const uint32_t address = r4 + 276U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A514U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A518U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r4 + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A528U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A52CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A534U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A538U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A540U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A540U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A540;
    }
block_0023A540:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A540U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A540U);
        }
        {
            const uint32_t address = r4 + 280U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A540U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A544U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r4 + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A54CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = 0x0023A55CU + 364U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A554U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A558U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A560U, 0xEE201A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A568U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A56CU, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A574U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A574U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A574;
    }
block_0023A574:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A574U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A574U);
        }
        {
            const uint32_t address = r4 + 284U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A574U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A578U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0023A5D0; }
        goto block_0023A584;
    }
block_0023A584:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A584U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A584U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A584U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A588U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00007F00U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A5A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331480_00331480(frame, context, state, 0x00331480U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A5A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A5A0;
    }
block_0023A5A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A5A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A5A0U);
        }
        {
            const uint32_t address = r4 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5A8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A5ACU, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A5B0U, 0xEE780A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[16], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r2 = 0x0000000FU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A5B8U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A5BCU, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A5C0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A5C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002998b0_002998B0(frame, context, state, 0x002998B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A5C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A5C8;
    }
block_0023A5C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A5C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A5C8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A5C8U, address);
            }
        }
        goto block_0023A5E8;
    }
block_0023A5D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A5D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A5D0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A5D0U, address);
            }
        }
        {
            const uint32_t address = r4 + 332U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5D4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r8 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A5DCU, 0xEEF40A40U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            const uint32_t address = r5 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A5E4U, address);
            }
        }
        goto block_0023A5E8;
    }
block_0023A5E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A5E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A5E8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5E8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t address = r4 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x0023A5FCU + 0xD0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5F4U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            r1 = frame.Guest.vfp[0];
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) {
            const uint32_t address = r4 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A600U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.C()) { goto block_0023A628; }
        goto block_0023A608;
    }
block_0023A608:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A608U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A608U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x14U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A608U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A610U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A610U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A610;
    }
block_0023A610:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A610U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A610U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r4 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A614U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A618U, 0xEE381A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[16], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A61CU, 0xEE200A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0023A628U + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A620U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A624U, 0xEE000A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        goto block_0023A628;
    }
block_0023A628:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A628U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A628U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A628U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0023A634U + 160U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A62CU, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t value = r0 & 0x00000080U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0023A650; }
        goto block_0023A638;
    }
block_0023A638:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A638U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A638U);
        }
        {
            r3 = r0 & 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r2 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000050U;
            r1 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A64CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003381e4_003381E4(frame, context, state, 0x003381E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A64CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A64C;
    }
block_0023A64C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A64CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A64CU);
        }
        goto block_0023A77C;
    }
block_0023A650:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A650U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A650U);
        }
        {
            const uint32_t value = r0 & 0x00000020U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0023A76C; }
        goto block_0023A658;
    }
block_0023A658:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A658U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A658U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A658U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x000000DCU;
            r9 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A664U, address);
            }
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A66CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A670U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A678U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_GetHeight_00367EF0(frame, context, state, 0x00367EF0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A678U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A678;
    }
block_0023A678:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A678U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A678U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A678U, 0xEE300A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A67CU, address);
            }
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A680U, address);
            }
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A684U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A688U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A690U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A690U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A690;
    }
block_0023A690:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A690U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A690U);
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A694U, 0xEEB40AEAU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[21],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            const uint32_t updatedAddress = r9 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A698U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x56U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A69CU, address);
            }
            r1 = value;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        if (flags.C()) { goto block_0023A6D8; }
        goto block_0023A6B0;
    }
block_0023A6B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A6B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A6B0U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A6B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A6B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A6B4;
    }
block_0023A6B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A6B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A6B4U);
        }
        goto block_0023A6E0;
    }
block_0023A6D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A6D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A6D8U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A6DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A6DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A6DC;
    }
block_0023A6DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A6DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A6DCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A6DCU, 0xEEB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        goto block_0023A6E0;
    }
block_0023A6E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A6E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A6E0U);
        }
        {
            const uint32_t updatedAddress = 0x0023A6E8U - 0x398U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A6E0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r13 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A6E4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x0000012CU;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A6ECU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A6F0U, 0xEE290A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A6F8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            const uint32_t operand = 0x00000038U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A704U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A708U, 0xEE400A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A710U, address);
            }
        }
        {
            const uint32_t address = r4 + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A714U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A718U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A720U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A720U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A720;
    }
block_0023A720:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A720U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A720U);
        }
        {
            const uint32_t address = r9 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A720U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 300U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A724U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0023A730U + 856U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A728U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x0000002CU;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A730U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A734U, address);
            }
        }
        {
            const uint32_t address = r9 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A738U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 304U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A73CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A740U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A744U, address);
            }
        }
        {
            const uint32_t address = r9 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A748U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 308U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A74CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A750U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A754U, address);
            }
        }
        {
            const uint32_t address = r4 + 328U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A758U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A75CU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A768U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A768U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A768;
    }
block_0023A768:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A768U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A768U);
        }
        goto block_0023A77C;
    }
block_0023A76C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A76CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A76CU);
        }
        {
            r2 = r0 & 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000050U;
            r1 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A77CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_CalcAtDefault_00338AC8(frame, context, state, 0x00338AC8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A77CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A77C;
    }
block_0023A77C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A77CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A77CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A77CU, address);
            }
            r0 = value;
        }
        {
            r9 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A788U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_InCsMode_0036A7A0(frame, context, state, 0x0036A7A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A788U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A788;
    }
block_0023A788:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A788U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A788U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0023A908; }
        goto block_0023A790;
    }
block_0023A790:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A790U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A790U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A790U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A798U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003fb3e8_003FB3E8(frame, context, state, 0x003FB3E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A798U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A798;
    }
block_0023A798:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A798U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A798U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0023A908; }
        goto block_0023A7A0;
    }
block_0023A7A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A7A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A7A0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7A4U, address);
            }
            r1 = value;
        }
        {
            r9 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00001700U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x84U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A7B0U, address);
            }
        }
        {
            const uint32_t address = r7 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7B8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x58U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7BCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7C0U, 0xEE700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A7C4U, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7CCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7D0U, 0xEE301A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0023A7D4U, address);
            }
        }
        {
            const uint32_t address = r7 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7DCU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7E0U, 0xEE701A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7E4U, 0xEE200AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0023A7E8U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7ECU, 0xEE010A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7F0U, 0xEE010AA1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7F4U, 0xEEB40A6AU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[21],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A7FCU, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A800U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A804U, address);
            }
        }
        if (flags.Z()) { goto block_0023A82C; }
        goto block_0023A80C;
    }
block_0023A80C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A80CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A80CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A80CU, 0xEEB10AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A810U, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A814U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A818U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A81CU, 0xEE610A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A820U, 0xEE210A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A824U, address);
            }
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A828U, address);
            }
        }
        goto block_0023A82C;
    }
block_0023A82C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A82CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A82CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x0023A838U + 596U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A830U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A834U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A838U, 0xEE609A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A83CU, 0xEEF49A6AU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[19], frame.Guest.vfp[21],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            frame.Guest.vfp[22] = frame.Guest.vfp[21];
        }
        if (flags.Z()) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        if (flags.Z()) { goto block_0023A864; }
        goto block_0023A850;
    }
block_0023A850:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A850U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A850U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A858U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A858U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A858;
    }
block_0023A858:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A858U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A858U);
        }
        {
            frame.Guest.vfp[22] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A864U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A864U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A864;
    }
block_0023A864:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A864U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A864U);
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A864U, address);
            }
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A868U, address);
            }
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0023A86CU, address);
            }
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A870U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A874U, 0xEEF10A4BU};
            frame.Guest.vfp[1] = frame.Guest.vfp[22] ^ 0x80000000U;
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0023A878U, address);
            }
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A87CU, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A880U, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A884U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A888U, address);
            }
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A88CU, address);
            }
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A890U, address);
            }
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A894U, address);
            }
        }
        {
            const uint32_t operand = 0x00000040U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000034U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A8A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A8A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A8A8;
    }
block_0023A8A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A8A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A8A8U);
        }
        {
            const uint32_t address = r13 + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8ACU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8B0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x84U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8B4U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8B8U, 0xEE700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r11 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8BCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x56U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8C0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8C4U, 0xEE609A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8C8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8CCU, 0xEE700AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8D0U, 0xEE60AA80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A8D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A8D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A8D8;
    }
block_0023A8D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A8D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A8D8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8D8U, 0xEEB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        {
            const uint32_t address = r11 + 76U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8DCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8E0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8E4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8E8U, 0xEE700AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A8ECU, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8F0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8F4U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A8F8U, address);
            }
        }
        {
            const uint32_t address = r7 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A900U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A904U, address);
            }
        }
        goto block_0023A908;
    }
block_0023A908:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A908U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A908U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A908U, address);
            }
            r2 = value;
        }
        {
            r1 = r7;
        }
        {
            const uint32_t operand = 0x00000060U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A918U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A918U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A918;
    }
block_0023A918:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A918U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A918U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A918U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A91CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r4 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A920U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A924U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A930U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033743c_0033743C(frame, context, state, 0x0033743CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A930U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A930;
    }
block_0023A930:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A930U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A930U);
        }
        {
            const uint32_t address = r13 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A930U, address);
            }
        }
        {
            const uint32_t address = r4 + 292U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A934U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A938U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0023A94C; }
        goto block_0023A944;
    }
block_0023A944:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A944U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A944U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0023A974; }
        goto block_0023A94C;
    }
block_0023A94C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A94CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A94CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A94CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x56U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A950U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A958U, address);
            }
        }
        {
            const uint32_t address = r4 + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A95CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x26U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A960U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A964U, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A96CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331440_00331440(frame, context, state, 0x00331440U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A96CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A96C;
    }
block_0023A96C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A96CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A96CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A96CU, address);
            }
        }
        goto block_0023A9F0;
    }
block_0023A974:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A974U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A974U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A974U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r0 = r4;
        }
        if (flags.Z()) { goto block_0023A9BC; }
        goto block_0023A984;
    }
block_0023A984:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A984U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A984U);
        }
        {
            const uint32_t address = r0 + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A984U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x56U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A988U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r5 + 0x16U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A98CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A990U, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = 0x0000000AU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A99CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331440_00331440(frame, context, state, 0x00331440U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A99CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A99C;
    }
block_0023A99C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A99CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A99CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A99CU, address);
            }
        }
        {
            const uint32_t address = r4 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9A4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r5 + 0x14U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9A8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A9ACU, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = 0x0000000AU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A9B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331440_00331440(frame, context, state, 0x00331440U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A9B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A9B8;
    }
block_0023A9B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A9B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A9B8U);
        }
        goto block_0023A9EC;
    }
block_0023A9BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A9BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A9BCU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r0 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9C4U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x56U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9C8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A9D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003380f0_003380F0(frame, context, state, 0x003380F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A9D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A9D4;
    }
block_0023A9D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A9D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A9D4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A9D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9D8U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r4 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9DCU, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9E0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A9ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00337fdc_00337FDC(frame, context, state, 0x00337FDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A9ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A9EC;
    }
block_0023A9EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A9ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A9ECU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A9ECU, address);
            }
        }
        goto block_0023A9F0;
    }
block_0023A9F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A9F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A9F0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9F0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0023A9FCU + 0x94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A9FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA00U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0023AA0CU + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA04U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AA0CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000060U;
            r1 = r13 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AA1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_AddVecGeoToVec3f_00372448(frame, context, state, 0x00372448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AA1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AA1C;
    }
block_0023AA1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AA1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AA1CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA1CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0023AA28U + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA20U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023AA24U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023AA28U, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0023AA2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x88U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA30U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA38U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x00000010U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0023ABE8; }
        goto block_0023AA44;
    }
block_0023AA44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AA44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AA44U);
        }
        {
            const uint32_t updatedAddress = r8 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA44U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00007F00U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AA50U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA54U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0023AA9C; }
        goto block_0023AA60;
    }
block_0023AA60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AA60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AA60U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0023AA64U, address);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA6CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = r5;
        }
        {
            const uint32_t operand = 0x00000078U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000060U;
            r1 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AA84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00337624_00337624(frame, context, state, 0x00337624U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AA84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AA84;
    }
block_0023AA84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AA84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AA84U);
        }
        goto block_0023AB14;
    }
block_0023AA9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AA9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AA9CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA9CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000006CU;
            r8 = r13 + operand;
        }
        {
            const uint32_t address = 0x0023AAACU + 472U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AAA4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000024U;
            r11 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0023AAACU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0023AAACU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0023AAACU,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0023AAB0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0023AAB0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0023AAB0U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AAB4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023AAB8U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023AABCU, address);
            }
        }
        {
            const uint32_t address = r5 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023AAC0U, address);
            }
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0023AAC4U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0023AAC4U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0023AAC4U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0023AAC8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0023AAC8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0023AAC8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000024U;
            r2 = r13 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AADCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_BGCheckInfo_003553FC(frame, context, state, 0x003553FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AADCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AADC;
    }
block_0023AADC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AADCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AADCU);
        }
        {
            const uint32_t firstAddress = r11;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0023AADCU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0023AADCU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0023AADCU,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0023AAE4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0023AAE4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0023AAE4U,
                                           firstAddress + 8U);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x56U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AAE8U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AAECU, address);
            }
        }
        if (!(flags.Z())) {
            r0 = ~(0x00000000U);
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AAF4U, address);
            }
        }
        if (!(flags.Z())) { goto block_0023AB10; }
        goto block_0023AAFC;
    }
block_0023AAFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AAFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AAFCU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0023AB04U, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AB10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AB10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AB10;
    }
block_0023AB10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB10U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023AB10U, address);
            }
        }
        goto block_0023AB14;
    }
block_0023AB14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB14U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB14U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0023AB5C; }
        goto block_0023AB20;
    }
block_0023AB20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB20U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r5 + 0x16U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB24U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r13 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB28U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0023AB34U + 340U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB2CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00007F00U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x7EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB34U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 - operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023AB3CU, 0xEE000AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AB58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331440_00331440(frame, context, state, 0x00331440U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AB58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AB58;
    }
block_0023AB58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB58U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x7EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AB58U, address);
            }
        }
        goto block_0023AB5C;
    }
block_0023AB5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB5CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB5CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x5CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB64U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x7CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AB6CU, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB70U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00007F00U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) { goto block_0023AB9C; }
        goto block_0023AB80;
    }
block_0023AB80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB80U);
        }
        {
            const uint32_t operand = 0x00000080U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000060U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AB90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AB90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AB90;
    }
block_0023AB90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB90U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x7CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AB94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB98U, address);
            }
            r0 = value;
        }
        goto block_0023AB9C;
    }
block_0023AB9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB9CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x7EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AB9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0023ABA8U + 0xE4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABA0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023ABA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABA8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000010U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0023AC24; }
        goto block_0023ABB4;
    }
block_0023ABB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023ABB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023ABB4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABB4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABB8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x000000FFU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0023AC1C; }
        goto block_0023ABC4;
    }
block_0023ABC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023ABC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023ABC4U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023ABC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023ABC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023ABC8;
    }
block_0023ABC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023ABC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023ABC8U);
        }
        {
            const uint32_t address = 0x0023ABD0U + 192U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABC8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x7EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABCCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023ABD0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023ABD4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x7EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023ABE0U, address);
            }
        }
        goto block_0023AC0C;
    }
block_0023ABE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023ABE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023ABE8U);
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABE8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r5 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023ABF0U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023ABF8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023ABFCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0023AC00U, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AC0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AC0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AC0C;
    }
block_0023AC0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC0CU);
        }
        {
            const uint32_t updatedAddress = 0x0023AC14U + 0x78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC10U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000010U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0023AC24; }
        goto block_0023AC1C;
    }
block_0023AC1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC1CU);
        }
        {
            const uint32_t address = 0x0023AC24U + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC1CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0023AC28;
    }
block_0023AC24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC24U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        goto block_0023AC28;
    }
block_0023AC28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC28U);
        }
        {
            const uint32_t address = r4 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC28U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r4 + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC2CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r4 + 324U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC30U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023AC34U, 0xEE210A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AC40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AC40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AC40;
    }
block_0023AC40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC40U);
        }
        {
            const uint32_t address = r4 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023AC40U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = r6 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC48U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x0000000AU;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AC58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331440_00331440(frame, context, state, 0x00331440U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AC58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AC58;
    }
block_0023AC58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC58U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = r6 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AC60U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AC70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_ClampLERPScale_003375BC(frame, context, state, 0x003375BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AC70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AC70;
    }
block_0023AC70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC70U);
        }
        {
            const uint32_t address = r4 + 328U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023AC70U, address);
            }
        }
        {
            const uint32_t operand = 0x0000008CU;
            r13 = r13 + operand;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Camera_Normal1_00239FD8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00239FD8U:
        goto block_00239FD8;
    case 0x0023A00CU:
        goto block_0023A00C;
    case 0x0023A160U:
        goto block_0023A160;
    case 0x0023A170U:
        goto block_0023A170;
    case 0x0023A188U:
        goto block_0023A188;
    case 0x0023A190U:
        goto block_0023A190;
    case 0x0023A198U:
        goto block_0023A198;
    case 0x0023A19CU:
        goto block_0023A19C;
    case 0x0023A1C4U:
        goto block_0023A1C4;
    case 0x0023A248U:
        goto block_0023A248;
    case 0x0023A280U:
        goto block_0023A280;
    case 0x0023A2B8U:
        goto block_0023A2B8;
    case 0x0023A2C0U:
        goto block_0023A2C0;
    case 0x0023A2CCU:
        goto block_0023A2CC;
    case 0x0023A310U:
        goto block_0023A310;
    case 0x0023A330U:
        goto block_0023A330;
    case 0x0023A33CU:
        goto block_0023A33C;
    case 0x0023A370U:
        goto block_0023A370;
    case 0x0023A3FCU:
        goto block_0023A3FC;
    case 0x0023A418U:
        goto block_0023A418;
    case 0x0023A454U:
        goto block_0023A454;
    case 0x0023A468U:
        goto block_0023A468;
    case 0x0023A494U:
        goto block_0023A494;
    case 0x0023A4BCU:
        goto block_0023A4BC;
    case 0x0023A4C0U:
        goto block_0023A4C0;
    case 0x0023A4E8U:
        goto block_0023A4E8;
    case 0x0023A514U:
        goto block_0023A514;
    case 0x0023A540U:
        goto block_0023A540;
    case 0x0023A574U:
        goto block_0023A574;
    case 0x0023A584U:
        goto block_0023A584;
    case 0x0023A5A0U:
        goto block_0023A5A0;
    case 0x0023A5C8U:
        goto block_0023A5C8;
    case 0x0023A5D0U:
        goto block_0023A5D0;
    case 0x0023A5E8U:
        goto block_0023A5E8;
    case 0x0023A608U:
        goto block_0023A608;
    case 0x0023A610U:
        goto block_0023A610;
    case 0x0023A628U:
        goto block_0023A628;
    case 0x0023A638U:
        goto block_0023A638;
    case 0x0023A64CU:
        goto block_0023A64C;
    case 0x0023A650U:
        goto block_0023A650;
    case 0x0023A658U:
        goto block_0023A658;
    case 0x0023A678U:
        goto block_0023A678;
    case 0x0023A690U:
        goto block_0023A690;
    case 0x0023A6B0U:
        goto block_0023A6B0;
    case 0x0023A6B4U:
        goto block_0023A6B4;
    case 0x0023A6D8U:
        goto block_0023A6D8;
    case 0x0023A6DCU:
        goto block_0023A6DC;
    case 0x0023A6E0U:
        goto block_0023A6E0;
    case 0x0023A720U:
        goto block_0023A720;
    case 0x0023A768U:
        goto block_0023A768;
    case 0x0023A76CU:
        goto block_0023A76C;
    case 0x0023A77CU:
        goto block_0023A77C;
    case 0x0023A788U:
        goto block_0023A788;
    case 0x0023A790U:
        goto block_0023A790;
    case 0x0023A798U:
        goto block_0023A798;
    case 0x0023A7A0U:
        goto block_0023A7A0;
    case 0x0023A80CU:
        goto block_0023A80C;
    case 0x0023A82CU:
        goto block_0023A82C;
    case 0x0023A850U:
        goto block_0023A850;
    case 0x0023A858U:
        goto block_0023A858;
    case 0x0023A864U:
        goto block_0023A864;
    case 0x0023A8A8U:
        goto block_0023A8A8;
    case 0x0023A8D8U:
        goto block_0023A8D8;
    case 0x0023A908U:
        goto block_0023A908;
    case 0x0023A918U:
        goto block_0023A918;
    case 0x0023A930U:
        goto block_0023A930;
    case 0x0023A944U:
        goto block_0023A944;
    case 0x0023A94CU:
        goto block_0023A94C;
    case 0x0023A96CU:
        goto block_0023A96C;
    case 0x0023A974U:
        goto block_0023A974;
    case 0x0023A984U:
        goto block_0023A984;
    case 0x0023A99CU:
        goto block_0023A99C;
    case 0x0023A9B8U:
        goto block_0023A9B8;
    case 0x0023A9BCU:
        goto block_0023A9BC;
    case 0x0023A9D4U:
        goto block_0023A9D4;
    case 0x0023A9ECU:
        goto block_0023A9EC;
    case 0x0023A9F0U:
        goto block_0023A9F0;
    case 0x0023AA1CU:
        goto block_0023AA1C;
    case 0x0023AA44U:
        goto block_0023AA44;
    case 0x0023AA60U:
        goto block_0023AA60;
    case 0x0023AA84U:
        goto block_0023AA84;
    case 0x0023AA9CU:
        goto block_0023AA9C;
    case 0x0023AADCU:
        goto block_0023AADC;
    case 0x0023AAFCU:
        goto block_0023AAFC;
    case 0x0023AB10U:
        goto block_0023AB10;
    case 0x0023AB14U:
        goto block_0023AB14;
    case 0x0023AB20U:
        goto block_0023AB20;
    case 0x0023AB58U:
        goto block_0023AB58;
    case 0x0023AB5CU:
        goto block_0023AB5C;
    case 0x0023AB80U:
        goto block_0023AB80;
    case 0x0023AB90U:
        goto block_0023AB90;
    case 0x0023AB9CU:
        goto block_0023AB9C;
    case 0x0023ABB4U:
        goto block_0023ABB4;
    case 0x0023ABC4U:
        goto block_0023ABC4;
    case 0x0023ABC8U:
        goto block_0023ABC8;
    case 0x0023ABE8U:
        goto block_0023ABE8;
    case 0x0023AC0CU:
        goto block_0023AC0C;
    case 0x0023AC1CU:
        goto block_0023AC1C;
    case 0x0023AC24U:
        goto block_0023AC24;
    case 0x0023AC28U:
        goto block_0023AC28;
    case 0x0023AC40U:
        goto block_0023AC40;
    case 0x0023AC58U:
        goto block_0023AC58;
    case 0x0023AC70U:
        goto block_0023AC70;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00239FD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00239FD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00239FD8U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00239FD8U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00000080U;
            r7 = r0 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000000DCU;
            r8 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r5 = r4 + operand;
        }
        {
            r13 -= 32U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x00239FF0U,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t operand = 0x0000008CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00239FF8U, address);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A000U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A004U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A00CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_GetHeight_00367EF0(frame, context, state, 0x00367EF0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A00CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A00C;
    }
block_0023A00C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A00CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A00CU);
        }
        {
            const uint32_t operand = 0x00000100U;
            r6 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0023A018U + 0x330U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A010U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A014U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0023A020U + 0x330U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A018U, address);
            }
            r9 = value;
        }
        {
            const uint32_t address = 0x0023A024U + 808U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A01CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0023A028U + 812U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A020U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A028U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A02CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A030U, 0xEE801A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0023A03CU + 796U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A034U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 3U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A03CU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A040U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A044U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t address = 0x0023A054U + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A04CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xF0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A050U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A058U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A05CU, 0xEE601AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A064U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A068U, 0xEEB82AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A070U, 0xEE420A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[4], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A074U, 0xEE410A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0023A080U + 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A078U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A07CU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A084U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A088U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A08CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A090U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A098U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A09CU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A0A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A0A4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0ACU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0B0U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A0B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A0B8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0C0U, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0C8U, 0xEE000A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0CCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0023A0D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A0D8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0E0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A0E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A0E8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A0F0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A0F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A0F8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A100U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A104U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A108U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A10CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A114U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A118U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A11CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A124U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A128U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A12CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A130U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A134U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0023A140U + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A138U, address);
            }
            r11 = value;
        }
        {
            r1 = r7;
        }
        {
            const uint32_t updatedAddress = r11 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A140U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A144U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A148U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A150U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A154U, address);
            }
        }
        {
            const uint32_t operand = 0x00000058U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A160U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A160U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A160;
    }
block_0023A160:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A160U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A160U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A160U, address);
            }
            r2 = value;
        }
        {
            r1 = r7;
        }
        {
            const uint32_t operand = 0x00000050U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A170U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A170U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A170;
    }
block_0023A170:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A170U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A170U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A170U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0023A17CU + 492U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A174U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r10 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0023A1C4; }
        goto block_0023A188;
    }
block_0023A188:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A188U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A188U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0023A19C; }
        goto block_0023A190;
    }
block_0023A190:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A190U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A190U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000019U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0023A248; }
        goto block_0023A198;
    }
block_0023A198:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A198U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A198U);
        }
        goto block_0023A1C4;
    }
block_0023A19C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A19CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A19CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A19CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A1A4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A1ACU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A1B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xCAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A1B4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A1BCU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 268U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A1C0U, address);
            }
        }
        goto block_0023A1C4;
    }
block_0023A1C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A1C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A1C4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A1C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A1C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A1CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A1D0U, address);
            }
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A1D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A1DCU, address);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A1E0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A1E4U, address);
            }
        }
        {
            const uint32_t address = r8 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A1E8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A1ECU, address);
            }
        }
        {
            const uint32_t address = r4 + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A1F0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A1F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A1F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A1FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A200U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A204U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A208U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A20CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A214U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A218U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A228U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A22CU, 0xEE201A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A234U, 0xDE510A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A238U, 0xCE410A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A23CU, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A244U, address);
            }
        }
        goto block_0023A248;
    }
block_0023A248:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A248U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A248U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A24CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A250U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A258U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A25CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0023A268U + 0x104U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A260U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A26CU, address);
            }
        }
        {
            const uint32_t address = r4 + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A270U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0023A2C0; }
        goto block_0023A280;
    }
block_0023A280:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A280U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A280U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A280U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A288U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A28CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A29CU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2A0U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2A8U, 0xDE100AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2ACU, 0xCE000AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2B0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_0023A2B8;
    }
block_0023A2B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A2B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A2B8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A2B8U, address);
            }
        }
        goto block_0023A370;
    }
block_0023A2C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A2C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A2C0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A2C0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0023A370; }
        goto block_0023A2CC;
    }
block_0023A2CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A2CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A2CCU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A2CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A2D4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2E0U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2E4U, 0xDE201A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2E8U, 0xCE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2F4U, 0xDE510A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2F8U, 0xCE000AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A2FCU, 0xDEBD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A300U, 0xCEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0023A33C; }
        goto block_0023A310;
    }
block_0023A310:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A310U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A310U);
        }
        {
            const uint32_t updatedAddress = r8 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A310U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A314U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00007F00U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = r2;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0023A324U, address);
            }
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A330U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A330U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A330;
    }
block_0023A330:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A330U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A330U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A330U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = r2;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A338U, address);
            }
        }
        goto block_0023A33C;
    }
block_0023A33C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A33CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A33CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A33CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        goto block_0023A2B8;
    }
block_0023A370:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A370U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A370U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A370U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0023A37CU + 840U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A374U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xC6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A37CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r1 + 0xC8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A380U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A388U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A38CU, 0xEE600A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A390U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A394U, 0xEE60AA80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A39CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = 0x0023A3ACU + 0x310U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3A4U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3A8U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (flags.Z()) {
            frame.Guest.vfp[2] = frame.Guest.vfp[21];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3B0U, 0xEE600AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3B4U, 0xEE20BA80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[22], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x0023A3C4U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3BCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (!(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3C0U, 0x1EB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3C4U, 0x1E201A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 120U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0023A3C8U, address);
            }
        }
        {
            const uint32_t address = r4 + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3D0U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r5 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A3D4U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3D8U, 0xEE701A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3DCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A3E0U, 0xEE219AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[18];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        {
            const uint32_t updatedAddress = r5 + 0x1AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3ECU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (!(flags.C())) {
            const uint32_t address = 0x0023A3F8U + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A3F0U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0023A468; }
        goto block_0023A3FC;
    }
block_0023A3FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A3FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A3FCU);
        }
        {
            r0 = Oot3dAotLsl(r0, 1U);
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A408U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A40CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A410U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A418U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A418U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A418;
    }
block_0023A418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A418U);
        }
        {
            const uint32_t address = r4 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A418U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A41CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A42CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A434U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = Oot3dAotLsl(r0, 1U);
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A440U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A444U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A448U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A44CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A454U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A454U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A454;
    }
block_0023A454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A454U);
        }
        {
            const uint32_t address = r4 + 268U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A454U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x1AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A458U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A460U, address);
            }
        }
        goto block_0023A4C0;
    }
block_0023A468:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A468U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A468U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A468U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A474U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A47CU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A480U, 0xEE600AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A484U, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A488U, 0xEE000AC9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A48CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A494U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A494U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A494;
    }
block_0023A494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A494U);
        }
        {
            const uint32_t address = r4 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A494U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A498U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r4 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4A8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4ACU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A4B4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A4BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A4BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A4BC;
    }
block_0023A4BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A4BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A4BCU);
        }
        {
            const uint32_t address = r4 + 268U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A4BCU, address);
            }
        }
        goto block_0023A4C0;
    }
block_0023A4C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A4C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A4C0U);
        }
        {
            const uint32_t updatedAddress = 0x0023A4C8U - 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4C0U, address);
            }
            r9 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            const uint32_t address = r4 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4CCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4D8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A4E0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A4E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A4E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A4E8;
    }
block_0023A4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A4E8U);
        }
        {
            const uint32_t address = r4 + 268U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A4E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4ECU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[21];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r4 + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A4FCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x98U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A500U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A508U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A50CU, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A514U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A514U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A514;
    }
block_0023A514:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A514U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A514U);
        }
        {
            const uint32_t address = r4 + 276U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A514U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A518U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r4 + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A528U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A52CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A534U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A538U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A540U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A540U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A540;
    }
block_0023A540:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A540U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A540U);
        }
        {
            const uint32_t address = r4 + 280U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A540U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A544U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r4 + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A54CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = 0x0023A55CU + 364U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A554U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A558U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A560U, 0xEE201A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A568U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A56CU, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A574U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A574U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A574;
    }
block_0023A574:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A574U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A574U);
        }
        {
            const uint32_t address = r4 + 284U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A574U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A578U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0023A5D0; }
        goto block_0023A584;
    }
block_0023A584:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A584U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A584U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A584U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A588U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00007F00U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A5A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331480_00331480(frame, context, state, 0x00331480U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A5A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A5A0;
    }
block_0023A5A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A5A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A5A0U);
        }
        {
            const uint32_t address = r4 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5A8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A5ACU, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A5B0U, 0xEE780A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[16], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r2 = 0x0000000FU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A5B8U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A5BCU, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A5C0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A5C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002998b0_002998B0(frame, context, state, 0x002998B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A5C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A5C8;
    }
block_0023A5C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A5C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A5C8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A5C8U, address);
            }
        }
        goto block_0023A5E8;
    }
block_0023A5D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A5D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A5D0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023A5D0U, address);
            }
        }
        {
            const uint32_t address = r4 + 332U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5D4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r8 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A5DCU, 0xEEF40A40U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            const uint32_t address = r5 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A5E4U, address);
            }
        }
        goto block_0023A5E8;
    }
block_0023A5E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A5E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A5E8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5E8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t address = r4 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x0023A5FCU + 0xD0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A5F4U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            r1 = frame.Guest.vfp[0];
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) {
            const uint32_t address = r4 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A600U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.C()) { goto block_0023A628; }
        goto block_0023A608;
    }
block_0023A608:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A608U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A608U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x14U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A608U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A610U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A610U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A610;
    }
block_0023A610:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A610U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A610U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r4 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A614U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A618U, 0xEE381A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[16], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A61CU, 0xEE200A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0023A628U + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A620U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A624U, 0xEE000A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        goto block_0023A628;
    }
block_0023A628:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A628U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A628U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A628U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0023A634U + 160U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A62CU, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t value = r0 & 0x00000080U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0023A650; }
        goto block_0023A638;
    }
block_0023A638:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A638U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A638U);
        }
        {
            r3 = r0 & 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r2 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000050U;
            r1 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A64CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003381e4_003381E4(frame, context, state, 0x003381E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A64CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A64C;
    }
block_0023A64C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A64CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A64CU);
        }
        goto block_0023A77C;
    }
block_0023A650:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A650U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A650U);
        }
        {
            const uint32_t value = r0 & 0x00000020U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0023A76C; }
        goto block_0023A658;
    }
block_0023A658:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A658U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A658U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A658U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x000000DCU;
            r9 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A664U, address);
            }
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A66CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A670U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A678U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_GetHeight_00367EF0(frame, context, state, 0x00367EF0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A678U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A678;
    }
block_0023A678:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A678U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A678U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A678U, 0xEE300A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A67CU, address);
            }
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A680U, address);
            }
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A684U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A688U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A690U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A690U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A690;
    }
block_0023A690:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A690U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A690U);
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A694U, 0xEEB40AEAU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[21],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            const uint32_t updatedAddress = r9 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A698U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x56U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A69CU, address);
            }
            r1 = value;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        if (flags.C()) { goto block_0023A6D8; }
        goto block_0023A6B0;
    }
block_0023A6B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A6B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A6B0U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A6B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A6B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A6B4;
    }
block_0023A6B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A6B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A6B4U);
        }
        goto block_0023A6E0;
    }
block_0023A6D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A6D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A6D8U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A6DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A6DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A6DC;
    }
block_0023A6DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A6DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A6DCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A6DCU, 0xEEB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        goto block_0023A6E0;
    }
block_0023A6E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A6E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A6E0U);
        }
        {
            const uint32_t updatedAddress = 0x0023A6E8U - 0x398U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A6E0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r13 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A6E4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x0000012CU;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A6ECU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A6F0U, 0xEE290A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A6F8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            const uint32_t operand = 0x00000038U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A704U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A708U, 0xEE400A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A710U, address);
            }
        }
        {
            const uint32_t address = r4 + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A714U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A718U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A720U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A720U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A720;
    }
block_0023A720:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A720U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A720U);
        }
        {
            const uint32_t address = r9 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A720U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 300U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A724U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0023A730U + 856U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A728U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x0000002CU;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A730U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A734U, address);
            }
        }
        {
            const uint32_t address = r9 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A738U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 304U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A73CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A740U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A744U, address);
            }
        }
        {
            const uint32_t address = r9 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A748U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 308U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A74CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A750U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A754U, address);
            }
        }
        {
            const uint32_t address = r4 + 328U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A758U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A75CU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A768U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A768U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A768;
    }
block_0023A768:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A768U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A768U);
        }
        goto block_0023A77C;
    }
block_0023A76C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A76CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A76CU);
        }
        {
            r2 = r0 & 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000050U;
            r1 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A77CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_CalcAtDefault_00338AC8(frame, context, state, 0x00338AC8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A77CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A77C;
    }
block_0023A77C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A77CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A77CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A77CU, address);
            }
            r0 = value;
        }
        {
            r9 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A788U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_InCsMode_0036A7A0(frame, context, state, 0x0036A7A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A788U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A788;
    }
block_0023A788:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A788U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A788U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0023A908; }
        goto block_0023A790;
    }
block_0023A790:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A790U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A790U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A790U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A798U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003fb3e8_003FB3E8(frame, context, state, 0x003FB3E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A798U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A798;
    }
block_0023A798:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A798U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A798U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0023A908; }
        goto block_0023A7A0;
    }
block_0023A7A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A7A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A7A0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7A4U, address);
            }
            r1 = value;
        }
        {
            r9 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00001700U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x84U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A7B0U, address);
            }
        }
        {
            const uint32_t address = r7 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7B8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x58U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7BCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7C0U, 0xEE700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A7C4U, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7CCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7D0U, 0xEE301A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0023A7D4U, address);
            }
        }
        {
            const uint32_t address = r7 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A7DCU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7E0U, 0xEE701A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7E4U, 0xEE200AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0023A7E8U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7ECU, 0xEE010A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7F0U, 0xEE010AA1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A7F4U, 0xEEB40A6AU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[21],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A7FCU, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A800U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A804U, address);
            }
        }
        if (flags.Z()) { goto block_0023A82C; }
        goto block_0023A80C;
    }
block_0023A80C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A80CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A80CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A80CU, 0xEEB10AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A810U, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A814U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A818U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A81CU, 0xEE610A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A820U, 0xEE210A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A824U, address);
            }
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A828U, address);
            }
        }
        goto block_0023A82C;
    }
block_0023A82C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A82CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A82CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x0023A838U + 596U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A830U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A834U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A838U, 0xEE609A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A83CU, 0xEEF49A6AU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[19], frame.Guest.vfp[21],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            frame.Guest.vfp[22] = frame.Guest.vfp[21];
        }
        if (flags.Z()) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        if (flags.Z()) { goto block_0023A864; }
        goto block_0023A850;
    }
block_0023A850:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A850U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A850U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A858U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A858U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A858;
    }
block_0023A858:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A858U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A858U);
        }
        {
            frame.Guest.vfp[22] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A864U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A864U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A864;
    }
block_0023A864:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A864U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A864U);
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A864U, address);
            }
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A868U, address);
            }
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0023A86CU, address);
            }
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A870U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A874U, 0xEEF10A4BU};
            frame.Guest.vfp[1] = frame.Guest.vfp[22] ^ 0x80000000U;
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0023A878U, address);
            }
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A87CU, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A880U, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A884U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A888U, address);
            }
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A88CU, address);
            }
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A890U, address);
            }
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0023A894U, address);
            }
        }
        {
            const uint32_t operand = 0x00000040U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000034U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A8A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A8A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A8A8;
    }
block_0023A8A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A8A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A8A8U);
        }
        {
            const uint32_t address = r13 + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8ACU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8B0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x84U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8B4U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8B8U, 0xEE700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r11 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8BCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x56U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8C0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8C4U, 0xEE609A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8C8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8CCU, 0xEE700AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8D0U, 0xEE60AA80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A8D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A8D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A8D8;
    }
block_0023A8D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A8D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A8D8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8D8U, 0xEEB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        {
            const uint32_t address = r11 + 76U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8DCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8E0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8E4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8E8U, 0xEE700AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023A8ECU, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8F0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A8F4U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A8F8U, address);
            }
        }
        {
            const uint32_t address = r7 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A8FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A900U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A904U, address);
            }
        }
        goto block_0023A908;
    }
block_0023A908:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A908U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A908U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A908U, address);
            }
            r2 = value;
        }
        {
            r1 = r7;
        }
        {
            const uint32_t operand = 0x00000060U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A918U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A918U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A918;
    }
block_0023A918:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A918U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A918U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A918U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A91CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r4 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A920U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A924U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A930U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033743c_0033743C(frame, context, state, 0x0033743CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A930U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A930;
    }
block_0023A930:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A930U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A930U);
        }
        {
            const uint32_t address = r13 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A930U, address);
            }
        }
        {
            const uint32_t address = r4 + 292U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023A934U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A938U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0023A94C; }
        goto block_0023A944;
    }
block_0023A944:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A944U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A944U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0023A974; }
        goto block_0023A94C;
    }
block_0023A94C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A94CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A94CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A94CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x56U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A950U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A958U, address);
            }
        }
        {
            const uint32_t address = r4 + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A95CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x26U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A960U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A964U, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A96CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331440_00331440(frame, context, state, 0x00331440U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A96CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A96C;
    }
block_0023A96C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A96CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A96CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A96CU, address);
            }
        }
        goto block_0023A9F0;
    }
block_0023A974:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A974U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A974U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A974U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r0 = r4;
        }
        if (flags.Z()) { goto block_0023A9BC; }
        goto block_0023A984;
    }
block_0023A984:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A984U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A984U);
        }
        {
            const uint32_t address = r0 + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A984U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x56U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A988U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r5 + 0x16U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A98CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A990U, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = 0x0000000AU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A99CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331440_00331440(frame, context, state, 0x00331440U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A99CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A99C;
    }
block_0023A99C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A99CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A99CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A99CU, address);
            }
        }
        {
            const uint32_t address = r4 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9A4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r5 + 0x14U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9A8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023A9ACU, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = 0x0000000AU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A9B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331440_00331440(frame, context, state, 0x00331440U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A9B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A9B8;
    }
block_0023A9B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A9B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A9B8U);
        }
        goto block_0023A9EC;
    }
block_0023A9BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A9BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A9BCU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r0 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9C4U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x56U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9C8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A9D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003380f0_003380F0(frame, context, state, 0x003380F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A9D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A9D4;
    }
block_0023A9D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A9D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A9D4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A9D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9D8U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r4 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9DCU, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9E0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023A9ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00337fdc_00337FDC(frame, context, state, 0x00337FDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023A9ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023A9EC;
    }
block_0023A9EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A9ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A9ECU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A9ECU, address);
            }
        }
        goto block_0023A9F0;
    }
block_0023A9F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023A9F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023A9F0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9F0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0023A9FCU + 0x94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023A9F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023A9FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA00U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0023AA0CU + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA04U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AA0CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000060U;
            r1 = r13 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AA1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_AddVecGeoToVec3f_00372448(frame, context, state, 0x00372448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AA1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AA1C;
    }
block_0023AA1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AA1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AA1CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA1CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0023AA28U + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA20U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023AA24U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0023AA28U, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0023AA2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x88U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA30U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA38U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x00000010U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0023ABE8; }
        goto block_0023AA44;
    }
block_0023AA44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AA44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AA44U);
        }
        {
            const uint32_t updatedAddress = r8 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA44U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00007F00U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AA50U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA54U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0023AA9C; }
        goto block_0023AA60;
    }
block_0023AA60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AA60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AA60U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0023AA64U, address);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA6CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = r5;
        }
        {
            const uint32_t operand = 0x00000078U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000060U;
            r1 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AA84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00337624_00337624(frame, context, state, 0x00337624U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AA84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AA84;
    }
block_0023AA84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AA84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AA84U);
        }
        goto block_0023AB14;
    }
block_0023AA9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AA9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AA9CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AA9CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000006CU;
            r8 = r13 + operand;
        }
        {
            const uint32_t address = 0x0023AAACU + 472U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AAA4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000024U;
            r11 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0023AAACU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0023AAACU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0023AAACU,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0023AAB0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0023AAB0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0023AAB0U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AAB4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023AAB8U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023AABCU, address);
            }
        }
        {
            const uint32_t address = r5 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023AAC0U, address);
            }
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0023AAC4U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0023AAC4U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0023AAC4U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0023AAC8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0023AAC8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0023AAC8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000024U;
            r2 = r13 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AADCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_BGCheckInfo_003553FC(frame, context, state, 0x003553FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AADCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AADC;
    }
block_0023AADC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AADCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AADCU);
        }
        {
            const uint32_t firstAddress = r11;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0023AADCU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0023AADCU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0023AADCU,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0023AAE4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0023AAE4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0023AAE4U,
                                           firstAddress + 8U);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x56U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AAE8U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AAECU, address);
            }
        }
        if (!(flags.Z())) {
            r0 = ~(0x00000000U);
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AAF4U, address);
            }
        }
        if (!(flags.Z())) { goto block_0023AB10; }
        goto block_0023AAFC;
    }
block_0023AAFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AAFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AAFCU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0023AB04U, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AB10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AB10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AB10;
    }
block_0023AB10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB10U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023AB10U, address);
            }
        }
        goto block_0023AB14;
    }
block_0023AB14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB14U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB14U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0023AB5C; }
        goto block_0023AB20;
    }
block_0023AB20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB20U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r5 + 0x16U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB24U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r13 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB28U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0023AB34U + 340U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB2CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00007F00U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x7EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB34U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 - operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023AB3CU, 0xEE000AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AB58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331440_00331440(frame, context, state, 0x00331440U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AB58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AB58;
    }
block_0023AB58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB58U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x7EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AB58U, address);
            }
        }
        goto block_0023AB5C;
    }
block_0023AB5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB5CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB5CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x5CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB64U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x7CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AB6CU, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB70U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00007F00U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) { goto block_0023AB9C; }
        goto block_0023AB80;
    }
block_0023AB80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB80U);
        }
        {
            const uint32_t operand = 0x00000080U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000060U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AB90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AB90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AB90;
    }
block_0023AB90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB90U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x7CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AB94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AB98U, address);
            }
            r0 = value;
        }
        goto block_0023AB9C;
    }
block_0023AB9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AB9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AB9CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x7EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AB9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0023ABA8U + 0xE4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABA0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023ABA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABA8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000010U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0023AC24; }
        goto block_0023ABB4;
    }
block_0023ABB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023ABB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023ABB4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABB4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABB8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x000000FFU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0023AC1C; }
        goto block_0023ABC4;
    }
block_0023ABC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023ABC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023ABC4U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023ABC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023ABC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023ABC8;
    }
block_0023ABC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023ABC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023ABC8U);
        }
        {
            const uint32_t address = 0x0023ABD0U + 192U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABC8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x7EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABCCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023ABD0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023ABD4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x7EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023ABE0U, address);
            }
        }
        goto block_0023AC0C;
    }
block_0023ABE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023ABE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023ABE8U);
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023ABE8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r5 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023ABF0U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023ABF8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0023ABFCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0023AC00U, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AC0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AC0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AC0C;
    }
block_0023AC0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC0CU);
        }
        {
            const uint32_t updatedAddress = 0x0023AC14U + 0x78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC10U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000010U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0023AC24; }
        goto block_0023AC1C;
    }
block_0023AC1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC1CU);
        }
        {
            const uint32_t address = 0x0023AC24U + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC1CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0023AC28;
    }
block_0023AC24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC24U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        goto block_0023AC28;
    }
block_0023AC28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC28U);
        }
        {
            const uint32_t address = r4 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC28U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r4 + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC2CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r4 + 324U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC30U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0023AC34U, 0xEE210A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AC40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AC40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AC40;
    }
block_0023AC40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC40U);
        }
        {
            const uint32_t address = r4 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023AC40U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = r6 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC48U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x0000000AU;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AC58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331440_00331440(frame, context, state, 0x00331440U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AC58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AC58;
    }
block_0023AC58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC58U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = r6 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0023AC60U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = r4 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0023AC64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0023AC70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_ClampLERPScale_003375BC(frame, context, state, 0x003375BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0023AC70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0023AC70;
    }
block_0023AC70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0023AC70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0023AC70U);
        }
        {
            const uint32_t address = r4 + 328U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0023AC70U, address);
            }
        }
        {
            const uint32_t operand = 0x0000008CU;
            r13 = r13 + operand;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0023AC7CU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0023AC80U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Camera_Parallel1_00275678(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00275678U:
        goto block_00275678;
    case 0x002756A8U:
        goto block_002756A8;
    case 0x00275818U:
        goto block_00275818;
    case 0x00275828U:
        goto block_00275828;
    case 0x00275848U:
        goto block_00275848;
    case 0x0027588CU:
        goto block_0027588C;
    case 0x002758A4U:
        goto block_002758A4;
    case 0x002758B0U:
        goto block_002758B0;
    case 0x002758CCU:
        goto block_002758CC;
    case 0x002758E0U:
        goto block_002758E0;
    case 0x002758ECU:
        goto block_002758EC;
    case 0x00275904U:
        goto block_00275904;
    case 0x00275910U:
        goto block_00275910;
    case 0x00275930U:
        goto block_00275930;
    case 0x00275938U:
        goto block_00275938;
    case 0x00275990U:
        goto block_00275990;
    case 0x002759A8U:
        goto block_002759A8;
    case 0x002759C4U:
        goto block_002759C4;
    case 0x002759F0U:
        goto block_002759F0;
    case 0x00275A1CU:
        goto block_00275A1C;
    case 0x00275A50U:
        goto block_00275A50;
    case 0x00275A64U:
        goto block_00275A64;
    case 0x00275AACU:
        goto block_00275AAC;
    case 0x00275AB4U:
        goto block_00275AB4;
    case 0x00275B24U:
        goto block_00275B24;
    case 0x00275B38U:
        goto block_00275B38;
    case 0x00275B50U:
        goto block_00275B50;
    case 0x00275B64U:
        goto block_00275B64;
    case 0x00275B6CU:
        goto block_00275B6C;
    case 0x00275B7CU:
        goto block_00275B7C;
    case 0x00275BA4U:
        goto block_00275BA4;
    case 0x00275BD4U:
        goto block_00275BD4;
    case 0x00275BF4U:
        goto block_00275BF4;
    case 0x00275C00U:
        goto block_00275C00;
    case 0x00275C14U:
        goto block_00275C14;
    case 0x00275C2CU:
        goto block_00275C2C;
    case 0x00275C3CU:
        goto block_00275C3C;
    case 0x00275C64U:
        goto block_00275C64;
    case 0x00275C94U:
        goto block_00275C94;
    case 0x00275CA0U:
        goto block_00275CA0;
    case 0x00275CCCU:
        goto block_00275CCC;
    case 0x00275CD0U:
        goto block_00275CD0;
    case 0x00275CE0U:
        goto block_00275CE0;
    case 0x00275CF0U:
        goto block_00275CF0;
    case 0x00275D00U:
        goto block_00275D00;
    case 0x00275D18U:
        goto block_00275D18;
    case 0x00275D28U:
        goto block_00275D28;
    case 0x00275D3CU:
        goto block_00275D3C;
    case 0x00275D4CU:
        goto block_00275D4C;
    case 0x00275D54U:
        goto block_00275D54;
    case 0x00275D60U:
        goto block_00275D60;
    case 0x00275D88U:
        goto block_00275D88;
    case 0x00275D90U:
        goto block_00275D90;
    case 0x00275DB4U:
        goto block_00275DB4;
    case 0x00275DD4U:
        goto block_00275DD4;
    case 0x00275DDCU:
        goto block_00275DDC;
    case 0x00275DE0U:
        goto block_00275DE0;
    case 0x00275DECU:
        goto block_00275DEC;
    case 0x00275E28U:
        goto block_00275E28;
    case 0x00275E5CU:
        goto block_00275E5C;
    case 0x00275EA4U:
        goto block_00275EA4;
    case 0x00275EB0U:
        goto block_00275EB0;
    case 0x00275EC8U:
        goto block_00275EC8;
    case 0x00275ED4U:
        goto block_00275ED4;
    case 0x00275F08U:
        goto block_00275F08;
    case 0x00275F34U:
        goto block_00275F34;
    case 0x00275F50U:
        goto block_00275F50;
    case 0x00275F64U:
        goto block_00275F64;
    case 0x00275F80U:
        goto block_00275F80;
    case 0x00275FB8U:
        goto block_00275FB8;
    case 0x00275FC0U:
        goto block_00275FC0;
    case 0x00275FF8U:
        goto block_00275FF8;
    case 0x0027600CU:
        goto block_0027600C;
    case 0x0027601CU:
        goto block_0027601C;
    case 0x00276090U:
        goto block_00276090;
    case 0x0027609CU:
        goto block_0027609C;
    case 0x002760B4U:
        goto block_002760B4;
    case 0x002760D8U:
        goto block_002760D8;
    case 0x002760E4U:
        goto block_002760E4;
    case 0x002760F4U:
        goto block_002760F4;
    case 0x00276104U:
        goto block_00276104;
    case 0x00276160U:
        goto block_00276160;
    case 0x00276198U:
        goto block_00276198;
    case 0x002761B0U:
        goto block_002761B0;
    case 0x002761D8U:
        goto block_002761D8;
    case 0x002761E8U:
        goto block_002761E8;
    case 0x00276200U:
        goto block_00276200;
    case 0x00276210U:
        goto block_00276210;
    case 0x00276224U:
        goto block_00276224;
    case 0x00276238U:
        goto block_00276238;
    case 0x00276298U:
        goto block_00276298;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00275678:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275678U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275678U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00275678U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00275678U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00275678U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00275678U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00275678U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00275678U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00275678U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00275678U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00275678U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000080U;
            r8 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000A4U;
            r10 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000DCU;
            r7 = r4 + operand;
        }
        {
            r13 -= 32U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00275690U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00275690U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00275690U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00275690U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x00275690U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x00275690U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x00275690U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x00275690U,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t operand = 0x00000074U;
            r13 = r13 - operand;
        }
        {
            const uint32_t operand = 0x00000028U;
            r5 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027569CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002756A0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002756A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_GetHeight_00367EF0(frame, context, state, 0x00367EF0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002756A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002756A8;
    }
block_002756A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002756A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002756A8U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r6 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x002756B4U + 0x3C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002756ACU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002756B0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r6 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002756B4U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x002756C0U + 0x3C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002756B8U, address);
            }
            r9 = value;
        }
        {
            const uint32_t address = 0x002756C4U + 956U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002756BCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r1 + operand;
        }
        {
            const uint32_t address = 0x002756CCU + 956U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002756C4U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002756C8U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 3U);
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002756D4U, 0xEE801A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002756D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002756DCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x002756E8U + 932U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002756E0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x002756ECU + 936U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002756E4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xF0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002756ECU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002756F4U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002756F8U, 0xEE601A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275700U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275704U, 0xEEB82AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027570CU, 0xEE420A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[4], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[4] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275714U, 0xEE410A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = r1;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[4];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275720U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275724U, 0xEE211A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275728U, 0xEE211A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027572CU, 0xEE211A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00275730U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275734U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027573CU, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275740U, 0xEE211A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275744U, 0xEE211A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275748U, 0xEE211A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0027574CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275750U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275758U, 0xEEF82AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00275764U + 812U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027575CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275760U, 0xEE421A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[5], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275764U, 0xEEFD1AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[3];
        }
        {
            const uint32_t updatedAddress = r4 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0027576CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275770U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[3] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275778U, 0xEEF81AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027577CU, 0xEE012A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[4], frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275780U, 0xEEBD1AC2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[2];
        }
        {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00275788U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027578CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275794U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00275798U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027579CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002757A4U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002757A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002757ACU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002757B4U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002757B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002757BCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002757C4U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002757C8U, 0xEE211A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002757CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002757D0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002757D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002757D8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r1;
        }
        {
            r1 = r8;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002757E4U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002757E8U, 0xEE211A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002757ECU, 0xEE210A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002757F0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002757F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x28U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002757F8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x0000005CU;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275804U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275808U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0027580CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275810U, address);
            }
            r2 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275818U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275818U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275818;
    }
block_00275818:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275818U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275818U);
        }
        {
            r2 = r10;
        }
        {
            r1 = r8;
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275828U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275828U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275828;
    }
block_00275828:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275828U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275828U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275828U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x00275834U + 612U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027582CU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            r11 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000019U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) { goto block_0027588C; }
        goto block_00275848;
    }
block_00275848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275848U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x00275848U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0027584CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275850U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275858U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + 0xC2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275860U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            r0 = 0x00000014U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275868U, address);
            }
        }
        {
            const uint32_t address = r5 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0027586CU, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275870U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275874U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275878U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0027587CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275880U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275888U, address);
            }
        }
        goto block_0027588C;
    }
block_0027588C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027588CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027588CU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275890U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275894U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            r0 = r4;
        }
        if (flags.Z()) { goto block_002758E0; }
        goto block_002758A4;
    }
block_002758A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002758A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002758A4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002758A4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_002758CC; }
        goto block_002758B0;
    }
block_002758B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002758B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002758B0U);
        }
        {
            const uint32_t updatedAddress = r7 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002758B0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002758B4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00007F00U;
            r1 = r1 - operand;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r1 = r1 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r0;
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x12U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002758C4U, address);
            }
        }
        goto block_00275910;
    }
block_002758CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002758CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002758CCU);
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r13 + 0x5AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002758D0U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002758D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x12U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002758D8U, address);
            }
        }
        goto block_00275910;
    }
block_002758E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002758E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002758E0U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002758E0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000020U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00275904; }
        goto block_002758EC;
    }
block_002758EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002758ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002758ECU);
        }
        {
            const uint32_t updatedAddress = r7 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002758ECU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r4 + 0x22U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002758F0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00007F00U;
            r1 = r1 - operand;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r1 = r1 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r0;
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x12U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275900U, address);
            }
        }
        goto block_00275904;
    }
block_00275904:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275904U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275904U);
        }
        {
            const uint32_t updatedAddress = 0x0027590CU + 0x190U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275904U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275908U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r1 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027590CU, address);
            }
        }
        goto block_00275910;
    }
block_00275910:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275910U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275910U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275910U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275918U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027591CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000015U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00275924U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00275928U, address);
            }
        }
        if (flags.Z()) { goto block_00275938; }
        goto block_00275930;
    }
block_00275930:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275930U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275930U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r6 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00275934U, address);
            }
        }
        goto block_00275938;
    }
block_00275938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275938U);
        }
        {
            const uint32_t updatedAddress = 0x00275940U + 0x144U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275938U, address);
            }
            r7 = value;
        }
        {
            const uint32_t address = r4 + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027593CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00275948U + 344U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275940U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275944U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[21];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xC6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275950U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            const uint32_t updatedAddress = r0 + 0xC8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275958U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027595CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275960U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275964U, 0xEE600A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275968U, 0xEE20AA20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275970U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275978U, 0xEE600A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027597CU, 0xEE60BA20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[23], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = r4 + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275984U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275988U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275990U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275990U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275990;
    }
block_00275990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275990U);
        }
        {
            const uint32_t address = r4 + 264U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275990U, address);
            }
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[21];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r4 + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027599CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002759A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002759A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002759A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002759A8;
    }
block_002759A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002759A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002759A8U);
        }
        {
            const uint32_t address = 0x002759B0U + 244U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002759A8U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = r4 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002759ACU, address);
            }
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[21];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[23];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            const uint32_t address = r4 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002759BCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002759C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002759C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002759C4;
    }
block_002759C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002759C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002759C4U);
        }
        {
            const uint32_t address = r4 + 268U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002759C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002759C8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[21];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r4 + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002759D8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x98U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002759DCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002759E4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002759E8U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002759F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002759F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002759F0;
    }
block_002759F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002759F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002759F0U);
        }
        {
            const uint32_t address = r4 + 276U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002759F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002759F4U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[21];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[23];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r4 + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275A04U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275A08U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275A10U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275A14U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275A1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275A1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275A1C;
    }
block_00275A1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275A1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275A1CU);
        }
        {
            const uint32_t address = r4 + 280U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275A1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275A20U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275A24U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00275A30U + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275A28U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[21];
        }
        {
            const uint32_t updatedAddress = r0 + 0x9CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275A34U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275A38U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275A3CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275A44U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275A48U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275A50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275A50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275A50;
    }
block_00275A50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275A50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275A50U);
        }
        {
            const uint32_t address = r4 + 284U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275A50U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275A54U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x00275A5CU, address);
            }
        }
        if (flags.Z()) { goto block_00275B24; }
        goto block_00275A64;
    }
block_00275A64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275A64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275A64U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275A64U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00007F00U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            r0 = r4;
        }
        goto block_00275AAC;
    }
block_00275AAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275AACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275AACU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275AACU, address);
            }
            r2 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275AB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331480_00331480(frame, context, state, 0x00331480U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275AB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275AB4;
    }
block_00275AB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275AB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275AB4U);
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275AB4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00275AC0U + 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275AB8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00275AC4U + 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275ABCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275AC0U, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275AC4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r1;
            r2 = r0 - operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275ACCU, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275AD0U, 0xEE200A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275AD4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275AE0U, 0xEE381A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[16], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275AE4U, 0xEE200A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275AE8U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00275AF4U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275AECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275AF0U, 0xEE200A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275AF4U, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r2 = operand - r2;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275B04U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275B0CU, 0xEE010A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275B10U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r3 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r3, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t operand = r3;
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275B20U, address);
            }
        }
        goto block_00275B24;
    }
block_00275B24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275B24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275B24U);
        }
        {
            const uint32_t address = r4 + 332U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275B24U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 224U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275B28U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275B2CU, 0xEEF40A40U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_00275B64; }
        goto block_00275B38;
    }
block_00275B38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275B38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275B38U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275B38U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00275B44U + 0x264U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275B3CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = r0 + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275B40U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x3U));
        }
        if (!(flags.C())) { goto block_00275B64; }
        goto block_00275B50;
    }
block_00275B50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275B50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275B50U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x710U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275B54U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00200000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00200000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) {
            r9 = 0x00000001U;
        }
        if (flags.Z()) { goto block_00275B6C; }
        goto block_00275B64;
    }
block_00275B64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275B64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275B64U);
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275B64U, address);
            }
        }
        {
            r9 = 0x00000000U;
        }
        goto block_00275B6C;
    }
block_00275B6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275B6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275B6CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275B6CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r1 = r0 & 0x00000080U;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r9, 0U, 0U, flags.C());
            r1 = r1 | shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r1, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00275EB0; }
        goto block_00275B7C;
    }
block_00275B7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275B7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275B7CU);
        }
        {
            const uint32_t address = r4 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275B7CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            r0 = r0 & 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275B84U, address);
            }
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275B8CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000150U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275B94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275B98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x000000DCU;
            r7 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275BA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_GetHeight_00367EF0(frame, context, state, 0x00367EF0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275BA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275BA4;
    }
block_00275BA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275BA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275BA4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275BA4U, 0xEE300A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = 0x00275BB0U - 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275BA8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00275BACU, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00275BB0U, address);
            }
        }
        {
            r1 = 0x000002ECU;
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275BB8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275BBCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275BC0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275BC8U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00275C00; }
        goto block_00275BD4;
    }
block_00275BD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275BD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275BD4U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x5AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275BD8U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275BDCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r7 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275BE0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275BE8U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275BECU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275BF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_CalcSlopeYAdj_00367E88(frame, context, state, 0x00367E88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275BF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275BF4;
    }
block_00275BF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275BF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275BF4U);
        }
        {
            const uint32_t address = r13 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275BF4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275BF8U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275BFCU, address);
            }
        }
        goto block_00275C00;
    }
block_00275C00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275C00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275C00U);
        }
        {
            const uint32_t address = r4 + 332U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C00U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 224U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C04U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275C08U, 0xEEF40A40U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_00275C3C; }
        goto block_00275C14;
    }
block_00275C14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275C14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275C14U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00275C20U + 0x188U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C18U, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = r0 + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C1CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_00275C3C; }
        goto block_00275C2C;
    }
block_00275C2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275C2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275C2CU);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x710U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C30U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00200000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00200000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00275CA0; }
        goto block_00275C3C;
    }
block_00275C3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275C3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275C3CU);
        }
        {
            const uint32_t updatedAddress = 0x00275C44U - 0x1C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C3CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[21];
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C44U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xEAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C4CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275C54U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275C58U, 0xEE201A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C5CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275C64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275C64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275C64;
    }
block_00275C64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275C64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275C64U);
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275C64U, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[21];
        }
        {
            const uint32_t operand = 0x0000012CU;
            r1 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275C74U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C78U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275C80U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275C84U, address);
            }
        }
        {
            const uint32_t address = r4 + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C88U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275C8CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275C94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275C94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275C94;
    }
block_00275C94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275C94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275C94U);
        }
        {
        }
        {
        }
        goto block_00275E5C;
    }
block_00275CA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275CA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275CA0U);
        }
        {
            const uint32_t updatedAddress = 0x00275CA8U - 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275CA0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275CA4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00275CB0U + 252U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275CA8U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275CB0U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275CB4U, 0xEE709A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xEAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275CBCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275CC4U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_00275D4C; }
        goto block_00275CCC;
    }
block_00275CCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275CCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275CCCU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275CD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDistXZ_00367E60(frame, context, state, 0x00367E60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275CD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275CD0;
    }
block_00275CD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275CD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275CD0U);
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275CE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_FAtan2F_003696EC(frame, context, state, 0x003696ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275CE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275CE0;
    }
block_00275CE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275CE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275CE0U);
        }
        {
            const uint32_t address = r4 + 324U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275CE0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00275CECU + 196U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275CE4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275CE8U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275CF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_TanF_003555D8(frame, context, state, 0x003555D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275CF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275CF0;
    }
block_00275CF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275CF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275CF0U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275CF0U, 0xEE200A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275CF4U, 0xEEF49AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[19], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00275D18; }
        goto block_00275D00;
    }
block_00275D00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275D00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275D00U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275D00U, 0xEE391AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275D04U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275D0CU, 0xEE700A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00275D10U, address);
            }
        }
        goto block_00275D3C;
    }
block_00275D18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275D18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275D18U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275D18U, 0xEEF10A40U};
            frame.Guest.vfp[1] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275D1CU, 0xEEF49AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[19], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_00275D3C; }
        goto block_00275D28;
    }
block_00275D28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275D28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275D28U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275D28U, 0xEE390A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275D2CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[1];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275D34U, 0xEE310A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275D38U, address);
            }
        }
        goto block_00275D3C;
    }
block_00275D3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275D3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275D3CU);
        }
        {
            const uint32_t address = r13 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275D3CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275D40U, 0xEE300A69U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275D44U, address);
            }
        }
        goto block_00275DEC;
    }
block_00275D4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275D4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275D4CU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275D54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDistXZ_00367E60(frame, context, state, 0x00367E60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275D54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275D54;
    }
block_00275D54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275D54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275D54U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275D60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_FAtan2F_003696EC(frame, context, state, 0x003696ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275D60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275D60;
    }
block_00275D60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275D60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275D60U);
        }
        {
            const uint32_t updatedAddress = 0x00275D68U - 0x2E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275D60U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275D64U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275D6CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275D74U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275D78U, 0xEE600A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275D7CU, 0xEEF40AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_00275DB4; }
        goto block_00275D88;
    }
block_00275D88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275D88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275D88U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275D88U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275D90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275D90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275D90;
    }
block_00275D90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275D90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275D90U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275D90U, 0xEE380A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
        }
        goto block_00275DE0;
    }
block_00275DB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275DB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275DB4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xD6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275DB4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275DBCU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275DC0U, 0xEE600A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275DC4U, 0xEEF40AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00275DE0; }
        goto block_00275DD4;
    }
block_00275DD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275DD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275DD4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275DD4U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275DDCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275DDCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275DDC;
    }
block_00275DDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275DDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275DDCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275DDCU, 0xEE380A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        goto block_00275DE0;
    }
block_00275DE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275DE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275DE0U);
        }
        {
            const uint32_t address = r13 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275DE0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275DE4U, 0xEE490AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00275DE8U, address);
            }
        }
        goto block_00275DEC;
    }
block_00275DEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275DECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275DECU);
        }
        {
            const uint32_t updatedAddress = 0x00275DF4U - 0x370U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275DECU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[21];
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275DF4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xD0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275DFCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0xCEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E00U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            const uint32_t operand = 0x0000012CU;
            r1 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275E0CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275E10U, 0xEE600A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275E1CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275E20U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275E28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275E28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275E28;
    }
block_00275E28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275E28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275E28U);
        }
        {
            const uint32_t updatedAddress = 0x00275E30U - 0x3ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E28U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E2CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E34U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275E3CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275E40U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 280U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275E44U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xD0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E48U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275E50U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275E54U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 276U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275E58U, address);
            }
        }
        goto block_00275E5C;
    }
block_00275E5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275E5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275E5CU);
        }
        {
            const uint32_t address = r7 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E5CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 300U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E60U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00275E6CU + 848U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E64U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275E6CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275E70U, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E74U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 304U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E78U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275E7CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275E80U, address);
            }
        }
        {
            const uint32_t address = r7 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E84U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 308U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E88U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275E8CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275E90U, address);
            }
        }
        {
            const uint32_t address = r4 + 328U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E94U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275E98U, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275EA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275EA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275EA4;
    }
block_00275EA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275EA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275EA4U);
        }
        {
        }
        {
        }
        goto block_00275EC8;
    }
block_00275EB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275EB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275EB0U);
        }
        {
            r3 = r0 & 0x00000001U;
        }
        {
            const uint32_t address = r4 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275EB4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000054U;
            r1 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275EC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003381e4_003381E4(frame, context, state, 0x003381E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275EC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275EC8;
    }
block_00275EC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275EC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275EC8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275EC8U, address);
            }
            r7 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00275F34; }
        goto block_00275ED4;
    }
block_00275ED4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275ED4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275ED4U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x94U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275ED4U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00000020U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275EDCU, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275EE4U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r7);
        }
        {
            r0 = Oot3dAotAsr(r0, 1U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x12U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275EF4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00275EF8U, address);
            }
        }
        {
            const uint32_t operand = r2;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275F08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275F08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275F08;
    }
block_00275F08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275F08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275F08U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275F08U, address);
            }
            r2 = value;
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r7 + r2);
        }
        {
            const uint32_t updatedAddress = r13 + 0x6AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275F10U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x60U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275F14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275F18U, address);
            }
        }
        {
            const uint32_t address = r13 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275F1CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275F20U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275F24U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275F2CU, address);
            }
        }
        goto block_00276090;
    }
block_00275F34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275F34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275F34U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x00275F34U, address);
            }
        }
        {
            const uint32_t address = r4 + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275F38U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[22];
        }
        {
            const uint32_t address = r4 + 292U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275F40U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275F44U, 0xEE881A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275F48U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275F50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275F50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275F50;
    }
block_00275F50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275F50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275F50U);
        }
        {
            const uint32_t address = r4 + 292U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275F50U, address);
            }
        }
        {
            r2 = r10;
        }
        {
            r1 = r8;
        }
        {
            const uint32_t operand = 0x00000064U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00275F64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00275F64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00275F64;
    }
block_00275F64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275F64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275F64U);
        }
        {
            const uint32_t address = r4 + 292U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275F64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00275F68U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275F6CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x5AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275F70U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t value = r0 & 0x00000040U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r5 + 0x12U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275F78U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (flags.Z()) { goto block_00275FC0; }
        goto block_00275F80;
    }
block_00275F80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275F80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275F80U);
        }
        {
            const uint32_t operand = r1;
            r2 = r0 - operand;
        }
        {
            const uint32_t address = 0x00275F8CU + 564U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275F84U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            frame.Guest.vfp[1] = r2;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r2 = operand - r2;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275F9CU, 0xEEB81AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275FA4U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275FA8U, 0xEEBD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r3 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r3, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r12 = value;
        }
        if ((flags.N()) != (flags.V())) { goto block_00275FF8; }
        goto block_00275FB8;
    }
block_00275FB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275FB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275FB8U);
        }
        {
            const uint32_t operand = r12;
            r0 = r1 + operand;
        }
        goto block_00275FF8;
    }
block_00275FC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275FC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275FC0U);
        }
        {
            const uint32_t operand = r1;
            r2 = r0 - operand;
        }
        {
            const uint32_t address = 0x00275FCCU + 504U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275FC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            frame.Guest.vfp[1] = r2;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r2 = operand - r2;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275FDCU, 0xEEB81AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275FE4U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00275FE8U, 0xEEBD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r3 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r3, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r12 = value;
        }
        if ((flags.N()) == (flags.V())) { goto block_00275FB8; }
        goto block_00275FF8;
    }
block_00275FF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00275FF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00275FF8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x6AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00275FF8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00275FFCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x14U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276004U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (flags.Z()) { goto block_0027601C; }
        goto block_0027600C;
    }
block_0027600C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027600CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027600CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x14U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027600CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276010U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        goto block_0027601C;
    }
block_0027601C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027601CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027601CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x58U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027601CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r4 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276020U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = r1;
            r2 = r0 - operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276028U, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            frame.Guest.vfp[1] = r2;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r2 = operand - r2;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276040U, 0xEEB81AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276048U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027604CU, 0xEEBD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r3 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r3, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t operand = r3;
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00276064U - 0x5E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027605CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00276064U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276068U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276070U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = r2;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027607CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0xD8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276080U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = r1;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027608CU, address);
            }
        }
        goto block_00276090;
    }
block_00276090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00276090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00276090U);
        }
        {
            const uint32_t operand = 0x00000064U;
            r1 = r13 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027609CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_AddVecGeoToVec3f_00372448(frame, context, state, 0x00372448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027609CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027609C;
    }
block_0027609C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027609CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027609CU);
        }
        {
            const uint32_t address = r10 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0027609CU, address);
            }
        }
        {
            const uint32_t address = r10 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002760A0U, address);
            }
        }
        {
            const uint32_t address = r10 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002760A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x88U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002760A8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00276224; }
        goto block_002760B4;
    }
block_002760B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002760B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002760B4U);
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002760B4U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002760B4U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002760B4U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t operand = 0x0000002CU;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = 0x002760C4U + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002760BCU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002760C0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002760C0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002760C0U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002760C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A5U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002760CCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002760E4; }
        goto block_002760D8;
    }
block_002760D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002760D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002760D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002760D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000010U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_002761D8; }
        goto block_002760E4;
    }
block_002760E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002760E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002760E4U);
        }
        {
            const uint32_t operand = 0x0000002CU;
            r2 = r13 + operand;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002760F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_BGCheckInfo_003553FC(frame, context, state, 0x003553FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002760F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002760F4;
    }
block_002760F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002760F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002760F4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00276198; }
        goto block_00276104;
    }
block_00276104:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00276104U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00276104U);
        }
        {
            const uint32_t address = r13 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276104U, address);
            }
            frame.Guest.vfp[6] = value;
        }
        {
            const uint32_t address = r8 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276108U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027610CU, address);
            }
            frame.Guest.vfp[7] = value;
        }
        {
            const uint32_t address = r13 + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276110U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276114U, 0xEE332A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[6], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276118U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x00276124U + 0xA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027611CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00276128U + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276120U, address);
            }
            frame.Guest.vfp[9] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276124U, 0xEE331AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[7], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276128U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027612CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276130U, 0xEE721AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276138U, 0xEE220A02U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[4], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[1] = frame.Guest.vfp[9];
        }
        if (flags.Z()) {
            const uint32_t address = 0x00276148U + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276140U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276144U, 0xEE010A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276148U, 0xEE010AA1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027614CU, 0xEEB10AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[8] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276154U, 0xEEB44AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[8], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00276198; }
        goto block_00276160;
    }
block_00276160:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00276160U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00276160U);
        }
        {
            frame.Guest.vfp[8] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276164U, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276168U, 0xEE222A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[4], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027616CU, 0xEE211A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276170U, 0xEE210A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276174U, 0xEEC40A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[8], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276178U, 0xEE780A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[16], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027617CU, 0xEE600AA4U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[9], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276180U, 0xEE023A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[6], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[6], frame.Guest.vfp[4], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276184U, 0xEE413A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[7], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[7], frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276188U, 0xEE402A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[6])) {
                return Oot3dAotMemoryFault(context, 0x0027618CU, address);
            }
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[7])) {
                return Oot3dAotMemoryFault(context, 0x00276190U, address);
            }
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[5])) {
                return Oot3dAotMemoryFault(context, 0x00276194U, address);
            }
        }
        goto block_00276198;
    }
block_00276198:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00276198U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00276198U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[21];
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002761A0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x0000002CU;
            r0 = r13 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002761B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002761B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002761B0;
    }
block_002761B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002761B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002761B0U);
        }
        {
        }
        {
        }
        goto block_00276224;
    }
block_002761D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002761D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002761D8U);
        }
        {
            const uint32_t operand = 0x0000002CU;
            r2 = r13 + operand;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002761E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00331ae8_00331AE8(frame, context, state, 0x00331AE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002761E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002761E8;
    }
block_002761E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002761E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002761E8U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[21];
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002761F0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x0000002CU;
            r0 = r13 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00276200U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00276200U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00276200;
    }
block_00276200:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00276200U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00276200U);
        }
        {
            const uint32_t operand = 0x00000080U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000064U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00276210U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00276210U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00276210;
    }
block_00276210:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00276210U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00276210U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276210U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x7CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00276214U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x6AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276218U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x7EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027621CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x00276220U, address);
            }
        }
        goto block_00276224;
    }
block_00276224:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00276224U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00276224U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r4 + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276228U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r4 + 324U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027622CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276230U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00276238U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00276238U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00276238;
    }
block_00276238:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00276238U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00276238U);
        }
        {
            const uint32_t address = r4 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00276238U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027623CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r1;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            r0 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276264U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00276268U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027626CU, 0xEEBD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t operand = r2;
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027627CU, address);
            }
        }
        {
            r0 = r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t address = r0 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00276288U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.Z())) {
            const uint32_t address = r0 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027628CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00276298U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_ClampLERPScale_003375BC(frame, context, state, 0x003375BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00276298U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00276298;
    }
block_00276298:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00276298U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00276298U);
        }
        {
            const uint32_t address = r4 + 328U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00276298U, address);
            }
        }
        {
            const uint32_t operand = 0x00000074U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002762A0U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002762A0U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002762A0U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002762A0U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002762A0U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002762A0U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002762A0U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002762A0U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002762A4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002762A4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002762A4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002762A4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002762A4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002762A4U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002762A4U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002762A4U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002762A4U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_00331440_00331440(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r12 = state.R[12];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00331440U:
        goto block_00331440;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00331440:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00331440U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00331440U);
        }
        {
            const uint32_t operand = r1;
            r3 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r3, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            frame.Guest.vfp[1] = r3;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r3 = operand - r3;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00331458U, 0xEEB81AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00331464U + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033145CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00331460U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00331464U, 0xEEBD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r12 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r12, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r12 = value;
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t operand = r12;
            r0 = r1 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_00337624_00337624(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00337624U:
        goto block_00337624;
    case 0x00337668U:
        goto block_00337668;
    case 0x00337670U:
        goto block_00337670;
    case 0x0033767CU:
        goto block_0033767C;
    case 0x00337688U:
        goto block_00337688;
    case 0x00337690U:
        goto block_00337690;
    case 0x0033769CU:
        goto block_0033769C;
    case 0x003376A8U:
        goto block_003376A8;
    case 0x003376B0U:
        goto block_003376B0;
    case 0x003376BCU:
        goto block_003376BC;
    case 0x00337704U:
        goto block_00337704;
    case 0x00337710U:
        goto block_00337710;
    case 0x00337730U:
        goto block_00337730;
    case 0x00337754U:
        goto block_00337754;
    case 0x00337760U:
        goto block_00337760;
    case 0x0033776CU:
        goto block_0033776C;
    case 0x0033779CU:
        goto block_0033779C;
    case 0x003377A8U:
        goto block_003377A8;
    case 0x003377BCU:
        goto block_003377BC;
    case 0x003377C0U:
        goto block_003377C0;
    case 0x003377D4U:
        goto block_003377D4;
    case 0x003377E0U:
        goto block_003377E0;
    case 0x003377F4U:
        goto block_003377F4;
    case 0x00337808U:
        goto block_00337808;
    case 0x00337818U:
        goto block_00337818;
    case 0x00337820U:
        goto block_00337820;
    case 0x0033782CU:
        goto block_0033782C;
    case 0x0033783CU:
        goto block_0033783C;
    case 0x00337848U:
        goto block_00337848;
    case 0x0033784CU:
        goto block_0033784C;
    case 0x0033786CU:
        goto block_0033786C;
    case 0x00337878U:
        goto block_00337878;
    case 0x0033787CU:
        goto block_0033787C;
    case 0x003378A0U:
        goto block_003378A0;
    case 0x0033790CU:
        goto block_0033790C;
    case 0x0033791CU:
        goto block_0033791C;
    case 0x00337920U:
        goto block_00337920;
    case 0x0033796CU:
        goto block_0033796C;
    case 0x00337980U:
        goto block_00337980;
    case 0x003379A4U:
        goto block_003379A4;
    case 0x003379C0U:
        goto block_003379C0;
    case 0x003379CCU:
        goto block_003379CC;
    case 0x00337A08U:
        goto block_00337A08;
    case 0x00337A2CU:
        goto block_00337A2C;
    case 0x00337A48U:
        goto block_00337A48;
    case 0x00337A54U:
        goto block_00337A54;
    case 0x00337AB4U:
        goto block_00337AB4;
    case 0x00337AC8U:
        goto block_00337AC8;
    case 0x00337AD4U:
        goto block_00337AD4;
    case 0x00337AE4U:
        goto block_00337AE4;
    case 0x00337AFCU:
        goto block_00337AFC;
    case 0x00337B10U:
        goto block_00337B10;
    case 0x00337B28U:
        goto block_00337B28;
    case 0x00337B30U:
        goto block_00337B30;
    case 0x00337B54U:
        goto block_00337B54;
    case 0x00337B68U:
        goto block_00337B68;
    case 0x00337B80U:
        goto block_00337B80;
    case 0x00337B88U:
        goto block_00337B88;
    case 0x00337B98U:
        goto block_00337B98;
    case 0x00337BB4U:
        goto block_00337BB4;
    case 0x00337BD4U:
        goto block_00337BD4;
    case 0x00337BE0U:
        goto block_00337BE0;
    case 0x00337C38U:
        goto block_00337C38;
    case 0x00337C58U:
        goto block_00337C58;
    case 0x00337C64U:
        goto block_00337C64;
    case 0x00337C78U:
        goto block_00337C78;
    case 0x00337C7CU:
        goto block_00337C7C;
    case 0x00337CACU:
        goto block_00337CAC;
    case 0x00337CDCU:
        goto block_00337CDC;
    case 0x00337CF0U:
        goto block_00337CF0;
    case 0x00337D0CU:
        goto block_00337D0C;
    case 0x00337D18U:
        goto block_00337D18;
    case 0x00337D24U:
        goto block_00337D24;
    case 0x00337D34U:
        goto block_00337D34;
    case 0x00337D48U:
        goto block_00337D48;
    case 0x00337D54U:
        goto block_00337D54;
    case 0x00337D58U:
        goto block_00337D58;
    case 0x00337D74U:
        goto block_00337D74;
    case 0x00337DB4U:
        goto block_00337DB4;
    case 0x00337DF4U:
        goto block_00337DF4;
    case 0x00337E10U:
        goto block_00337E10;
    case 0x00337E2CU:
        goto block_00337E2C;
    case 0x00337E54U:
        goto block_00337E54;
    case 0x00337E88U:
        goto block_00337E88;
    case 0x00337EA4U:
        goto block_00337EA4;
    case 0x00337EFCU:
        goto block_00337EFC;
    case 0x00337F20U:
        goto block_00337F20;
    case 0x00337F2CU:
        goto block_00337F2C;
    case 0x00337F38U:
        goto block_00337F38;
    case 0x00337F5CU:
        goto block_00337F5C;
    case 0x00337FB4U:
        goto block_00337FB4;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00337624:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337624U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337624U);
        }
        {
            const uint32_t firstAddress = r13 - 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00337624U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00337624U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00337624U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00337624U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00337624U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00337624U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00337624U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00337624U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00337624U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00337624U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00337624U,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00337624U,
                                           firstAddress + 44U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 48U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00337624U,
                                           firstAddress + 48U);
            }
            r13 = r13 - 52U;
        }
        {
            r4 = r3;
        }
        {
            r6 = r0;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r7 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000080U;
            r9 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000000A4U;
            r10 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00337644U + 0x5A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033763CU, address);
            }
            r8 = value;
        }
        {
            r5 = r1;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337644U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00337644U,
                                           firstAddress + 4U);
            }
        }
        {
            r13 -= 32U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00337648U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00337648U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00337648U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00337648U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x00337648U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x00337648U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x00337648U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x00337648U,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t operand = 0x00000044U;
            r13 = r13 - operand;
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[17] = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = r8 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337658U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033765CU, address);
            }
            r11 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0033767C; }
        goto block_00337668;
    }
block_00337668:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337668U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337668U);
        }
        {
            const uint32_t operand = 0x00000044U;
            r0 = r8 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337670U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337670U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337670;
    }
block_00337670:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337670U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337670U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000044U;
            r0 = r8 + operand;
        }
        {
            r0 = r0;
        }
        goto block_0033767C;
    }
block_0033767C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033767CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033767CU);
        }
        {
            const uint32_t updatedAddress = r8 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033767CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0033769C; }
        goto block_00337688;
    }
block_00337688:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337688U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337688U);
        }
        {
            const uint32_t updatedAddress = 0x00337690U + 0x55CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337688U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337690U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337690U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337690;
    }
block_00337690:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337690U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337690U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x0033769CU + 0x550U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337694U, address);
            }
            r0 = value;
        }
        {
            r0 = r0;
        }
        goto block_0033769C;
    }
block_0033769C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033769CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033769CU);
        }
        {
            const uint32_t updatedAddress = r8 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033769CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003376BC; }
        goto block_003376A8;
    }
block_003376A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003376A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003376A8U);
        }
        {
            const uint32_t updatedAddress = 0x003376B0U + 0x540U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003376A8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003376B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003376B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003376B0;
    }
block_003376B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003376B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003376B0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x003376BCU + 0x534U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003376B4U, address);
            }
            r0 = value;
        }
        {
            r0 = r0;
        }
        goto block_003376BC;
    }
block_003376BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003376BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003376BCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003376BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x000000A4U;
            r1 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003376C4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, operand, r0, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = operand - r0;
        }
        if (!(flags.C())) {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003376D0U, address);
            }
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003376D8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003376E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003376ECU + 0x508U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003376E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003376E8U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003376E8U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003376E8U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            r8 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003376F0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003376F0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x003376F0U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003376F8U, address);
            }
            r1 = value;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337704U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_BGCheckInfo_003553FC(frame, context, state, 0x003553FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337704U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337704;
    }
block_00337704:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337704U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337704U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337708U, address);
            }
        }
        if (flags.Z()) { goto block_0033784C; }
        goto block_00337710;
    }
block_00337710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337710U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337710U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0033771CU + 0x4DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337714U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00337718U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00337718U,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00337718U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0033771CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0033771CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0033771CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000028U;
            r8 = r0 - operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r8 + operand;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r8 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337730U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fToVecSphGeo_00342E8C(frame, context, state, 0x00342E8CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337730U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337730;
    }
block_00337730:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337730U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337730U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337730U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0033773CU + 0x4C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337734U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x00337740U + 0x4B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337738U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r5 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337740U, address);
            }
            r0 = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r8 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337744U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337748U, address);
            }
            r1 = value;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337754U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_BGCheckInfo_003553FC(frame, context, state, 0x003553FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337754U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337754;
    }
block_00337754:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337754U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337754U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337758U, address);
            }
        }
        if (!(flags.Z())) { goto block_003377C0; }
        goto block_00337760;
    }
block_00337760:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337760U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337760U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337760U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00337818; }
        goto block_0033776C;
    }
block_0033776C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033776CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033776CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033776CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x00337778U + 0x480U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337770U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00337774U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00337774U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00337774U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00337778U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00337778U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00337778U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337780U, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00337784U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00337784U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00337784U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0033778CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0033778CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0033778CU,
                                           firstAddress + 8U);
            }
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = 0x0033779CU + 0x45CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337794U, address);
            }
            r2 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0033779CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_BGCheckInfo_003553FC(frame, context, state, 0x003553FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0033779CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0033779C;
    }
block_0033779C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033779CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033779CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_00337818; }
        goto block_003377A8;
    }
block_003377A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003377A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003377A8U);
        }
        {
            const uint32_t updatedAddress = 0x003377B0U + 0x448U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003377A8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003377ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003377B0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00337818; }
        goto block_003377BC;
    }
block_003377BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003377BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003377BCU);
        }
        goto block_003377D4;
    }
block_003377C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003377C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003377C0U);
        }
        {
            const uint32_t updatedAddress = 0x003377C8U + 0x430U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003377C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003377C4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003377C8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00337818; }
        goto block_003377D4;
    }
block_003377D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003377D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003377D4U);
        }
        {
            const uint32_t updatedAddress = 0x003377DCU + 0x424U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003377D4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r1 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003377E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fToVecSphGeo_00342E8C(frame, context, state, 0x00342E8CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003377E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003377E0;
    }
block_003377E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003377E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003377E0U);
        }
        {
            const uint32_t updatedAddress = 0x003377E8U + 0x410U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003377E0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003377ECU + 0x410U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003377E4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003377E8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00337808; }
        goto block_003377F4;
    }
block_003377F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003377F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003377F4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003377F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00337800U + 0x3F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003377F8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00007F00U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337804U, address);
            }
        }
        goto block_00337808;
    }
block_00337808:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337808U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337808U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337808U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033780CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00337820; }
        goto block_00337818;
    }
block_00337818:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337818U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337818U);
        }
        {
            r8 = 0x00000003U;
        }
        goto block_0033784C;
    }
block_00337820:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337820U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337820U);
        }
        {
            const uint32_t updatedAddress = 0x00337828U + 0x3D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337820U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r8 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0033782CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00340404_00340404(frame, context, state, 0x00340404U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0033782CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0033782C;
    }
block_0033782C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033782CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033782CU);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0xBF000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) {
            r8 = 0x00000006U;
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0033784C; }
        goto block_0033783C;
    }
block_0033783C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033783CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033783CU);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00337818; }
        goto block_00337848;
    }
block_00337848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337848U);
        }
        {
            r8 = 0x00000002U;
        }
        goto block_0033784C;
    }
block_0033784C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033784CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033784CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = 0x00337858U + 940U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337850U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x0033785CU + 940U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337854U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x00337860U + 940U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337858U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x00337864U + 940U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033785CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x00337868U + 940U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337860U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0033787C; }
        goto block_0033786C;
    }
block_0033786C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033786CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033786CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000006U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00337F2C; }
        goto block_00337878;
    }
block_00337878:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337878U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337878U);
        }
        goto block_00337B10;
    }
block_0033787C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033787CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033787CU);
        }
        {
            const uint32_t updatedAddress = 0x00337884U + 0x374U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033787CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r3 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00337884U, address);
            }
        }
        {
            const uint32_t operand = 0x00000028U;
            r8 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033788CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337890U, address);
            }
            r0 = value;
        }
        {
            r3 = r10;
        }
        {
            r2 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003378A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003a2f84_003A2F84(frame, context, state, 0x003A2F84U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003378A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003378A0;
    }
block_003378A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003378A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003378A0U);
        }
        {
            const uint32_t address = r13 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003378A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003378A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003378A8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r4 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003378ACU, address);
            }
        }
        {
            const uint32_t address = r4 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003378B0U, address);
            }
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x003378B4U, address);
            }
        }
        {
            const uint32_t address = r8 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003378B8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000000U;
            r1 = r8 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003378C4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003378C8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003378CCU, 0xEE000A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003378D0U, address);
            }
        }
        {
            const uint32_t address = r4 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003378D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r8 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003378D8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003378DCU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003378E0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003378E4U, 0xEE000A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003378E8U, address);
            }
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003378ECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r8 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003378F0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003378F4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003378F8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r0 = r9;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337900U, 0xEE000A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337904U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0033790CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Vec3f_DistXYZ_00338A90(frame, context, state, 0x00338A90U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0033790CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0033790C;
    }
block_0033790C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033790CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033790CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0033790CU, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00337920; }
        goto block_0033791C;
    }
block_0033791C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033791CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033791CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0033791CU, 0xEE800A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        goto block_00337920;
    }
block_00337920:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337920U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337920U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337920U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000038U;
            r2 = r13 + operand;
        }
        {
            r1 = r9;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0033792CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00337938U + 0x2E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337930U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337934U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033793CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = 0x00000001U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337948U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0033794CU, 0xEE200A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337950U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337954U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00337960U + 0x298U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337958U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033795CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337960U, address);
            }
        }
        {
            const uint32_t operand = 0x00000030U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0033796CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0033796CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0033796C;
    }
block_0033796C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033796CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033796CU);
        }
        {
            const uint32_t address = r5 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033796CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r1 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337974U, address);
            }
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337980U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_AddVecGeoToVec3f_00372448(frame, context, state, 0x00372448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337980U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337980;
    }
block_00337980:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337980U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337980U);
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337980U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00337988U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0033798CU, address);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[23];
        }
        {
            r1 = r7;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r13 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003379A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003379A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003379A4;
    }
block_003379A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003379A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003379A4U);
        }
        {
            const uint32_t updatedAddress = 0x003379ACU + 0x270U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003379A4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003379A8U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003379A8U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003379A8U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003379ACU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003379ACU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003379ACU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r2 = r0 + operand;
        }
        {
            r1 = r9;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003379C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_BGCheckInfo_003553FC(frame, context, state, 0x003553FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003379C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003379C0;
    }
block_003379C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003379C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003379C0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00337AE4; }
        goto block_003379CC;
    }
block_003379CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003379CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003379CCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003379CCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003379D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r0;
            r1 = r1 - operand;
        }
        {
            r1 = Oot3dAotLsl(r1, 16U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 17U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003379E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003379E4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003379E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r0;
            r1 = r1 - operand;
        }
        {
            r1 = Oot3dAotLsl(r1, 16U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 17U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003379F8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000030U;
            r1 = r13 + operand;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337A08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_AddVecGeoToVec3f_00372448(frame, context, state, 0x00372448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337A08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337A08;
    }
block_00337A08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337A08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337A08U);
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337A08U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00337A10U, address);
            }
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00337A14U, address);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[23];
        }
        {
            r1 = r7;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r13 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337A2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337A2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337A2C;
    }
block_00337A2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337A2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337A2CU);
        }
        {
            const uint32_t updatedAddress = r8 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A2CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x00337A38U + 0x1E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A30U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r13 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A38U, address);
            }
            r0 = value;
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r4 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337A3CU, address);
            }
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A40U, address);
            }
            r0 = value;
        }
        if ((flags.N()) != (flags.V())) { goto block_00337A54; }
        goto block_00337A48;
    }
block_00337A48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337A48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337A48U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A48U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337A4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A50U, address);
            }
            r0 = value;
        }
        goto block_00337A54;
    }
block_00337A54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337A54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337A54U);
        }
        {
            const uint32_t operand = 0x00000038U;
            r2 = r13 + operand;
        }
        {
            r1 = r9;
        }
        {
            const uint32_t updatedAddress = r4 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337A5CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00337A68U + 0x190U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A60U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r8 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337A6CU, 0xEE000A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A70U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337A74U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337A78U, address);
            }
        }
        {
            const uint32_t address = r8 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A7CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A80U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337A84U, 0xEE000A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A88U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337A8CU, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337A90U, address);
            }
        }
        {
            const uint32_t address = r8 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A94U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337A98U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337AA0U, 0xEE000A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337AA4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337AA8U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337AACU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337AB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337AB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337AB4;
    }
block_00337AB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337AB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337AB4U);
        }
        {
            const uint32_t address = r5 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337AB4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r1 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337ABCU, address);
            }
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337AC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_AddVecGeoToVec3f_00372448(frame, context, state, 0x00372448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337AC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337AC8;
    }
block_00337AC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337AC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337AC8U);
        }
        {
            const uint32_t address = r10 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337AC8U, address);
            }
        }
        {
            const uint32_t address = r10 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00337ACCU, address);
            }
        }
        {
            const uint32_t address = r10 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00337AD0U, address);
            }
        }
        goto block_00337AD4;
    }
block_00337AD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337AD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337AD4U);
        }
        {
            const uint32_t operand = 0x00000044U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00337AD8U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00337AD8U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00337AD8U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00337AD8U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00337AD8U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00337AD8U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00337AD8U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00337AD8U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            const uint32_t operand = 0x00000018U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00337AE0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00337AE0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00337AE0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00337AE0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00337AE0U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00337AE0U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00337AE0U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00337AE0U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00337AE0U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_00337AE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337AE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337AE4U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[23];
        }
        {
            const uint32_t updatedAddress = 0x00337AF4U + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337AECU, address);
            }
            r0 = value;
        }
        {
            r1 = r7;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337AFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337AFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337AFC;
    }
block_00337AFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337AFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337AFCU);
        }
        {
            const uint32_t updatedAddress = 0x00337B04U + 0x118U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337AFCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00337B00U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00337B00U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00337B00U,
                                           firstAddress + 8U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00337B00U,
                                           firstAddress + 12U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x00337B00U,
                                           firstAddress + 16U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
            r14 = value14;
            r0 = r0 + 20U;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00337B04U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00337B04U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00337B04U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00337B04U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00337B04U,
                                           firstAddress + 16U);
            }
            r8 = r8 + 20U;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00337B08U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00337B08U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00337B08U,
                                           firstAddress + 8U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00337B08U,
                                           firstAddress + 12U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x00337B08U,
                                           firstAddress + 16U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
            r14 = value14;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00337B0CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00337B0CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00337B0CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00337B0CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00337B0CU,
                                           firstAddress + 16U);
            }
        }
        goto block_00337B10;
    }
block_00337B10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337B10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337B10U);
        }
        {
            const uint32_t updatedAddress = 0x00337B18U + 0xDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B10U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = 0x00337B1CU + 0x108U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B14U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r8 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B18U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_00337BD4; }
        goto block_00337B28;
    }
block_00337B28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337B28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337B28U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B28U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337B30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_GetHeight_00367EF0(frame, context, state, 0x00367EF0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337B30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337B30;
    }
block_00337B30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337B30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337B30U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B30U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B34U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000104U;
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B3CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r1 + r2;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B40U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337B48U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00337B68; }
        goto block_00337B54;
    }
block_00337B54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337B54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337B54U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x00337B60U + 0xC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B58U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + r2;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B5CU, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_00337B80; }
        goto block_00337B68;
    }
block_00337B68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337B68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337B68U);
        }
        {
            const uint32_t address = 0x00337B70U + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337B6CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B70U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337B74U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000001U;
        }
        goto block_00337B80;
    }
block_00337B80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337B80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337B80U);
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r11, 0U, 0U, flags.C());
            r0 = r0 | shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00337BD4; }
        goto block_00337B88;
    }
block_00337B88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337B88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337B88U);
        }
        {
            const uint32_t updatedAddress = 0x00337B90U + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B88U, address);
            }
            r2 = value;
        }
        {
            r1 = r9;
        }
        {
            const uint32_t operand = 0x00000030U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337B98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337B98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337B98;
    }
block_00337B98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337B98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337B98U);
        }
        {
            const uint32_t updatedAddress = 0x00337BA0U + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337B9CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r1 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337BA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337BA8U, address);
            }
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337BB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_AddVecGeoToVec3f_00372448(frame, context, state, 0x00372448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337BB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337BB4;
    }
block_00337BB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337BB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337BB4U);
        }
        {
            const uint32_t updatedAddress = 0x00337BBCU + 0x78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337BB4U, address);
            }
            r0 = value;
        }
        {
            r1 = r9;
        }
        {
            const uint32_t operand = 0x00000028U;
            r2 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337BC0U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00337BC4U, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00337BC8U, address);
            }
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337BD4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_BGCheckInfo_003553FC(frame, context, state, 0x003553FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337BD4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337BD4;
    }
block_00337BD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337BD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337BD4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337BD4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00337C58; }
        goto block_00337BE0;
    }
block_00337BE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337BE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337BE0U);
        }
        {
            const uint32_t updatedAddress = 0x00337BE8U + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337BE0U, address);
            }
            r0 = value;
        }
        goto block_00337C38;
    }
block_00337C38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337C38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337C38U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337C38U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xFCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337C44U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337C48U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00337C4CU, address);
            }
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00337C50U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00337C50U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00337C50U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r10;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00337C54U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00337C54U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00337C54U,
                                           firstAddress + 8U);
            }
        }
        goto block_00337C58;
    }
block_00337C58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337C58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337C58U);
        }
        {
            r0 = r9;
        }
        {
            const uint32_t updatedAddress = 0x00337C64U - 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337C5CU, address);
            }
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337C64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Vec3f_DistXYZ_00338A90(frame, context, state, 0x00338A90U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337C64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337C64;
    }
block_00337C64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337C64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337C64U);
        }
        {
            frame.Guest.vfp[21] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337C68U, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00337C7C; }
        goto block_00337C78;
    }
block_00337C78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337C78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337C78U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337C78U, 0xEE8A0A88U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[21], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        goto block_00337C7C;
    }
block_00337C7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337C7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337C7CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337C7CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337C80U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337C84U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = 0x00337C90U + 0x330U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337C88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337C8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337C90U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t address = 0x00337CA0U + 804U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337C98U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x00337CA4U + 804U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337C9CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337CA0U, 0xEEF4AAC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[21], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_00337D58; }
        goto block_00337CAC;
    }
block_00337CAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337CACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337CACU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337CACU, 0xEE280A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[16], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00337CB0U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00337CB0U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00337CB0U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00337CB0U,
                                           firstAddress + 12U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00337CB0U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x00337CB0U,
                                           firstAddress + 20U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
            r14 = value14;
            r8 = r8 + 24U;
        }
        {
            r10 = r13;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r11, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t firstAddress = r10;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00337CBCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00337CBCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00337CBCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00337CBCU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00337CBCU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00337CBCU,
                                           firstAddress + 20U);
            }
            r10 = r10 + 24U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337CC0U, 0xEE0A0AEAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00337CC4U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00337CC4U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00337CC4U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00337CC4U,
                                           firstAddress + 12U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t operand = 0x00000018U;
            r8 = r8 - operand;
        }
        {
            const uint32_t firstAddress = r10;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00337CCCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00337CCCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00337CCCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00337CCCU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r10 = r10 - operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337CD4U, 0xEEB10AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (flags.Z()) { goto block_00337CF0; }
        goto block_00337CDC;
    }
block_00337CDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337CDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337CDCU);
        }
        {
            const uint32_t address = r8 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337CDCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x00337CE8U - 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337CE0U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337CECU, 0x8EB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        goto block_00337CF0;
    }
block_00337CF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337CF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337CF0U);
        }
        {
            const uint32_t address = r8 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337CF0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x00337CFCU - 0x108U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337CF4U, address);
            }
            r2 = value;
        }
        {
            r1 = r9;
        }
        {
            r0 = r6;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337D00U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337D04U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337D0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_BGCheckInfo_003553FC(frame, context, state, 0x003553FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337D0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337D0C;
    }
block_00337D0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337D0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337D0CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00337D48; }
        goto block_00337D18;
    }
block_00337D18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337D18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337D18U);
        }
        {
            const uint32_t updatedAddress = 0x00337D20U - 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337D18U, address);
            }
            r1 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337D24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Vec3f_DistXYZ_00338A90(frame, context, state, 0x00338A90U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337D24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337D24;
    }
block_00337D24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337D24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337D24U);
        }
        {
            const uint32_t updatedAddress = 0x00337D2CU + 0x2A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337D24U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00337D48; }
        goto block_00337D34;
    }
block_00337D34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337D34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337D34U);
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00337D34U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00337D34U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00337D34U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00337D34U,
                                           firstAddress + 12U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00337D34U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00337D34U,
                                           firstAddress + 20U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x00337D34U,
                                           firstAddress + 24U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r12 = value12;
            r14 = value14;
            r10 = r10 + 28U;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00337D38U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00337D38U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00337D38U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00337D38U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00337D38U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00337D38U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00337D38U,
                                           firstAddress + 24U);
            }
            r8 = r8 + 28U;
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00337D3CU,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00337D3CU,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00337D3CU,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00337D40U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00337D40U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00337D40U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r8 = r8 - operand;
        }
        goto block_00337D48;
    }
block_00337D48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337D48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337D48U);
        }
        {
            const uint32_t updatedAddress = 0x00337D50U - 0x15CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337D48U, address);
            }
            r1 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337D54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Vec3f_DistXYZ_00338A90(frame, context, state, 0x00338A90U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337D54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337D54;
    }
block_00337D54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337D54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337D54U);
        }
        {
            frame.Guest.vfp[21] = frame.Guest.vfp[0];
        }
        goto block_00337D58;
    }
block_00337D58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337D58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337D58U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337D58U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337D60U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t value = r0 & 0x00004000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00004000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00337D68U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00337D68U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00337D68U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        if (!(flags.Z())) {
            const uint32_t firstAddress = r7;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00337D6CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00337D6CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00337D6CU,
                                           firstAddress + 8U);
            }
        }
        if (!(flags.Z())) { goto block_00337E54; }
        goto block_00337D74;
    }
block_00337D74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337D74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337D74U);
        }
        {
            const uint32_t address = r9 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337D74U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r8 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337D78U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r8 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337D7CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r9 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337D80U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337D84U, 0xEE303A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[6], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r9 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337D88U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r8 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337D8CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x00337D98U + 568U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337D90U, address);
            }
            frame.Guest.vfp[7] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337D94U, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337D98U, 0xEE322A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[4], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337D9CU, 0xEE632A03U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[6], frame.Guest.vfp[6], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DA0U, 0xEE402A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DA4U, 0xEE422A02U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[5], frame.Guest.vfp[4], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DA8U, 0xEEF42A63U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[5], frame.Guest.vfp[7],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_00337E2C; }
        goto block_00337DB4;
    }
block_00337DB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337DB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337DB4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DB4U, 0xEEF12AE2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337DB8U, address);
            }
            frame.Guest.vfp[9] = value;
        }
        {
            const uint32_t updatedAddress = 0x00337DC4U + 0x210U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337DBCU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DC0U, 0xEECA2A22U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[20], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DC4U, 0xEE234A22U};
            Oot3dAotCommitVfp(frame.Guest.vfp[8], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[6], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DC8U, 0xEE603A22U};
            Oot3dAotCommitVfp(frame.Guest.vfp[7], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DCCU, 0xEE223A22U};
            Oot3dAotCommitVfp(frame.Guest.vfp[6], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[4], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337DD0U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            const uint32_t address = r8 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337DD4U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DD8U, 0xEE240A22U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[8], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DDCU, 0xEE030AA4U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[7], frame.Guest.vfp[9], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DE0U, 0xEE030A02U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[6], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_00337E10; }
        goto block_00337DF4;
    }
block_00337DF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337DF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337DF4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DF4U, 0xEE420A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DF8U, 0xEE041A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[9], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337DFCU, 0xEE421A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[4], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00337E00U, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00337E04U, address);
            }
        }
        {
            const uint32_t address = r7 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x00337E08U, address);
            }
        }
        goto block_00337E54;
    }
block_00337E10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337E10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337E10U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337E10U, 0xEE440A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[8], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337E14U, 0xEE031A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[7], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337E18U, 0xEE431A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[6], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00337E1CU, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00337E20U, address);
            }
        }
        {
            const uint32_t address = r7 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x00337E24U, address);
            }
        }
        goto block_00337E54;
    }
block_00337E2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337E2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337E2CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r8 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337E30U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337E34U, 0xEE420A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[4], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337E38U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337E3CU, 0xEE021A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[4], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337E40U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337E44U, 0xEE421A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[4], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00337E48U, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00337E4CU, address);
            }
        }
        {
            const uint32_t address = r7 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x00337E50U, address);
            }
        }
        goto block_00337E54;
    }
block_00337E54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337E54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337E54U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337E58U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00337E64U - 0x24CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337E5CU, address);
            }
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r11, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337E64U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337E6CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337E74U, 0xEEF88AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[17] = frame.Guest.vfp[16];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337E7CU, 0xEEF4AAE8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[21], frame.Guest.vfp[17],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_00337AD4; }
        goto block_00337E88;
    }
block_00337E88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337E88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337E88U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337E88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337E8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337E90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00003F00U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337EA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337EA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337EA4;
    }
block_00337EA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337EA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337EA4U);
        }
        {
            const uint32_t address = 0x00337EACU + 300U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337EA4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337EA8U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337EACU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337EB4U, 0xEE380AEAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[17], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337EB8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337EBCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337EC4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            const uint32_t updatedAddress = 0x00337ED4U + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337ECCU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337ED0U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337ED4U, 0xEE600A8BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337ED8U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337EE0U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[18] = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r13 + operand;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00337EF4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337EFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_AddVecGeoToVec3f_00372448(frame, context, state, 0x00372448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337EFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337EFC;
    }
block_00337EFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337EFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337EFCU);
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337EFCU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00337F04U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00337F08U, address);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[23];
        }
        {
            r1 = r7;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r13 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337F20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337F20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337F20;
    }
block_00337F20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337F20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337F20U);
        }
        {
        }
        {
        }
        goto block_00337AD4;
    }
block_00337F2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337F2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337F2CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337F2CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00337F5C; }
        goto block_00337F38;
    }
block_00337F38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337F38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337F38U);
        }
        {
            const uint32_t updatedAddress = 0x00337F40U - 0x328U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337F38U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337F3CU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xFCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337F48U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00337F4CU, address);
            }
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00337F50U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00337F50U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00337F50U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r10;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00337F54U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00337F54U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00337F54U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337F58U, address);
            }
        }
        goto block_00337F5C;
    }
block_00337F5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337F5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337F5CU);
        }
        {
            const uint32_t updatedAddress = 0x00337F64U - 0x370U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337F5CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00337F60U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00337F68U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337F6CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337F70U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r1 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337F74U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r1 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337F78U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337F7CU, 0xEE000A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337F80U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337F88U, 0xEE410A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00337F8CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r1 = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00337F94U, 0xEE011A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00337F98U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00337FA0U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00337FA8U, address);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[23];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00337FB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00337FB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00337FB4;
    }
block_00337FB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00337FB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00337FB4U);
        }
        {
        }
        {
        }
        goto block_00337AD4;
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_003381e4_003381E4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003381E4U:
        goto block_003381E4;
    case 0x00338218U:
        goto block_00338218;
    case 0x00338238U:
        goto block_00338238;
    case 0x0033825CU:
        goto block_0033825C;
    case 0x00338268U:
        goto block_00338268;
    case 0x00338280U:
        goto block_00338280;
    case 0x0033828CU:
        goto block_0033828C;
    case 0x003382B8U:
        goto block_003382B8;
    case 0x003382C0U:
        goto block_003382C0;
    case 0x003382CCU:
        goto block_003382CC;
    case 0x003382E8U:
        goto block_003382E8;
    case 0x003382F0U:
        goto block_003382F0;
    case 0x003382F4U:
        goto block_003382F4;
    case 0x0033833CU:
        goto block_0033833C;
    case 0x00338384U:
        goto block_00338384;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003381E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003381E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003381E4U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x003381E4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003381E4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003381E4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x003381E4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x003381E4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x003381E4U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x003381E4U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x003381E4U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003381E4U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00000080U;
            r7 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000000DCU;
            r5 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000150U;
            r11 = r0 + operand;
        }
        {
            r8 = r1;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003381FCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x003381FCU,
                                           firstAddress + 4U);
            }
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338204U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 - operand;
        }
        {
            r9 = r2;
        }
        {
            r10 = r3;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00338218U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_GetHeight_00367EF0(frame, context, state, 0x00367EF0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00338218U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00338218;
    }
block_00338218:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00338218U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00338218U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00338218U, 0xEE300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00338224U + 368U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033821CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x00338228U + 0x170U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338220U, address);
            }
            r6 = value;
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00338224U, address);
            }
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00338228U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r10, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00338230U, address);
            }
        }
        if (flags.Z()) { goto block_00338268; }
        goto block_00338238;
    }
block_00338238:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00338238U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00338238U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338238U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033823CU, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r5 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338240U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338248U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = r11;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00338254U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0033825CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_CalcSlopeYAdj_00367E88(frame, context, state, 0x00367E88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0033825CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0033825C;
    }
block_0033825C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033825CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033825CU);
        }
        {
            const uint32_t address = r13 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033825CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00338260U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00338264U, address);
            }
        }
        goto block_00338268;
    }
block_00338268:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00338268U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00338268U);
        }
        {
            const uint32_t address = r5 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338268U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r9 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033826CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r4 + operand;
        }
        {
            r0 = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00338278U, 0xEE708A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00338280U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDistXZ_00367E60(frame, context, state, 0x00367E60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00338280U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00338280;
    }
block_00338280:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00338280U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00338280U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0033828CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_FAtan2F_003696EC(frame, context, state, 0x003696ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0033828CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0033828C;
    }
block_0033828C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033828CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033828CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033828CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00338298U + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338290U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0033829CU + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338294U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033829CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003382A4U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003382A8U, 0xEE600A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003382ACU, 0xEEF40AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_003382CC; }
        goto block_003382B8;
    }
block_003382B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003382B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003382B8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003382B8U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003382C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003382C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003382C0;
    }
block_003382C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003382C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003382C0U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003382C0U, 0xEE388A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
        }
        goto block_003382F4;
    }
block_003382CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003382CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003382CCU);
        }
        {
            const uint32_t updatedAddress = r0 + 0xD6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003382CCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003382D4U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003382D8U, 0xEE600A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003382DCU, 0xEEF40AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003382F4; }
        goto block_003382E8;
    }
block_003382E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003382E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003382E8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003382E8U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003382F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003382F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003382F0;
    }
block_003382F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003382F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003382F0U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003382F0U, 0xEE388A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        goto block_003382F4;
    }
block_003382F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003382F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003382F4U);
        }
        {
            const uint32_t address = r13 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003382F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003382F8U, 0xEE080AC8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003382FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338300U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xD0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338308U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0xCEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033830CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            const uint32_t operand = 0x0000012CU;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00338320U, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00338324U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00338330U + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338328U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0033832CU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00338330U, 0xEE210A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0033833CU + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338334U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0033833CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0033833CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0033833C;
    }
block_0033833C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033833CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033833CU);
        }
        {
            const uint32_t address = r5 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033833CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 300U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338340U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0033834CU + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338344U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r1 = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0033834CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00338354U, address);
            }
        }
        {
            const uint32_t address = r5 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338358U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 304U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033835CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00338360U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00338364U, address);
            }
        }
        {
            const uint32_t address = r5 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338368U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 308U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033836CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00338370U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00338374U, address);
            }
        }
        {
            const uint32_t address = r4 + 328U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338378U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00338384U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilVec3f_00367DF4(frame, context, state, 0x00367DF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00338384U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00338384;
    }
block_00338384:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00338384U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00338384U);
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0033838CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0033838CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00338390U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00338390U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00338390U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00338390U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00338390U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00338390U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00338390U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00338390U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00338390U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Camera_BGCheckInfo_003553FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003553FCU:
        goto block_003553FC;
    case 0x00355420U:
        goto block_00355420;
    case 0x00355424U:
        goto block_00355424;
    case 0x0035543CU:
        goto block_0035543C;
    case 0x00355478U:
        goto block_00355478;
    case 0x00355484U:
        goto block_00355484;
    case 0x0035548CU:
        goto block_0035548C;
    case 0x00355498U:
        goto block_00355498;
    case 0x003554C4U:
        goto block_003554C4;
    case 0x003554E0U:
        goto block_003554E0;
    case 0x003554F8U:
        goto block_003554F8;
    case 0x00355510U:
        goto block_00355510;
    case 0x00355530U:
        goto block_00355530;
    case 0x0035554CU:
        goto block_0035554C;
    case 0x0035555CU:
        goto block_0035555C;
    case 0x003555A8U:
        goto block_003555A8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003553FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003553FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003553FCU);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x003553FCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003553FCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003553FCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003553FCU,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            const uint32_t operand = 0x00000040U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00355404U, address);
            }
            r0 = value;
        }
        {
            r6 = r1;
        }
        {
            r4 = r2;
        }
        {
            const uint32_t operand = 0x00000800U;
            r5 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00355420U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_OLib_Vec3fDiffToVecSphGeo_00372474(frame, context, state, 0x00372474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00355420U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00355420;
    }
block_00355420:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00355420U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00355420U);
        }
        {
            const uint32_t address = r13 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00355420U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_00355424;
    }
block_00355424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00355424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00355424U);
        }
        {
            const uint32_t address = 0x0035542CU + 408U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00355424U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000018U;
            r1 = r13 + operand;
        }
        {
            r0 = r6;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00355430U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00355434U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035543CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_AddVecGeoToVec3f_00372448(frame, context, state, 0x00372448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035543CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035543C;
    }
block_0035543C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035543CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035543CU);
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0035543CU, address);
            }
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00355440U, address);
            }
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00355444U, address);
            }
        }
        {
            const uint32_t operand = 0x00000024U;
            r3 = r4 + operand;
        }
        {
            r2 = ~(0x00000000U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00355454U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00355458U, address);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00355460U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00355464U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00355468U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0035546CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000034U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000028U;
            r2 = r13 + operand;
        }
        goto block_00355478;
    }
block_00355478:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00355478U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00355478U);
        }
        {
            r1 = r6;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00355484U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003723c0_003723C0(frame, context, state, 0x003723C0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00355484U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00355484;
    }
block_00355484:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00355484U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00355484U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0035554C; }
        goto block_0035548C;
    }
block_0035548C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035548CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035548CU);
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00355498U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00372348_00372348(frame, context, state, 0x00372348U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00355498U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00355498;
    }
block_00355498:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00355498U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00355498U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00355498U, 0xEEB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        {
            const uint32_t operand = 0x00000034U;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003554A0U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003554A4U, 0xEEB10A60U};
            frame.Guest.vfp[0] = frame.Guest.vfp[1] ^ 0x80000000U;
        }
        {
            const uint32_t address = 0x003554B0U + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003554A8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003554ACU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003554B0U, 0xEEB10A41U};
            frame.Guest.vfp[0] = frame.Guest.vfp[2] ^ 0x80000000U;
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003554B4U, address);
            }
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003554B8U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003554B8U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003554B8U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003554BCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003554BCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003554BCU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000034U;
            r3 = r13 + operand;
        }
        goto block_003554C4;
    }
block_003554C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003554C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003554C4U);
        }
        {
            const uint32_t address = r13 + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003554C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000020U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r1 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003554D0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = r5;
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003554D8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003554E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BgCheck_EntityRaycastFloor9_00372300(frame, context, state, 0x00372300U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003554E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003554E0;
    }
block_003554E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003554E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003554E0U);
        }
        {
            const uint32_t address = r4 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003554E0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x003554ECU + 0xE0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003554E4U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003554E8U, 0xEE301AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[2];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00355530; }
        goto block_003554F8;
    }
block_003554F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003554F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003554F8U);
        }
        {
            const uint32_t address = r4 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003554F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003554FCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00355504U, 0xEE300A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00355508U, address);
            }
        }
        {
            const uint32_t address = r4 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035550CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_00355510;
    }
block_00355510:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00355510U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00355510U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00355510U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00355514U, address);
            }
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00355518U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035551CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00355520U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00355524U, address);
            }
        }
        {
            const uint32_t operand = 0x00000040U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0035552CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0035552CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0035552CU,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0035552CU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_00355530:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00355530U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00355530U);
        }
        {
            const uint32_t address = 0x00355538U + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00355530U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00355534U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00355538U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r4 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0035553CU, address);
            }
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00355540U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00355544U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00355548U, address);
            }
        }
        goto block_0035554C;
    }
block_0035554C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035554CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035554CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035554CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00355558U + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00355550U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00355554U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        goto block_0035555C;
    }
block_0035555C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035555CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035555CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0035555CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00355560U, 0xEE600A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00355564U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00355568U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00355570U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00355574U, 0xEE200A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00355578U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035557CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[3] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00355584U, 0xEEF81AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00355588U, 0xEE211A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0035558CU, address);
            }
        }
        {
            const uint32_t address = r13 + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00355590U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00355594U, 0xEE710AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00355598U, address);
            }
        }
        {
            const uint32_t address = r13 + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035559CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003555A0U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003555A4U, address);
            }
        }
        goto block_003555A8;
    }
block_003555A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003555A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003555A8U);
        }
        {
            const uint32_t address = r13 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003555A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003555ACU, 0xEE300A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003555B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003555B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000040U;
            r13 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003555C0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003555C0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003555C0U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003555C0U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Camera_LERPCeilVec3f_00367DF4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00367DF4U:
        goto block_00367DF4;
    case 0x00367E24U:
        goto block_00367E24;
    case 0x00367E3CU:
        goto block_00367E3C;
    case 0x00367E54U:
        goto block_00367E54;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00367DF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367DF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367DF4U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00367DF4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00367DF4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00367DF4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00367DF4U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            r5 = r0;
        }
        {
            r4 = r1;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00367E00U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00367E00U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00367E00U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00367E00U,
                                           firstAddress + 12U);
            }
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[17] = frame.Guest.vfp[2];
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r1 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367E10U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367E14U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00367E24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00367E24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00367E24;
    }
block_00367E24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367E24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367E24U);
        }
        {
            const uint32_t address = r4 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00367E24U, address);
            }
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r4 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367E30U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367E34U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00367E3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00367E3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00367E3C;
    }
block_00367E3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367E3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367E3CU);
        }
        {
            const uint32_t address = r4 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00367E3CU, address);
            }
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367E48U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367E4CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00367E54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_LERPCeilF_00355780(frame, context, state, 0x00355780U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00367E54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00367E54;
    }
block_00367E54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367E54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367E54U);
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00367E54U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00367E58U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00367E58U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00367E58U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00367E58U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00367E5CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00367E5CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00367E5CU,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00367E5CU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Player_GetHeight_00367EF0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r4 = state.R[4];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00367EF0U:
        goto block_00367EF0;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00367EF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00367EF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00367EF0U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x710U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367EF4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00800000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00800000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = 0x00367F04U + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367EFCU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t address = 0x00367F08U + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367F00U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x00367F0CU + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367F04U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367F08U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x00367F18U + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367F10U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (flags.Z()) {
            const uint32_t address = 0x00367F1CU + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00367F14U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00367F18U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
