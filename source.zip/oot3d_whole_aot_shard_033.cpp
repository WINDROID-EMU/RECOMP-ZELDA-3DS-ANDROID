#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_EnBombf_Update_0014CAA8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_001e3ccc_001E3CCC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnItem00_Update_0022B71C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnFish_Update_0022E520(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_sin_idx8_002CFCA0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003318bc_003318BC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Flags_SetCollectible_003329D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_cos_idx8_00338F60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Inventory_ChangeUpgrade_0033C730(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0034536c_0034536C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00346778_00346778(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Health_ChangeBy_00352DBC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00357540_00357540(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003575e8_003575E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00357680_00357680(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Lights_PointNoGlowSetInfo_003591E4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b164_0035B164(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b9d4_0035B9D4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsDeadSound_SpawnStationary_0035E4F4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ActorContext_FindActorsById_00360084(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Environment_LerpWeight_00361490(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsDust_SpawnDefault_00366150(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_RequestQuake_0036627C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_AnimationResource_GetLastFrameByIndex_0036AE18(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ActorModelPose_Advance_0036C950(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToF_0036E168(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BgCheck_EntityRaycastFloor4_0036E81C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsBomb2_SpawnLayered_0036F95C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_StepToF_003705A0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_QueueTextRequest_003716F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_HasParent_00371E40(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Find_00372D64(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetFocus_0037322C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Spawn_003738D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Kill_00374428(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlaySoundGeneral_0037547C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_get_flag_22a0_0037571C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetScale_0037572C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroOne_003759D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlayActorSound2_00375BCC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_Change_00375c08_00375C08(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetAC_00376168(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetOC_003762A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_UpdateBgCheckInfo_00376340(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_MoveForward_00376864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Item_Give_00376A78(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_WaterMedallion_MoveHorse_004BD9A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004be050_004BE050(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_EnBombf_Update_0014CAA8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0014CAA8U:
        goto block_0014CAA8;
    case 0x0014CB30U:
        goto block_0014CB30;
    case 0x0014CB38U:
        goto block_0014CB38;
    case 0x0014CB4CU:
        goto block_0014CB4C;
    case 0x0014CB58U:
        goto block_0014CB58;
    case 0x0014CB64U:
        goto block_0014CB64;
    case 0x0014CB74U:
        goto block_0014CB74;
    case 0x0014CB94U:
        goto block_0014CB94;
    case 0x0014CB98U:
        goto block_0014CB98;
    case 0x0014CBBCU:
        goto block_0014CBBC;
    case 0x0014CBE4U:
        goto block_0014CBE4;
    case 0x0014CBF0U:
        goto block_0014CBF0;
    case 0x0014CC00U:
        goto block_0014CC00;
    case 0x0014CC10U:
        goto block_0014CC10;
    case 0x0014CC18U:
        goto block_0014CC18;
    case 0x0014CC24U:
        goto block_0014CC24;
    case 0x0014CC34U:
        goto block_0014CC34;
    case 0x0014CC44U:
        goto block_0014CC44;
    case 0x0014CC54U:
        goto block_0014CC54;
    case 0x0014CC60U:
        goto block_0014CC60;
    case 0x0014CC7CU:
        goto block_0014CC7C;
    case 0x0014CC88U:
        goto block_0014CC88;
    case 0x0014CC94U:
        goto block_0014CC94;
    case 0x0014CCA0U:
        goto block_0014CCA0;
    case 0x0014CCC8U:
        goto block_0014CCC8;
    case 0x0014CCF0U:
        goto block_0014CCF0;
    case 0x0014CD00U:
        goto block_0014CD00;
    case 0x0014CD0CU:
        goto block_0014CD0C;
    case 0x0014CD1CU:
        goto block_0014CD1C;
    case 0x0014CD28U:
        goto block_0014CD28;
    case 0x0014CD34U:
        goto block_0014CD34;
    case 0x0014CD48U:
        goto block_0014CD48;
    case 0x0014CD54U:
        goto block_0014CD54;
    case 0x0014CD60U:
        goto block_0014CD60;
    case 0x0014CD90U:
        goto block_0014CD90;
    case 0x0014CDA0U:
        goto block_0014CDA0;
    case 0x0014CDBCU:
        goto block_0014CDBC;
    case 0x0014CDC8U:
        goto block_0014CDC8;
    case 0x0014CE00U:
        goto block_0014CE00;
    case 0x0014CE18U:
        goto block_0014CE18;
    case 0x0014CE24U:
        goto block_0014CE24;
    case 0x0014CE38U:
        goto block_0014CE38;
    case 0x0014CE48U:
        goto block_0014CE48;
    case 0x0014CE60U:
        goto block_0014CE60;
    case 0x0014CEBCU:
        goto block_0014CEBC;
    case 0x0014CEDCU:
        goto block_0014CEDC;
    case 0x0014CEE8U:
        goto block_0014CEE8;
    case 0x0014CEFCU:
        goto block_0014CEFC;
    case 0x0014CF08U:
        goto block_0014CF08;
    case 0x0014CF28U:
        goto block_0014CF28;
    case 0x0014CF4CU:
        goto block_0014CF4C;
    case 0x0014CF6CU:
        goto block_0014CF6C;
    case 0x0014CF78U:
        goto block_0014CF78;
    case 0x0014CFA4U:
        goto block_0014CFA4;
    case 0x0014CFC0U:
        goto block_0014CFC0;
    case 0x0014CFD4U:
        goto block_0014CFD4;
    case 0x0014CFE0U:
        goto block_0014CFE0;
    case 0x0014D018U:
        goto block_0014D018;
    case 0x0014D038U:
        goto block_0014D038;
    case 0x0014D05CU:
        goto block_0014D05C;
    case 0x0014D068U:
        goto block_0014D068;
    case 0x0014D080U:
        goto block_0014D080;
    case 0x0014D08CU:
        goto block_0014D08C;
    case 0x0014D09CU:
        goto block_0014D09C;
    case 0x0014D0ACU:
        goto block_0014D0AC;
    case 0x0014D0C0U:
        goto block_0014D0C0;
    case 0x0014D0CCU:
        goto block_0014D0CC;
    case 0x0014D0DCU:
        goto block_0014D0DC;
    case 0x0014D0FCU:
        goto block_0014D0FC;
    case 0x0014D108U:
        goto block_0014D108;
    case 0x0014D114U:
        goto block_0014D114;
    case 0x0014D120U:
        goto block_0014D120;
    case 0x0014D134U:
        goto block_0014D134;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0014CAA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CAA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CAA8U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0014CAA8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0014CAA8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0014CAA8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0014CAA8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0014CAA8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0014CAA8U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0014CAA8U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0014CAA8U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0014CAA8U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00000200U;
            r6 = r4 + operand;
        }
        {
            r5 = r1;
        }
        {
            const uint32_t updatedAddress = 0x0014CAC0U + 0x3B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CAB8U, address);
            }
            r0 = value;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0014CABCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0014CABCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0014CABCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0014CABCU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000054U;
            r13 = r13 - operand;
        }
        {
            const uint32_t address = 0x0014CACCU + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CAC4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014CAD8U, address);
            }
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0014CADCU, address);
            }
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0014CAE0U, address);
            }
        }
        {
            const uint32_t address = 0x0014CAECU + 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CAE4U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014CAE8U, address);
            }
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0014CAECU, address);
            }
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0014CAF4U, address);
            }
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014CAF8U, address);
            }
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0014CAFCU, address);
            }
        }
        {
            const uint32_t address = 0x0014CB08U + 876U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CB00U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0014CB04U, address);
            }
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014CB08U, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0014CB0CU, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014CB10U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CB14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014CB18U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x274U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CB1CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CB24U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014CB38; }
        goto block_0014CB30;
    }
block_0014CB30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CB30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CB30U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014CB34U, address);
            }
        }
        goto block_0014CB38;
    }
block_0014CB38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CB38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CB38U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x278U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CB38U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014CB44U + 0x338U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CB3CU, address);
            }
            r11 = value;
        }
        {
            r8 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014CB98; }
        goto block_0014CB4C;
    }
block_0014CB4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CB4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CB4CU);
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CB58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_HasParent_00371E40(frame, context, state, 0x00371E40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CB58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CB58;
    }
block_0014CB58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CB58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CB58U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0014CB98; }
        goto block_0014CB64;
    }
block_0014CB64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CB64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CB64U);
        }
        {
            const uint32_t address = r4 + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CB64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r11, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0014CB94; }
        goto block_0014CB74;
    }
block_0014CB74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CB74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CB74U);
        }
        {
            const uint32_t address = r4 + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CB74U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0014CB80U + 0x300U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CB78U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CB7CU, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.N()) != (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CB84U, 0xBEB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0014CB98; }
        goto block_0014CB94;
    }
block_0014CB94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CB94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CB94U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x278U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0014CB94U, address);
            }
        }
        goto block_0014CB98;
    }
block_0014CB98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CB98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CB98U);
        }
        {
            const uint32_t address = r4 + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CB98U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0014CBA4U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CB9CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x0014CBA8U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CBA0U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CBA4U, 0xEEB40A48U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            const uint32_t address = 0x0014CBB0U + 736U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CBA8U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = 0x0014CBB4U + 0x2D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CBACU, address);
            }
            r10 = value;
        }
        {
            r9 = 0x00000000U;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_0014CBF0; }
        goto block_0014CBBC;
    }
block_0014CBBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CBBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CBBCU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CBBCU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000500U;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t updatedAddress = r0 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0014CBD0U, address);
            }
        }
        {
            r2 = 0x0000001FU;
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CBE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdateBgCheckInfo_00376340(frame, context, state, 0x00376340U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CBE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CBE4;
    }
block_0014CBE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CBE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CBE4U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CBE4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000500U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0014CBECU, address);
            }
        }
        goto block_0014CBF0;
    }
block_0014CBF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CBF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CBF0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x270U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CBF0U, address);
            }
            r2 = value;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0014CC00U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CC00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CC00;
    }
block_0014CC00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CC00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CC00U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CC00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r7 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014D038; }
        goto block_0014CC10;
    }
block_0014CC10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CC10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CC10U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CC18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_MoveForward_00376864(frame, context, state, 0x00376864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CC18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CC18;
    }
block_0014CC18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CC18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CC18U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CC18U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014D038; }
        goto block_0014CC24;
    }
block_0014CC24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CC24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CC24U);
        }
        {
            const uint32_t address = r4 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CC24U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CC28U, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0014CC44; }
        goto block_0014CC34;
    }
block_0014CC34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CC34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CC34U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x90U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CC34U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000010U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CC3CU, 0x1EB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        if (!(flags.Z())) {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014CC40U, address);
            }
        }
        goto block_0014CC44;
    }
block_0014CC44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CC44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CC44U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CC44U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CC48U, 0xEEB40A48U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_0014CCF0; }
        goto block_0014CC54;
    }
block_0014CC54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CC54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CC54U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x90U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CC54U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000008U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0014CCF0; }
        goto block_0014CC60;
    }
block_0014CC60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CC60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CC60U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x82U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CC60U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CC64U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r0;
            r2 = r1 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t operand = 0x00004000U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00008000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0014CC88; }
        goto block_0014CC7C;
    }
block_0014CC7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CC7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CC7CU);
        }
        {
            const uint32_t operand = 0x00008000U;
            r0 = r2 - operand;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014CC84U, address);
            }
        }
        goto block_0014CC88;
    }
block_0014CC88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CC88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CC88U);
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CC94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00357680_00357680(frame, context, state, 0x00357680U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CC94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CC94;
    }
block_0014CC94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CC94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CC94U);
        }
        {
            r0 = r4;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CCA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_MoveForward_00376864(frame, context, state, 0x00376864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CCA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CCA0;
    }
block_0014CCA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CCA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CCA0U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CCA0U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000500U;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t updatedAddress = r0 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0014CCB4U, address);
            }
        }
        {
            r2 = 0x0000001FU;
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CCC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdateBgCheckInfo_00376340(frame, context, state, 0x00376340U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CCC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CCC8;
    }
block_0014CCC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CCC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CCC8U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CCC8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0014CCD4U + 448U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CCCCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000500U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0014CCD4U, address);
            }
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CCD8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CCDCU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014CCE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x90U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CCE4U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000008U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014CCECU, address);
            }
        }
        goto block_0014CCF0;
    }
block_0014CCF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CCF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CCF0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1B5U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CCF0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0014CCFCU + 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CCF4U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) { goto block_0014CD1C; }
        goto block_0014CD00;
    }
block_0014CD00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CD00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CD00U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1B6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CD00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014CD28; }
        goto block_0014CD0C;
    }
block_0014CD0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CD0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CD0CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CD0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CD10U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014CD28; }
        goto block_0014CD1C;
    }
block_0014CD1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CD1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CD1CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x274U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0014CD1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0014CD20U, address);
            }
        }
        goto block_0014CD60;
    }
block_0014CD28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CD28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CD28U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CD28U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000096U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0014CD54; }
        goto block_0014CD34;
    }
block_0014CD34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CD34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CD34U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = 0x0014CD40U + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CD38U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CD48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003575e8_003575E8(frame, context, state, 0x003575E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CD48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CD48;
    }
block_0014CD48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CD48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CD48U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r1 = 0x00000096U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014CD50U, address);
            }
        }
        goto block_0014CD54;
    }
block_0014CD54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CD54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CD54U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x274U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CD54U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014D038; }
        goto block_0014CD60;
    }
block_0014CD60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CD60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CD60U);
        }
        {
            const uint32_t operand = 0x00000024U;
            r9 = r13 + operand;
        }
        {
            const uint32_t address = 0x0014CD6CU + 308U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CD64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0014CD70U + 308U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CD68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014CD6CU, address);
            }
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0014CD70U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0014CD70U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014CD70U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0014CD74U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014CD74U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0014CD74U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r13 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CD78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CD7CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014CD80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CD84U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000BFU, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0014CE00; }
        goto block_0014CD90;
    }
block_0014CD90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CD90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CD90U);
        }
        {
            const uint32_t updatedAddress = 0x0014CD98U + 0x110U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CD90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CD94U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0014CDBC; }
        goto block_0014CDA0;
    }
block_0014CDA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CDA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CDA0U);
        }
        {
            const uint32_t operand = 0x00000030U;
            r3 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0014CDA4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000048U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r2 = r13 + operand;
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CDBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00357540_00357540(frame, context, state, 0x00357540U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CDBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CDBC;
    }
block_0014CDBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CDBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CDBCU);
        }
        {
            const uint32_t updatedAddress = 0x0014CDC4U + 0xE8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CDBCU, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CDC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CDC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CDC8;
    }
block_0014CDC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CDC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CDC8U);
        }
        {
            const uint32_t address = r13 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CDC8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0014CDD4U + 220U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CDCCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = 0x00000005U;
        }
        {
            r2 = 0x00000032U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CDD8U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000014U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014CDE4U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0014CDE8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014CDE8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0014CDE8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0014CDE8U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000048U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000018U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r1 = r13 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CE00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsDust_SpawnDefault_00366150(frame, context, state, 0x00366150U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CE00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CE00;
    }
block_0014CE00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CE00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CE00U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CE00U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000032U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000046U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014CE24; }
        goto block_0014CE18;
    }
block_0014CE18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CE18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CE18U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x7AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CE18U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = Oot3dAotAsr(r0, 1U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x7AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014CE20U, address);
            }
        }
        goto block_0014CE24;
    }
block_0014CE24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CE24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CE24U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CE24U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0014CE30U + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CE28U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0014CE34U + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CE2CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000096U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0014CEBC; }
        goto block_0014CE38;
    }
block_0014CE38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CE38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CE38U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x7AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CE38U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r0 + operand;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r2, 0U, 0U, flags.C());
            const uint32_t value = r1 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014CEBC; }
        goto block_0014CE48;
    }
block_0014CE48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CE48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CE48U);
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x0000027CU;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CE54U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CE58U, 0xEE801A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CE60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CE60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CE60;
    }
block_0014CE60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CE60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CE60U);
        }
        {
        }
        {
        }
        goto block_0014CEDC;
    }
block_0014CEBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CEBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CEBCU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x7AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CEBCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            const uint32_t operand = 0x0000027CU;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CEC8U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CECCU, 0xEE801A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CEDCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CEDCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CEDC;
    }
block_0014CEDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CEDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CEDCU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CEDCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0014D038; }
        goto block_0014CEE8;
    }
block_0014CEE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CEE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CEE8U);
        }
        {
            const uint32_t address = r4 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CEE8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0014CEF4U + 588U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CEECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r0 = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CEF4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CEFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetScale_0037572C(frame, context, state, 0x0037572CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CEFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CEFC;
    }
block_0014CEFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CEFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CEFCU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CEFCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014D038; }
        goto block_0014CF08;
    }
block_0014CF08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CF08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CF08U);
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0014CF08U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0014CF08U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014CF08U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0014CF0CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014CF0CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0014CF0CU,
                                           firstAddress + 8U);
            }
        }
        {
            r1 = r5;
        }
        {
            const uint32_t address = r13 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CF14U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CF1CU, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014CF20U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CF28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_HasParent_00371E40(frame, context, state, 0x00371E40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CF28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CF28;
    }
block_0014CF28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CF28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CF28U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t address = r13 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CF2CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CF30U, 0x1E300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        if (!(flags.Z())) {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014CF34U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CF38U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00004000U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00003980U;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000700U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0014CF78; }
        goto block_0014CF4C;
    }
block_0014CF4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CF4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CF4CU);
        }
        {
            r3 = 0x00000013U;
        }
        {
            r2 = 0x00000064U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0014CF54U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x0000003CU;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000048U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r1 = r13 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CF6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsBomb2_SpawnLayered_0036F95C(frame, context, state, 0x0036F95CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CF6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CF6C;
    }
block_0014CF6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CF6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CF6CU);
        }
        {
        }
        {
        }
        goto block_0014CFA4;
    }
block_0014CF78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CF78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CF78U);
        }
        {
            const uint32_t address = r13 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CF78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x00000013U;
        }
        {
            r2 = ~(0x00000063U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014CF84U, 0xEEB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        {
            const uint32_t operand = 0x00000024U;
            r1 = r13 + operand;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014CF90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0014CF94U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x0000003CU;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000048U;
            r2 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CFA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsBomb2_SpawnLayered_0036F95C(frame, context, state, 0x0036F95CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CFA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CFA4;
    }
block_0014CFA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CFA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CFA4U);
        }
        {
            const uint32_t address = r4 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CFA4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0014CFB0U + 0x194U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CFA8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014CFACU, address);
            }
        }
        {
            const uint32_t address = r4 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CFB0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0014CFD4; }
        goto block_0014CFC0;
    }
block_0014CFC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CFC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CFC0U);
        }
        {
            const uint32_t operand = 0x00000030U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000048U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r1 = r13 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CFD4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b9d4_0035B9D4(frame, context, state, 0x0035B9D4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CFD4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CFD4;
    }
block_0014CFD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CFD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CFD4U);
        }
        {
            const uint32_t updatedAddress = 0x0014CFDCU + 0x16CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014CFD4U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014CFE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014CFE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014CFE0;
    }
block_0014CFE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014CFE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014CFE0U);
        }
        {
            const uint32_t operand = 0x00003200U;
            r0 = r5 + operand;
        }
        {
            r1 = 0x000000FAU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014CFE8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014CFECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014CFF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014CFF4U, address);
            }
        }
        {
            const uint32_t operand = 0x00003100U;
            r0 = r5 + operand;
        }
        {
            r3 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xFEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014D000U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014D004U, address);
            }
        }
        {
            r2 = 0x0000000BU;
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x00000364U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014D018U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_RequestQuake_0036627C(frame, context, state, 0x0036627CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014D018U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014D018;
    }
block_0014D018:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D018U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D018U);
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0014D01CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014D020U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014D024U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 | 0x00000020U;
        }
        {
            const uint32_t updatedAddress = 0x0014D034U + 0x118U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014D02CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x270U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014D030U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014D034U, address);
            }
        }
        goto block_0014D038;
    }
block_0014D038:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D038U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D038U);
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0014D038U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014D038U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0014D038U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014D040U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0014D040U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0014D040U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r4 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014D044U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014D048U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014D04CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014D050U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0014D0AC; }
        goto block_0014D05C;
    }
block_0014D05C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D05CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D05CU);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r1 = r4 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014D068U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014D068U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014D068;
    }
block_0014D068:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D068U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D068U);
        }
        {
            const uint32_t address = r4 + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014D068U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00005C00U;
            r6 = r5 + operand;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000078U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0014D09C; }
        goto block_0014D080;
    }
block_0014D080:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D080U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D080U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x278U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014D080U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0014D09C; }
        goto block_0014D08C;
    }
block_0014D08C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D08CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D08CU);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014D09CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014D09CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014D09C;
    }
block_0014D09C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D09CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D09CU);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014D0ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014D0ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014D0AC;
    }
block_0014D0AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D0ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D0ACU);
        }
        {
            const uint32_t address = r4 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014D0ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0014D0B8U + 0x98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014D0B0U, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0014D108; }
        goto block_0014D0C0;
    }
block_0014D0C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D0C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D0C0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014D0C0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0014D108; }
        goto block_0014D0CC;
    }
block_0014D0CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D0CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D0CCU);
        }
        {
            const uint32_t address = r4 + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014D0CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r11, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0014D114; }
        goto block_0014D0DC;
    }
block_0014D0DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D0DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D0DCU);
        }
        {
            r3 = 0x0000000AU;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0014D0E4U, faultAddress);
            }
        }
        {
            r3 = r2;
        }
        {
            const uint32_t updatedAddress = 0x0014D0F4U + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014D0ECU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014D0FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsDeadSound_SpawnStationary_0035E4F4(frame, context, state, 0x0035E4F4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014D0FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014D0FC;
    }
block_0014D0FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D0FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D0FCU);
        }
        {
            r0 = r4;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014D108U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014D108U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014D108;
    }
block_0014D108:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D108U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D108U);
        }
        {
            const uint32_t operand = 0x00000054U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0014D10CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0014D10CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014D10CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0014D10CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0014D110U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0014D110U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0014D110U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0014D110U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0014D110U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0014D110U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0014D110U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0014D110U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0014D110U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_0014D114:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D114U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D114U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x90U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014D114U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000040U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014D108; }
        goto block_0014D120;
    }
block_0014D120:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D120U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D120U);
        }
        {
            r0 = r0 & ~(0x00000040U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014D124U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0014D130U + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014D128U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014D134U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014D134U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014D134;
    }
block_0014D134:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014D134U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014D134U);
        }
        {
            const uint32_t operand = 0x00000054U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0014D138U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0014D138U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014D138U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0014D138U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0014D13CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0014D13CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0014D13CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0014D13CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0014D13CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0014D13CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0014D13CU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0014D13CU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0014D13CU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_001e3ccc_001E3CCC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001E3CCCU:
        goto block_001E3CCC;
    case 0x001E3CFCU:
        goto block_001E3CFC;
    case 0x001E3D08U:
        goto block_001E3D08;
    case 0x001E3D0CU:
        goto block_001E3D0C;
    case 0x001E3D1CU:
        goto block_001E3D1C;
    case 0x001E3D28U:
        goto block_001E3D28;
    case 0x001E3D30U:
        goto block_001E3D30;
    case 0x001E3D34U:
        goto block_001E3D34;
    case 0x001E3D4CU:
        goto block_001E3D4C;
    case 0x001E3D58U:
        goto block_001E3D58;
    case 0x001E3D5CU:
        goto block_001E3D5C;
    case 0x001E3D64U:
        goto block_001E3D64;
    case 0x001E3D70U:
        goto block_001E3D70;
    case 0x001E3D7CU:
        goto block_001E3D7C;
    case 0x001E3D88U:
        goto block_001E3D88;
    case 0x001E3DD4U:
        goto block_001E3DD4;
    case 0x001E3E1CU:
        goto block_001E3E1C;
    case 0x001E3E2CU:
        goto block_001E3E2C;
    case 0x001E3E58U:
        goto block_001E3E58;
    case 0x001E3ED8U:
        goto block_001E3ED8;
    case 0x001E3EF0U:
        goto block_001E3EF0;
    case 0x001E3F08U:
        goto block_001E3F08;
    case 0x001E3F2CU:
        goto block_001E3F2C;
    case 0x001E3F40U:
        goto block_001E3F40;
    case 0x001E3F44U:
        goto block_001E3F44;
    case 0x001E3F50U:
        goto block_001E3F50;
    case 0x001E3F68U:
        goto block_001E3F68;
    case 0x001E3F74U:
        goto block_001E3F74;
    case 0x001E3F88U:
        goto block_001E3F88;
    case 0x001E3F9CU:
        goto block_001E3F9C;
    case 0x001E3FA8U:
        goto block_001E3FA8;
    case 0x001E3FBCU:
        goto block_001E3FBC;
    case 0x001E3FC8U:
        goto block_001E3FC8;
    case 0x001E3FD4U:
        goto block_001E3FD4;
    case 0x001E3FE0U:
        goto block_001E3FE0;
    case 0x001E3FECU:
        goto block_001E3FEC;
    case 0x001E3FF4U:
        goto block_001E3FF4;
    case 0x001E4000U:
        goto block_001E4000;
    case 0x001E4014U:
        goto block_001E4014;
    case 0x001E4028U:
        goto block_001E4028;
    case 0x001E4034U:
        goto block_001E4034;
    case 0x001E4048U:
        goto block_001E4048;
    case 0x001E4054U:
        goto block_001E4054;
    case 0x001E409CU:
        goto block_001E409C;
    case 0x001E40A8U:
        goto block_001E40A8;
    case 0x001E40B4U:
        goto block_001E40B4;
    case 0x001E40BCU:
        goto block_001E40BC;
    case 0x001E40C8U:
        goto block_001E40C8;
    case 0x001E40DCU:
        goto block_001E40DC;
    case 0x001E40F0U:
        goto block_001E40F0;
    case 0x001E4100U:
        goto block_001E4100;
    case 0x001E4114U:
        goto block_001E4114;
    case 0x001E4120U:
        goto block_001E4120;
    case 0x001E412CU:
        goto block_001E412C;
    case 0x001E4138U:
        goto block_001E4138;
    case 0x001E4144U:
        goto block_001E4144;
    case 0x001E4150U:
        goto block_001E4150;
    case 0x001E4160U:
        goto block_001E4160;
    case 0x001E416CU:
        goto block_001E416C;
    case 0x001E4180U:
        goto block_001E4180;
    case 0x001E418CU:
        goto block_001E418C;
    case 0x001E41A0U:
        goto block_001E41A0;
    case 0x001E41ACU:
        goto block_001E41AC;
    case 0x001E41B8U:
        goto block_001E41B8;
    case 0x001E41C4U:
        goto block_001E41C4;
    case 0x001E41D0U:
        goto block_001E41D0;
    case 0x001E41D8U:
        goto block_001E41D8;
    case 0x001E41E8U:
        goto block_001E41E8;
    case 0x001E41F4U:
        goto block_001E41F4;
    case 0x001E4208U:
        goto block_001E4208;
    case 0x001E4210U:
        goto block_001E4210;
    case 0x001E4218U:
        goto block_001E4218;
    case 0x001E422CU:
        goto block_001E422C;
    case 0x001E4238U:
        goto block_001E4238;
    case 0x001E4244U:
        goto block_001E4244;
    case 0x001E4250U:
        goto block_001E4250;
    case 0x001E4254U:
        goto block_001E4254;
    case 0x001E426CU:
        goto block_001E426C;
    case 0x001E4274U:
        goto block_001E4274;
    case 0x001E42B4U:
        goto block_001E42B4;
    case 0x001E4320U:
        goto block_001E4320;
    case 0x001E439CU:
        goto block_001E439C;
    case 0x001E4414U:
        goto block_001E4414;
    case 0x001E442CU:
        goto block_001E442C;
    case 0x001E4458U:
        goto block_001E4458;
    case 0x001E4464U:
        goto block_001E4464;
    case 0x001E447CU:
        goto block_001E447C;
    case 0x001E4498U:
        goto block_001E4498;
    case 0x001E44B4U:
        goto block_001E44B4;
    case 0x001E44DCU:
        goto block_001E44DC;
    case 0x001E4548U:
        goto block_001E4548;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001E3CCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3CCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3CCCU);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001E3CCCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001E3CCCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001E3CCCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001E3CCCU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001E3CCCU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001E3CCCU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001E3CCCU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001E3CCCU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001E3CCCU,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r6 = r0;
        }
        {
            const uint32_t operand = 0x00000400U;
            r5 = r6 + operand;
        }
        {
            r8 = r1;
        }
        {
            const uint32_t operand = 0x00000100U;
            r9 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = 0x001E3CE8U + 0x378U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3CE0U, address);
            }
            r0 = value;
        }
        {
            r13 -= 32U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001E3CE4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001E3CE4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001E3CE4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001E3CE4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x001E3CE4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x001E3CE4U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x001E3CE4U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x001E3CE4U,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3CECU, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x80U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3CF0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003EU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001E3D70; }
        goto block_001E3CFC;
    }
block_001E3CFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3CFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3CFCU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3CFCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000016U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001E3D7C; }
        goto block_001E3D08;
    }
block_001E3D08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3D08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3D08U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E3D0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b164_0035B164(frame, context, state, 0x0035B164U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E3D0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E3D0C;
    }
block_001E3D0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3D0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3D0CU);
        }
        {
            const uint32_t value = r0 ^ 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        if (flags.Z()) { goto block_001E3D34; }
        goto block_001E3D1C;
    }
block_001E3D1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3D1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3D1CU);
        }
        {
            r2 = 0x00000008U;
        }
        {
            r1 = 0x0000005FU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E3D28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Find_00372D64(frame, context, state, 0x00372D64U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E3D28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E3D28;
    }
block_001E3D28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3D28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3D28U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x001E3D30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E3D30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E3D30;
    }
block_001E3D30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3D30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3D30U);
        }
        goto block_001E3D70;
    }
block_001E3D34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3D34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3D34U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001E3D38U, address);
            }
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r13 + operand;
        }
        {
            r2 = 0x0000000BU;
        }
        {
            r1 = 0x0000000AU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E3D4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorContext_FindActorsById_00360084(frame, context, state, 0x00360084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E3D4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E3D4C;
    }
block_001E3D4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3D4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3D4CU);
        }
        {
            const uint32_t operand = 0x00000000U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r11 = r0 - operand;
        }
        {
            r7 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001E3D70; }
        goto block_001E3D58;
    }
block_001E3D58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3D58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3D58U);
        }
        {
            const uint32_t operand = 0x00000004U;
            r10 = r13 + operand;
        }
        goto block_001E3D5C;
    }
block_001E3D5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3D5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3D5CU);
        }
        {
            const uint32_t updatedAddress = r10 + Oot3dAotLsl(r7, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3D5CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E3D64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E3D64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E3D64;
    }
block_001E3D64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3D64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3D64U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r7 = r7 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, r11, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001E3D5C; }
        goto block_001E3D70;
    }
block_001E3D70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3D70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3D70U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x80U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3D70U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001E3D88; }
        goto block_001E3D7C;
    }
block_001E3D7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3D7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3D7CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x80U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3D7CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001E3D84U, address);
            }
        }
        goto block_001E3D88;
    }
block_001E3D88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3D88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3D88U);
        }
        {
            const uint32_t updatedAddress = 0x001E3D90U + 0x2D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3D88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001E3D94U + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3D8CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001E3D98U + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3D90U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x80U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3D94U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3D98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001E3DA4U + 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3D9CU, address);
            }
            r11 = value;
        }
        {
            const uint32_t address = 0x001E3DA8U + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3DA0U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = 0x001E3DB0U + 708U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3DA8U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3DACU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001E3DB8U + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3DB0U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3DB8U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3DBCU, 0xEE800A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3DC0U, 0xEE300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3DC4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_001E3F08; }
        goto block_001E3DD4;
    }
block_001E3DD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3DD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3DD4U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3DD4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3DD8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3DDCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r1 = 0x0000002DU;
        }
        if (flags.Z()) {
            r1 = 0x00000023U;
        }
        {
            frame.Guest.vfp[2] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3DF0U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3DF4U, 0xEEB81A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3DF8U, 0xEEB40AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t address = r4 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001E3E00U, address);
            }
        }
        if (!(flags.C()) || (flags.Z())) {
            const uint32_t address = 0x001E3E0CU + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3E04U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001E3E08U, address);
            }
        }
        if (!(flags.C()) || (flags.Z())) {
            const uint32_t address = r4 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001E3E0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x80U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3E10U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001E3ED8; }
        goto block_001E3E1C;
    }
block_001E3E1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3E1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3E1CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x88U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3E1CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001E3E28U + 604U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3E20U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000FA0U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_001E3E58; }
        goto block_001E3E2C;
    }
block_001E3E2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3E2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3E2CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3E2CU, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001E3E38U + 592U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3E30U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[2] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3E38U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3E3CU, 0xEE211A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3E44U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3E48U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[1];
        }
        {
            const uint32_t operand = r2;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x88U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001E3E54U, address);
            }
        }
        goto block_001E3E58;
    }
block_001E3E58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3E58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3E58U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x88U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3E58U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3E5CU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3E68U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3E70U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3E74U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3E78U, 0xEE201A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3E80U, 0xDE510A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3E84U, 0xCE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3E88U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[1];
        }
        {
            const uint32_t operand = r1;
            r1 = r2 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001E3E94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x88U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3E98U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3E9CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3EACU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3EB0U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3EB4U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3EB8U, 0xEE201A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3EC0U, 0xDE510A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3EC4U, 0xCE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E3EC8U, 0xEEBD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = r0;
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001E3ED4U, address);
            }
        }
        goto block_001E3ED8;
    }
block_001E3ED8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3ED8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3ED8U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3EE4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E3EF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E3EF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E3EF0;
    }
block_001E3EF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3EF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3EF0U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3EFCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E3F08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E3F08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E3F08;
    }
block_001E3F08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3F08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3F08U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3F08U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001E3F14U + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3F0CU, address);
            }
            r1 = value;
        }
        {
            r10 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001E3F1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3F20U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001E4274; }
        goto block_001E3F2C;
    }
block_001E3F2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3F2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3F2CU);
        }
        {
            const uint32_t updatedAddress = 0x001E3F34U + 0x15CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3F2CU, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3F30U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000FF00U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x000000EFU;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (!(flags.Z())) { goto block_001E4274; }
        goto block_001E3F40;
    }
block_001E3F40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3F40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3F40U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E3F44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b164_0035B164(frame, context, state, 0x0035B164U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E3F44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E3F44;
    }
block_001E3F44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3F44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3F44U);
        }
        {
            const uint32_t value = r0 ^ 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
        }
        if (flags.Z()) { goto block_001E426C; }
        goto block_001E3F50;
    }
block_001E3F50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3F50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3F50U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3F50U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00001500U;
            r0 = r7 - operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r9 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000014U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        {
            const uint32_t operand = 0x00000E00U;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) { goto block_001E3FEC; }
        goto block_001E3F68;
    }
block_001E3F68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3F68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3F68U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xF4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3F68U, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x00000100U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000100U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_001E3FA8; }
        goto block_001E3F74;
    }
block_001E3F74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3F74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3F74U);
        }
        {
            r1 = r1 | 0x00000100U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001E3F78U, address);
            }
        }
        {
            r1 = 0x00000066U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E3F88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E3F88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E3F88;
    }
block_001E3F88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3F88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3F88U);
        }
        {
            r3 = 0x00000003U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            r1 = 0x0000006BU;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E3F9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E3F9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E3F9C;
    }
block_001E3F9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3F9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3F9CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001E3F9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x5A3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001E3FA0U, address);
            }
        }
        goto block_001E4254;
    }
block_001E3FA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3FA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3FA8U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3FA8U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000003U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001E3FD4; }
        goto block_001E3FBC;
    }
block_001E3FBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3FBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3FBCU);
        }
        {
            r1 = 0x00000600U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E3FC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E3FC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E3FC8;
    }
block_001E3FC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3FC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3FC8U);
        }
        {
        }
        {
        }
        goto block_001E4250;
    }
block_001E3FD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3FD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3FD4U);
        }
        {
            const uint32_t updatedAddress = 0x001E3FDCU + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3FD4U, address);
            }
            r1 = value;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E3FE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E3FE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E3FE0;
    }
block_001E3FE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3FE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3FE0U);
        }
        {
        }
        {
        }
        goto block_001E4250;
    }
block_001E3FEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3FECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3FECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000015U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (!(flags.Z())) { goto block_001E40B4; }
        goto block_001E3FF4;
    }
block_001E3FF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E3FF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E3FF4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xF4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E3FF4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x00000200U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000200U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_001E4034; }
        goto block_001E4000;
    }
block_001E4000:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4000U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4000U);
        }
        {
            r1 = r1 | 0x00000200U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001E4004U, address);
            }
        }
        {
            r1 = 0x00000067U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4014U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4014U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4014;
    }
block_001E4014:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4014U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4014U);
        }
        {
            r3 = 0x00000003U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            r1 = 0x000000DBU;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4028U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4028U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4028;
    }
block_001E4028:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4028U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4028U);
        }
        {
            r0 = ~(0x0000000CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001E402CU, address);
            }
        }
        goto block_001E4254;
    }
block_001E4034:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4034U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4034U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4034U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000003U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001E409C; }
        goto block_001E4048;
    }
block_001E4048:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4048U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4048U);
        }
        {
            const uint32_t updatedAddress = 0x001E4050U + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4048U, address);
            }
            r1 = value;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4054U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4054U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4054;
    }
block_001E4054:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4054U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4054U);
        }
        {
        }
        {
        }
        goto block_001E4250;
    }
block_001E409C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E409CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E409CU);
        }
        {
            const uint32_t updatedAddress = 0x001E40A4U + 0x4B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E409CU, address);
            }
            r1 = value;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E40A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E40A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E40A8;
    }
block_001E40A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E40A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E40A8U);
        }
        {
        }
        {
        }
        goto block_001E4250;
    }
block_001E40B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E40B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E40B4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000016U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (!(flags.Z())) { goto block_001E4144; }
        goto block_001E40BC;
    }
block_001E40BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E40BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E40BCU);
        }
        {
            const uint32_t updatedAddress = r0 + 0xF4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E40BCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x00000400U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000400U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_001E4100; }
        goto block_001E40C8;
    }
block_001E40C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E40C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E40C8U);
        }
        {
            r1 = r1 | 0x00000400U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001E40CCU, address);
            }
        }
        {
            r1 = 0x00000068U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E40DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E40DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E40DC;
    }
block_001E40DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E40DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E40DCU);
        }
        {
            r3 = 0x00000003U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            r1 = 0x0000006BU;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E40F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E40F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E40F0;
    }
block_001E40F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E40F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E40F0U);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r7 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001E40F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x5A3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001E40F8U, address);
            }
        }
        goto block_001E4254;
    }
block_001E4100:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4100U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4100U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4100U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000003U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001E412C; }
        goto block_001E4114;
    }
block_001E4114:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4114U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4114U);
        }
        {
            const uint32_t operand = 0x000005F0U;
            r1 = r2 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4120U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4120U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4120;
    }
block_001E4120:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4120U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4120U);
        }
        {
        }
        {
        }
        goto block_001E4250;
    }
block_001E412C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E412CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E412CU);
        }
        {
            const uint32_t updatedAddress = 0x001E4134U + 0x424U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E412CU, address);
            }
            r1 = value;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4138U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4138U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4138;
    }
block_001E4138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4138U);
        }
        {
        }
        {
        }
        goto block_001E4250;
    }
block_001E4144:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4144U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4144U);
        }
        {
            const uint32_t updatedAddress = 0x001E414CU + 0x410U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4144U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000017U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_001E41D0; }
        goto block_001E4150;
    }
block_001E4150:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4150U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4150U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4150U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4154U, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_001E418C; }
        goto block_001E4160;
    }
block_001E4160:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4160U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4160U);
        }
        {
            r1 = 0x00000069U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E416CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E416CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E416C;
    }
block_001E416C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E416CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E416CU);
        }
        {
            r3 = 0x00000003U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            r1 = 0x0000006BU;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4180U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4180U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4180;
    }
block_001E4180:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4180U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4180U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r7 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001E4184U, address);
            }
        }
        goto block_001E4210;
    }
block_001E418C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E418CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E418CU);
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E418CU, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000003U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001E41B8; }
        goto block_001E41A0;
    }
block_001E41A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E41A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E41A0U);
        }
        {
            const uint32_t updatedAddress = 0x001E41A8U + 0x3B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E41A0U, address);
            }
            r1 = value;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E41ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E41ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E41AC;
    }
block_001E41AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E41ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E41ACU);
        }
        {
        }
        {
        }
        goto block_001E4250;
    }
block_001E41B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E41B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E41B8U);
        }
        {
            r1 = 0x00000610U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E41C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E41C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E41C4;
    }
block_001E41C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E41C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E41C4U);
        }
        {
        }
        {
        }
        goto block_001E4250;
    }
block_001E41D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E41D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E41D0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000018U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_001E4254; }
        goto block_001E41D8;
    }
block_001E41D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E41D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E41D8U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E41D8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E41DCU, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_001E4218; }
        goto block_001E41E8;
    }
block_001E41E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E41E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E41E8U);
        }
        {
            r1 = 0x0000006AU;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E41F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E41F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E41F4;
    }
block_001E41F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E41F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E41F4U);
        }
        {
            r3 = 0x00000003U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            r1 = 0x0000006BU;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4208U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4208U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4208;
    }
block_001E4208:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4208U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4208U);
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r7 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001E420CU, address);
            }
        }
        goto block_001E4210;
    }
block_001E4210:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4210U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4210U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x5A3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001E4210U, address);
            }
        }
        goto block_001E4254;
    }
block_001E4218:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4218U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4218U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4218U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000003U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001E4244; }
        goto block_001E422C;
    }
block_001E422C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E422CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E422CU);
        }
        {
            const uint32_t updatedAddress = 0x001E4234U + 0x330U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E422CU, address);
            }
            r1 = value;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4238U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4238U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4238;
    }
block_001E4238:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4238U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4238U);
        }
        {
        }
        {
        }
        goto block_001E4250;
    }
block_001E4244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4244U);
        }
        {
            r1 = 0x00000580U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4250U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4250U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4250;
    }
block_001E4250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4250U);
        }
        {
            const uint32_t updatedAddress = r7 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001E4250U, address);
            }
        }
        goto block_001E4254;
    }
block_001E4254:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4254U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4254U);
        }
        {
            const uint32_t updatedAddress = 0x001E425CU + 0x30CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4254U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000014U;
        }
        {
            const uint32_t updatedAddress = r1 + r8;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001E425CU, address);
            }
        }
        {
            r0 = 0x00000007U;
        }
        {
            const uint32_t updatedAddress = r9 + 0x5ABU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001E4264U, address);
            }
        }
        goto block_001E4274;
    }
block_001E426C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E426CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E426CU);
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4274U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034536c_0034536C(frame, context, state, 0x0034536CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4274U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4274;
    }
block_001E4274:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4274U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4274U);
        }
        {
            const uint32_t updatedAddress = 0x001E427CU - 0x218U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4274U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001E4280U + 748U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4278U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E427CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = 0x001E4288U + 744U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4280U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4284U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001E4290U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4288U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4290U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E4298U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E429CU, 0xEEC00A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E42A0U, 0xEE700A88U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E42A4U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001E4320; }
        goto block_001E42B4;
    }
block_001E42B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E42B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E42B4U);
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r8 + operand;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x261U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001E42BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E42C0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E42C4U, address);
            }
            r2 = value;
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E42CCU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E42D0U, 0xEE800A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x001E42DCU + 668U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E42D4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E42D8U, 0xEE300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E42DCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = r1;
            r1 = r2 - operand;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E42ECU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E42F0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            r1 = 0x000000A0U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x262U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001E4304U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x263U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001E4308U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x264U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001E430CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E4310U, 0xEE200A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E4314U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0x265U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001E431CU, address);
            }
        }
        goto block_001E4320;
    }
block_001E4320:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4320U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4320U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001E4328U, faultAddress);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E432CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001E4338U + 580U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4330U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            r3 = 0x0000007FU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E4338U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x00000075U;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E4350U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E4354U, 0xEE301A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4358U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E435CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E436CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E4370U, 0xEE700A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4374U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E4378U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000098U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E4390U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E4394U, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E439CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Lights_PointNoGlowSetInfo_003591E4(frame, context, state, 0x003591E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E439CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E439C;
    }
block_001E439C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E439CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E439CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001E43A4U, faultAddress);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E43A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x0000007FU;
        }
        {
            r2 = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E43B4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = 0x00000075U;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E43C8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E43CCU, 0xEE301A4BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E43D0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E43D4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E43E4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E43E8U, 0xEE700A4BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E43ECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E43F0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x000000B4U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E4408U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E440CU, 0xEE300A4BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4414U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Lights_PointNoGlowSetInfo_003591E4(frame, context, state, 0x003591E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4414U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4414;
    }
block_001E4414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4414U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x001E4424U + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E441CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x001E4428U + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4420U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000000C4U;
            r0 = r6 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E442CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E442CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E442C;
    }
block_001E442C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E442CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E442CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E442CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001E4438U + 336U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4430U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000320U;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001E4444U, address);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r6 + operand;
        }
        {
            const uint32_t address = 0x001E4454U + 312U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E444CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4458U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4458U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4458;
    }
block_001E4458:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4458U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4458U);
        }
        {
            const uint32_t operand = 0x00000360U;
            r0 = r6 + operand;
        }
        {
            r1 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4464U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorModelPose_Advance_0036C950(frame, context, state, 0x0036C950U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4464U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4464;
    }
block_001E4464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4464U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = 0x001E4478U + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4470U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000470U;
            r0 = r6 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E447CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E447CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E447C;
    }
block_001E447C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E447CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E447CU);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r6 + operand;
        }
        {
            const uint32_t address = 0x001E4494U + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E448CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000074U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E4498U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E4498U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E4498;
    }
block_001E4498:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4498U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4498U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001E44B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001E44B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001E44B4;
    }
block_001E44B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E44B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E44B4U);
        }
        {
            const uint32_t updatedAddress = 0x001E44BCU - 0x430U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E44B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E44B8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E44BCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E44C8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E44CCU, 0xEE00AA49U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E44D0U, 0xEEB4AAE8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[20], frame.Guest.vfp[17],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001E4548; }
        goto block_001E44DC;
    }
block_001E44DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E44DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E44DCU);
        }
        {
            const uint32_t operand = 0x00003200U;
            r0 = r8 + operand;
        }
        {
            const uint32_t address = 0x001E44E8U + 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E44E0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00003100U;
            r1 = r8 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E44E8U, 0xEE2A0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E44ECU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001E44F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001E44F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0xFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001E44FCU, address);
            }
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001E4504U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001E4508U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0xFEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001E450CU, address);
            }
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x001E451CU + 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4514U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001E4518U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E451CU, 0xEE2A0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001E4520U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001E4524U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001E4528U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r1, 0x0000012CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r0 + 0xEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001E4538U, address);
            }
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = 0x001E4544U + 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E453CU, address);
            }
            r0 = value;
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001E4540U, address);
            }
            r0 = value;
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r0 + 0xADU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001E4544U, address);
            }
        }
        goto block_001E4548;
    }
block_001E4548:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001E4548U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001E4548U);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001E454CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001E454CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001E454CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001E454CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001E454CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001E454CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001E454CU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001E454CU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001E4550U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001E4550U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001E4550U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001E4550U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001E4550U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001E4550U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001E4550U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001E4550U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001E4550U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_EnItem00_Update_0022B71C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0022B71CU:
        goto block_0022B71C;
    case 0x0022B758U:
        goto block_0022B758;
    case 0x0022B764U:
        goto block_0022B764;
    case 0x0022B774U:
        goto block_0022B774;
    case 0x0022B790U:
        goto block_0022B790;
    case 0x0022B7B0U:
        goto block_0022B7B0;
    case 0x0022B7BCU:
        goto block_0022B7BC;
    case 0x0022B7D4U:
        goto block_0022B7D4;
    case 0x0022B7E0U:
        goto block_0022B7E0;
    case 0x0022B7F4U:
        goto block_0022B7F4;
    case 0x0022B814U:
        goto block_0022B814;
    case 0x0022B850U:
        goto block_0022B850;
    case 0x0022B860U:
        goto block_0022B860;
    case 0x0022B86CU:
        goto block_0022B86C;
    case 0x0022B888U:
        goto block_0022B888;
    case 0x0022B8ACU:
        goto block_0022B8AC;
    case 0x0022B8B8U:
        goto block_0022B8B8;
    case 0x0022B8CCU:
        goto block_0022B8CC;
    case 0x0022B8E4U:
        goto block_0022B8E4;
    case 0x0022B8ECU:
        goto block_0022B8EC;
    case 0x0022B908U:
        goto block_0022B908;
    case 0x0022B914U:
        goto block_0022B914;
    case 0x0022B928U:
        goto block_0022B928;
    case 0x0022B93CU:
        goto block_0022B93C;
    case 0x0022B94CU:
        goto block_0022B94C;
    case 0x0022B958U:
        goto block_0022B958;
    case 0x0022B964U:
        goto block_0022B964;
    case 0x0022B974U:
        goto block_0022B974;
    case 0x0022B980U:
        goto block_0022B980;
    case 0x0022B9E8U:
        goto block_0022B9E8;
    case 0x0022B9F4U:
        goto block_0022B9F4;
    case 0x0022BA00U:
        goto block_0022BA00;
    case 0x0022BA0CU:
        goto block_0022BA0C;
    case 0x0022BA18U:
        goto block_0022BA18;
    case 0x0022BA24U:
        goto block_0022BA24;
    case 0x0022BA30U:
        goto block_0022BA30;
    case 0x0022BA3CU:
        goto block_0022BA3C;
    case 0x0022BA48U:
        goto block_0022BA48;
    case 0x0022BA54U:
        goto block_0022BA54;
    case 0x0022BA8CU:
        goto block_0022BA8C;
    case 0x0022BA94U:
        goto block_0022BA94;
    case 0x0022BA9CU:
        goto block_0022BA9C;
    case 0x0022BAA8U:
        goto block_0022BAA8;
    case 0x0022BAB4U:
        goto block_0022BAB4;
    case 0x0022BAC0U:
        goto block_0022BAC0;
    case 0x0022BACCU:
        goto block_0022BACC;
    case 0x0022BAD8U:
        goto block_0022BAD8;
    case 0x0022BAE4U:
        goto block_0022BAE4;
    case 0x0022BAF0U:
        goto block_0022BAF0;
    case 0x0022BAFCU:
        goto block_0022BAFC;
    case 0x0022BB08U:
        goto block_0022BB08;
    case 0x0022BB14U:
        goto block_0022BB14;
    case 0x0022BB20U:
        goto block_0022BB20;
    case 0x0022BB2CU:
        goto block_0022BB2C;
    case 0x0022BB38U:
        goto block_0022BB38;
    case 0x0022BB40U:
        goto block_0022BB40;
    case 0x0022BB4CU:
        goto block_0022BB4C;
    case 0x0022BB58U:
        goto block_0022BB58;
    case 0x0022BB68U:
        goto block_0022BB68;
    case 0x0022BB74U:
        goto block_0022BB74;
    case 0x0022BB7CU:
        goto block_0022BB7C;
    case 0x0022BB8CU:
        goto block_0022BB8C;
    case 0x0022BB90U:
        goto block_0022BB90;
    case 0x0022BB98U:
        goto block_0022BB98;
    case 0x0022BBA0U:
        goto block_0022BBA0;
    case 0x0022BBA8U:
        goto block_0022BBA8;
    case 0x0022BBB0U:
        goto block_0022BBB0;
    case 0x0022BBB8U:
        goto block_0022BBB8;
    case 0x0022BBC0U:
        goto block_0022BBC0;
    case 0x0022BBC8U:
        goto block_0022BBC8;
    case 0x0022BBD0U:
        goto block_0022BBD0;
    case 0x0022BBD8U:
        goto block_0022BBD8;
    case 0x0022BBE0U:
        goto block_0022BBE0;
    case 0x0022BBF0U:
        goto block_0022BBF0;
    case 0x0022BBFCU:
        goto block_0022BBFC;
    case 0x0022BC08U:
        goto block_0022BC08;
    case 0x0022BC14U:
        goto block_0022BC14;
    case 0x0022BC20U:
        goto block_0022BC20;
    case 0x0022BC2CU:
        goto block_0022BC2C;
    case 0x0022BC34U:
        goto block_0022BC34;
    case 0x0022BC3CU:
        goto block_0022BC3C;
    case 0x0022BC5CU:
        goto block_0022BC5C;
    case 0x0022BC64U:
        goto block_0022BC64;
    case 0x0022BC70U:
        goto block_0022BC70;
    case 0x0022BC7CU:
        goto block_0022BC7C;
    case 0x0022BC88U:
        goto block_0022BC88;
    case 0x0022BC9CU:
        goto block_0022BC9C;
    case 0x0022BCB8U:
        goto block_0022BCB8;
    case 0x0022BCBCU:
        goto block_0022BCBC;
    case 0x0022BCC8U:
        goto block_0022BCC8;
    case 0x0022BCF4U:
        goto block_0022BCF4;
    case 0x0022BD00U:
        goto block_0022BD00;
    case 0x0022BD04U:
        goto block_0022BD04;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0022B71C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B71CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B71CU);
        }
        {
            const uint32_t firstAddress = r13 - 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0022B71CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0022B71CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0022B71CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0022B71CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0022B71CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0022B71CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0022B71CU,
                                           firstAddress + 24U);
            }
            r13 = r13 - 28U;
        }
        {
            r5 = r0;
        }
        {
            const uint32_t operand = 0x00000100U;
            r7 = r0 + operand;
        }
        {
            r4 = r1;
        }
        {
            r6 = 0x00000000U;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0022B730U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0022B730U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0xB2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B738U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r7 + 0xB2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B744U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0xB2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B748U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000027U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0022B764; }
        goto block_0022B758;
    }
block_0022B758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B758U);
        }
        {
            const uint32_t updatedAddress = r7 + 0xACU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B758U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r7 + 0xAEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B760U, address);
            }
        }
        goto block_0022B764;
    }
block_0022B764:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B764U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B764U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B764U, address);
            }
            r2 = value;
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0022B774U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B774U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B774;
    }
block_0022B774:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B774U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B774U);
        }
        {
            const uint32_t address = r5 + 436U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B774U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0022B780U + 736U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B778U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0022B784U + 736U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B77CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B784U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B790U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B790U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B790;
    }
block_0022B790:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B790U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B790U);
        }
        {
            const uint32_t address = r5 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B790U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r9 = 0x00000000U;
        }
        {
            const uint32_t address = r5 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022B798U, address);
            }
        }
        {
            const uint32_t address = r5 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022B79CU, address);
            }
        }
        {
            const uint32_t address = r5 + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B7A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B7A4U, 0xEEB40A48U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_0022B8AC; }
        goto block_0022B7B0;
    }
block_0022B7B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B7B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B7B0U);
        }
        {
            r8 = 0x00000001U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B7BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_MoveForward_00376864(frame, context, state, 0x00376864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B7BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B7BC;
    }
block_0022B7BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B7BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B7BCU);
        }
        {
            const uint32_t updatedAddress = 0x0022B7C4U + 0x2A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B7BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0022B7C8U + 0x2A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B7C0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B7C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B7C8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0022B860; }
        goto block_0022B7D4;
    }
block_0022B7D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B7D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B7D4U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B7D4U, address);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0022B7DCU, address);
            }
        }
        goto block_0022B7E0;
    }
block_0022B7E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B7E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B7E0U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B7E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0022B850; }
        goto block_0022B7F4;
    }
block_0022B7F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B7F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B7F4U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 3U);
            r0 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xAECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B800U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x13CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B808U, address);
            }
            r2 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0022B850; }
        goto block_0022B814;
    }
block_0022B814:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B814U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B814U);
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B814U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B818U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B81CU, 0xEEB40A60U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B824U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) {
            const uint32_t address = r0 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B828U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (flags.Z()) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B82CU, 0x0EB40A60U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        if (flags.Z()) {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B834U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) {
            const uint32_t address = r0 + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B838U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (flags.Z()) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B83CU, 0x0EB40A60U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        if (flags.Z()) {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r9 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022B848U, address);
            }
        }
        if (!(flags.Z())) { goto block_0022B860; }
        goto block_0022B850;
    }
block_0022B850:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B850U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B850U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r1 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000032U, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0022B7E0; }
        goto block_0022B860;
    }
block_0022B860:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B860U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B860U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B860U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r8, 0U, 0U, flags.C());
            r0 = r0 | shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0022B8AC; }
        goto block_0022B86C;
    }
block_0022B86C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B86CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B86CU);
        }
        {
            r2 = 0x0000001DU;
        }
        {
            const uint32_t address = 0x0022B878U + 504U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B870U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0022B87CU + 504U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B874U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r5;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B888U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdateBgCheckInfo_00376340(frame, context, state, 0x00376340U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B888U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B888;
    }
block_0022B888:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B888U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B888U);
        }
        {
            const uint32_t address = r5 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B888U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0022B894U + 0x1E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B88CU, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        if (flags.C()) {
            r0 = r5;
        }
        if (flags.C()) {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0022B8A0U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0022B8A0U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        if (flags.C()) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022B8A4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022B8A4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022B8A4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022B8A4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0022B8A4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0022B8A4U,
                                           firstAddress + 20U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x0022B8A4U,
                                           firstAddress + 24U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r14 = value14;
            r13 = r13 + 28U;
        }
        if (flags.C()) { return Oot3dAotBranch(0x00374428U); }
        goto block_0022B8AC;
    }
block_0022B8AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B8ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B8ACU);
        }
        {
            const uint32_t operand = 0x000001B8U;
            r1 = r5 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B8B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B8B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B8B8;
    }
block_0022B8B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B8B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B8B8U);
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001B8U;
            r2 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B8CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B8CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B8CC;
    }
block_0022B8CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B8CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B8CCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B8CCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000015U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000016U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000017U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000018U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022B908; }
        goto block_0022B8E4;
    }
block_0022B8E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B8E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B8E4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B8E4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B8ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B8ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B8EC;
    }
block_0022B8EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B8ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B8ECU);
        }
        {
            const uint32_t address = 0x0022B8F4U + 392U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B8ECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B8F0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022B8F4U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B8F8U, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.N()) != (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022B900U, 0xBEB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        {
            const uint32_t address = r5 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022B904U, address);
            }
        }
        goto block_0022B908;
    }
block_0022B908:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B908U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B908U);
        }
        {
            const uint32_t updatedAddress = r7 + 0xACU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B908U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0022BD04; }
        goto block_0022B914;
    }
block_0022B914:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B914U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B914U);
        }
        {
            const uint32_t address = r5 + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B914U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0022B920U + 0x160U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B918U, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0022B94C; }
        goto block_0022B928;
    }
block_0022B928:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B928U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B928U);
        }
        {
            const uint32_t address = r5 + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B928U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0022B934U + 0x150U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B92CU, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0022B94C; }
        goto block_0022B93C;
    }
block_0022B93C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B93CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B93CU);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x80000000U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0022B964; }
        goto block_0022B94C;
    }
block_0022B94C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B94CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B94CU);
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B958U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_HasParent_00371E40(frame, context, state, 0x00371E40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B958U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B958;
    }
block_0022B958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B958U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0022BD04; }
        goto block_0022B964;
    }
block_0022B964:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B964U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B964U);
        }
        {
            const uint32_t updatedAddress = 0x0022B96CU + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B964U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B968U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022BD04; }
        goto block_0022B974;
    }
block_0022B974:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B974U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B974U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B974U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000019U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x0022B984U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022B97CU, address);
            }
            switch (value) {
            case 0x0022B71CU:
                goto block_0022B71C;
            case 0x0022B758U:
                goto block_0022B758;
            case 0x0022B764U:
                goto block_0022B764;
            case 0x0022B774U:
                goto block_0022B774;
            case 0x0022B790U:
                goto block_0022B790;
            case 0x0022B7B0U:
                goto block_0022B7B0;
            case 0x0022B7BCU:
                goto block_0022B7BC;
            case 0x0022B7D4U:
                goto block_0022B7D4;
            case 0x0022B7E0U:
                goto block_0022B7E0;
            case 0x0022B7F4U:
                goto block_0022B7F4;
            case 0x0022B814U:
                goto block_0022B814;
            case 0x0022B850U:
                goto block_0022B850;
            case 0x0022B860U:
                goto block_0022B860;
            case 0x0022B86CU:
                goto block_0022B86C;
            case 0x0022B888U:
                goto block_0022B888;
            case 0x0022B8ACU:
                goto block_0022B8AC;
            case 0x0022B8B8U:
                goto block_0022B8B8;
            case 0x0022B8CCU:
                goto block_0022B8CC;
            case 0x0022B8E4U:
                goto block_0022B8E4;
            case 0x0022B8ECU:
                goto block_0022B8EC;
            case 0x0022B908U:
                goto block_0022B908;
            case 0x0022B914U:
                goto block_0022B914;
            case 0x0022B928U:
                goto block_0022B928;
            case 0x0022B93CU:
                goto block_0022B93C;
            case 0x0022B94CU:
                goto block_0022B94C;
            case 0x0022B958U:
                goto block_0022B958;
            case 0x0022B964U:
                goto block_0022B964;
            case 0x0022B974U:
                goto block_0022B974;
            case 0x0022B980U:
                goto block_0022B980;
            case 0x0022B9E8U:
                goto block_0022B9E8;
            case 0x0022B9F4U:
                goto block_0022B9F4;
            case 0x0022BA00U:
                goto block_0022BA00;
            case 0x0022BA0CU:
                goto block_0022BA0C;
            case 0x0022BA18U:
                goto block_0022BA18;
            case 0x0022BA24U:
                goto block_0022BA24;
            case 0x0022BA30U:
                goto block_0022BA30;
            case 0x0022BA3CU:
                goto block_0022BA3C;
            case 0x0022BA48U:
                goto block_0022BA48;
            case 0x0022BA54U:
                goto block_0022BA54;
            case 0x0022BA8CU:
                goto block_0022BA8C;
            case 0x0022BA94U:
                goto block_0022BA94;
            case 0x0022BA9CU:
                goto block_0022BA9C;
            case 0x0022BAA8U:
                goto block_0022BAA8;
            case 0x0022BAB4U:
                goto block_0022BAB4;
            case 0x0022BAC0U:
                goto block_0022BAC0;
            case 0x0022BACCU:
                goto block_0022BACC;
            case 0x0022BAD8U:
                goto block_0022BAD8;
            case 0x0022BAE4U:
                goto block_0022BAE4;
            case 0x0022BAF0U:
                goto block_0022BAF0;
            case 0x0022BAFCU:
                goto block_0022BAFC;
            case 0x0022BB08U:
                goto block_0022BB08;
            case 0x0022BB14U:
                goto block_0022BB14;
            case 0x0022BB20U:
                goto block_0022BB20;
            case 0x0022BB2CU:
                goto block_0022BB2C;
            case 0x0022BB38U:
                goto block_0022BB38;
            case 0x0022BB40U:
                goto block_0022BB40;
            case 0x0022BB4CU:
                goto block_0022BB4C;
            case 0x0022BB58U:
                goto block_0022BB58;
            case 0x0022BB68U:
                goto block_0022BB68;
            case 0x0022BB74U:
                goto block_0022BB74;
            case 0x0022BB7CU:
                goto block_0022BB7C;
            case 0x0022BB8CU:
                goto block_0022BB8C;
            case 0x0022BB90U:
                goto block_0022BB90;
            case 0x0022BB98U:
                goto block_0022BB98;
            case 0x0022BBA0U:
                goto block_0022BBA0;
            case 0x0022BBA8U:
                goto block_0022BBA8;
            case 0x0022BBB0U:
                goto block_0022BBB0;
            case 0x0022BBB8U:
                goto block_0022BBB8;
            case 0x0022BBC0U:
                goto block_0022BBC0;
            case 0x0022BBC8U:
                goto block_0022BBC8;
            case 0x0022BBD0U:
                goto block_0022BBD0;
            case 0x0022BBD8U:
                goto block_0022BBD8;
            case 0x0022BBE0U:
                goto block_0022BBE0;
            case 0x0022BBF0U:
                goto block_0022BBF0;
            case 0x0022BBFCU:
                goto block_0022BBFC;
            case 0x0022BC08U:
                goto block_0022BC08;
            case 0x0022BC14U:
                goto block_0022BC14;
            case 0x0022BC20U:
                goto block_0022BC20;
            case 0x0022BC2CU:
                goto block_0022BC2C;
            case 0x0022BC34U:
                goto block_0022BC34;
            case 0x0022BC3CU:
                goto block_0022BC3C;
            case 0x0022BC5CU:
                goto block_0022BC5C;
            case 0x0022BC64U:
                goto block_0022BC64;
            case 0x0022BC70U:
                goto block_0022BC70;
            case 0x0022BC7CU:
                goto block_0022BC7C;
            case 0x0022BC88U:
                goto block_0022BC88;
            case 0x0022BC9CU:
                goto block_0022BC9C;
            case 0x0022BCB8U:
                goto block_0022BCB8;
            case 0x0022BCBCU:
                goto block_0022BCBC;
            case 0x0022BCC8U:
                goto block_0022BCC8;
            case 0x0022BCF4U:
                goto block_0022BCF4;
            case 0x0022BD00U:
                goto block_0022BD00;
            case 0x0022BD04U:
                goto block_0022BD04;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_0022B980;
    }
block_0022B980:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B980U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B980U);
        }
        goto block_0022BB38;
    }
block_0022B9E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B9E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B9E8U);
        }
        {
            r1 = 0x00000084U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022B9F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022B9F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022B9F4;
    }
block_0022B9F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022B9F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022B9F4U);
        }
        {
        }
        {
        }
        goto block_0022BB38;
    }
block_0022BA00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BA00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BA00U);
        }
        {
            r1 = 0x00000085U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BA0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BA0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BA0C;
    }
block_0022BA0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BA0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BA0CU);
        }
        {
        }
        {
        }
        goto block_0022BB38;
    }
block_0022BA18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BA18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BA18U);
        }
        {
            r1 = 0x00000086U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BA24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BA24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BA24;
    }
block_0022BA24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BA24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BA24U);
        }
        {
        }
        {
        }
        goto block_0022BB38;
    }
block_0022BA30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BA30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BA30U);
        }
        {
            r1 = 0x00000087U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BA3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BA3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BA3C;
    }
block_0022BA3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BA3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BA3CU);
        }
        {
        }
        {
        }
        goto block_0022BB38;
    }
block_0022BA48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BA48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BA48U);
        }
        {
            r1 = 0x00000088U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BA54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BA54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BA54;
    }
block_0022BA54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BA54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BA54U);
        }
        {
        }
        {
        }
        goto block_0022BB38;
    }
block_0022BA8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BA8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BA8CU);
        }
        {
            r6 = 0x00000007U;
        }
        goto block_0022BB40;
    }
block_0022BA94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BA94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BA94U);
        }
        {
            r6 = 0x00000002U;
        }
        goto block_0022BB40;
    }
block_0022BA9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BA9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BA9CU);
        }
        {
            r1 = 0x00000083U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BAA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BAA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BAA8;
    }
block_0022BAA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BAA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BAA8U);
        }
        {
        }
        {
        }
        goto block_0022BB38;
    }
block_0022BAB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BAB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BAB4U);
        }
        {
            r1 = 0x00000070U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BAC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Health_ChangeBy_00352DBC(frame, context, state, 0x00352DBCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BAC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BAC0;
    }
block_0022BAC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BAC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BAC0U);
        }
        {
        }
        {
        }
        goto block_0022BB38;
    }
block_0022BACC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BACCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BACCU);
        }
        {
            r1 = 0x0000008EU;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BAD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BAD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BAD8;
    }
block_0022BAD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BAD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BAD8U);
        }
        {
        }
        {
        }
        goto block_0022BB38;
    }
block_0022BAE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BAE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BAE4U);
        }
        {
            r1 = 0x00000003U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BAF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BAF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BAF0;
    }
block_0022BAF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BAF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BAF0U);
        }
        {
        }
        {
        }
        goto block_0022BB38;
    }
block_0022BAFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BAFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BAFCU);
        }
        {
            r1 = 0x00000092U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BB08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BB08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BB08;
    }
block_0022BB08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB08U);
        }
        {
        }
        {
        }
        goto block_0022BB38;
    }
block_0022BB14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB14U);
        }
        {
            r1 = 0x00000093U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BB20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BB20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BB20;
    }
block_0022BB20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB20U);
        }
        {
        }
        {
        }
        goto block_0022BB38;
    }
block_0022BB2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB2CU);
        }
        {
            r1 = 0x00000094U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BB38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BB38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BB38;
    }
block_0022BB38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB38U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022BB68; }
        goto block_0022BB40;
    }
block_0022BB40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB40U);
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BB4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_HasParent_00371E40(frame, context, state, 0x00371E40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BB4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BB4C;
    }
block_0022BB4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB4CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0022BB68; }
        goto block_0022BB58;
    }
block_0022BB58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB58U);
        }
        {
            r2 = r6;
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BB68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00346778_00346778(frame, context, state, 0x00346778U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BB68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BB68;
    }
block_0022BB68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB68U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022BB68U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000015U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022BBF0; }
        goto block_0022BB74;
    }
block_0022BB74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB74U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0022BBE0; }
        goto block_0022BB7C;
    }
block_0022BB7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB7CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000011U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022BC2C; }
        goto block_0022BB8C;
    }
block_0022BB8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB8CU);
        }
        goto block_0022BBF0;
    }
block_0022BB90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB90U);
        }
        {
            r6 = 0x0000003CU;
        }
        goto block_0022BB40;
    }
block_0022BB98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BB98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BB98U);
        }
        {
            r6 = 0x00000042U;
        }
        goto block_0022BB40;
    }
block_0022BBA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BBA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BBA0U);
        }
        {
            r6 = 0x0000003EU;
        }
        goto block_0022BB40;
    }
block_0022BBA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BBA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BBA8U);
        }
        {
            r6 = 0x0000003DU;
        }
        goto block_0022BB40;
    }
block_0022BBB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BBB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BBB0U);
        }
        {
            r6 = 0x00000044U;
        }
        goto block_0022BB40;
    }
block_0022BBB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BBB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BBB8U);
        }
        {
            r6 = 0x00000043U;
        }
        goto block_0022BB40;
    }
block_0022BBC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BBC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BBC0U);
        }
        {
            r6 = 0x00000029U;
        }
        goto block_0022BB40;
    }
block_0022BBC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BBC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BBC8U);
        }
        {
            r6 = 0x0000002AU;
        }
        goto block_0022BB40;
    }
block_0022BBD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BBD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BBD0U);
        }
        {
            r6 = 0x0000002DU;
        }
        goto block_0022BB40;
    }
block_0022BBD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BBD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BBD8U);
        }
        {
            r6 = 0x0000002CU;
        }
        goto block_0022BB40;
    }
block_0022BBE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BBE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BBE0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000016U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000017U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000018U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022BC2C; }
        goto block_0022BBF0;
    }
block_0022BBF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BBF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BBF0U);
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BBFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_HasParent_00371E40(frame, context, state, 0x00371E40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BBFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BBFC;
    }
block_0022BBFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BBFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BBFCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0022BD00; }
        goto block_0022BC08;
    }
block_0022BC08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BC08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BC08U);
        }
        {
            const uint32_t updatedAddress = r7 + 0xA8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022BC08U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BC14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_SetCollectible_003329D8(frame, context, state, 0x003329D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BC14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BC14;
    }
block_0022BC14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BC14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BC14U);
        }
        {
            r0 = r5;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BC20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BC20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BC20;
    }
block_0022BC20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BC20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BC20U);
        }
        {
        }
        {
        }
        goto block_0022BD00;
    }
block_0022BC2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BC2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BC2CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0022BC3C; }
        goto block_0022BC34;
    }
block_0022BC34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BC34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BC34U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022BC5C; }
        goto block_0022BC3C;
    }
block_0022BC3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BC3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BC3CU);
        }
        {
            const uint32_t updatedAddress = 0x0022BC44U + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022BC3CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0022BC48U + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022BC40U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0022BC4CU + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022BC44U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0022BC4CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        goto block_0022BCB8;
    }
block_0022BC5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BC5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BC5CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022BC9C; }
        goto block_0022BC64;
    }
block_0022BC64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BC64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BC64U);
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BC70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_HasParent_00371E40(frame, context, state, 0x00371E40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BC70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BC70;
    }
block_0022BC70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BC70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BC70U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0022BD04; }
        goto block_0022BC7C;
    }
block_0022BC7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BC7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BC7CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0xA8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022BC7CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BC88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_SetCollectible_003329D8(frame, context, state, 0x003329D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BC88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BC88;
    }
block_0022BC88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BC88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BC88U);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0022BC90U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0022BC90U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022BC94U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022BC94U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022BC94U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022BC94U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0022BC94U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0022BC94U,
                                           firstAddress + 20U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x0022BC94U,
                                           firstAddress + 24U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r14 = value14;
            r13 = r13 + 28U;
        }
        return Oot3dAotBranch(0x00374428U);
    }
block_0022BC9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BC9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BC9CU);
        }
        {
            const uint32_t updatedAddress = 0x0022BCA4U + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022BC9CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0022BCA8U + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022BCA0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0022BCACU + 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022BCA4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0022BCACU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        goto block_0022BCB8;
    }
block_0022BCB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BCB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BCB8U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BCBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BCBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BCBC;
    }
block_0022BCBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BCBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BCBCU);
        }
        {
            const uint32_t updatedAddress = r7 + 0xA8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022BCBCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BCC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_SetCollectible_003329D8(frame, context, state, 0x003329D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BCC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BCC8;
    }
block_0022BCC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BCC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BCC8U);
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r7 + 0xB2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022BCCCU, address);
            }
        }
        {
            r0 = 0x00000023U;
        }
        {
            const uint32_t updatedAddress = r7 + 0xACU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022BCD4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xC0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0022BCD8U, address);
            }
        }
        {
            const uint32_t address = r5 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0022BCDCU, address);
            }
        }
        {
            const uint32_t address = r5 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0022BCE0U, address);
            }
        }
        {
            const uint32_t address = r5 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0022BCE4U, address);
            }
        }
        {
            const uint32_t address = r5 + 436U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022BCE8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022BCF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetScale_0037572C(frame, context, state, 0x0037572CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022BCF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022BCF4;
    }
block_0022BCF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BCF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BCF4U);
        }
        {
            const uint32_t updatedAddress = 0x0022BCFCU + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022BCF4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0xAAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0022BCF8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022BCFCU, address);
            }
        }
        goto block_0022BD00;
    }
block_0022BD00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BD00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BD00U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x214U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0022BD00U, address);
            }
        }
        goto block_0022BD04;
    }
block_0022BD04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022BD04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022BD04U);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0022BD08U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0022BD08U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022BD0CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022BD0CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022BD0CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022BD0CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0022BD0CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0022BD0CU,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0022BD0CU,
                                           firstAddress + 24U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_EnFish_Update_0022E520(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0022E520U:
        goto block_0022E520;
    case 0x0022E570U:
        goto block_0022E570;
    case 0x0022E57CU:
        goto block_0022E57C;
    case 0x0022E584U:
        goto block_0022E584;
    case 0x0022E594U:
        goto block_0022E594;
    case 0x0022E5A4U:
        goto block_0022E5A4;
    case 0x0022E5B4U:
        goto block_0022E5B4;
    case 0x0022E5FCU:
        goto block_0022E5FC;
    case 0x0022E610U:
        goto block_0022E610;
    case 0x0022E62CU:
        goto block_0022E62C;
    case 0x0022E638U:
        goto block_0022E638;
    case 0x0022E640U:
        goto block_0022E640;
    case 0x0022E64CU:
        goto block_0022E64C;
    case 0x0022E6BCU:
        goto block_0022E6BC;
    case 0x0022E6C4U:
        goto block_0022E6C4;
    case 0x0022E6CCU:
        goto block_0022E6CC;
    case 0x0022E6E0U:
        goto block_0022E6E0;
    case 0x0022E6ECU:
        goto block_0022E6EC;
    case 0x0022E6F4U:
        goto block_0022E6F4;
    case 0x0022E700U:
        goto block_0022E700;
    case 0x0022E738U:
        goto block_0022E738;
    case 0x0022E740U:
        goto block_0022E740;
    case 0x0022E754U:
        goto block_0022E754;
    case 0x0022E75CU:
        goto block_0022E75C;
    case 0x0022E778U:
        goto block_0022E778;
    case 0x0022E784U:
        goto block_0022E784;
    case 0x0022E79CU:
        goto block_0022E79C;
    case 0x0022E7CCU:
        goto block_0022E7CC;
    case 0x0022E7D8U:
        goto block_0022E7D8;
    case 0x0022E7E4U:
        goto block_0022E7E4;
    case 0x0022E7F0U:
        goto block_0022E7F0;
    case 0x0022E86CU:
        goto block_0022E86C;
    case 0x0022E8A0U:
        goto block_0022E8A0;
    case 0x0022E92CU:
        goto block_0022E92C;
    case 0x0022E958U:
        goto block_0022E958;
    case 0x0022E9A4U:
        goto block_0022E9A4;
    case 0x0022E9B4U:
        goto block_0022E9B4;
    case 0x0022E9C4U:
        goto block_0022E9C4;
    case 0x0022E9E0U:
        goto block_0022E9E0;
    case 0x0022E9ECU:
        goto block_0022E9EC;
    case 0x0022E9F8U:
        goto block_0022E9F8;
    case 0x0022EA00U:
        goto block_0022EA00;
    case 0x0022EA0CU:
        goto block_0022EA0C;
    case 0x0022EA10U:
        goto block_0022EA10;
    case 0x0022EA1CU:
        goto block_0022EA1C;
    case 0x0022EA24U:
        goto block_0022EA24;
    case 0x0022EA60U:
        goto block_0022EA60;
    case 0x0022EA7CU:
        goto block_0022EA7C;
    case 0x0022EA9CU:
        goto block_0022EA9C;
    case 0x0022EAC8U:
        goto block_0022EAC8;
    case 0x0022EB44U:
        goto block_0022EB44;
    case 0x0022EB50U:
        goto block_0022EB50;
    case 0x0022EB58U:
        goto block_0022EB58;
    case 0x0022EB64U:
        goto block_0022EB64;
    case 0x0022EB70U:
        goto block_0022EB70;
    case 0x0022EB7CU:
        goto block_0022EB7C;
    case 0x0022EB84U:
        goto block_0022EB84;
    case 0x0022EB90U:
        goto block_0022EB90;
    case 0x0022EBA8U:
        goto block_0022EBA8;
    case 0x0022EBBCU:
        goto block_0022EBBC;
    case 0x0022EBD0U:
        goto block_0022EBD0;
    case 0x0022EBE0U:
        goto block_0022EBE0;
    case 0x0022EBECU:
        goto block_0022EBEC;
    case 0x0022EBF8U:
        goto block_0022EBF8;
    case 0x0022EC08U:
        goto block_0022EC08;
    case 0x0022EC1CU:
        goto block_0022EC1C;
    case 0x0022EC54U:
        goto block_0022EC54;
    case 0x0022EC64U:
        goto block_0022EC64;
    case 0x0022EC7CU:
        goto block_0022EC7C;
    case 0x0022EC8CU:
        goto block_0022EC8C;
    case 0x0022ECA8U:
        goto block_0022ECA8;
    case 0x0022ECD8U:
        goto block_0022ECD8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0022E520:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E520U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E520U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0022E520U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0022E520U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0022E520U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0022E520U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0022E520U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0022E520U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0022E520U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0022E520U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0022E520U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r7 = r1;
        }
        {
            const uint32_t operand = 0x00002000U;
            r5 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000500U;
            r6 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0022E53CU + 0x398U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E534U, address);
            }
            r9 = value;
        }
        {
            const uint32_t updatedAddress = 0x0022E540U + 0x3B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E538U, address);
            }
            r10 = value;
        }
        {
            r8 = 0x00000000U;
        }
        {
            r13 -= 32U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0022E540U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0022E540U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0022E540U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0022E540U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0022E540U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0022E540U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0022E540U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0022E540U,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E548U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0022E554U + 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E54CU, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x0022E558U + 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E550U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x0022E55CU + 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E554U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x0022E560U + 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E558U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0022E564U + 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E55CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x0022E568U + 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E560U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x0022E56CU + 904U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E564U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0022E638; }
        goto block_0022E570;
    }
block_0022E570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E570U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E570U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022E9B4; }
        goto block_0022E57C;
    }
block_0022E57C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E57CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E57CU);
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E584U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_22a0_0037571C(frame, context, state, 0x0037571CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E584U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E584;
    }
block_0022E584:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E584U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E584U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x2E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E588U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0022E62C; }
        goto block_0022E594;
    }
block_0022E594:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E594U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E594U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E594U, address);
            }
            r0 = value;
        }
        {
            r11 = r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022E638; }
        goto block_0022E5A4;
    }
block_0022E5A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E5A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E5A4U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            r0 = r11;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0022E5ACU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E5B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetScale_0037572C(frame, context, state, 0x0037572CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E5B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E5B4;
    }
block_0022E5B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E5B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E5B4U);
        }
        {
            const uint32_t updatedAddress = 0x0022E5BCU + 0x33CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E5B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0022E5C0U + 832U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E5B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r11 + 0x140U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022E5C0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0022E5CCU + 0x330U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E5C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0022E5C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022E5CCU, address);
            }
        }
        {
            r0 = 0x00004000U;
        }
        {
            const uint32_t updatedAddress = r11 + 0xC0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022E5D4U, address);
            }
        }
        {
            const uint32_t address = r11 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022E5D8U, address);
            }
        }
        {
            const uint32_t address = 0x0022E5E4U + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E5DCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r9 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022E5E0U, address);
            }
        }
        {
            const uint32_t address = r9 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0022E5E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E5E8U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022E5F0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000214U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E5FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AnimationResource_GetLastFrameByIndex_0036AE18(frame, context, state, 0x0036AE18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E5FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E5FC;
    }
block_0022E5FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E5FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E5FCU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x244U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E600U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E608U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (flags.Z()) { goto block_0022E62C; }
        goto block_0022E610;
    }
block_0022E610:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E610U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E610U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t address = 0x0022E624U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E61CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x00000214U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E62CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E62CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E62C;
    }
block_0022E62C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E62CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E62CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E62CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0022E9B4; }
        goto block_0022E638;
    }
block_0022E638:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E638U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E638U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r4, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0022E9B4; }
        goto block_0022E640;
    }
block_0022E640:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E640U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E640U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E640U, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022E6CC; }
        goto block_0022E64C;
    }
block_0022E64C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E64CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E64CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E64CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E650U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E658U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E660U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E664U, 0xEE201A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E670U, 0xEE410A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E674U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[1];
        }
        {
            const uint32_t operand = r2;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0xE0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0022E680U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E684U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r6 + 0xE2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E688U, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E690U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E694U, 0xEE600A8BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0022E6A0U + 620U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E698U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E69CU, 0xEE000AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E6A0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0xE2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022E6ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E6B0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022E6EC; }
        goto block_0022E6BC;
    }
block_0022E6BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E6BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E6BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022E7D8; }
        goto block_0022E6C4;
    }
block_0022E6C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E6C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E6C4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022E8A0; }
        goto block_0022E6CC;
    }
block_0022E6CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E6CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E6CCU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0022E6CCU, address);
            }
        }
        {
            const uint32_t address = r9 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0022E6D0U, address);
            }
        }
        {
            const uint32_t address = r9 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0022E6D4U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E6E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E6E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E6E0;
    }
block_0022E6E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E6E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E6E0U);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E4U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E4U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E4U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E4U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E4U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E4U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E4U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E4U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E8U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E8U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E8U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E8U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E8U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E8U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E8U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0022E6E8U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_0022E6EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E6ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E6ECU);
        }
        {
            const uint32_t updatedAddress = r6 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E6ECU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E6F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E6F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E6F4;
    }
block_0022E6F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E6F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E6F4U);
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r6 + 0xE2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E6F8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E700U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E700U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E700;
    }
block_0022E700:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E700U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E700U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E700U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[21] = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E70CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E714U, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r9 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E718U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E71CU, 0xEE201A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r9 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E720U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E724U, 0xEE410A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[1];
        }
        {
            const uint32_t address = r9 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0022E72CU, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0022E784; }
        goto block_0022E738;
    }
block_0022E738:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E738U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E738U);
        }
        {
            const uint32_t address = r9 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0022E738U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E740U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E740U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E740;
    }
block_0022E740:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E740U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E740U);
        }
        {
            const uint32_t updatedAddress = 0x0022E748U + 0x1C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E740U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t address = r9 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0022E74CU, address);
            }
        }
        if ((flags.N()) == (flags.V())) { goto block_0022E79C; }
        goto block_0022E754;
    }
block_0022E754:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E754U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E754U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E75CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E75CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E75C;
    }
block_0022E75C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E75CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E75CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = 0x0022E768U + 428U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E760U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = 0x0022E76CU + 0x1ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E764U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E76CU, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r9 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0022E770U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E778U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E778U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E778;
    }
block_0022E778:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E778U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E778U);
        }
        {
        }
        {
        }
        goto block_0022E79C;
    }
block_0022E784:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E784U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E784U);
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            const uint32_t address = 0x0022E790U + 396U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E788U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E78CU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E790U, 0xEE600A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E794U, 0xEE000AE9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r9 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022E798U, address);
            }
        }
        goto block_0022E79C;
    }
block_0022E79C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E79CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E79CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E79CU, 0xEE3A0A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[20], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E7A0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000214U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E7ACU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E7B0U, 0xEE009A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E7B8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E7BCU, 0xEE290A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E7C0U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 596U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022E7C4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E7CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E7CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E7CC;
    }
block_0022E7CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E7CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E7CCU);
        }
        {
        }
        {
        }
        goto block_0022E8A0;
    }
block_0022E7D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E7D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E7D8U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E7D8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r8 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E7E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E7E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E7E4;
    }
block_0022E7E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E7E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E7E4U);
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r6 + 0xE2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E7E8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E7F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E7F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E7F0;
    }
block_0022E7F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E7F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E7F0U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E7F0U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[21] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x0022E800U + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E7F8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E800U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E804U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E80CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E810U, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E818U, 0xEE000AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0022E824U + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E81CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E820U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = r2;
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0022E82CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E830U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r8 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E834U, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E83CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E840U, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E848U, 0xEE000AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[22];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E850U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0xC0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022E860U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0022E86CU + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E864U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E86CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_StepToF_003705A0(frame, context, state, 0x003705A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E86CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E86C;
    }
block_0022E86C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E86CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E86CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E870U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000214U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E87CU, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E880U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E884U, 0xEE009A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E88CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E890U, 0xEE290A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E894U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 596U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022E898U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E8A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E8A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E8A0;
    }
block_0022E8A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E8A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E8A0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E8A0U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E8A8U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E8ACU, 0xEEB88AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E8B4U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E8B8U, 0xEEF88AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E8C0U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E8C4U, 0xEEB89AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E8CCU, 0xEEB8AAC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        goto block_0022E92C;
    }
block_0022E92C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E92CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E92CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E92CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E930U, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E938U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E93CU, 0xEEF8AAC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = 0x0022E94CU + 0x3B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E944U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r7;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E948U, address);
            }
            r2 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E94CU, 0xEEF89AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E950U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E958U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Environment_LerpWeight_00361490(frame, context, state, 0x00361490U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E958U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E958;
    }
block_0022E958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E958U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E958U, 0xEE7A0A48U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[20], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E95CU, 0xEE3A1AE8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[21], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000028U;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000007CU;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E974U, 0xEE008A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[16], frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0022E978U, address);
            }
        }
        {
            const uint32_t address = r9 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E97CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E980U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E984U, 0xEE700AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0022E988U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E98CU, 0xEE790AC9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[19], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022E990U, 0xEE009A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[18], frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0022E994U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0022E998U, address);
            }
        }
        {
            r3 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022E9A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BgCheck_EntityRaycastFloor4_0036E81C(frame, context, state, 0x0036E81CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022E9A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022E9A4;
    }
block_0022E9A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E9A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E9A4U);
        }
        {
            const uint32_t address = r4 + 132U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022E9A4U, address);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0022E9ACU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0022E9ACU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0022E9ACU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0022E9ACU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022E9ACU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022E9ACU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022E9ACU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022E9ACU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022E9B0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022E9B0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022E9B0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022E9B0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0022E9B0U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0022E9B0U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0022E9B0U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0022E9B0U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0022E9B0U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_0022E9B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E9B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E9B4U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xDEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E9B4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0022E9C0U + 832U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E9B8U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0022EAC8; }
        goto block_0022E9C4;
    }
block_0022E9C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E9C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E9C4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0xDEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022E9C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E9CCU, address);
            }
            r2 = value;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022EC08; }
        goto block_0022E9E0;
    }
block_0022E9E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E9E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E9E0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E9E0U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0022EA00; }
        goto block_0022E9EC;
    }
block_0022E9EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E9ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E9ECU);
        }
        {
            const uint32_t updatedAddress = r2 + 0x13CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022E9ECU, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0022EA00; }
        goto block_0022E9F8;
    }
block_0022E9F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022E9F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022E9F8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r4, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x128U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0022E9FCU, address);
            }
        }
        goto block_0022EA00;
    }
block_0022EA00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EA00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EA00U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x5D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EA00U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022EA1C; }
        goto block_0022EA0C;
    }
block_0022EA0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EA0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EA0CU);
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0022EA10U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022EA10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022EA10;
    }
block_0022EA10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EA10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EA10U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x13CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EA10U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022E6E0; }
        goto block_0022EA1C;
    }
block_0022EA1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EA1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EA1CU);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022EA24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_MoveForward_00376864(frame, context, state, 0x00376864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022EA24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022EA24;
    }
block_0022EA24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EA24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EA24U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EA24U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000110U;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EA2CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r6 + 0xDEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EA30U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EA38U, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0022EA44U + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EA3CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EA40U, 0xEEC00A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EA44U, 0xEE700AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EA48U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0022EA5CU - 0x164U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EA54U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x140U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022EA58U, address);
            }
        }
        if (flags.Z()) { goto block_0022E6E0; }
        goto block_0022EA60;
    }
block_0022EA60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EA60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EA60U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        if (flags.Z()) {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        if (flags.Z()) {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0022EA6CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0022EA6CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0022EA6CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0022EA6CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022EA6CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022EA6CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022EA6CU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022EA6CU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022EA74U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022EA74U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022EA74U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022EA74U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0022EA74U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0022EA74U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0022EA74U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0022EA74U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x0022EA74U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r14 = value14;
            r13 = r13 + 36U;
        }
        if (flags.Z()) { return Oot3dAotBranch(0x0037572CU); }
        goto block_0022EA7C;
    }
block_0022EA7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EA7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EA7CU);
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EA80U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EA84U, 0xEE800A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EA88U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EA8CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0022E6E0; }
        goto block_0022EA9C;
    }
block_0022EA9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EA9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EA9CU);
        }
        {
            const uint32_t address = r4 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EA9CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0022EAA8U + 0x260U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EAA0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EAA8U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0022EAB8U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0022EAB8U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0022EAB8U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0022EAB8U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022EAB8U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022EAB8U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022EAB8U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022EAB8U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022EAC0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022EAC0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022EAC0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022EAC0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0022EAC0U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0022EAC0U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0022EAC0U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0022EAC0U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x0022EAC0U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r14 = value14;
            r13 = r13 + 36U;
        }
        return Oot3dAotBranch(0x0037572CU);
    }
block_0022EAC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EAC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EAC8U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xDCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EAC8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r6 + 0xDCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022EAD4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EAD8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EADCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EAE4U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EAECU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EAF0U, 0xEE201A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EAFCU, 0xEE410A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EB00U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[1];
        }
        {
            const uint32_t operand = r2;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0xE0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0022EB0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EB10U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r6 + 0xE2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EB14U, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EB1CU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EB20U, 0xEE600A8BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EB24U, 0xEE000AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EB28U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0xE2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022EB34U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EB38U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0022EB58; }
        goto block_0022EB44;
    }
block_0022EB44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EB44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EB44U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x13CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EB44U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0022EB58; }
        goto block_0022EB50;
    }
block_0022EB50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EB50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EB50U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r4, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x128U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0022EB54U, address);
            }
        }
        goto block_0022EB58;
    }
block_0022EB58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EB58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EB58U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x5D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EB58U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022EB7C; }
        goto block_0022EB64;
    }
block_0022EB64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EB64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EB64U);
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0022EB70U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022EB70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022EB70;
    }
block_0022EB70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EB70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EB70U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x13CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EB70U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022E6E0; }
        goto block_0022EB7C;
    }
block_0022EB7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EB7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EB7CU);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022EB84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_MoveForward_00376864(frame, context, state, 0x00376864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022EB84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022EB84;
    }
block_0022EB84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EB84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EB84U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x5E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EB84U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022EBA8; }
        goto block_0022EB90;
    }
block_0022EB90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EB90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EB90U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0022EB9CU + 368U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EB94U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0022EBA0U + 368U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EB98U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r4;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022EBA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdateBgCheckInfo_00376340(frame, context, state, 0x00376340U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022EBA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022EBA8;
    }
block_0022EBA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EBA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EBA8U);
        }
        {
            const uint32_t address = r4 + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EBA8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0022EBB4U + 0x160U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EBACU, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0022EBD0; }
        goto block_0022EBBC;
    }
block_0022EBBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EBBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EBBCU);
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r7 + operand;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022EBD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022EBD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022EBD0;
    }
block_0022EBD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EBD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EBD0U);
        }
        {
            const uint32_t address = r4 + 196U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EBD0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EBD8U, 0xEE200A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022EBE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetFocus_0037322C(frame, context, state, 0x0037322CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022EBE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022EBE0;
    }
block_0022EBE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EBE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EBE0U);
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022EBECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_HasParent_00371E40(frame, context, state, 0x00371E40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022EBECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022EBEC;
    }
block_0022EBEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EBECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EBECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_0022EC64; }
        goto block_0022EBF8;
    }
block_0022EBF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EBF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EBF8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x124U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0022EBF8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EBFCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022EC1C; }
        goto block_0022EC08;
    }
block_0022EC08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EC08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EC08U);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0022EC10U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0022EC10U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0022EC10U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0022EC10U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022EC10U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022EC10U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022EC10U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022EC10U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022EC14U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022EC14U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022EC14U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022EC14U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0022EC14U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0022EC14U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0022EC14U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0022EC14U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x0022EC14U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r14 = value14;
            r13 = r13 + 36U;
        }
        return Oot3dAotBranch(0x00374428U);
    }
block_0022EC1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EC1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EC1CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EC1CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0022EC28U + 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EC20U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EC28U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EC30U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EC34U, 0xEE800A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EC38U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EC3CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r6 + 0xDEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022EC48U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022EC54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetScale_0037572C(frame, context, state, 0x0037572CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022EC54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022EC54;
    }
block_0022EC54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EC54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EC54U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x140U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0022EC54U, address);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0022EC5CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0022EC5CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0022EC5CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0022EC5CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022EC5CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022EC5CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022EC5CU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022EC5CU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022EC60U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022EC60U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022EC60U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022EC60U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0022EC60U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0022EC60U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0022EC60U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0022EC60U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0022EC60U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_0022EC64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EC64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EC64U);
        }
        {
            const uint32_t address = r4 + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EC64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EC68U, address);
            }
            r5 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            r6 = r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x42000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0022E6E0; }
        goto block_0022EC7C;
    }
block_0022EC7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EC7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EC7CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EC7CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00008000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022EC8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022EC8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022EC8C;
    }
block_0022EC8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022EC8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022EC8CU);
        }
        {
            const uint32_t address = r5 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EC8CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0022EC98U + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EC90U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022EC94U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022EC98U, 0xEE008A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00008000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022ECA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022ECA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022ECA8;
    }
block_0022ECA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022ECA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022ECA8U);
        }
        {
            const uint32_t address = r5 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022ECA8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = 0x0022ECB4U + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022ECACU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022ECB0U, 0xEE001A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022ECB4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022ECB8U, 0xEE780A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022ECBCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022ECC0U, 0xEE310A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022ECC4U, 0xEE600AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022ECC8U, 0xEE400A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0022E6E0; }
        goto block_0022ECD8;
    }
block_0022ECD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022ECD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022ECD8U);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        {
            r1 = r7;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0022ECE0U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0022ECE0U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0022ECE0U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0022ECE0U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022ECE0U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022ECE0U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022ECE0U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022ECE0U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            r0 = r4;
        }
        {
            r2 = 0x0000007EU;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022ECECU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022ECECU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0022ECECU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0022ECECU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0022ECECU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0022ECECU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0022ECECU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0022ECECU,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x0022ECECU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r14 = value14;
            r13 = r13 + 36U;
        }
        {
            const uint32_t address = 0x0022ECF8U + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022ECF0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0022ECFCU + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022ECF4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        return Oot3dAotBranch(0x003724DCU);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Inventory_ChangeUpgrade_0033C730(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r8 = state.R[8];
    uint32_t& r12 = state.R[12];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0033C730U:
        goto block_0033C730;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0033C730:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033C730U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033C730U);
        }
        {
            const uint32_t updatedAddress = 0x0033C738U + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033C730U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0033C73CU + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033C734U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033C738U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r12 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033C73CU, address);
            }
            r12 = value;
        }
        {
            r2 = r2 & r12;
        }
        {
            const uint32_t updatedAddress = 0x0033C74CU + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033C744U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r12 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033C748U, address);
            }
            r0 = value;
        }
        {
            r0 = r2 | Oot3dAotShiftRegister(r1, 0U, r0, false).Value;
        }
        {
            const uint32_t updatedAddress = r3 + 0xB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0033C750U, address);
            }
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Message_QueueTextRequest_003716F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003716F0U:
        goto block_003716F0;
    case 0x00371704U:
        goto block_00371704;
    case 0x00371710U:
        goto block_00371710;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003716F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003716F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003716F0U);
        }
        {
            const uint32_t operand = 0x00005C00U;
            r12 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 - 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x003716F4U, address);
            }
            r13 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r12 + 0x32U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003716F8U, address);
            }
            r4 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00371710; }
        goto block_00371704;
    }
block_00371704:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00371704U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00371704U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = r13;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00371704U, address);
            }
            r4 = value;
            r13 = updatedAddress;
        }
        {
            r0 = 0x00000000U;
        }
        return Oot3dAotReturned(r14);
    }
block_00371710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00371710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00371710U);
        }
        {
            const uint32_t operand = 0x00005000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00371714U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xC2DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00371718U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xC76U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0037171CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = r13;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00371720U, address);
            }
            r4 = value;
            r13 = updatedAddress;
        }
        {
            r0 = 0x00000001U;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Actor_HasParent_00371E40(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r4 = state.R[4];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00371E40U:
        goto block_00371E40;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00371E40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00371E40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00371E40U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x124U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00371E40U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Actor_MoveForward_00376864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00376864U:
        goto block_00376864;
    case 0x00376874U:
        goto block_00376874;
    case 0x00376888U:
        goto block_00376888;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00376864:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376864U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376864U);
        }
        {
            const uint32_t firstAddress = r13 - 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00376864U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00376864U,
                                           firstAddress + 4U);
            }
            r13 = r13 - 8U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t updatedAddress = r0 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037686CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00376874U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376874U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376874;
    }
block_00376874:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376874U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376874U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376874U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00376878U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0037687CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376880U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00376888U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376888U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376888;
    }
block_00376888:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376888U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376888U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376888U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x00376894U + 0x9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037688CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00376890U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0037689CU + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376894U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 104U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00376898U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037689CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003768A0U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003768A8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003768B0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003768B4U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003768B8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003768BCU, 0xEE410A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003768C0U, address);
            }
        }
        {
            const uint32_t address = r4 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003768C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003768C8U, 0xEEF40AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x003768DCU + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003768D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003768D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003768DCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r4 + 164U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003768E0U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            const uint32_t address = r4 + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003768E4U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            frame.Guest.vfp[3] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003768ECU, 0xEEF81AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003768F0U, 0xEE210A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003768F4U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003768F8U, 0xEE711AA2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[3], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003768FCU, 0xEE421A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[4], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x00376900U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376904U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r4 + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376908U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0037690CU, 0xEE711A82U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[3], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00376910U, 0xEE401A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x00376914U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376918U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037691CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00376920U, 0xEE700AA1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00376924U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00376928U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0037692CU,
                                           firstAddress + 0U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0037692CU,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r13 = r13 + 8U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Item_Give_00376A78(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00376A78U:
        goto block_00376A78;
    case 0x00376A98U:
        goto block_00376A98;
    case 0x00376AACU:
        goto block_00376AAC;
    case 0x00376ACCU:
        goto block_00376ACC;
    case 0x00376AD4U:
        goto block_00376AD4;
    case 0x00376AE0U:
        goto block_00376AE0;
    case 0x00376B00U:
        goto block_00376B00;
    case 0x00376B18U:
        goto block_00376B18;
    case 0x00376B24U:
        goto block_00376B24;
    case 0x00376B30U:
        goto block_00376B30;
    case 0x00376B48U:
        goto block_00376B48;
    case 0x00376B54U:
        goto block_00376B54;
    case 0x00376B64U:
        goto block_00376B64;
    case 0x00376B78U:
        goto block_00376B78;
    case 0x00376B80U:
        goto block_00376B80;
    case 0x00376BA0U:
        goto block_00376BA0;
    case 0x00376BB8U:
        goto block_00376BB8;
    case 0x00376BD4U:
        goto block_00376BD4;
    case 0x00376BF4U:
        goto block_00376BF4;
    case 0x00376C10U:
        goto block_00376C10;
    case 0x00376C18U:
        goto block_00376C18;
    case 0x00376C38U:
        goto block_00376C38;
    case 0x00376C44U:
        goto block_00376C44;
    case 0x00376C54U:
        goto block_00376C54;
    case 0x00376C60U:
        goto block_00376C60;
    case 0x00376C6CU:
        goto block_00376C6C;
    case 0x00376C90U:
        goto block_00376C90;
    case 0x00376C9CU:
        goto block_00376C9C;
    case 0x00376CB0U:
        goto block_00376CB0;
    case 0x00376CC8U:
        goto block_00376CC8;
    case 0x00376CE0U:
        goto block_00376CE0;
    case 0x00376CE8U:
        goto block_00376CE8;
    case 0x00376D04U:
        goto block_00376D04;
    case 0x00376D48U:
        goto block_00376D48;
    case 0x00376D58U:
        goto block_00376D58;
    case 0x00376D64U:
        goto block_00376D64;
    case 0x00376D78U:
        goto block_00376D78;
    case 0x00376DB4U:
        goto block_00376DB4;
    case 0x00376DBCU:
        goto block_00376DBC;
    case 0x00376DC4U:
        goto block_00376DC4;
    case 0x00376DD0U:
        goto block_00376DD0;
    case 0x00376DE0U:
        goto block_00376DE0;
    case 0x00376DE8U:
        goto block_00376DE8;
    case 0x00376DF4U:
        goto block_00376DF4;
    case 0x00376E00U:
        goto block_00376E00;
    case 0x00376E08U:
        goto block_00376E08;
    case 0x00376E14U:
        goto block_00376E14;
    case 0x00376E20U:
        goto block_00376E20;
    case 0x00376E28U:
        goto block_00376E28;
    case 0x00376E34U:
        goto block_00376E34;
    case 0x00376E38U:
        goto block_00376E38;
    case 0x00376E40U:
        goto block_00376E40;
    case 0x00376E68U:
        goto block_00376E68;
    case 0x00376E78U:
        goto block_00376E78;
    case 0x00376E84U:
        goto block_00376E84;
    case 0x00376E9CU:
        goto block_00376E9C;
    case 0x00376ED0U:
        goto block_00376ED0;
    case 0x00376ED4U:
        goto block_00376ED4;
    case 0x00376EDCU:
        goto block_00376EDC;
    case 0x00376EE8U:
        goto block_00376EE8;
    case 0x00376EF4U:
        goto block_00376EF4;
    case 0x00376EFCU:
        goto block_00376EFC;
    case 0x00376F08U:
        goto block_00376F08;
    case 0x00376F0CU:
        goto block_00376F0C;
    case 0x00376F10U:
        goto block_00376F10;
    case 0x00376F18U:
        goto block_00376F18;
    case 0x00376F20U:
        goto block_00376F20;
    case 0x00376F38U:
        goto block_00376F38;
    case 0x00376F44U:
        goto block_00376F44;
    case 0x00376F4CU:
        goto block_00376F4C;
    case 0x00376F60U:
        goto block_00376F60;
    case 0x00376F68U:
        goto block_00376F68;
    case 0x00376F6CU:
        goto block_00376F6C;
    case 0x00376F74U:
        goto block_00376F74;
    case 0x00376F80U:
        goto block_00376F80;
    case 0x00376F88U:
        goto block_00376F88;
    case 0x00376F8CU:
        goto block_00376F8C;
    case 0x00376F94U:
        goto block_00376F94;
    case 0x00376FA0U:
        goto block_00376FA0;
    case 0x00376FA8U:
        goto block_00376FA8;
    case 0x00376FACU:
        goto block_00376FAC;
    case 0x00376FB0U:
        goto block_00376FB0;
    case 0x00376FB4U:
        goto block_00376FB4;
    case 0x00376FB8U:
        goto block_00376FB8;
    case 0x00376FC8U:
        goto block_00376FC8;
    case 0x00376FE8U:
        goto block_00376FE8;
    case 0x00376FF4U:
        goto block_00376FF4;
    case 0x00376FFCU:
        goto block_00376FFC;
    case 0x0037701CU:
        goto block_0037701C;
    case 0x00377020U:
        goto block_00377020;
    case 0x00377028U:
        goto block_00377028;
    case 0x00377038U:
        goto block_00377038;
    case 0x00377058U:
        goto block_00377058;
    case 0x00377064U:
        goto block_00377064;
    case 0x0037706CU:
        goto block_0037706C;
    case 0x0037708CU:
        goto block_0037708C;
    case 0x00377090U:
        goto block_00377090;
    case 0x00377098U:
        goto block_00377098;
    case 0x003770A0U:
        goto block_003770A0;
    case 0x003770D0U:
        goto block_003770D0;
    case 0x003770D4U:
        goto block_003770D4;
    case 0x003770F0U:
        goto block_003770F0;
    case 0x00377100U:
        goto block_00377100;
    case 0x0037710CU:
        goto block_0037710C;
    case 0x0037711CU:
        goto block_0037711C;
    case 0x00377150U:
        goto block_00377150;
    case 0x00377168U:
        goto block_00377168;
    case 0x00377178U:
        goto block_00377178;
    case 0x00377184U:
        goto block_00377184;
    case 0x00377194U:
        goto block_00377194;
    case 0x003771C8U:
        goto block_003771C8;
    case 0x003771D0U:
        goto block_003771D0;
    case 0x003771E8U:
        goto block_003771E8;
    case 0x003771F8U:
        goto block_003771F8;
    case 0x00377204U:
        goto block_00377204;
    case 0x0037720CU:
        goto block_0037720C;
    case 0x00377214U:
        goto block_00377214;
    case 0x00377244U:
        goto block_00377244;
    case 0x00377250U:
        goto block_00377250;
    case 0x00377260U:
        goto block_00377260;
    case 0x0037726CU:
        goto block_0037726C;
    case 0x00377284U:
        goto block_00377284;
    case 0x003772B4U:
        goto block_003772B4;
    case 0x003772BCU:
        goto block_003772BC;
    case 0x003772C4U:
        goto block_003772C4;
    case 0x003772F8U:
        goto block_003772F8;
    case 0x003772FCU:
        goto block_003772FC;
    case 0x00377308U:
        goto block_00377308;
    case 0x00377340U:
        goto block_00377340;
    case 0x00377348U:
        goto block_00377348;
    case 0x00377360U:
        goto block_00377360;
    case 0x00377378U:
        goto block_00377378;
    case 0x00377390U:
        goto block_00377390;
    case 0x00377394U:
        goto block_00377394;
    case 0x003773A0U:
        goto block_003773A0;
    case 0x003773BCU:
        goto block_003773BC;
    case 0x003773D0U:
        goto block_003773D0;
    case 0x003773ECU:
        goto block_003773EC;
    case 0x003773F4U:
        goto block_003773F4;
    case 0x00377400U:
        goto block_00377400;
    case 0x0037744CU:
        goto block_0037744C;
    case 0x00377454U:
        goto block_00377454;
    case 0x0037745CU:
        goto block_0037745C;
    case 0x00377468U:
        goto block_00377468;
    case 0x00377470U:
        goto block_00377470;
    case 0x0037747CU:
        goto block_0037747C;
    case 0x0037748CU:
        goto block_0037748C;
    case 0x00377494U:
        goto block_00377494;
    case 0x003774B8U:
        goto block_003774B8;
    case 0x003774F0U:
        goto block_003774F0;
    case 0x003774F4U:
        goto block_003774F4;
    case 0x003774FCU:
        goto block_003774FC;
    case 0x00377534U:
        goto block_00377534;
    case 0x00377540U:
        goto block_00377540;
    case 0x0037754CU:
        goto block_0037754C;
    case 0x00377560U:
        goto block_00377560;
    case 0x00377568U:
        goto block_00377568;
    case 0x00377598U:
        goto block_00377598;
    case 0x003775A0U:
        goto block_003775A0;
    case 0x003775A8U:
        goto block_003775A8;
    case 0x003775C4U:
        goto block_003775C4;
    case 0x003775D8U:
        goto block_003775D8;
    case 0x003775F0U:
        goto block_003775F0;
    case 0x003775FCU:
        goto block_003775FC;
    case 0x00377604U:
        goto block_00377604;
    case 0x0037760CU:
        goto block_0037760C;
    case 0x00377614U:
        goto block_00377614;
    case 0x00377630U:
        goto block_00377630;
    case 0x00377638U:
        goto block_00377638;
    case 0x00377658U:
        goto block_00377658;
    case 0x00377688U:
        goto block_00377688;
    case 0x003776B0U:
        goto block_003776B0;
    case 0x003776BCU:
        goto block_003776BC;
    case 0x003776C8U:
        goto block_003776C8;
    case 0x003776D8U:
        goto block_003776D8;
    case 0x003776E4U:
        goto block_003776E4;
    case 0x003776E8U:
        goto block_003776E8;
    case 0x003776F0U:
        goto block_003776F0;
    case 0x003776FCU:
        goto block_003776FC;
    case 0x00377708U:
        goto block_00377708;
    case 0x00377718U:
        goto block_00377718;
    case 0x00377724U:
        goto block_00377724;
    case 0x00377730U:
        goto block_00377730;
    case 0x0037773CU:
        goto block_0037773C;
    case 0x00377748U:
        goto block_00377748;
    case 0x00377768U:
        goto block_00377768;
    case 0x00377770U:
        goto block_00377770;
    case 0x00377784U:
        goto block_00377784;
    case 0x00377790U:
        goto block_00377790;
    case 0x00377798U:
        goto block_00377798;
    case 0x003777A4U:
        goto block_003777A4;
    case 0x003777ACU:
        goto block_003777AC;
    case 0x003777B8U:
        goto block_003777B8;
    case 0x003777BCU:
        goto block_003777BC;
    case 0x003777C8U:
        goto block_003777C8;
    case 0x003777D0U:
        goto block_003777D0;
    case 0x003777E0U:
        goto block_003777E0;
    case 0x003777F0U:
        goto block_003777F0;
    case 0x00377804U:
        goto block_00377804;
    case 0x00377820U:
        goto block_00377820;
    case 0x00377838U:
        goto block_00377838;
    case 0x00377850U:
        goto block_00377850;
    case 0x00377864U:
        goto block_00377864;
    case 0x00377870U:
        goto block_00377870;
    case 0x00377880U:
        goto block_00377880;
    case 0x00377884U:
        goto block_00377884;
    case 0x00377894U:
        goto block_00377894;
    case 0x0037789CU:
        goto block_0037789C;
    case 0x003778A8U:
        goto block_003778A8;
    case 0x003778B4U:
        goto block_003778B4;
    case 0x003778C0U:
        goto block_003778C0;
    case 0x003778C8U:
        goto block_003778C8;
    case 0x003778D4U:
        goto block_003778D4;
    case 0x003778F8U:
        goto block_003778F8;
    case 0x003778FCU:
        goto block_003778FC;
    case 0x0037790CU:
        goto block_0037790C;
    case 0x0037791CU:
        goto block_0037791C;
    case 0x00377924U:
        goto block_00377924;
    case 0x00377930U:
        goto block_00377930;
    case 0x00377940U:
        goto block_00377940;
    case 0x00377944U:
        goto block_00377944;
    case 0x0037794CU:
        goto block_0037794C;
    case 0x00377990U:
        goto block_00377990;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00376A78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376A78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376A78U);
        }
        {
            const uint32_t firstAddress = r13 - 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00376A78U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00376A78U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00376A78U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00376A78U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00376A78U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00376A78U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00376A78U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00376A78U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00376A78U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00376A78U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00376A78U,
                                           firstAddress + 40U);
            }
            r13 = r13 - 44U;
        }
        {
            const uint32_t operand = 0x00000034U;
            r13 = r13 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000008AU, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        {
            r4 = r1;
        }
        {
            const uint32_t updatedAddress = 0x00376A90U + 0xF18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376A88U, address);
            }
            r9 = value;
        }
        {
            const uint32_t updatedAddress = r9 + r1;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376A8CU, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x00376A90U, address);
            }
        }
        if (!(flags.C())) { goto block_00376AAC; }
        goto block_00376A98;
    }
block_00376A98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376A98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376A98U);
        }
        {
            const uint32_t updatedAddress = 0x00376AA0U + 0xF0CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376A98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xECU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376AA4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r9 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376AA8U, address);
            }
            r7 = value;
        }
        goto block_00376AAC;
    }
block_00376AAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376AACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376AACU);
        }
        {
            const uint32_t updatedAddress = 0x00376AB4U + 0xEFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376AACU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376AB4U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            r0 = r0 | 0x00000800U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + 0x3D0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376ABCU, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_00376AD4; }
        goto block_00376ACC;
    }
block_00376ACC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376ACCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376ACCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000082U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00376AE0; }
        goto block_00376AD4;
    }
block_00376AD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376AD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376AD4U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376AD4U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00002000U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x3D0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376ADCU, address);
            }
        }
        goto block_00376AE0;
    }
block_00376AE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376AE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376AE0U);
        }
        {
            const uint32_t updatedAddress = 0x00376AE8U + 0xED0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376AE0U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = 0x00376AECU + 0xEC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376AE4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000066U;
            r2 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t updatedAddress = r8 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376AF0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00376AF8U, address);
            }
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00376B24; }
        goto block_00376B00;
    }
block_00376B00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376B00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376B00U);
        }
        {
            const uint32_t updatedAddress = r0 - 0x198U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376B00U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000068U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r0 = r0 | r3;
        }
        {
            const uint32_t updatedAddress = r8 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376B0CU, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376B10U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x00376B18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_WaterMedallion_MoveHorse_004BD9A8(frame, context, state, 0x004BD9A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376B18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376B18;
    }
block_00376B18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376B18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376B18U);
        }
        {
        }
        {
        }
        goto block_00376C54;
    }
block_00376B24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376B24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376B24U);
        }
        {
            const uint32_t operand = 0x0000005AU;
            r2 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00376B48; }
        goto block_00376B30;
    }
block_00376B30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376B30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376B30U);
        }
        {
            const uint32_t updatedAddress = r0 - 0x150U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376B30U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | r3;
        }
        {
            const uint32_t updatedAddress = r8 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376B38U, address);
            }
        }
        {
            const uint32_t operand = 0x0000003CU;
            r13 = r13 + operand;
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00376B44U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00376B44U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00376B44U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00376B44U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00376B44U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00376B44U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00376B44U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00376B44U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00376B44U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_00376B48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376B48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376B48U);
        }
        {
            const uint32_t operand = 0x0000006CU;
            r2 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00376B64; }
        goto block_00376B54;
    }
block_00376B54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376B54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376B54U);
        }
        {
            const uint32_t updatedAddress = r0 - 0x168U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376B54U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | r3;
        }
        {
            const uint32_t updatedAddress = r8 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376B5CU, address);
            }
        }
        goto block_00376C54;
    }
block_00376B64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376B64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376B64U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000006FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000070U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 - 0x168U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376B6CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            r0 = r0 | r3;
        }
        if (flags.Z()) { goto block_00377604; }
        goto block_00376B78;
    }
block_00376B78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376B78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376B78U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000071U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376BA0; }
        goto block_00376B80;
    }
block_00376B80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376B80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376B80U);
        }
        {
            const uint32_t updatedAddress = 0x00376B88U + 0xE2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376B80U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376B84U, address);
            }
            r1 = value;
        }
        {
            r0 = r3 | r1;
        }
        {
            const uint32_t updatedAddress = r8 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376B8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xE8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376B90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376B98U, address);
            }
        }
        goto block_00376C54;
    }
block_00376BA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376BA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376BA0U);
        }
        {
            const uint32_t updatedAddress = 0x00376BA8U + 0xE10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376BA0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00376BACU + 0xE10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376BA4U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x0000003BU;
            r12 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t updatedAddress = r2 + 0xB6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376BB0U, address);
            }
            r2 = value;
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00376C38; }
        goto block_00376BB8;
    }
block_00376BB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376BB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376BB8U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376BB8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 - 0xECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376BBCU, address);
            }
            r0 = value;
        }
        {
            r0 = r2 | Oot3dAotShiftRegister(r0, 0U, r1, false).Value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000003DU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r8 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376BCCU, address);
            }
        }
        if (!(flags.Z())) { goto block_00376C10; }
        goto block_00376BD4;
    }
block_00376BD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376BD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376BD4U);
        }
        {
            const uint32_t updatedAddress = 0x00376BDCU + 0xDE4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376BD4U, address);
            }
            r3 = value;
        }
        {
            r2 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r8 + 0x4AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00376BDCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376BE0U, address);
            }
            r3 = value;
        }
        {
            r3 = r3 & r0;
        }
        {
            r3 = Oot3dAotShiftRegister(r3, 1U, r1, false).Value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376C54; }
        goto block_00376BF4;
    }
block_00376BF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376BF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376BF4U);
        }
        {
            r0 = r0 ^ Oot3dAotShiftRegister(r2, 0U, r1, false).Value;
        }
        {
            const uint32_t updatedAddress = r8 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376BF8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x80U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376BFCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000055U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x0000003DU;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376C08U, address);
            }
        }
        goto block_00376C54;
    }
block_00376C10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376C10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376C10U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376C54; }
        goto block_00376C18;
    }
block_00376C18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376C18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376C18U);
        }
        {
            r0 = 0x0000003CU;
        }
        {
            const uint32_t updatedAddress = r8 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376C1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x8AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376C20U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x0000000FU);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r0 = value;
        }
        {
            r0 = r0 | 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r8 + 0x8AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376C30U, address);
            }
        }
        goto block_00376C54;
    }
block_00376C38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376C38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376C38U);
        }
        {
            const uint32_t operand = 0x0000003EU;
            r12 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00376C60; }
        goto block_00376C44;
    }
block_00376C44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376C44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376C44U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376C44U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 - 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376C48U, address);
            }
            r0 = value;
        }
        {
            r0 = r2 | Oot3dAotShiftRegister(r0, 0U, r1, false).Value;
        }
        {
            const uint32_t updatedAddress = r8 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376C50U, address);
            }
        }
        goto block_00376C54;
    }
block_00376C54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376C54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376C54U);
        }
        {
            const uint32_t operand = 0x0000003CU;
            r13 = r13 + operand;
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00376C5CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00376C5CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00376C5CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00376C5CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00376C5CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00376C5CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00376C5CU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00376C5CU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00376C5CU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_00376C60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376C60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376C60U);
        }
        {
            const uint32_t operand = 0x00000041U;
            r12 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00376C90; }
        goto block_00376C6C;
    }
block_00376C6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376C6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376C6CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000043U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376C70U, address);
            }
            r12 = value;
        }
        if (flags.Z()) {
            r12 = r12 | 0x00000200U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + 0x3D0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x00376C78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376C7CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 - 0x104U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376C80U, address);
            }
            r0 = value;
        }
        {
            r0 = r2 | Oot3dAotShiftRegister(r0, 0U, r1, false).Value;
        }
        {
            const uint32_t updatedAddress = r8 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376C88U, address);
            }
        }
        goto block_00376C54;
    }
block_00376C90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376C90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376C90U);
        }
        {
            const uint32_t operand = 0x00000044U;
            r12 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00376CB0; }
        goto block_00376C9C;
    }
block_00376C9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376C9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376C9CU);
        }
        {
            const uint32_t updatedAddress = r3 + 0x3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376C9CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 - 0x110U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376CA0U, address);
            }
            r0 = value;
        }
        {
            r0 = r2 | Oot3dAotShiftRegister(r0, 0U, r1, false).Value;
        }
        {
            const uint32_t updatedAddress = r8 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376CA8U, address);
            }
        }
        goto block_00376C54;
    }
block_00376CB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376CB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376CB0U);
        }
        {
            const uint32_t updatedAddress = 0x00376CB8U + 0xD0CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376CB0U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000074U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000075U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000076U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r2 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376CC0U, address);
            }
            r3 = value;
        }
        if (!(flags.Z())) { goto block_00376CE0; }
        goto block_00376CC8;
    }
block_00376CC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376CC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376CC8U);
        }
        {
            const uint32_t updatedAddress = 0x00376CD0U + 0xCF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376CC8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 - 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376CCCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r3 + r1;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376CD0U, address);
            }
            r2 = value;
        }
        {
            r0 = r0 | r2;
        }
        {
            const uint32_t updatedAddress = r3 + r1;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376CD8U, address);
            }
        }
        goto block_00376C54;
    }
block_00376CE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376CE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376CE0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000077U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00376D04; }
        goto block_00376CE8;
    }
block_00376CE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376CE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376CE8U);
        }
        {
            const uint32_t updatedAddress = 0x00376CF0U + 0xCDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376CE8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r3 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376CECU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        if ((flags.N()) != (flags.V())) {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r3 + r0;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00376CFCU, address);
            }
        }
        goto block_00376C54;
    }
block_00376D04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376D04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376D04U);
        }
        {
            const uint32_t updatedAddress = 0x00376D0CU + 0xCC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D04U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00376D10U + 0xCC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D08U, address);
            }
            r11 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000004AU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D14U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = 0x00376D20U + 0xCB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D18U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D1CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00376D28U + 0xC90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D20U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x00376D24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00376D28U, address);
            }
        }
        {
            const uint32_t operand = 0x0000008CU;
            r6 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D30U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x000000A6U;
            r5 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00376D40U + 0xC68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D38U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D3CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376D40U, address);
            }
        }
        if (!(flags.Z())) { goto block_00376DBC; }
        goto block_00376D48;
    }
block_00376D48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376D48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376D48U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D48U, address);
            }
            r0 = value;
        }
        {
            r1 = r3 & r12;
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r1, 2U, r0, flags.C());
            r0 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00376D78; }
        goto block_00376D58;
    }
block_00376D58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376D58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376D58U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00376D64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376D64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376D64;
    }
block_00376D64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376D64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376D64U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D64U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00376D6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D70U, address);
            }
            r1 = value;
        }
        goto block_0037748C;
    }
block_00376D78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376D78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376D78U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D78U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D7CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D80U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376D8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D90U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D94U, address);
            }
            r1 = value;
        }
        {
            r2 = r2 & r1;
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376D9CU, address);
            }
            r1 = value;
        }
        {
            r2 = Oot3dAotShiftRegister(r2, 2U, r1, false).Value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r1 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376DA8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_00377990; }
        goto block_00376DB4;
    }
block_00376DB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376DB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376DB4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376DB4U, address);
            }
            r0 = value;
        }
        goto block_0037720C;
    }
block_00376DBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376DBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376DBCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376DE0; }
        goto block_00376DC4;
    }
block_00376DC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376DC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376DC4U);
        }
        {
            r1 = 0x00000002U;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00376DD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376DD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376DD0;
    }
block_00376DD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376DD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376DD0U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376DD0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376DD4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376DD8U, address);
            }
        }
        goto block_00376C54;
    }
block_00376DE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376DE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376DE0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000004CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376E00; }
        goto block_00376DE8;
    }
block_00376DE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376DE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376DE8U);
        }
        {
            r1 = 0x00000003U;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00376DF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376DF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376DF4;
    }
block_00376DF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376DF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376DF4U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376DF4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376DF8U, address);
            }
            r1 = value;
        }
        goto block_00376F10;
    }
block_00376E00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376E00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376E00U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000048U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376E20; }
        goto block_00376E08;
    }
block_00376E08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376E08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376E08U);
        }
        {
            r1 = 0x00000002U;
        }
        {
            r0 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00376E14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376E14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376E14;
    }
block_00376E14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376E14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376E14U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376E14U, address);
            }
            r0 = value;
        }
        {
        }
        goto block_00376E38;
    }
block_00376E20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376E20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376E20U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000049U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376E40; }
        goto block_00376E28;
    }
block_00376E28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376E28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376E28U);
        }
        {
            r1 = 0x00000003U;
        }
        {
            r0 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00376E34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376E34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376E34;
    }
block_00376E34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376E34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376E34U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x2EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376E34U, address);
            }
            r0 = value;
        }
        goto block_00376E38;
    }
block_00376E38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376E38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376E38U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376E38U, address);
            }
            r1 = value;
        }
        goto block_00376F10;
    }
block_00376E40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376E40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376E40U);
        }
        {
            const uint32_t updatedAddress = 0x00376E48U + 0xB88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376E40U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00376E4CU + 0xB88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376E44U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = 0x00376E50U + 0xB58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376E48U, address);
            }
            r14 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000004DU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376E50U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376E54U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376E58U, address);
            }
        }
        {
            const uint32_t updatedAddress = r14 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376E5CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x00376E60U, address);
            }
        }
        if (!(flags.Z())) { goto block_00376ED4; }
        goto block_00376E68;
    }
block_00376E68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376E68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376E68U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376E68U, address);
            }
            r1 = value;
        }
        {
            r2 = r3 & r1;
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r2, 2U, r12, flags.C());
            r1 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r1, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00376E9C; }
        goto block_00376E78;
    }
block_00376E78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376E78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376E78U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00376E84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376E84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376E84;
    }
block_00376E84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376E84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376E84U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376E84U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00376E8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376E90U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00376E94U, address);
            }
        }
        goto block_00376C54;
    }
block_00376E9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376E9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376E9CU);
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376E9CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00376EA8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376EACU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376EB0U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & r3;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376EB8U, address);
            }
            r3 = value;
        }
        {
            r3 = Oot3dAotShiftRegister(r1, 2U, r3, false).Value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r1 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376EC4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_00377990; }
        goto block_00376ED0;
    }
block_00376ED0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376ED0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376ED0U);
        }
        goto block_0037720C;
    }
block_00376ED4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376ED4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376ED4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000004EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376EF4; }
        goto block_00376EDC;
    }
block_00376EDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376EDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376EDCU);
        }
        {
            r1 = 0x00000002U;
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00376EE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376EE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376EE8;
    }
block_00376EE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376EE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376EE8U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376EE8U, address);
            }
            r0 = value;
        }
        {
        }
        goto block_00376F0C;
    }
block_00376EF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376EF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376EF4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000004FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376F18; }
        goto block_00376EFC;
    }
block_00376EFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376EFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376EFCU);
        }
        {
            r1 = 0x00000003U;
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00376F08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376F08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376F08;
    }
block_00376F08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F08U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376F08U, address);
            }
            r0 = value;
        }
        goto block_00376F0C;
    }
block_00376F0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F0CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376F0CU, address);
            }
            r1 = value;
        }
        goto block_00376F10;
    }
block_00376F10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F10U);
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376F10U, address);
            }
        }
        goto block_00376C54;
    }
block_00376F18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F18U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000050U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376F44; }
        goto block_00376F20;
    }
block_00376F20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F20U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376F20U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00000080U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x3D0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376F28U, address);
            }
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x00000002U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00376F38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376F38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376F38;
    }
block_00376F38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F38U);
        }
        {
        }
        {
        }
        goto block_00376C54;
    }
block_00376F44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F44U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000051U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376F60; }
        goto block_00376F4C;
    }
block_00376F4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F4CU);
        }
        {
            const uint32_t updatedAddress = r1 + 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376F4CU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00000100U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x3D0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376F54U, address);
            }
        }
        {
            r1 = 0x00000002U;
        }
        goto block_00376F6C;
    }
block_00376F60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F60U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000052U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376F74; }
        goto block_00376F68;
    }
block_00376F68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F68U);
        }
        {
            r1 = 0x00000003U;
        }
        goto block_00376F6C;
    }
block_00376F6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F6CU);
        }
        {
            r0 = 0x00000002U;
        }
        goto block_00376FB0;
    }
block_00376F74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F74U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000053U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r1 = 0x00000001U;
        }
        if (flags.Z()) { goto block_00376F8C; }
        goto block_00376F80;
    }
block_00376F80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F80U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000054U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376F94; }
        goto block_00376F88;
    }
block_00376F88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F88U);
        }
        {
            r1 = 0x00000002U;
        }
        goto block_00376F8C;
    }
block_00376F8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F8CU);
        }
        {
            r0 = 0x00000003U;
        }
        goto block_00376FB0;
    }
block_00376F94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376F94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376F94U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000056U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r1 = 0x00000001U;
        }
        if (flags.Z()) { goto block_00376FAC; }
        goto block_00376FA0;
    }
block_00376FA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376FA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376FA0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000057U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376FB8; }
        goto block_00376FA8;
    }
block_00376FA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376FA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376FA8U);
        }
        {
            r1 = 0x00000002U;
        }
        goto block_00376FAC;
    }
block_00376FAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376FACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376FACU);
        }
        {
            r0 = 0x00000004U;
        }
        goto block_00376FB0;
    }
block_00376FB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376FB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376FB0U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00376FB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376FB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376FB4;
    }
block_00376FB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376FB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376FB4U);
        }
        goto block_00376C54;
    }
block_00376FB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376FB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376FB8U);
        }
        {
            const uint32_t updatedAddress = 0x00376FC0U + 0x9E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376FB8U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000098U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376FC0U, address);
            }
            r3 = value;
        }
        if (!(flags.Z())) { goto block_00376FF4; }
        goto block_00376FC8;
    }
block_00376FC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376FC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376FC8U);
        }
        {
            const uint32_t operand = r7;
            r0 = r8 + operand;
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376FD0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r3 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00376FDCU, address);
            }
        }
        {
            r0 = 0x00000006U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00376FE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00376FE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00376FE8;
    }
block_00376FE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376FE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376FE8U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x34U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376FE8U, address);
            }
            r0 = value;
        }
        {
        }
        goto block_00377020;
    }
block_00376FF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376FF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376FF4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000099U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00377028; }
        goto block_00376FFC;
    }
block_00376FFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376FFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376FFCU);
        }
        {
            const uint32_t operand = r7;
            r0 = r8 + operand;
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377004U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r3 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377010U, address);
            }
        }
        {
            r0 = 0x00000006U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0037701CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0037701CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0037701C;
    }
block_0037701C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037701CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037701CU);
        }
        {
            const uint32_t updatedAddress = r11 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037701CU, address);
            }
            r0 = value;
        }
        goto block_00377020;
    }
block_00377020:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377020U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377020U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377020U, address);
            }
            r1 = value;
        }
        goto block_00376F10;
    }
block_00377028:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377028U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377028U);
        }
        {
            const uint32_t updatedAddress = 0x00377030U + 0x978U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377028U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000009AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r12 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377030U, address);
            }
            r12 = value;
        }
        if (!(flags.Z())) { goto block_00377064; }
        goto block_00377038;
    }
block_00377038:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377038U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377038U);
        }
        {
            const uint32_t operand = r7;
            r0 = r8 + operand;
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377040U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000001U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r12 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0037704CU, address);
            }
        }
        {
            r0 = 0x00000007U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00377058U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00377058U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00377058;
    }
block_00377058:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377058U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377058U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377058U, address);
            }
            r0 = value;
        }
        {
        }
        goto block_00377090;
    }
block_00377064:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377064U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377064U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000009BU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00377098; }
        goto block_0037706C;
    }
block_0037706C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037706CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037706CU);
        }
        {
            const uint32_t operand = r7;
            r0 = r8 + operand;
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377074U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000001U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r12 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377080U, address);
            }
        }
        {
            r0 = 0x00000007U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0037708CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0037708CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0037708C;
    }
block_0037708C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037708CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037708CU);
        }
        {
            const uint32_t updatedAddress = r11 + 0x3EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037708CU, address);
            }
            r0 = value;
        }
        goto block_00377090;
    }
block_00377090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377090U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377090U, address);
            }
            r1 = value;
        }
        goto block_00376F10;
    }
block_00377098:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377098U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377098U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003770D4; }
        goto block_003770A0;
    }
block_003770A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003770A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003770A0U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xBU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003770A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x003770A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x81U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003770A8U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x0000000BU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x81U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003770B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x82U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003770B8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x82U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003770C0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x83U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003770C4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376C54; }
        goto block_003770D0;
    }
block_003770D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003770D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003770D0U);
        }
        goto block_00377598;
    }
block_003770D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003770D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003770D4U);
        }
        {
            const uint32_t updatedAddress = 0x003770DCU + 0x8F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003770D4U, address);
            }
            r14 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r14 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003770DCU, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = 0x003770E8U + 0x8ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003770E0U, address);
            }
            r14 = value;
        }
        {
            const uint32_t updatedAddress = r14 + 0x6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003770E4U, address);
            }
            r14 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x003770E8U, address);
            }
        }
        if (!(flags.Z())) { goto block_00377150; }
        goto block_003770F0;
    }
block_003770F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003770F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003770F0U);
        }
        {
            const uint32_t operand = r7;
            r0 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003770F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0037711C; }
        goto block_00377100;
    }
block_00377100:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377100U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377100U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x00000006U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0037710CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0037710CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0037710C;
    }
block_0037710C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037710CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037710CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037710CU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377114U, address);
            }
        }
        goto block_00377990;
    }
block_0037711C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037711CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037711CU);
        }
        {
            const uint32_t updatedAddress = r3 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037711CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r3 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377128U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037712CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377130U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & r2;
        }
        {
            r2 = Oot3dAotShiftRegister(r1, 2U, r14, false).Value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r1 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377140U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r3 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00377148U, address);
            }
        }
        goto block_00377990;
    }
block_00377150:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377150U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377150U);
        }
        {
            const uint32_t updatedAddress = 0x00377158U + 0x884U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377150U, address);
            }
            r10 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000008AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000008BU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r10 = r10 + operand;
        }
        {
            const uint32_t operand = 0x00000200U;
            r10 = r10 - operand;
        }
        if (!(flags.Z())) { goto block_003771D0; }
        goto block_00377168;
    }
block_00377168:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377168U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377168U);
        }
        {
            const uint32_t operand = r7;
            r0 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037716CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00377194; }
        goto block_00377178;
    }
block_00377178:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377178U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377178U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x00000006U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00377184U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00377184U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00377184;
    }
block_00377184:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377184U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377184U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377184U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0xECU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377188U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0037718CU, address);
            }
        }
        goto block_003771C8;
    }
block_00377194:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377194U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377194U);
        }
        {
            const uint32_t updatedAddress = r3 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377194U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0xECU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377198U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r3 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003771A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003771A8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003771ACU, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & r2;
        }
        {
            r2 = Oot3dAotShiftRegister(r1, 2U, r14, false).Value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r1 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003771BCU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r3 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003771C4U, address);
            }
        }
        goto block_003771C8;
    }
block_003771C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003771C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003771C8U);
        }
        {
            r4 = 0x00000000U;
        }
        goto block_00377990;
    }
block_003771D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003771D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003771D0U);
        }
        {
            const uint32_t updatedAddress = 0x003771D8U + 0x7F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003771D0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x003771DCU + 0x7F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003771D4U, address);
            }
            r14 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r3 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003771DCU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r14 + 0x7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003771E0U, address);
            }
            r14 = value;
        }
        if (!(flags.Z())) { goto block_00377244; }
        goto block_003771E8;
    }
block_003771E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003771E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003771E8U);
        }
        {
            const uint32_t operand = r7;
            r0 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003771ECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00377214; }
        goto block_003771F8;
    }
block_003771F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003771F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003771F8U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x00000007U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00377204U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00377204U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00377204;
    }
block_00377204:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377204U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377204U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377204U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000001U;
        }
        goto block_0037720C;
    }
block_0037720C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037720CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037720CU);
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0037720CU, address);
            }
        }
        goto block_00377990;
    }
block_00377214:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377214U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377214U);
        }
        {
            const uint32_t updatedAddress = r12 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377214U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r12 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377220U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377224U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & r3;
        }
        {
            r1 = Oot3dAotShiftRegister(r1, 2U, r14, false).Value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r1 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377234U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r12 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0037723CU, address);
            }
        }
        goto block_00377990;
    }
block_00377244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377244U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000008CU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000008DU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003772BC; }
        goto block_00377250;
    }
block_00377250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377250U);
        }
        {
            const uint32_t operand = r7;
            r0 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377254U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00377284; }
        goto block_00377260;
    }
block_00377260:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377260U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377260U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x00000007U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0037726CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0037726CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0037726C;
    }
block_0037726C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037726CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037726CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037726CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0xE8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377270U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377274U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r2;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0037727CU, address);
            }
        }
        goto block_003772B4;
    }
block_00377284:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377284U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377284U);
        }
        {
            const uint32_t updatedAddress = r12 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377284U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0xE8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377288U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r12 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377294U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377298U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & r3;
        }
        {
            r1 = Oot3dAotShiftRegister(r1, 2U, r14, false).Value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r1 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003772A8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r12 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003772B0U, address);
            }
        }
        goto block_003772B4;
    }
block_003772B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003772B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003772B4U);
        }
        {
            r4 = 0x00000001U;
        }
        goto block_00377990;
    }
block_003772BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003772BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003772BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003772FC; }
        goto block_003772C4;
    }
block_003772C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003772C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003772C4U);
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003772C4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003772D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003772D4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003772D8U, address);
            }
            r3 = value;
        }
        {
            r3 = r3 & r2;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003772E0U, address);
            }
            r2 = value;
        }
        {
            r2 = Oot3dAotShiftRegister(r3, 2U, r2, false).Value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r2 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003772ECU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00376C54; }
        goto block_003772F8;
    }
block_003772F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003772F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003772F8U);
        }
        goto block_00377340;
    }
block_003772FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003772FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003772FCU);
        }
        {
            const uint32_t operand = 0x0000008EU;
            r3 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00377348; }
        goto block_00377308;
    }
block_00377308:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377308U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377308U);
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377308U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0xE4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037730CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = r2;
            r1 = r1 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00377318U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037731CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377320U, address);
            }
            r3 = value;
        }
        {
            r3 = r3 & r2;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377328U, address);
            }
            r2 = value;
        }
        {
            r2 = Oot3dAotShiftRegister(r3, 2U, r2, false).Value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r2 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377334U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00376C54; }
        goto block_00377340;
    }
block_00377340:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377340U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377340U);
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00377340U, address);
            }
        }
        goto block_00376C54;
    }
block_00377348:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377348U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377348U);
        }
        {
            const uint32_t updatedAddress = 0x00377350U + 0x658U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377348U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000009U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            r12 = 0x00000009U;
        }
        {
            r3 = 0x00000032U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377358U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_00377394; }
        goto block_00377360;
    }
block_00377360:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377360U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377360U);
        }
        {
            const uint32_t operand = r7;
            r1 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377364U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r1 = 0x0000000AU;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x00377370U, address);
            }
        }
        if (flags.Z()) { goto block_0037748C; }
        goto block_00377378;
    }
block_00377378:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377378U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377378U);
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377378U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x0000000AU;
            r1 = r1 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000032U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00377388U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00376C54; }
        goto block_00377390;
    }
block_00377390:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377390U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377390U);
        }
        goto block_003773EC;
    }
block_00377394:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377394U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377394U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000096U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000097U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003773F4; }
        goto block_003773A0;
    }
block_003773A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003773A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003773A0U);
        }
        {
            const uint32_t operand = r7;
            r1 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003773A4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x003773B0U + 0x630U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003773A8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000200U;
            r1 = r1 - operand;
        }
        if (!(flags.Z())) { goto block_003773D0; }
        goto block_003773BC;
    }
block_003773BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003773BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003773BCU);
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x003773BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003773C0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003773C4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r2;
            r1 = r1 + operand;
        }
        goto block_0037748C;
    }
block_003773D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003773D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003773D0U);
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003773D0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003773D4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r2;
            r1 = r1 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000032U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003773E4U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00376C54; }
        goto block_003773EC;
    }
block_003773EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003773ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003773ECU);
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003773ECU, address);
            }
        }
        goto block_00376C54;
    }
block_003773F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003773F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003773F4U);
        }
        {
            const uint32_t operand = 0x00000092U;
            r0 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00377468; }
        goto block_00377400;
    }
block_00377400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377400U);
        }
        {
            const uint32_t updatedAddress = 0x00377408U + 0x5DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377400U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377404U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000200U;
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377410U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xDCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377414U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377418U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r2;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377424U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377428U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037742CU, address);
            }
            r1 = value;
        }
        {
            r2 = r2 & r1;
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377434U, address);
            }
            r1 = value;
        }
        {
            r2 = Oot3dAotShiftRegister(r2, 2U, r1, false).Value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r1 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377440U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00377454; }
        goto block_0037744C;
    }
block_0037744C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037744CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037744CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0037745C; }
        goto block_00377454;
    }
block_00377454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377454U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377454U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00377458U, address);
            }
        }
        goto block_0037745C;
    }
block_0037745C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037745CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037745CU);
        }
        {
            const uint32_t operand = 0x0000003CU;
            r13 = r13 + operand;
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00377464U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00377464U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00377464U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00377464U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00377464U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00377464U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00377464U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00377464U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00377464U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_00377468:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377468U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377468U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00377494; }
        goto block_00377470;
    }
block_00377470:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377470U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377470U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0037747CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Inventory_ChangeUpgrade_0033C730(frame, context, state, 0x0033C730U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0037747CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0037747C;
    }
block_0037747C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037747CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037747CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037747CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00377484U, address);
            }
        }
        {
            r1 = 0x0000001EU;
        }
        goto block_0037748C;
    }
block_0037748C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037748CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037748CU);
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0037748CU, address);
            }
        }
        goto block_00376C54;
    }
block_00377494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377494U);
        }
        {
            const uint32_t updatedAddress = 0x0037749CU + 0x534U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377494U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003774A0U + 0x548U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377498U, address);
            }
            r10 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000058U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003774A0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x003774ACU + 0x528U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003774A4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x5U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003774A8U, address);
            }
            r14 = value;
        }
        {
            const uint32_t updatedAddress = 0x003774B4U + 0x4F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003774ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003774B0U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_003774F4; }
        goto block_003774B8;
    }
block_003774B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003774B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003774B8U);
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003774B8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000005U;
            r1 = r1 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003774C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003774C8U, address);
            }
            r2 = value;
        }
        {
            r2 = r2 & r3;
        }
        {
            r3 = Oot3dAotShiftRegister(r2, 2U, r14, false).Value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r2 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x28U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003774D8U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003774E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003774E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000008U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00377540; }
        goto block_003774F0;
    }
block_003774F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003774F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003774F0U);
        }
        goto block_00377534;
    }
block_003774F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003774F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003774F4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000095U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0037754C; }
        goto block_003774FC;
    }
block_003774FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003774FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003774FCU);
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003774FCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x0000001EU;
            r1 = r1 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00377508U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037750CU, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & r3;
        }
        {
            r3 = Oot3dAotShiftRegister(r1, 2U, r14, false).Value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r1 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x28U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037751CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00377524U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377528U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000008U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00377540; }
        goto block_00377534;
    }
block_00377534:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377534U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377534U);
        }
        {
            r0 = r0 | 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r10 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377538U, address);
            }
        }
        goto block_00376C54;
    }
block_00377540:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377540U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377540U);
        }
        {
            const uint32_t operand = 0x0000003CU;
            r13 = r13 + operand;
        }
        {
            r0 = 0x00000058U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00377548U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00377548U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00377548U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00377548U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00377548U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00377548U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00377548U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00377548U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00377548U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_0037754C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037754CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037754CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r9 + 0x7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377550U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = 0x00000007U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377558U, address);
            }
        }
        if (flags.Z()) { goto block_00376C54; }
        goto block_00377560;
    }
block_00377560:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377560U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377560U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003775A0; }
        goto block_00377568;
    }
block_00377568:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377568U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377568U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377568U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r1 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377570U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x81U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377574U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000007U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x81U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0037757CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x82U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377580U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000007U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x82U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377588U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x83U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037758CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00376C54; }
        goto block_00377598;
    }
block_00377598:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377598U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377598U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x83U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377598U, address);
            }
        }
        goto block_00376C54;
    }
block_003775A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003775A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003775A0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000010U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003775F0; }
        goto block_003775A8;
    }
block_003775A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003775A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003775A8U);
        }
        {
            const uint32_t operand = r7;
            r0 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003775ACU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x003775B8U + 0x3F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003775B0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r0 + 0x11U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003775B8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003775BCU, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_003775D8; }
        goto block_003775C4;
    }
block_003775C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003775C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003775C4U);
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x003775C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003775CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003775D0U, address);
            }
        }
        goto block_00376C54;
    }
block_003775D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003775D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003775D8U);
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003775D8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003775E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003775E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        goto block_00376F10;
    }
block_003775F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003775F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003775F0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000007AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000073U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0037760C; }
        goto block_003775FC;
    }
block_003775FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003775FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003775FCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003775FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x10000000U;
            r0 = r0 + operand;
        }
        goto block_00377604;
    }
block_00377604:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377604U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377604U);
        }
        {
            const uint32_t updatedAddress = r8 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377604U, address);
            }
        }
        goto block_00376C54;
    }
block_0037760C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037760CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037760CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000072U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00377630; }
        goto block_00377614;
    }
block_00377614:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377614U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377614U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377614U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0x42U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0037761CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377620U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377628U, address);
            }
        }
        goto block_00376C54;
    }
block_00377630:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377630U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377630U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000083U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00377688; }
        goto block_00377638;
    }
block_00377638:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377638U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377638U);
        }
        {
            const uint32_t updatedAddress = 0x00377640U + 0x3ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377638U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00377644U + 0x3ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037763CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00377648U + 0x3ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377640U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00377648U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00377658U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00377658U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00377658;
    }
block_00377658:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377658U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377658U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377658U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377664U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377668U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = r1;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r8 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377678U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r8 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377680U, address);
            }
        }
        goto block_00377730;
    }
block_00377688:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377688U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377688U);
        }
        {
            const uint32_t updatedAddress = 0x00377690U + 0x328U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377688U, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000078U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r5 + 0x50U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377690U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377694U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            r14 = Oot3dAotLsl(r0, 4U);
        }
        {
            r0 = 0x00001580U;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003776A8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (!(flags.Z())) { goto block_003776E8; }
        goto block_003776B0;
    }
block_003776B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003776B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003776B0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003776C8; }
        goto block_003776BC;
    }
block_003776BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003776BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003776BCU);
        }
        {
            const uint32_t updatedAddress = r2 + 0x82U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003776BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x86U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r14))) {
                return Oot3dAotMemoryFault(context, 0x003776C0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x003776C4U, address);
            }
        }
        goto block_003776C8;
    }
block_003776C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003776C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003776C8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003776C8U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000005U;
        }
        {
            r1 = 0x0000000CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003776D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003318bc_003318BC(frame, context, state, 0x003318BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003776D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003776D8;
    }
block_003776D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003776D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003776D8U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003776D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000100U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000100U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00377730; }
        goto block_003776E4;
    }
block_003776E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003776E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003776E4U);
        }
        goto block_00377724;
    }
block_003776E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003776E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003776E8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000079U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0037773C; }
        goto block_003776F0;
    }
block_003776F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003776F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003776F0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00377708; }
        goto block_003776FC;
    }
block_003776FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003776FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003776FCU);
        }
        {
            const uint32_t updatedAddress = r2 + 0x82U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003776FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x86U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r14))) {
                return Oot3dAotMemoryFault(context, 0x00377700U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x00377704U, address);
            }
        }
        goto block_00377708;
    }
block_00377708:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377708U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377708U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377708U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000005U;
        }
        {
            r1 = 0x00000018U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00377718U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003318bc_003318BC(frame, context, state, 0x003318BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00377718U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00377718;
    }
block_00377718:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377718U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377718U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377718U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000100U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000100U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00377730; }
        goto block_00377724;
    }
block_00377724:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377724U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377724U);
        }
        {
            r0 = r0 | 0x00000100U;
        }
        {
            const uint32_t updatedAddress = r10 + 0x42U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377728U, address);
            }
        }
        goto block_00376C54;
    }
block_00377730:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377730U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377730U);
        }
        {
            const uint32_t operand = 0x0000003CU;
            r13 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00377738U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00377738U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00377738U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00377738U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00377738U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00377738U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00377738U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00377738U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00377738U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_0037773C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037773CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037773CU);
        }
        {
            const uint32_t operand = 0x00000084U;
            r0 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00377768; }
        goto block_00377748;
    }
block_00377748:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377748U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377748U);
        }
        {
            const uint32_t updatedAddress = 0x00377750U + 0x2A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377748U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x5CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037774CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377758U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00377760U, address);
            }
        }
        goto block_00376C54;
    }
block_00377768:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377768U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377768U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000014U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003777BC; }
        goto block_00377770;
    }
block_00377770:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377770U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377770U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x14U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377770U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r8;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377778U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00377894; }
        goto block_00377784;
    }
block_00377784:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377784U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377784U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x8DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377784U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00377798; }
        goto block_00377790;
    }
block_00377790:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377790U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377790U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x8DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00377790U, address);
            }
        }
        goto block_00376C54;
    }
block_00377798:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377798U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377798U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x8EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377798U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003777AC; }
        goto block_003777A4;
    }
block_003777A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003777A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003777A4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x8EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x003777A4U, address);
            }
        }
        goto block_00376C54;
    }
block_003777AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003777ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003777ACU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x8FU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003777ACU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00377990; }
        goto block_003777B8;
    }
block_003777B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003777B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003777B8U);
        }
        goto block_003778C0;
    }
block_003777BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003777BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003777BCU);
        }
        {
            const uint32_t operand = 0x00000015U;
            r0 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_003777D0; }
        goto block_003777C8;
    }
block_003777C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003777C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003777C8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000082U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003778C8; }
        goto block_003777D0;
    }
block_003777D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003777D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003777D0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003777D0U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000001AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000001BU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00377884; }
        goto block_003777E0;
    }
block_003777E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003777E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003777E0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000082U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r9 + 0x1AU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003777E4U, address);
            }
            r2 = value;
        }
        if (flags.Z()) {
            r4 = 0x0000001AU;
        }
        {
            r0 = 0x00000000U;
        }
        goto block_003777F0;
    }
block_003777F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003777F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003777F0U);
        }
        {
            const uint32_t operand = r0;
            r3 = r2 + operand;
        }
        {
            const uint32_t operand = r8;
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003777F8U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000014U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00377870; }
        goto block_00377804;
    }
block_00377804:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377804U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377804U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x85U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377804U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = r2;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r2 = 0x00000000U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x81U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00377814U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + 0x570U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00377818U, address);
            }
        }
        if (flags.Z()) { goto block_00377864; }
        goto block_00377820;
    }
block_00377820:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377820U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377820U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x86U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377820U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r2 = 0x00000000U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x82U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0037782CU, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + 0x571U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00377830U, address);
            }
        }
        if (flags.Z()) { goto block_00377864; }
        goto block_00377838;
    }
block_00377838:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377838U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377838U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x87U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377838U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r2 = 0x00000000U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x83U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00377844U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + 0x572U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00377848U, address);
            }
        }
        if (flags.Z()) { goto block_00377864; }
        goto block_00377850;
    }
block_00377850:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377850U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377850U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x88U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377850U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r2 = 0x00000000U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x84U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0037785CU, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + 0x573U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00377860U, address);
            }
        }
        goto block_00377864;
    }
block_00377864:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377864U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377864U);
        }
        {
            const uint32_t operand = r8;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00377868U, address);
            }
        }
        goto block_00376C54;
    }
block_00377870:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377870U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377870U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_003777F0; }
        goto block_00377880;
    }
block_00377880:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377880U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377880U);
        }
        goto block_00377990;
    }
block_00377884:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377884U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377884U);
        }
        {
            const uint32_t operand = r2;
            r0 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377888U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0037789C; }
        goto block_00377894;
    }
block_00377894:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377894U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377894U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00377894U, address);
            }
        }
        goto block_00376C54;
    }
block_0037789C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037789CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037789CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x8DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037789CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00377790; }
        goto block_003778A8;
    }
block_003778A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003778A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003778A8U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x8EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003778A8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003777A4; }
        goto block_003778B4;
    }
block_003778B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003778B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003778B4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x8FU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003778B4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00377990; }
        goto block_003778C0;
    }
block_003778C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003778C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003778C0U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x8FU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x003778C0U, address);
            }
        }
        goto block_00376C54;
    }
block_003778C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003778C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003778C8U);
        }
        {
            const uint32_t operand = 0x00000021U;
            r0 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000016U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00377944; }
        goto block_003778D4;
    }
block_003778D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003778D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003778D4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000021U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003778D8U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            r0 = r0 | 0x00000400U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + 0x3D0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003778E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003778E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003778E8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x003778ECU, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00376C54; }
        goto block_003778F8;
    }
block_003778F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003778F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003778F8U);
        }
        {
            r0 = 0x00000001U;
        }
        goto block_003778FC;
    }
block_003778FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003778FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003778FCU);
        }
        {
            const uint32_t operand = r0;
            r2 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x80U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377900U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00377930; }
        goto block_0037790C;
    }
block_0037790C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037790CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037790CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000002CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = r8;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00377914U, address);
            }
        }
        if (!(flags.Z())) { goto block_00376C54; }
        goto block_0037791C;
    }
block_0037791C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037791CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037791CU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00377924U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_004be050_004BE050(frame, context, state, 0x004BE050U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00377924U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00377924;
    }
block_00377924:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377924U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377924U);
        }
        {
        }
        {
        }
        goto block_00376C54;
    }
block_00377930:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377930U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377930U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_003778FC; }
        goto block_00377940;
    }
block_00377940:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377940U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377940U);
        }
        goto block_00376C54;
    }
block_00377944:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377944U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377944U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00377990; }
        goto block_0037794C;
    }
block_0037794C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037794CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037794CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037794CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00377958U + 0xA4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377950U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r0 + operand;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377960U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00377964U, address);
            }
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00377968U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00377968U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00377968U,
                                           firstAddress + 8U);
            }
        }
        {
            r3 = r1;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377970U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0037797CU + 0x84U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377974U, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = r12 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377978U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r1 + operand;
        }
        {
            const uint32_t address = r12 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377980U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r12 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377984U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00377990U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Spawn_003738D0(frame, context, state, 0x003738D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00377990U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00377990;
    }
block_00377990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00377990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00377990U);
        }
        {
            const uint32_t updatedAddress = r9 + r4;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377990U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r7;
            r0 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00377998U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0037799CU, address);
            }
        }
        {
            const uint32_t operand = 0x0000003CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003779A4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003779A4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003779A4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003779A4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003779A4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003779A4U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003779A4U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x003779A4U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003779A4U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
