#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_FUN_0011393c_0011393C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossGanondrof_Charge_001C8528(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_001fdcb8_001FDCB8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossGoma_Update_00221F20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossGanon_Update_00242A94(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossGoma_UpdateHit_00262258(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor1D8_Update_002AD98C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_sin_idx8_002CFCA0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00334914_00334914(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_cos_idx8_00338F60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00339f1c_00339F1C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossGanondrof_SetupNeutral_00353B70(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003544a4_003544A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkeletonAnimationModel_ApplyTevConstantColor_00358778(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00363a98_00363A98(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Object_GetIndex_00363C10(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_UpdateVelocityXYZ_00365860(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FrameAdvance_IsEnabled_00366738(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_StaticInitGuard_TryAcquire_003679B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Runtime_SignedDivMod32_00368D94(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Matrix_RotateX_00369014(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseContext_GetState_003695F8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_FAtan2F_003696EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SpawnAsChild_0036AA20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_GetLastFrame_0036AE14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_UpdatePos_0036B96C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0036cae4_0036CAE4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToF_0036E168(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_WorldYawTowardActor_0036E800(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_ApproachZeroF_0036FC20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToSUpdateRate_00370084(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_MorphToLoop_00370350(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Matrix_RotateZ_00371234(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Matrix_Scale_00371348(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Mtx3x4_Translate_003713FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroFloat_00371E50(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_translate_mtx3x4_local_00372070(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003720a4_003720A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelHandle_Submit_00372170(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelHandle_CopyOverrideTransform_003721E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_CosF_Core_00372674(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SinF_003727F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_ApproachF_00373500(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_transform_mtx3x4_vec3_003735AC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Matrix_RotateY_003735E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_OnFrameImpl_003736FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_CenteredFloat_003738A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Spawn_003738D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_MorphToPlayOnce_00374A58(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00374be8_00374BE8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlaySoundGeneral_0037547C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroOne_003759D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlayActorSound2_00375BCC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetAC_00376168(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetAT_003761F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetOC_003762A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_UpdateBgCheckInfo_00376340(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_MoveForward_00376864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Fishing_DrawRod_003CC884(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_BossGanondrof_Charge_001C8528(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001C8528U:
        goto block_001C8528;
    case 0x001C8550U:
        goto block_001C8550;
    case 0x001C8578U:
        goto block_001C8578;
    case 0x001C85A8U:
        goto block_001C85A8;
    case 0x001C85BCU:
        goto block_001C85BC;
    case 0x001C85C4U:
        goto block_001C85C4;
    case 0x001C85CCU:
        goto block_001C85CC;
    case 0x001C85DCU:
        goto block_001C85DC;
    case 0x001C8608U:
        goto block_001C8608;
    case 0x001C8618U:
        goto block_001C8618;
    case 0x001C8624U:
        goto block_001C8624;
    case 0x001C863CU:
        goto block_001C863C;
    case 0x001C8650U:
        goto block_001C8650;
    case 0x001C8680U:
        goto block_001C8680;
    case 0x001C8690U:
        goto block_001C8690;
    case 0x001C869CU:
        goto block_001C869C;
    case 0x001C86B8U:
        goto block_001C86B8;
    case 0x001C86D8U:
        goto block_001C86D8;
    case 0x001C86ECU:
        goto block_001C86EC;
    case 0x001C86F8U:
        goto block_001C86F8;
    case 0x001C870CU:
        goto block_001C870C;
    case 0x001C8718U:
        goto block_001C8718;
    case 0x001C8724U:
        goto block_001C8724;
    case 0x001C8744U:
        goto block_001C8744;
    case 0x001C874CU:
        goto block_001C874C;
    case 0x001C8758U:
        goto block_001C8758;
    case 0x001C876CU:
        goto block_001C876C;
    case 0x001C87B0U:
        goto block_001C87B0;
    case 0x001C87C4U:
        goto block_001C87C4;
    case 0x001C87CCU:
        goto block_001C87CC;
    case 0x001C87D8U:
        goto block_001C87D8;
    case 0x001C87ECU:
        goto block_001C87EC;
    case 0x001C8804U:
        goto block_001C8804;
    case 0x001C8818U:
        goto block_001C8818;
    case 0x001C8828U:
        goto block_001C8828;
    case 0x001C8888U:
        goto block_001C8888;
    case 0x001C8894U:
        goto block_001C8894;
    case 0x001C88A4U:
        goto block_001C88A4;
    case 0x001C88B4U:
        goto block_001C88B4;
    case 0x001C88C8U:
        goto block_001C88C8;
    case 0x001C88D8U:
        goto block_001C88D8;
    case 0x001C88F0U:
        goto block_001C88F0;
    case 0x001C88FCU:
        goto block_001C88FC;
    case 0x001C8908U:
        goto block_001C8908;
    case 0x001C891CU:
        goto block_001C891C;
    case 0x001C8930U:
        goto block_001C8930;
    case 0x001C893CU:
        goto block_001C893C;
    case 0x001C8988U:
        goto block_001C8988;
    case 0x001C89B0U:
        goto block_001C89B0;
    case 0x001C89B8U:
        goto block_001C89B8;
    case 0x001C89C4U:
        goto block_001C89C4;
    case 0x001C8A18U:
        goto block_001C8A18;
    case 0x001C8A20U:
        goto block_001C8A20;
    case 0x001C8A2CU:
        goto block_001C8A2C;
    case 0x001C8A8CU:
        goto block_001C8A8C;
    case 0x001C8AACU:
        goto block_001C8AAC;
    case 0x001C8AB4U:
        goto block_001C8AB4;
    case 0x001C8AC0U:
        goto block_001C8AC0;
    case 0x001C8B20U:
        goto block_001C8B20;
    case 0x001C8B30U:
        goto block_001C8B30;
    case 0x001C8BE4U:
        goto block_001C8BE4;
    case 0x001C8C04U:
        goto block_001C8C04;
    case 0x001C8C10U:
        goto block_001C8C10;
    case 0x001C8C4CU:
        goto block_001C8C4C;
    case 0x001C8C50U:
        goto block_001C8C50;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001C8528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8528U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001C8528U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001C8528U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001C8528U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001C8528U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001C8528U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001C8528U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001C8528U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001C8528U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001C8528U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r11 = r1;
        }
        {
            const uint32_t updatedAddress = 0x001C853CU + 0x304U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8534U, address);
            }
            r0 = value;
        }
        {
            r13 -= 40U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001C8538U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C8538U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001C8538U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001C8538U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x001C8538U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x001C8538U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x001C8538U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x001C8538U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x001C8538U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x001C8538U,
                                           firstAddress + 36U);
            }
        }
        {
            const uint32_t operand = 0x0000007CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8540U, address);
            }
            r6 = value;
        }
        {
            const uint32_t operand = 0x00000148U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8550U;
            const Oot3dWholeAotFlow callFlow = Oot3dAotCallExternal(context, 0x00372224U, frame, state, commitState, reloadState);
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8550U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8550;
    }
block_001C8550:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8550U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8550U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8550U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001C855CU + 744U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8554U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r0 = 0x00000009U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C855CU, 0xEE709A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8560U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001C856CU + 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8564U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x448U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C8568U, address);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8570U, 0xEE309A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8578U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8578U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8578;
    }
block_001C8578:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8578U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8578U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r5 = r4 + operand;
        }
        {
            const uint32_t address = 0x001C8584U + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C857CU, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8580U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001C858CU + 708U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8584U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t address = 0x001C8590U + 708U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8588U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x001C8594U + 708U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C858CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x001C8598U + 708U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8590U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x001C859CU + 708U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8594U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            r10 = 0x00000001U;
        }
        {
            r9 = 0x00000000U;
        }
        if (flags.Z()) { goto block_001C8624; }
        goto block_001C85A8;
    }
block_001C85A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C85A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C85A8U);
        }
        {
            const uint32_t updatedAddress = 0x001C85B0U + 0x2B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C85A8U, address);
            }
            r7 = value;
        }
        {
            const uint32_t address = 0x001C85B4U + 692U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C85ACU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x02EC0000U;
            r8 = r7 - operand;
        }
        if (flags.Z()) { goto block_001C86F8; }
        goto block_001C85BC;
    }
block_001C85BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C85BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C85BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001C874C; }
        goto block_001C85C4;
    }
block_001C85C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C85C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C85C4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001C8908; }
        goto block_001C85CC;
    }
block_001C85CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C85CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C85CCU);
        }
        {
            r0 = r4;
        }
        {
            const uint32_t address = 0x001C85D8U + 660U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C85D0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C85D4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C85DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_MoveForward_00376864(frame, context, state, 0x00376864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C85DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C85DC;
    }
block_001C85DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C85DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C85DCU);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C85DCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C85E4U, 0xEE290AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[19], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r8, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x001C85ECU, address);
            }
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C85F0U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C85F4U, 0xEE090A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C85F8U, 0xEEB10AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r7, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001C8888; }
        goto block_001C8608;
    }
block_001C8608:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8608U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8608U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x0000006CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8618U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8618U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8618;
    }
block_001C8618:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8618U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8618U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x001C8618U, address);
            }
        }
        {
        }
        goto block_001C8894;
    }
block_001C8624:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8624U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8624U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8624U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000047U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x001C8638U + 0x238U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8630U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x001C863CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C863CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C863C;
    }
block_001C863C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C863CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C863CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C863CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x001C864CU + 0x228U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8644U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8650U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8650U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8650;
    }
block_001C8650:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8650U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8650U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8650U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8654U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000060U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C865CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C8660U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8664U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 104U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8668U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C866CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[23];
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C8674U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8680U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8680U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8680;
    }
block_001C8680:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8680U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8680U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[23];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000068U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8690U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8690U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8690;
    }
block_001C8690:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8690U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8690U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8690U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001C86D8; }
        goto block_001C869C;
    }
block_001C869C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C869CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C869CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001C869CU, address);
            }
        }
        {
            const uint32_t address = r4 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C86A0U, address);
            }
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C86A8U, address);
            }
        }
        {
            r1 = 0x00000016U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C86B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C86B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C86B8;
    }
block_001C86B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C86B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C86B8U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r1 = 0x00000016U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C86C4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C86C8U, 0xEE200A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 632U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C86CCU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C86D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C86D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C86D8;
    }
block_001C86D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C86D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C86D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C86D8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r3 = 0x000007D0U;
        }
        {
            r2 = 0x00000005U;
        }
        {
            const uint32_t operand = 0x000000BEU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C86ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C86ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C86EC;
    }
block_001C86EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C86ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C86ECU);
        }
        {
        }
        {
        }
        goto block_001C8908;
    }
block_001C86F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C86F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C86F8U);
        }
        {
            const uint32_t address = r4 + 632U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C86F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001C8704U + 372U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C86FCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8704U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C870CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C870CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C870C;
    }
block_001C870C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C870CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C870CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001C874C; }
        goto block_001C8718;
    }
block_001C8718:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8718U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8718U);
        }
        {
            r1 = 0x00000015U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8724U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8724U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8724;
    }
block_001C8724:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8724U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8724U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r1 = 0x00000015U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8730U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8734U, 0xEE200A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 632U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C8738U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8744U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8744U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8744;
    }
block_001C8744:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8744U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8744U);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C8748U, address);
            }
        }
        goto block_001C874C;
    }
block_001C874C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C874CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C874CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C874CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001C87C4; }
        goto block_001C8758;
    }
block_001C8758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8758U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8758U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r3 = 0x000007D0U;
        }
        {
            r2 = 0x00000005U;
        }
        {
            const uint32_t operand = 0x000000BEU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C876CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C876CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C876C;
    }
block_001C876C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C876CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C876CU);
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C876CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8770U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8774U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8778U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C877CU, 0xEE301A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8780U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001C878CU + 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8784U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8788U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C878CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8790U, 0xEE211A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8794U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8798U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C879CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C87A0U, 0xEE700AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C87A4U, 0xEE001AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C87A8U, 0xEEF10AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C87B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_FAtan2F_003696EC(frame, context, state, 0x003696ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C87B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C87B0;
    }
block_001C87B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C87B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C87B0U);
        }
        {
            const uint32_t address = 0x001C87B8U + 200U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C87B0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C87B4U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C87B8U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C87C0U, address);
            }
        }
        goto block_001C87C4;
    }
block_001C87C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C87C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C87C4U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C87CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdateVelocityXYZ_00365860(frame, context, state, 0x00365860U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C87CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C87CC;
    }
block_001C87CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C87CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C87CCU);
        }
        {
            r0 = r4;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C87D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdatePos_0036B96C(frame, context, state, 0x0036B96CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C87D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C87D8;
    }
block_001C87D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C87D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C87D8U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[23];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            const uint32_t operand = 0x0000006CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C87ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C87ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C87EC;
    }
block_001C87EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C87ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C87ECU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C87ECU, 0xEE290AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[19], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C87F0U, 0xEE090A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C87F4U, 0xEEB10AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r7, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001C8818; }
        goto block_001C8804;
    }
block_001C8804:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8804U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8804U);
        }
        {
            const uint32_t address = r4 + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8804U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x001C8810U + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8808U, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_001C8828; }
        goto block_001C8818;
    }
block_001C8818:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8818U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8818U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C881CU, address);
            }
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C8824U, address);
            }
        }
        goto block_001C8828;
    }
block_001C8828:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8828U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8828U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8828U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r8, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x001C8834U, address);
            }
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C8838U, address);
            }
        }
        goto block_001C8908;
    }
block_001C8888:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8888U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8888U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8888U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001C8908; }
        goto block_001C8894;
    }
block_001C8894:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8894U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8894U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x0000006CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C88A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C88A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C88A4;
    }
block_001C88A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C88A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C88A4U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000064U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C88B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C88B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C88B4;
    }
block_001C88B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C88B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C88B4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C88B4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r3 = 0x000007D0U;
        }
        {
            r2 = 0x00000005U;
        }
        {
            const uint32_t operand = 0x000000BEU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C88C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C88C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C88C8;
    }
block_001C88C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C88C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C88C8U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C88C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001C8908; }
        goto block_001C88D8;
    }
block_001C88D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C88D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C88D8U);
        }
        {
            const uint32_t address = r4 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C88D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x001C88E4U + 0x378U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C88DCU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C88E0U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001C8908; }
        goto block_001C88F0;
    }
block_001C88F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C88F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C88F0U);
        }
        {
            r0 = r4;
        }
        {
            const uint32_t address = 0x001C88FCU + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C88F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C88FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BossGanondrof_SetupNeutral_00353B70(frame, context, state, 0x00353B70U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C88FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C88FC;
    }
block_001C88FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C88FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C88FCU);
        }
        {
            r0 = 0x0000002DU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C8900U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x271U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001C8904U, address);
            }
        }
        goto block_001C8908;
    }
block_001C8908:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8908U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8908U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8908U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x001C8914U + 0x350U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C890CU, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001C893C; }
        goto block_001C891C;
    }
block_001C891C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C891CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C891CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C891CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001C8928U + 0x340U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8920U, address);
            }
            r1 = value;
        }
        {
            const int32_t left = static_cast<int16_t>(
                r0 >> 0U);
            const int32_t right = static_cast<int16_t>(
                r1 >> 0U);
            r0 = static_cast<uint32_t>(left * right);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8930U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8930U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8930;
    }
block_001C8930:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8930U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8930U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8930U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8934U, 0xEE400A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C8938U, address);
            }
        }
        goto block_001C893C;
    }
block_001C893C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C893CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C893CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = 0x001C8950U + 0x328U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8948U, address);
            }
            r10 = value;
        }
        {
            const uint32_t address = 0x001C8954U + 792U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C894CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C8950U, address);
            }
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C8954U, address);
            }
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C8958U, address);
            }
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C895CU, address);
            }
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C8960U, address);
            }
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C8964U, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C8968U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C896CU, address);
            }
        }
        {
            const uint32_t address = 0x001C8978U + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8970U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x001C897CU + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8974U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x001C8978U, address);
            }
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r8 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000148U;
            r7 = r4 + operand;
        }
        goto block_001C8988;
    }
block_001C8988:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8988U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8988U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8988U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8990U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8994U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8998U, 0xEE60AA29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C899CU, 0xEEF4AA68U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[21], frame.Guest.vfp[17],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            frame.Guest.vfp[20] = frame.Guest.vfp[17];
        }
        if (flags.Z()) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        if (flags.Z()) { goto block_001C89C4; }
        goto block_001C89B0;
    }
block_001C89B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C89B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C89B0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C89B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C89B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C89B8;
    }
block_001C89B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C89B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C89B8U);
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C89C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C89C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C89C4;
    }
block_001C89C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C89C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C89C4U);
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C89C4U, address);
            }
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C89C8U, address);
            }
        }
        {
            const uint32_t address = r13 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x001C89CCU, address);
            }
        }
        {
            const uint32_t address = r13 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C89D0U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C89D4U, 0xEEF10A4AU};
            frame.Guest.vfp[1] = frame.Guest.vfp[20] ^ 0x80000000U;
        }
        {
            const uint32_t address = r13 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001C89D8U, address);
            }
        }
        {
            const uint32_t address = r13 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C89DCU, address);
            }
        }
        {
            const uint32_t address = r13 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C89E0U, address);
            }
        }
        {
            const uint32_t address = r13 + 104U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C89E4U, address);
            }
        }
        {
            const uint32_t address = r13 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C89E8U, address);
            }
        }
        {
            const uint32_t address = r13 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C89ECU, address);
            }
        }
        {
            const uint32_t address = r13 + 116U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C89F0U, address);
            }
        }
        {
            const uint32_t address = r13 + 120U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C89F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C89F8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A00U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A04U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A08U, 0xEE60AA29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A0CU, 0xEEF4AA68U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[21], frame.Guest.vfp[17],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_001C8A8C; }
        goto block_001C8A18;
    }
block_001C8A18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8A18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8A18U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8A20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8A20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8A20;
    }
block_001C8A20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8A20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8A20U);
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8A2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8A2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8A2C;
    }
block_001C8A2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8A2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8A2CU);
        }
        {
            const uint32_t address = r13 + 80U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8A2CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8A30U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A34U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A38U, 0xEE411A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A3CU, 0xEE211A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C8A40U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A44U, 0xEE001ACAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C8A48U, address);
            }
        }
        {
            const uint32_t address = r13 + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8A4CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8A50U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A54U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A58U, 0xEE411A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A5CU, 0xEE211A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C8A60U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A64U, 0xEE001ACAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C8A68U, address);
            }
        }
        {
            const uint32_t address = r13 + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8A6CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8A70U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A74U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A78U, 0xEE210A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A7CU, 0xEE411A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A80U, 0xEE000ACAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C8A84U, address);
            }
        }
        {
            const uint32_t address = r13 + 116U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C8A88U, address);
            }
        }
        goto block_001C8A8C;
    }
block_001C8A8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8A8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8A8CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8A8CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A94U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A98U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8A9CU, 0xEE20AA29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8AA0U, 0xEEB4AA68U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[20], frame.Guest.vfp[17],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_001C8B20; }
        goto block_001C8AAC;
    }
block_001C8AAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8AACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8AACU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8AB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8AB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8AB4;
    }
block_001C8AB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8AB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8AB4U);
        }
        {
            frame.Guest.vfp[21] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8AC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8AC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8AC0;
    }
block_001C8AC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8AC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8AC0U);
        }
        {
            const uint32_t address = r13 + 76U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8AC0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 80U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8AC4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8AC8U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8ACCU, 0xEE411A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8AD0U, 0xEE211A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C8AD4U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8AD8U, 0xEE001AEAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C8ADCU, address);
            }
        }
        {
            const uint32_t address = r13 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8AE0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8AE4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8AE8U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8AECU, 0xEE411A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8AF0U, 0xEE211A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C8AF4U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8AF8U, 0xEE001AEAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C8AFCU, address);
            }
        }
        {
            const uint32_t address = r13 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8B00U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8B04U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8B08U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8B0CU, 0xEE210A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8B10U, 0xEE411A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8B14U, 0xEE000AEAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C8B18U, address);
            }
        }
        {
            const uint32_t address = r13 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C8B1CU, address);
            }
        }
        goto block_001C8B20;
    }
block_001C8B20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8B20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8B20U);
        }
        {
            const uint32_t operand = 0x0000004CU;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8B30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8B30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8B30;
    }
block_001C8B30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8B30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8B30U);
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001C8B30U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C8B30U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C8B30U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C8B30U,
                                           firstAddress + 12U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001C8B30U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001C8B30U,
                                           firstAddress + 20U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
            r14 = value14;
            r7 = r7 + 24U;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001C8B34U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C8B34U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C8B34U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C8B34U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001C8B34U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001C8B34U,
                                           firstAddress + 20U);
            }
            r8 = r8 + 24U;
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001C8B38U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C8B38U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C8B38U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C8B38U,
                                           firstAddress + 12U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001C8B38U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001C8B38U,
                                           firstAddress + 20U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000018U;
            r7 = r7 - operand;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001C8B40U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C8B40U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C8B40U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C8B40U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001C8B40U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001C8B40U,
                                           firstAddress + 20U);
            }
        }
        {
            r0 = r6;
        }
        {
            r1 = r9;
        }
        {
            const uint32_t leftValue = r10;
            const uint32_t rightValue = r6;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            value += (static_cast<uint64_t>(r0) << 32U) |
                     r1;
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            const uint32_t address = r4 + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8B50U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8B54U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x00000096U;
        }
        {
            r1 = Oot3dAotAsr(r0, 2U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8B60U, 0xEE700A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t operand = 0x00000018U;
            r8 = r8 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = r6;
            r0 = r0 + operand;
        }
        {
            r3 = r0 & 0x000000FFU;
        }
        {
            const uint32_t operand = 0x00000040U;
            r1 = r13 + operand;
        }
        {
            r0 = r11;
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C8B80U, address);
            }
        }
        {
            const uint32_t address = r4 + 692U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8B84U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r13 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8B88U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8B8CU, 0xEE311A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C8B90U, address);
            }
        }
        {
            const uint32_t address = r4 + 696U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8B94U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r13 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8B98U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8B9CU, 0xEE711A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C8BA0U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8BA4U, 0xEE601A2BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8BA8U, 0xEE200A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C8BACU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8BB0U, 0xEE601AABU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C8BB4U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8BB8U, 0xEE611A2BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C8BBCU, address);
            }
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C8BC0U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8BC4U, 0xEE200A8BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C8BC8U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C8BCCU, 0xEE210A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C8BD0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001C8BD4U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000028U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000034U;
            r2 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8BE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00363a98_00363A98(frame, context, state, 0x00363A98U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8BE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8BE4;
    }
block_001C8BE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8BE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8BE4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8BE4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001800U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x0000025CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C8BF0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r6 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r6 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C8988; }
        goto block_001C8C04;
    }
block_001C8C04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8C04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8C04U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8C04U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000007U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_001C8C50; }
        goto block_001C8C10;
    }
block_001C8C10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8C10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8C10U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8C10U, address);
            }
            r5 = value;
        }
        {
            r3 = 0x00000026U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x00000008U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001C8C24U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C8C24U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C8C24U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C8C24U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r11 + operand;
        }
        {
            const uint32_t address = r4 + 696U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8C2CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r4 + 692U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8C30U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C8C34U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x0000006DU;
        }
        {
            r1 = r4;
        }
        {
            r2 = r11;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C8C4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C8C4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C8C4C;
    }
block_001C8C4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8C4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8C4CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x128U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x001C8C4CU, address);
            }
        }
        goto block_001C8C50;
    }
block_001C8C50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C8C50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C8C50U);
        }
        {
            const uint32_t operand = 0x0000007CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001C8C54U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C8C54U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C8C54U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C8C54U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C8C54U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C8C54U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C8C54U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C8C54U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001C8C54U,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001C8C54U,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            r13 += 40U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C8C58U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C8C58U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C8C58U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C8C58U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001C8C58U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001C8C58U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001C8C58U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001C8C58U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001C8C58U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_BossGoma_Update_00221F20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00221F20U:
        goto block_00221F20;
    case 0x00221F90U:
        goto block_00221F90;
    case 0x00221FA8U:
        goto block_00221FA8;
    case 0x00221FB0U:
        goto block_00221FB0;
    case 0x00221FCCU:
        goto block_00221FCC;
    case 0x00221FE0U:
        goto block_00221FE0;
    case 0x00221FECU:
        goto block_00221FEC;
    case 0x00222000U:
        goto block_00222000;
    case 0x00222014U:
        goto block_00222014;
    case 0x0022202CU:
        goto block_0022202C;
    case 0x00222050U:
        goto block_00222050;
    case 0x00222054U:
        goto block_00222054;
    case 0x00222064U:
        goto block_00222064;
    case 0x00222094U:
        goto block_00222094;
    case 0x002220CCU:
        goto block_002220CC;
    case 0x002220F0U:
        goto block_002220F0;
    case 0x002220FCU:
        goto block_002220FC;
    case 0x00222110U:
        goto block_00222110;
    case 0x00222124U:
        goto block_00222124;
    case 0x00222138U:
        goto block_00222138;
    case 0x00222144U:
        goto block_00222144;
    case 0x0022215CU:
        goto block_0022215C;
    case 0x00222174U:
        goto block_00222174;
    case 0x00222184U:
        goto block_00222184;
    case 0x00222190U:
        goto block_00222190;
    case 0x0022219CU:
        goto block_0022219C;
    case 0x002221A0U:
        goto block_002221A0;
    case 0x002221B4U:
        goto block_002221B4;
    case 0x002221C8U:
        goto block_002221C8;
    case 0x002221D4U:
        goto block_002221D4;
    case 0x002221E8U:
        goto block_002221E8;
    case 0x002221FCU:
        goto block_002221FC;
    case 0x00222214U:
        goto block_00222214;
    case 0x00222228U:
        goto block_00222228;
    case 0x0022223CU:
        goto block_0022223C;
    case 0x00222248U:
        goto block_00222248;
    case 0x00222260U:
        goto block_00222260;
    case 0x00222274U:
        goto block_00222274;
    case 0x00222288U:
        goto block_00222288;
    case 0x002222D0U:
        goto block_002222D0;
    case 0x002222E0U:
        goto block_002222E0;
    case 0x002222ECU:
        goto block_002222EC;
    case 0x00222328U:
        goto block_00222328;
    case 0x00222360U:
        goto block_00222360;
    case 0x0022237CU:
        goto block_0022237C;
    case 0x0022239CU:
        goto block_0022239C;
    case 0x002223BCU:
        goto block_002223BC;
    case 0x002223E0U:
        goto block_002223E0;
    case 0x00222400U:
        goto block_00222400;
    case 0x00222420U:
        goto block_00222420;
    case 0x0022242CU:
        goto block_0022242C;
    case 0x00222444U:
        goto block_00222444;
    case 0x00222450U:
        goto block_00222450;
    case 0x00222464U:
        goto block_00222464;
    case 0x00222484U:
        goto block_00222484;
    case 0x00222498U:
        goto block_00222498;
    case 0x0022249CU:
        goto block_0022249C;
    case 0x002224ACU:
        goto block_002224AC;
    case 0x002224B8U:
        goto block_002224B8;
    case 0x002224C4U:
        goto block_002224C4;
    case 0x002224E4U:
        goto block_002224E4;
    case 0x002224F4U:
        goto block_002224F4;
    case 0x0022250CU:
        goto block_0022250C;
    case 0x00222518U:
        goto block_00222518;
    case 0x00222524U:
        goto block_00222524;
    case 0x0022253CU:
        goto block_0022253C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00221F20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00221F20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00221F20U);
        }
        {
            const uint32_t firstAddress = r13 - 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00221F20U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00221F20U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00221F20U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00221F20U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00221F20U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00221F20U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00221F20U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00221F20U,
                                           firstAddress + 28U);
            }
            r13 = r13 - 32U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00000200U;
            r6 = r4 + operand;
        }
        {
            r0 = 0x00000001U;
        }
        {
            r8 = 0x00000000U;
        }
        {
            r13 -= 24U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00221F34U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00221F34U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00221F34U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00221F34U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x00221F34U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x00221F34U,
                                           firstAddress + 20U);
            }
        }
        {
            r9 = r1;
        }
        {
            r1 = r9;
        }
        {
            const uint32_t updatedAddress = r6 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00221F40U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00221F44U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00221F4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00221F50U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x6EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00221F5CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x70U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00221F60U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00221F6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x72U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00221F70U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x72U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00221F7CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x00221F80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00221F84U, address);
            }
            r2 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x00221F90U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00221F90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00221F90;
    }
block_00221F90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00221F90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00221F90U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00221F90U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00221F94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x52U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00221F98U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x52U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x00221FA0U, address);
            }
        }
        if (!(flags.Z())) { goto block_00221FB0; }
        goto block_00221FA8;
    }
block_00221FA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00221FA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00221FA8U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00221FB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_MoveForward_00376864(frame, context, state, 0x00376864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00221FB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00221FB0;
    }
block_00221FB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00221FB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00221FB0U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00221FB0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x00221FBCU + 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00221FB4U, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x00221FC4U + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00221FBCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x00221FC8U + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00221FC0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_00221FEC; }
        goto block_00221FCC;
    }
block_00221FCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00221FCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00221FCCU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        {
            r2 = 0x00000005U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00221FE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdateBgCheckInfo_00376340(frame, context, state, 0x00376340U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00221FE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00221FE0;
    }
block_00221FE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00221FE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00221FE0U);
        }
        {
        }
        {
        }
        goto block_00222000;
    }
block_00221FEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00221FECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00221FECU);
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t address = 0x00221FF8U + 680U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00221FF0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r4;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00222000U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdateBgCheckInfo_00376340(frame, context, state, 0x00376340U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00222000U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00222000;
    }
block_00222000:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222000U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222000U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x5AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222000U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0022200CU + 664U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222004U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x00222010U + 664U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222008U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00222228; }
        goto block_00222014;
    }
block_00222014:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222014U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222014U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r7 = r9 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x50U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222018U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022201CU, address);
            }
            r0 = value;
        }
        {
            r5 = 0x0000000BU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00222064; }
        goto block_0022202C;
    }
block_0022202C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022202CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022202CU);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x47EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222030U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x47EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x00222038U, address);
            }
        }
        if (!(flags.Z())) {
            r0 = 0x00000012U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00222040U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222044U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x0000000FU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00222064; }
        goto block_00222050;
    }
block_00222050:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222050U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222050U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00222054U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00222054U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00222054;
    }
block_00222054:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222054U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222054U);
        }
        {
            const uint32_t updatedAddress = 0x0022205CU + 0x250U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222054U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r6 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x00222060U, address);
            }
        }
        goto block_00222064;
    }
block_00222064:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222064U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222064U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x40U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222064U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000200U;
            r10 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000036U;
            r10 = r10 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r6 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222074U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022207CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r6 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x00222084U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222088U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002220FC; }
        goto block_00222094;
    }
block_00222094:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222094U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222094U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r5 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022209CU, address);
            }
        }
        {
            const uint32_t address = r5 + 80U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002220A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x002220ACU + 520U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002220A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x002220B0U + 512U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002220A8U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            r3 = 0x000007D0U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002220B0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r2 = 0x00000001U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002220B8U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000234U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002220CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002220CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002220CC;
    }
block_002220CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002220CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002220CCU);
        }
        {
            const uint32_t address = r5 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002220CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x000007D0U;
        }
        {
            r2 = 0x00000001U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002220D8U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002220DCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002220F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002220F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002220F0;
    }
block_002220F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002220F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002220F0U);
        }
        {
        }
        {
        }
        goto block_00222124;
    }
block_002220FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002220FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002220FCU);
        }
        {
            r3 = 0x000007D0U;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000234U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00222110U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00222110U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00222110;
    }
block_00222110:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222110U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222110U);
        }
        {
            r3 = 0x000007D0U;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00222124U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00222124U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00222124;
    }
block_00222124:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222124U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222124U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x50U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222124U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r10 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000003AU;
            r10 = r10 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002221D4; }
        goto block_00222138;
    }
block_00222138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222138U);
        }
        {
            const uint32_t updatedAddress = r7 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222138U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00222144U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_WorldYawTowardActor_0036E800(frame, context, state, 0x0036E800U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00222144U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00222144;
    }
block_00222144:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222144U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222144U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222144U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022214CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r5 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022215CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00339f1c_00339F1C(frame, context, state, 0x00339F1CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022215CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022215C;
    }
block_0022215C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022215CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022215CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022215CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r7 = value;
        }
        {
            const uint32_t operand = 0x00004000U;
            r0 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00008000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_00222184; }
        goto block_00222174;
    }
block_00222174:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222174U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222174U);
        }
        {
            const uint32_t operand = 0x00008000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00222180U + 0x138U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222178U, address);
            }
            r7 = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r5 = value;
        }
        goto block_00222184;
    }
block_00222184:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222184U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222184U);
        }
        {
            const uint32_t updatedAddress = 0x0022218CU + 0x130U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222184U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0022219C; }
        goto block_00222190;
    }
block_00222190:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222190U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222190U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 13U);
            r0 = operand - r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_002221A0; }
        goto block_0022219C;
    }
block_0022219C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022219CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022219CU);
        }
        {
            r5 = r0;
        }
        goto block_002221A0;
    }
block_002221A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002221A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002221A0U);
        }
        {
            r3 = 0x000007D0U;
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = r5;
        }
        {
            const uint32_t operand = 0x0000023CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002221B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002221B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002221B4;
    }
block_002221B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002221B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002221B4U);
        }
        {
            r3 = 0x000007D0U;
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = r7;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002221C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002221C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002221C8;
    }
block_002221C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002221C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002221C8U);
        }
        {
        }
        {
        }
        goto block_002221FC;
    }
block_002221D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002221D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002221D4U);
        }
        {
            r3 = 0x000003E8U;
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x0000023CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002221E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002221E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002221E8;
    }
block_002221E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002221E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002221E8U);
        }
        {
            r3 = 0x000003E8U;
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002221FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002221FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002221FC;
    }
block_002221FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002221FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002221FCU);
        }
        {
            const uint32_t address = 0x00222204U + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002221FCU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000294U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00222214U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00222214U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00222214;
    }
block_00222214:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222214U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222214U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x000002C0U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00222228U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00222228U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00222228;
    }
block_00222228:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222228U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222228U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222228U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x00222234U + 144U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022222CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x00222238U + 144U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222230U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_002222D0; }
        goto block_0022223C;
    }
block_0022223C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022223CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022223CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022223CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x00000010U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_002222D0; }
        goto block_00222248;
    }
block_00222248:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222248U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222248U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = 0x00222254U + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022224CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x000002A0U;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00222260U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00222260U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00222260;
    }
block_00222260:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222260U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222260U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x000002A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00222274U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00222274U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00222274;
    }
block_00222274:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222274U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222274U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x000002A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00222288U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00222288U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00222288;
    }
block_00222288:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222288U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222288U);
        }
        {
        }
        {
        }
        goto block_002223BC;
    }
block_002222D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002222D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002222D0U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x56U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002222D0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x002222DCU + 0x268U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002222D4U, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00222360; }
        goto block_002222E0;
    }
block_002222E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002222E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002222E0U);
        }
        {
            const uint32_t value = r1 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        if (flags.Z()) { goto block_00222328; }
        goto block_002222EC;
    }
block_002222EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002222ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002222ECU);
        }
        {
            const uint32_t operand = 0x00000048U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r1 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002222F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002222F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002222FCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r1 + operand;
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222308U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0022230CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222310U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r1 + operand;
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022231CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00222320U, address);
            }
        }
        goto block_002223BC;
    }
block_00222328:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222328U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222328U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022232CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00222330U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222334U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222340U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00222344U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222348U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222354U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00222358U, address);
            }
        }
        goto block_002223BC;
    }
block_00222360:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222360U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222360U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r5 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222370U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000002A0U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022237CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022237CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022237C;
    }
block_0022237C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022237CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022237CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022237CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222390U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000002A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022239CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022239CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022239C;
    }
block_0022239C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022239CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022239CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022239CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002223B0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000002A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002223BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002223BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002223BC;
    }
block_002223BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002223BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002223BCU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002223BCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x002223C8U + 0x180U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002223C0U, address);
            }
            r5 = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002223D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002223E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002223E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002223E0;
    }
block_002223E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002223E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002223E0U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002223E0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002223F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000002B0U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00222400U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00222400U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00222400;
    }
block_00222400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222400U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222400U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222414U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000002B4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00222420U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00222420U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00222420;
    }
block_00222420:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222420U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222420U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222420U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x0000007FU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00222444; }
        goto block_0022242C;
    }
block_0022242C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022242CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022242CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x3EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022242CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r6 + 0x3EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0022243CU, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r6 + 0x3EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x00222440U, address);
            }
        }
        goto block_00222444;
    }
block_00222444:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222444U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222444U);
        }
        {
            const uint32_t address = 0x0022244CU + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222444U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x00222450U + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222448U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            r5 = 0x00000000U;
        }
        goto block_00222450;
    }
block_00222450:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222450U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222450U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x46U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222458U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00222484; }
        goto block_00222464;
    }
block_00222464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222464U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r0 + 0x46U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00222474U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000284U;
            r0 = r0 + operand;
        }
        goto block_00222498;
    }
block_00222484:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222484U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222484U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000284U;
            r0 = r0 + operand;
        }
        goto block_00222498;
    }
block_00222498:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222498U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222498U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0022249CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022249CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022249C;
    }
block_0022249C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022249CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022249CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r5 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00222450; }
        goto block_002224AC;
    }
block_002224AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002224ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002224ACU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x5AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002224ACU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022253C; }
        goto block_002224B8;
    }
block_002224B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002224B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002224B8U);
        }
        {
            r1 = r9;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002224C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BossGoma_UpdateHit_00262258(frame, context, state, 0x00262258U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002224C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002224C4;
    }
block_002224C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002224C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002224C4U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000378U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r5 = r2;
        }
        {
            r7 = r1;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002224E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002224E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002224E4;
    }
block_002224E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002224E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002224E4U);
        }
        {
            r2 = r5;
        }
        {
            r1 = r7;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002224F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002224F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002224F4;
    }
block_002224F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002224F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002224F4U);
        }
        {
            const uint32_t updatedAddress = 0x002224FCU + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002224F4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002224F8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x00222508U + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222500U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0022253C; }
        goto block_0022250C;
    }
block_0022250C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022250CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022250CU);
        }
        {
            const uint32_t updatedAddress = 0x00222514U + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022250CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00222524; }
        goto block_00222518;
    }
block_00222518:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222518U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222518U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x70U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00222518U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0022253C; }
        goto block_00222524;
    }
block_00222524:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00222524U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00222524U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00222524U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00222524U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00222524U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00222524U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00222524U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00222524U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            r13 += 24U;
        }
        {
            r2 = r5;
        }
        {
            r1 = r7;
        }
        {
            r0 = r9;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00222534U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00222534U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00222534U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00222534U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00222534U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00222534U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00222534U,
                                           firstAddress + 24U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x00222534U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r14 = value14;
            r13 = r13 + 32U;
        }
        return Oot3dAotBranch(0x003761F0U);
    }
block_0022253C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022253CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022253CU);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0022253CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0022253CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0022253CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0022253CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022253CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0022253CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            r13 += 24U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00222540U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00222540U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00222540U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00222540U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00222540U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00222540U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00222540U,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00222540U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_BossGanon_Update_00242A94(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00242A94U:
        goto block_00242A94;
    case 0x00242ACCU:
        goto block_00242ACC;
    case 0x00242ADCU:
        goto block_00242ADC;
    case 0x00242AE0U:
        goto block_00242AE0;
    case 0x00242B08U:
        goto block_00242B08;
    case 0x00242B24U:
        goto block_00242B24;
    case 0x00242B6CU:
        goto block_00242B6C;
    case 0x00242B88U:
        goto block_00242B88;
    case 0x00242BA4U:
        goto block_00242BA4;
    case 0x00242BC0U:
        goto block_00242BC0;
    case 0x00242BF0U:
        goto block_00242BF0;
    case 0x00242BF8U:
        goto block_00242BF8;
    case 0x00242C04U:
        goto block_00242C04;
    case 0x00242C14U:
        goto block_00242C14;
    case 0x00242C1CU:
        goto block_00242C1C;
    case 0x00242C28U:
        goto block_00242C28;
    case 0x00242C34U:
        goto block_00242C34;
    case 0x00242C40U:
        goto block_00242C40;
    case 0x00242C48U:
        goto block_00242C48;
    case 0x00242C54U:
        goto block_00242C54;
    case 0x00242C60U:
        goto block_00242C60;
    case 0x00242C64U:
        goto block_00242C64;
    case 0x00242C6CU:
        goto block_00242C6C;
    case 0x00242C78U:
        goto block_00242C78;
    case 0x00242C84U:
        goto block_00242C84;
    case 0x00242CC8U:
        goto block_00242CC8;
    case 0x00242CD4U:
        goto block_00242CD4;
    case 0x00242CE0U:
        goto block_00242CE0;
    case 0x00242D14U:
        goto block_00242D14;
    case 0x00242D24U:
        goto block_00242D24;
    case 0x00242D38U:
        goto block_00242D38;
    case 0x00242D48U:
        goto block_00242D48;
    case 0x00242DB0U:
        goto block_00242DB0;
    case 0x00242DC4U:
        goto block_00242DC4;
    case 0x00242DD4U:
        goto block_00242DD4;
    case 0x00242DE4U:
        goto block_00242DE4;
    case 0x00242DF4U:
        goto block_00242DF4;
    case 0x00242E14U:
        goto block_00242E14;
    case 0x00242E18U:
        goto block_00242E18;
    case 0x00242E64U:
        goto block_00242E64;
    case 0x00242E6CU:
        goto block_00242E6C;
    case 0x00242E7CU:
        goto block_00242E7C;
    case 0x00242E80U:
        goto block_00242E80;
    case 0x00242EA8U:
        goto block_00242EA8;
    case 0x00242F20U:
        goto block_00242F20;
    case 0x00242F70U:
        goto block_00242F70;
    case 0x00242F7CU:
        goto block_00242F7C;
    case 0x00242FB0U:
        goto block_00242FB0;
    case 0x00242FBCU:
        goto block_00242FBC;
    case 0x00242FCCU:
        goto block_00242FCC;
    case 0x00242FECU:
        goto block_00242FEC;
    case 0x00242FFCU:
        goto block_00242FFC;
    case 0x00243008U:
        goto block_00243008;
    case 0x00243018U:
        goto block_00243018;
    case 0x0024302CU:
        goto block_0024302C;
    case 0x00243074U:
        goto block_00243074;
    case 0x00243084U:
        goto block_00243084;
    case 0x00243090U:
        goto block_00243090;
    case 0x002430BCU:
        goto block_002430BC;
    case 0x002430D8U:
        goto block_002430D8;
    case 0x002430F4U:
        goto block_002430F4;
    case 0x00243108U:
        goto block_00243108;
    case 0x00243114U:
        goto block_00243114;
    case 0x00243120U:
        goto block_00243120;
    case 0x00243128U:
        goto block_00243128;
    case 0x00243140U:
        goto block_00243140;
    case 0x00243144U:
        goto block_00243144;
    case 0x00243158U:
        goto block_00243158;
    case 0x0024317CU:
        goto block_0024317C;
    case 0x00243188U:
        goto block_00243188;
    case 0x002431A0U:
        goto block_002431A0;
    case 0x002431B0U:
        goto block_002431B0;
    case 0x002431BCU:
        goto block_002431BC;
    case 0x002431E0U:
        goto block_002431E0;
    case 0x002431F0U:
        goto block_002431F0;
    case 0x00243200U:
        goto block_00243200;
    case 0x00243230U:
        goto block_00243230;
    case 0x0024323CU:
        goto block_0024323C;
    case 0x00243280U:
        goto block_00243280;
    case 0x0024329CU:
        goto block_0024329C;
    case 0x002432B0U:
        goto block_002432B0;
    case 0x002432C4U:
        goto block_002432C4;
    case 0x002432D0U:
        goto block_002432D0;
    case 0x00243314U:
        goto block_00243314;
    case 0x0024337CU:
        goto block_0024337C;
    case 0x00243390U:
        goto block_00243390;
    case 0x002433A0U:
        goto block_002433A0;
    case 0x002433B4U:
        goto block_002433B4;
    case 0x002433CCU:
        goto block_002433CC;
    case 0x002433D8U:
        goto block_002433D8;
    case 0x00243418U:
        goto block_00243418;
    case 0x0024342CU:
        goto block_0024342C;
    case 0x00243454U:
        goto block_00243454;
    case 0x00243468U:
        goto block_00243468;
    case 0x00243474U:
        goto block_00243474;
    case 0x002434B4U:
        goto block_002434B4;
    case 0x002434C8U:
        goto block_002434C8;
    case 0x002434E4U:
        goto block_002434E4;
    case 0x002434F8U:
        goto block_002434F8;
    case 0x00243510U:
        goto block_00243510;
    case 0x00243518U:
        goto block_00243518;
    case 0x00243528U:
        goto block_00243528;
    case 0x00243544U:
        goto block_00243544;
    case 0x00243560U:
        goto block_00243560;
    case 0x00243564U:
        goto block_00243564;
    case 0x00243570U:
        goto block_00243570;
    case 0x002435C4U:
        goto block_002435C4;
    case 0x002435D0U:
        goto block_002435D0;
    case 0x002435E0U:
        goto block_002435E0;
    case 0x002435F0U:
        goto block_002435F0;
    case 0x002435FCU:
        goto block_002435FC;
    case 0x00243608U:
        goto block_00243608;
    case 0x00243610U:
        goto block_00243610;
    case 0x0024361CU:
        goto block_0024361C;
    case 0x00243620U:
        goto block_00243620;
    case 0x0024364CU:
        goto block_0024364C;
    case 0x00243654U:
        goto block_00243654;
    case 0x00243660U:
        goto block_00243660;
    case 0x002436A4U:
        goto block_002436A4;
    case 0x002436DCU:
        goto block_002436DC;
    case 0x002436ECU:
        goto block_002436EC;
    case 0x002436F8U:
        goto block_002436F8;
    case 0x00243700U:
        goto block_00243700;
    case 0x0024370CU:
        goto block_0024370C;
    case 0x00243710U:
        goto block_00243710;
    case 0x0024371CU:
        goto block_0024371C;
    case 0x0024372CU:
        goto block_0024372C;
    case 0x00243738U:
        goto block_00243738;
    case 0x00243764U:
        goto block_00243764;
    case 0x0024376CU:
        goto block_0024376C;
    case 0x00243778U:
        goto block_00243778;
    case 0x002437E0U:
        goto block_002437E0;
    case 0x002437E8U:
        goto block_002437E8;
    case 0x002437F0U:
        goto block_002437F0;
    case 0x00243804U:
        goto block_00243804;
    case 0x0024381CU:
        goto block_0024381C;
    case 0x0024382CU:
        goto block_0024382C;
    case 0x00243838U:
        goto block_00243838;
    case 0x00243840U:
        goto block_00243840;
    case 0x00243848U:
        goto block_00243848;
    case 0x00243868U:
        goto block_00243868;
    case 0x00243874U:
        goto block_00243874;
    case 0x0024388CU:
        goto block_0024388C;
    case 0x00243898U:
        goto block_00243898;
    case 0x002438B4U:
        goto block_002438B4;
    case 0x002438C0U:
        goto block_002438C0;
    case 0x002438DCU:
        goto block_002438DC;
    case 0x002438E8U:
        goto block_002438E8;
    case 0x002438F0U:
        goto block_002438F0;
    case 0x002438F4U:
        goto block_002438F4;
    case 0x002438FCU:
        goto block_002438FC;
    case 0x00243920U:
        goto block_00243920;
    case 0x0024392CU:
        goto block_0024392C;
    case 0x0024393CU:
        goto block_0024393C;
    case 0x0024395CU:
        goto block_0024395C;
    case 0x00243968U:
        goto block_00243968;
    case 0x00243978U:
        goto block_00243978;
    case 0x002439A0U:
        goto block_002439A0;
    case 0x002439ACU:
        goto block_002439AC;
    case 0x002439CCU:
        goto block_002439CC;
    case 0x002439D8U:
        goto block_002439D8;
    case 0x002439FCU:
        goto block_002439FC;
    case 0x00243A08U:
        goto block_00243A08;
    case 0x00243A24U:
        goto block_00243A24;
    case 0x00243A48U:
        goto block_00243A48;
    case 0x00243A54U:
        goto block_00243A54;
    case 0x00243A78U:
        goto block_00243A78;
    case 0x00243A84U:
        goto block_00243A84;
    case 0x00243AA4U:
        goto block_00243AA4;
    case 0x00243AB0U:
        goto block_00243AB0;
    case 0x00243AB4U:
        goto block_00243AB4;
    case 0x00243ABCU:
        goto block_00243ABC;
    case 0x00243AE0U:
        goto block_00243AE0;
    case 0x00243AECU:
        goto block_00243AEC;
    case 0x00243B0CU:
        goto block_00243B0C;
    case 0x00243B28U:
        goto block_00243B28;
    case 0x00243B48U:
        goto block_00243B48;
    case 0x00243B5CU:
        goto block_00243B5C;
    case 0x00243B8CU:
        goto block_00243B8C;
    case 0x00243BA0U:
        goto block_00243BA0;
    case 0x00243BB8U:
        goto block_00243BB8;
    case 0x00243BC4U:
        goto block_00243BC4;
    case 0x00243BD8U:
        goto block_00243BD8;
    case 0x00243C04U:
        goto block_00243C04;
    case 0x00243C18U:
        goto block_00243C18;
    case 0x00243C2CU:
        goto block_00243C2C;
    case 0x00243C38U:
        goto block_00243C38;
    case 0x00243C44U:
        goto block_00243C44;
    case 0x00243C54U:
        goto block_00243C54;
    case 0x00243C80U:
        goto block_00243C80;
    case 0x00243C84U:
        goto block_00243C84;
    case 0x00243C90U:
        goto block_00243C90;
    case 0x00243CCCU:
        goto block_00243CCC;
    case 0x00243CE0U:
        goto block_00243CE0;
    case 0x00243D4CU:
        goto block_00243D4C;
    case 0x00243D50U:
        goto block_00243D50;
    case 0x00243D60U:
        goto block_00243D60;
    case 0x00243D78U:
        goto block_00243D78;
    case 0x00243D88U:
        goto block_00243D88;
    case 0x00243DA0U:
        goto block_00243DA0;
    case 0x00243DB0U:
        goto block_00243DB0;
    case 0x00243DC0U:
        goto block_00243DC0;
    case 0x00243DCCU:
        goto block_00243DCC;
    case 0x00243DDCU:
        goto block_00243DDC;
    case 0x00243DE0U:
        goto block_00243DE0;
    case 0x00243E1CU:
        goto block_00243E1C;
    case 0x00243E4CU:
        goto block_00243E4C;
    case 0x00243E68U:
        goto block_00243E68;
    case 0x00243E74U:
        goto block_00243E74;
    case 0x00243E80U:
        goto block_00243E80;
    case 0x00243E90U:
        goto block_00243E90;
    case 0x00243E98U:
        goto block_00243E98;
    case 0x00243EA4U:
        goto block_00243EA4;
    case 0x00243EC0U:
        goto block_00243EC0;
    case 0x00243F08U:
        goto block_00243F08;
    case 0x00243F18U:
        goto block_00243F18;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00242A94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242A94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242A94U);
        }
        {
            const uint32_t firstAddress = r13 - 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00242A94U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00242A94U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00242A94U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00242A94U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00242A94U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00242A94U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00242A94U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00242A94U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00242A94U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00242A94U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00242A94U,
                                           firstAddress + 40U);
            }
            r13 = r13 - 44U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t updatedAddress = 0x00242AA4U + 0x41CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242A9CU, address);
            }
            r2 = value;
        }
        {
            r13 -= 56U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 44U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 48U, frame.Guest.vfp[28])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 48U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 52U, frame.Guest.vfp[29])) {
                return Oot3dAotMemoryFault(context, 0x00242AA0U,
                                           firstAddress + 52U);
            }
        }
        {
            const uint32_t operand = 0x00000064U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242AA8U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xAC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242AACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r11 = r7 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r11 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242AB8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00242ABCU, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x00242AC8U + 0x3FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242AC0U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00242AE0; }
        goto block_00242ACC;
    }
block_00242ACC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242ACCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242ACCU);
        }
        {
            const uint32_t operand = 0x00003800U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            r1 = 0x0000017CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242ADCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242ADCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242ADC;
    }
block_00242ADC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242ADCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242ADCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242ADCU, address);
            }
        }
        goto block_00242AE0;
    }
block_00242AE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242AE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242AE0U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242AE4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xA3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242AE8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00242AF4U + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242AECU, address);
            }
            frame.Guest.vfp[28] = value;
        }
        {
            const uint32_t address = 0x00242AF8U + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242AF0U, address);
            }
            frame.Guest.vfp[27] = value;
        }
        {
            const uint32_t address = 0x00242AFCU + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242AF4U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x00242B00U + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242AF8U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t address = 0x00242B04U + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242AFCU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00242D48; }
        goto block_00242B08;
    }
block_00242B08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242B08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242B08U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[28];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x00007C00U;
            r0 = r7 + operand;
        }
        {
            const uint32_t address = 0x00242B20U + 956U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242B18U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000398U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242B24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242B24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242B24;
    }
block_00242B24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242B24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242B24U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000030U;
            r0 = r13 + operand;
        }
        {
            r2 = r1;
        }
        {
            r3 = r1;
        }
        {
            r5 = r1;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00242B38U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00242B38U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00242B38U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00242B38U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00007C00U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00004C00U;
            r5 = r7 + operand;
        }
        {
            const uint32_t address = r0 + 920U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242B44U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242B4CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000038U;
            r5 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00242B54U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242B58U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r3 = r13 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242B6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkeletonAnimationModel_ApplyTevConstantColor_00358778(frame, context, state, 0x00358778U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242B6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242B6C;
    }
block_00242B6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242B6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242B6CU);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00242B70U, address);
            }
        }
        {
            r2 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242B78U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r3 = r13 + operand;
        }
        {
            r1 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242B88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkeletonAnimationModel_ApplyTevConstantColor_00358778(frame, context, state, 0x00358778U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242B88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242B88;
    }
block_00242B88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242B88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242B88U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00242B8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242B90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r3 = r13 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242BA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkeletonAnimationModel_ApplyTevConstantColor_00358778(frame, context, state, 0x00358778U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242BA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242BA4;
    }
block_00242BA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242BA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242BA4U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00242BA8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242BACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r3 = r13 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000009U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242BC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkeletonAnimationModel_ApplyTevConstantColor_00358778(frame, context, state, 0x00358778U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242BC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242BC0;
    }
block_00242BC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242BC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242BC0U);
        }
        {
            const uint32_t updatedAddress = 0x00242BC8U + 0x334U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242BC0U, address);
            }
            r10 = value;
        }
        {
            const uint32_t address = 0x00242BCCU + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242BC4U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x00242BD0U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242BC8U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x00242BD4U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242BCCU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x00242BD8U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242BD0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x00242BDCU + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242BD4U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x00242BE0U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242BD8U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x00242BE4U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242BDCU, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00242BE0U, address);
            }
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r9 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00005000U;
            r8 = r7 + operand;
        }
        goto block_00242BF0;
    }
block_00242BF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242BF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242BF0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242BF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242BF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242BF8;
    }
block_00242BF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242BF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242BF8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00242BF8U, 0xEE300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242BFCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242C04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242C04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242C04;
    }
block_00242C04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242C04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242C04U);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_00242C40; }
        goto block_00242C14;
    }
block_00242C14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242C14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242C14U);
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242C14U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242C1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242C1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242C1C;
    }
block_00242C1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242C1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242C1CU);
        }
        {
            const uint32_t address = r13 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242C1CU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[23];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242C28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242C28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242C28;
    }
block_00242C28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242C28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242C28U);
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242C28U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242C34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242C34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242C34;
    }
block_00242C34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242C34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242C34U);
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242C34U, address);
            }
        }
        {
        }
        goto block_00242C64;
    }
block_00242C40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242C40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242C40U);
        }
        {
            const uint32_t address = r13 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242C40U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242C48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242C48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242C48;
    }
block_00242C48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242C48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242C48U);
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242C48U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[23];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242C54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242C54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242C54;
    }
block_00242C54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242C54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242C54U);
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242C54U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242C60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242C60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242C60;
    }
block_00242C60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242C60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242C60U);
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242C60U, address);
            }
        }
        goto block_00242C64;
    }
block_00242C64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242C64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242C64U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[27];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242C6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242C6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242C6C;
    }
block_00242C6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242C6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242C6CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00242C6CU, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r8 + 0xC28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242C70U, address);
            }
            r5 = value;
        }
        {
            r0 = 0x00000000U;
        }
        goto block_00242C78;
    }
block_00242C78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242C78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242C78U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242C78U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00242D24; }
        goto block_00242C84;
    }
block_00242C84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242C84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242C84U);
        }
        {
            r0 = 0x00000009U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242C88U, address);
            }
        }
        {
            const uint32_t firstAddress = r9;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00242C8CU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00242C8CU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00242C8CU,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r5 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00242C94U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00242C94U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00242C94U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000040U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r5 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00242CA0U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00242CA0U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00242CA0U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t updatedAddress = 0x00242CACU + 0x254U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242CA4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00242CA8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00242CA8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00242CA8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r5 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00242CB0U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00242CB0U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00242CB0U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00242CB4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00242CB4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00242CB4U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r5 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x00242CB8U, address);
            }
        }
        {
            const uint32_t address = r5 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242CBCU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242CC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242CC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242CC8;
    }
block_00242CC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242CC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242CC8U);
        }
        {
            const uint32_t address = r5 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242CC8U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242CD4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242CD4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242CD4;
    }
block_00242CD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242CD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242CD4U);
        }
        {
            const uint32_t address = r5 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242CD4U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[25];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242CE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242CE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242CE0;
    }
block_00242CE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242CE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242CE0U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00242CE0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242CF4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r10;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00242CFCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242D00U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x29U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00242D04U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242D08U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242D0CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242D14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242D14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242D14;
    }
block_00242D14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242D14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242D14U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00242D14U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242D1CU, address);
            }
        }
        goto block_00242D38;
    }
block_00242D24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242D24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242D24U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r5 = r5 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000C8U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_00242C78; }
        goto block_00242D38;
    }
block_00242D38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242D38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242D38U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r6 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r6 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00242BF0; }
        goto block_00242D48;
    }
block_00242D48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242D48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242D48U);
        }
        {
            const uint32_t updatedAddress = 0x00242D50U + 0x1B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242D48U, address);
            }
            r9 = value;
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242D50U, address);
            }
        }
        {
            const uint32_t address = 0x00242D5CU + 424U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242D54U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242D58U, address);
            }
            r0 = value;
        }
        {
            r5 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000A00U;
            r8 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00001400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00242D70U + 0x19CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242D68U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r0 + 800U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242D6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xC18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x00242D70U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242D74U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00242D80U + 0x190U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242D78U, address);
            }
            r6 = value;
        }
        {
            const uint32_t address = 0x00242D84U + 400U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242D7CU, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242D84U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xCEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242D88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0xCEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242D90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xD0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242D94U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0xD0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242D9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xAC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242DA0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00242E6C; }
        goto block_00242DB0;
    }
block_00242DB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242DB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242DB0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242DB0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x47EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242DB8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00242E6C; }
        goto block_00242DC4;
    }
block_00242DC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242DC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242DC4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0xEEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242DC8U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00242E18; }
        goto block_00242DD4;
    }
block_00242DD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242DD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242DD4U);
        }
        {
            const uint32_t operand = 0x00003800U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            r1 = 0x0000017CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242DE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242DE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242DE4;
    }
block_00242DE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242DE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242DE4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242DE4U, address);
            }
        }
        {
            r1 = 0x0000001BU;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242DF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242DF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242DF4;
    }
block_00242DF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242DF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242DF4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            r1 = 0x0000001BU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00242E00U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242E04U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242E14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242E14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242E14;
    }
block_00242E14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242E14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242E14U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAC0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00242E14U, address);
            }
        }
        goto block_00242E18;
    }
block_00242E18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242E18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242E18U);
        }
        {
            r0 = 0x0000000FU;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x00242E28U + 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242E20U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0xEEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x00242E24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xE2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242E28U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00242E34U + 0xE8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242E2CU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00242E30U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00242E34U, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00242E3CU, 0xEE000A8BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00242E40U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r9 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242E4CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001400U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00242E54U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 792U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00242E58U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242E64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242E64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242E64;
    }
block_00242E64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242E64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242E64U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r0 + 904U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00242E68U, address);
            }
        }
        goto block_00242E6C;
    }
block_00242E6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242E6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242E6CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242E6CU, address);
            }
            r2 = value;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x00242E7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242E7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242E7C;
    }
block_00242E7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242E7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242E7CU);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_00242E80;
    }
block_00242E80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242E80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242E80U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000A00U;
            r2 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0xE2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242E8CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r2 + 0xE2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00242E9CU, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_00242E80; }
        goto block_00242EA8;
    }
block_00242EA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242EA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242EA8U);
        }
        {
            const uint32_t updatedAddress = r8 + 0xD2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242EA8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000C00U;
            r9 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r8 + 0xD2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242EB8U, address);
            }
        }
        goto block_00242F20;
    }
block_00242F20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242F20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242F20U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242F20U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r9 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242F2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242F30U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r9 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242F3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x1AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242F40U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r9 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242F4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xC8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242F50U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r8 + 0xC8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00242F5CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242F60U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242F64U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00242FFC; }
        goto block_00242F70;
    }
block_00242F70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242F70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242F70U);
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242F7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_001fdcb8_001FDCB8(frame, context, state, 0x001FDCB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242F7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242F7C;
    }
block_00242F7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242F7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242F7CU);
        }
        {
            const uint32_t operand = 0x00000B30U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00242F84U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00242F84U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00242F84U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t operand = 0x000003D8U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r6 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000038CU;
            r6 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00242F94U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00242F94U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00242F94U,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = r6;
        }
        {
            const uint32_t updatedAddress = r13 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242F9CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            r10 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242FB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242FB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242FB0;
    }
block_00242FB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242FB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242FB0U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242FB0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00242FFC; }
        goto block_00242FBC;
    }
block_00242FBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242FBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242FBCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242FBCU, address);
            }
            r0 = value;
        }
        {
            r2 = r6;
        }
        {
            r1 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242FCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242FCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242FCC;
    }
block_00242FCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242FCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242FCCU);
        }
        {
            const uint32_t updatedAddress = 0x00242FD4U + 0x35CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242FCCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242FD0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x00242FE0U + 0x354U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242FD8U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x00242FE8U + 0x350U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242FE0U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00242FFC; }
        goto block_00242FEC;
    }
block_00242FEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242FECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242FECU);
        }
        {
            const uint32_t updatedAddress = r13 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242FECU, address);
            }
            r0 = value;
        }
        {
            r2 = r6;
        }
        {
            r1 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00242FFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAT_003761F0(frame, context, state, 0x003761F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00242FFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00242FFC;
    }
block_00242FFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00242FFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00242FFCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAC5U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00242FFCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00243084; }
        goto block_00243008;
    }
block_00243008:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243008U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243008U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243008U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243018U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243018U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243018;
    }
block_00243018:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243018U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243018U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243018U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[17] = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0024302CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0024302CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0024302C;
    }
block_0024302C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024302CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024302CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r4 + 104U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243034U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r4 + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243038U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x00243044U + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0024303CU, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0xCEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243040U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0024304CU + 0x2F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243044U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243048U, 0xEE612A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        {
            const int32_t left = static_cast<int16_t>(
                r0 >> 0U);
            const int32_t right = static_cast<int16_t>(
                r1 >> 0U);
            r0 = static_cast<uint32_t>(left * right);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243054U, 0xEE610A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0024305CU, 0xEE402A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243064U, 0xEE400A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243068U, 0xEE228A82U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[5], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0024306CU, 0xEE608A82U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243074U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243074U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243074;
    }
block_00243074:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243074U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243074U);
        }
        {
            const uint32_t address = 0x0024307CU + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243074U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00243080U + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243078U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0024307CU, 0xEE10AA20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        goto block_00243090;
    }
block_00243084:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243084U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243084U);
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[17] = frame.Guest.vfp[16];
        }
        goto block_00243090;
    }
block_00243090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243090U);
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[24];
        }
        {
            const uint32_t address = 0x0024309CU + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243094U, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r4 + 0xAC5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002430ACU, address);
            }
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000288U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002430BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002430BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002430BC;
    }
block_002430BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002430BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002430BCU);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000028CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002430D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002430D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002430D8;
    }
block_002430D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002430D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002430D8U);
        }
        {
            const uint32_t address = 0x002430E0U + 624U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002430D8U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00000E90U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002430F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002430F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002430F4;
    }
block_002430F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002430F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002430F4U);
        }
        {
            const uint32_t updatedAddress = r8 + 0xE6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002430F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x00243104U + 0x250U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002430FCU, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x00243108U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243108U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243108;
    }
block_00243108:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243108U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243108U);
        }
        {
            const uint32_t updatedAddress = r8 + 0xE6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243108U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000096U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00243128; }
        goto block_00243114;
    }
block_00243114:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243114U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243114U);
        }
        {
            const uint32_t updatedAddress = 0x0024311CU + 0x23CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243114U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243120U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243120U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243120;
    }
block_00243120:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243120U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243120U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r8 + 0xE6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243124U, address);
            }
        }
        goto block_00243128;
    }
block_00243128:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243128U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243128U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x1AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243128U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00243134U + 552U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0024312CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r9 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243134U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_002431F0; }
        goto block_00243140;
    }
block_00243140:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243140U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243140U);
        }
        {
            r5 = 0x00000001U;
        }
        goto block_00243144;
    }
block_00243144:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243144U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243144U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000E00U;
            r1 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x60U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0024314CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00243188; }
        goto block_00243158;
    }
block_00243158:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243158U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243158U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0024315CU, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 2U);
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[23];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r9 + 644U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243170U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000218U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0024317CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0024317CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0024317C;
    }
block_0024317C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024317CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024317CU);
        }
        {
        }
        {
        }
        goto block_002431A0;
    }
block_00243188:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243188U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243188U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 2U);
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000218U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002431A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002431A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002431A0;
    }
block_002431A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002431A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002431A0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r5 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000012U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_00243144; }
        goto block_002431B0;
    }
block_002431B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002431B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002431B0U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002431B0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002431F0; }
        goto block_002431BC;
    }
block_002431BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002431BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002431BCU);
        }
        {
            const uint32_t updatedAddress = 0x002431C4U + 0x19CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002431BCU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x002431C8U + 0x19CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002431C0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002431C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x002431C8U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x002431DCU + 0x18CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002431D4U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002431E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002431E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002431E0;
    }
block_002431E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002431E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002431E0U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t address = 0x002431ECU + 384U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002431E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002431F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0036cae4_0036CAE4(frame, context, state, 0x0036CAE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002431F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002431F0;
    }
block_002431F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002431F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002431F0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xACBU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002431F0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x002431FCU + 372U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002431F4U, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00243390; }
        goto block_00243200;
    }
block_00243200:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243200U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243200U);
        }
        {
            r10 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243208U, address);
            }
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0024320CU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0024320CU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0024320CU,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r6 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00005000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t address = 0x00243220U + 340U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243218U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0024321CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0024321CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0024321CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00243220U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243224U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xC28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243228U, address);
            }
            r5 = value;
        }
        {
            r0 = r10;
        }
        goto block_00243230;
    }
block_00243230:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243230U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243230U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243230U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0024329C; }
        goto block_0024323C;
    }
block_0024323C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024323CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024323CU);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243240U, address);
            }
        }
        {
            const uint32_t firstAddress = r6;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00243244U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00243244U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00243244U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r5 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0024324CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0024324CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0024324CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0024325CU - 0x35CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243254U, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00243258U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00243258U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00243258U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0024325CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0024325CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0024325CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r5 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00243264U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00243264U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00243264U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00243268U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00243268U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00243268U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r5 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0024326CU, address);
            }
        }
        {
            const uint32_t address = r5 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00243270U, address);
            }
        }
        {
            const uint32_t address = r5 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00243274U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243280U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243280U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243280;
    }
block_00243280:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243280U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243280U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243280U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243288U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0024328CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243290U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243294U, address);
            }
        }
        goto block_002432B0;
    }
block_0024329C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024329CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024329CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r5 = r5 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000096U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_00243230; }
        goto block_002432B0;
    }
block_002432B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002432B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002432B0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002432B0U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[24] = frame.Guest.vfp[26];
        }
        {
            const uint32_t address = 0x002432C0U + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002432B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xC28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002432BCU, address);
            }
            r5 = value;
        }
        {
            r0 = 0x00000000U;
        }
        goto block_002432C4;
    }
block_002432C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002432C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002432C4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002432C4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0024337C; }
        goto block_002432D0;
    }
block_002432D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002432D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002432D0U);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002432D4U, address);
            }
        }
        {
            const uint32_t firstAddress = r6;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002432D8U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002432D8U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002432D8U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r5 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002432E0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002432E0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002432E0U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = 0x002432F0U - 0x3F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002432E8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002432ECU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002432ECU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002432ECU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002432F0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002432F0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002432F0U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r5 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002432F8U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002432F8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002432F8U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002432FCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002432FCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002432FCU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r5 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00243300U, address);
            }
        }
        {
            const uint32_t address = r5 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x00243304U, address);
            }
        }
        {
            const uint32_t address = r5 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00243308U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243314U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243314U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243314;
    }
block_00243314:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243314U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243314U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243314U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0024331CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243320U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243324U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243328U, address);
            }
        }
        goto block_00243390;
    }
block_0024337C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024337CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024337CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r5 = r5 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000096U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_002432C4; }
        goto block_00243390;
    }
block_00243390:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243390U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243390U);
        }
        {
            const uint32_t operand = 0x00000B00U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243394U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_002434C8; }
        goto block_002433A0;
    }
block_002433A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002433A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002433A0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r1 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002433ACU, address);
            }
        }
        if (!(flags.Z())) { goto block_0024342C; }
        goto block_002433B4;
    }
block_002433B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002433B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002433B4U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            const uint32_t updatedAddress = 0x002433C0U + 0x3E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002433B8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + r7;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002433C4U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        goto block_002433CC;
    }
block_002433CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002433CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002433CCU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002433CCU, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00243418; }
        goto block_002433D8;
    }
block_002433D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002433D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002433D8U);
        }
        {
            const uint32_t updatedAddress = 0x002433E0U - 0x4E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002433D8U, address);
            }
            r6 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002433E0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000010U;
            r5 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r6;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002433E8U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002433E8U,
                                           firstAddress + 4U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002433E8U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r10 = value10;
        }
        {
            const uint32_t firstAddress = r5;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002433ECU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002433ECU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002433ECU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r5 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r6;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002433F4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002433F4U,
                                           firstAddress + 4U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002433F4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r10 = value10;
        }
        {
            const uint32_t firstAddress = r5;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002433F8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002433F8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002433F8U,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00243400U, address);
            }
        }
        {
            const uint32_t address = r0 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00243404U, address);
            }
        }
        {
            const uint32_t address = r0 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00243408U, address);
            }
        }
        {
            const uint32_t address = r0 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0024340CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00243410U, address);
            }
        }
        goto block_0024342C;
    }
block_00243418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243418U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000096U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_002433CC; }
        goto block_0024342C;
    }
block_0024342C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024342CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024342CU);
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x00243438U + 888U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243430U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 932U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243434U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243438U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x00243444U + 0x368U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0024343CU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r1 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243448U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0024344CU, 0xEE408A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[17], frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243454U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243454U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243454;
    }
block_00243454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243454U);
        }
        {
            const uint32_t address = 0x0024345CU + 856U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243454U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x00243460U + 0x348U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243458U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243460U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r0 + r7;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243464U, address);
            }
            r0 = value;
        }
        goto block_00243468;
    }
block_00243468:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243468U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243468U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243468U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_002434B4; }
        goto block_00243474;
    }
block_00243474:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243474U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243474U);
        }
        {
            const uint32_t updatedAddress = 0x0024347CU - 0x57CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243474U, address);
            }
            r5 = value;
        }
        {
            r1 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0024347CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000010U;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00243484U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00243484U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00243484U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00243488U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00243488U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00243488U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00243490U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00243490U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00243490U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00243494U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00243494U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00243494U,
                                           firstAddress + 8U);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0024349CU, address);
            }
        }
        {
            const uint32_t address = r0 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x002434A0U, address);
            }
        }
        {
            const uint32_t address = r0 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x002434A4U, address);
            }
        }
        {
            const uint32_t address = r0 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002434A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002434ACU, address);
            }
        }
        goto block_002434C8;
    }
block_002434B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002434B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002434B4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000096U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_00243468; }
        goto block_002434C8;
    }
block_002434C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002434C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002434C8U);
        }
        {
            const uint32_t updatedAddress = r8 + 0xC8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002434C8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x002434D4U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002434CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r10 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0xACAU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002434D8U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_002435FC; }
        goto block_002434E4;
    }
block_002434E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002434E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002434E4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAC6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002434E4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0xC8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002434ECU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00243564; }
        goto block_002434F8;
    }
block_002434F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002434F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002434F8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAC6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002434F8U, address);
            }
        }
        {
            const uint32_t address = 0x00243504U + 696U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002434FCU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00243500U, address);
            }
        }
        {
            const uint32_t address = 0x0024350CU + 692U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243504U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0024350CU, address);
            }
        }
        goto block_00243510;
    }
block_00243510:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243510U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243510U);
        }
        {
            r5 = 0x00000000U;
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00243514U, address);
            }
        }
        goto block_00243518;
    }
block_00243518:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243518U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243518U);
        }
        {
            const uint32_t operand = 0x00000040U;
            r2 = r13 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243528U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003544a4_003544A4(frame, context, state, 0x003544A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243528U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243528;
    }
block_00243528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243528U);
        }
        {
            const uint32_t address = r13 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243528U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243530U, 0xEE300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0024353CU, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00243518; }
        goto block_00243544;
    }
block_00243544:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243544U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243544U);
        }
        {
            const uint32_t address = r13 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243544U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r6 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0024354CU, 0xEE300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r6 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00243558U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00243510; }
        goto block_00243560;
    }
block_00243560:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243560U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243560U);
        }
        goto block_002435FC;
    }
block_00243564:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243564U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243564U);
        }
        {
            const uint32_t updatedAddress = r8 + 0xC8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243564U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_002435FC; }
        goto block_00243570;
    }
block_00243570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243570U);
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00243570U, address);
            }
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00243574U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xC8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243578U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x00243584U + 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0024357CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243588U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0024358CU, 0xEE611A2BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243594U, 0xDE111AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243598U, 0xCE011AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0024359CU, 0xEEFD0AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002435A8U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002435ACU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x002435B8U + 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002435B0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002435B4U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002435B8U, address);
            }
        }
        {
            const uint32_t address = 0x002435C4U + 520U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002435BCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002435C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002435C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002435C4;
    }
block_002435C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002435C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002435C4U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002435D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Matrix_RotateY_003735E8(frame, context, state, 0x003735E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002435D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002435D0;
    }
block_002435D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002435D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002435D0U);
        }
        {
            const uint32_t operand = 0x0000004CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000040U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002435E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002435E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002435E0;
    }
block_002435E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002435E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002435E0U);
        }
        {
            const uint32_t operand = 0x00000040U;
            r2 = r13 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002435F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003544a4_003544A4(frame, context, state, 0x003544A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002435F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002435F0;
    }
block_002435F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002435F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002435F0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xACAU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002435F0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002435F8U, address);
            }
        }
        goto block_002435FC;
    }
block_002435FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002435FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002435FCU);
        }
        {
            const uint32_t updatedAddress = r11 + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002435FCU, address);
            }
            r6 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002436F8; }
        goto block_00243608;
    }
block_00243608:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243608U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243608U);
        }
        {
            const uint32_t address = 0x00243610U + 448U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243608U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x00243614U + 448U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0024360CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        goto block_00243610;
    }
block_00243610:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243610U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243610U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243610U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_002436EC; }
        goto block_0024361C;
    }
block_0024361C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024361CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024361CU);
        }
        {
            r5 = 0x00000000U;
        }
        goto block_00243620;
    }
block_00243620:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243620U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243620U);
        }
        {
            frame.Guest.vfp[0] = r5;
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00243624U, address);
            }
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00243628U, address);
            }
        }
        {
            const uint32_t address = r13 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0024362CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243630U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243634U, 0xEE60AA28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243638U, 0xEEF4AA69U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[21], frame.Guest.vfp[19],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            frame.Guest.vfp[20] = frame.Guest.vfp[19];
        }
        if (flags.Z()) {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        if (flags.Z()) { goto block_00243660; }
        goto block_0024364C;
    }
block_0024364C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024364CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024364CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243654U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243654U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243654;
    }
block_00243654:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243654U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243654U);
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243660U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243660U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243660;
    }
block_00243660:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243660U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243660U);
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00243660U, address);
            }
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00243664U, address);
            }
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x00243668U, address);
            }
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0024366CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243670U, 0xEEF10A4AU};
            frame.Guest.vfp[1] = frame.Guest.vfp[20] ^ 0x80000000U;
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00243674U, address);
            }
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00243678U, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0024367CU, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00243680U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00243684U, address);
            }
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00243688U, address);
            }
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0024368CU, address);
            }
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00243690U, address);
            }
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000040U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002436A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002436A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002436A4;
    }
block_002436A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002436A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002436A4U);
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002436A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002436A8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000034U;
            r2 = r13 + operand;
        }
        {
            r1 = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002436B4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = r4;
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002436BCU, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002436C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002436C4U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002436C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002436CCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002436D0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002436D4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002436DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003544a4_003544A4(frame, context, state, 0x003544A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002436DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002436DC;
    }
block_002436DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002436DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002436DCU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r5 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_00243620; }
        goto block_002436EC;
    }
block_002436EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002436ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002436ECU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x130U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002436ECU, address);
            }
            r6 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00243610; }
        goto block_002436F8;
    }
block_002436F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002436F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002436F8U);
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243700U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0011393c_0011393C(frame, context, state, 0x0011393CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243700U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243700;
    }
block_00243700:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243700U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243700U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243700U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00243738; }
        goto block_0024370C;
    }
block_0024370C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024370CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024370CU);
        }
        {
            const uint32_t updatedAddress = 0x00243714U + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0024370CU, address);
            }
            r1 = value;
        }
        goto block_00243710;
    }
block_00243710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243710U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243710U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0024372C; }
        goto block_0024371C;
    }
block_0024371C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024371CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024371CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x1C6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0024371CU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243724U, address);
            }
        }
        if (!(flags.Z())) { goto block_00243738; }
        goto block_0024372C;
    }
block_0024372C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024372CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024372CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x130U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0024372CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00243710; }
        goto block_00243738;
    }
block_00243738:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243738U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243738U);
        }
        {
            const uint32_t operand = 0x00003000U;
            r5 = r7 + operand;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x237U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00243740U, address);
            }
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00243748U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x25CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0024374CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xCCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243750U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            const uint32_t address = 0x0024375CU + 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243754U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = 0x0000000BU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002439D8; }
        goto block_00243764;
    }
block_00243764:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243764U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243764U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_002437E0; }
        goto block_0024376C;
    }
block_0024376C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024376CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024376CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x0024377CU + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243774U, address);
            }
            switch (value) {
            case 0x00242A94U:
                goto block_00242A94;
            case 0x00242ACCU:
                goto block_00242ACC;
            case 0x00242ADCU:
                goto block_00242ADC;
            case 0x00242AE0U:
                goto block_00242AE0;
            case 0x00242B08U:
                goto block_00242B08;
            case 0x00242B24U:
                goto block_00242B24;
            case 0x00242B6CU:
                goto block_00242B6C;
            case 0x00242B88U:
                goto block_00242B88;
            case 0x00242BA4U:
                goto block_00242BA4;
            case 0x00242BC0U:
                goto block_00242BC0;
            case 0x00242BF0U:
                goto block_00242BF0;
            case 0x00242BF8U:
                goto block_00242BF8;
            case 0x00242C04U:
                goto block_00242C04;
            case 0x00242C14U:
                goto block_00242C14;
            case 0x00242C1CU:
                goto block_00242C1C;
            case 0x00242C28U:
                goto block_00242C28;
            case 0x00242C34U:
                goto block_00242C34;
            case 0x00242C40U:
                goto block_00242C40;
            case 0x00242C48U:
                goto block_00242C48;
            case 0x00242C54U:
                goto block_00242C54;
            case 0x00242C60U:
                goto block_00242C60;
            case 0x00242C64U:
                goto block_00242C64;
            case 0x00242C6CU:
                goto block_00242C6C;
            case 0x00242C78U:
                goto block_00242C78;
            case 0x00242C84U:
                goto block_00242C84;
            case 0x00242CC8U:
                goto block_00242CC8;
            case 0x00242CD4U:
                goto block_00242CD4;
            case 0x00242CE0U:
                goto block_00242CE0;
            case 0x00242D14U:
                goto block_00242D14;
            case 0x00242D24U:
                goto block_00242D24;
            case 0x00242D38U:
                goto block_00242D38;
            case 0x00242D48U:
                goto block_00242D48;
            case 0x00242DB0U:
                goto block_00242DB0;
            case 0x00242DC4U:
                goto block_00242DC4;
            case 0x00242DD4U:
                goto block_00242DD4;
            case 0x00242DE4U:
                goto block_00242DE4;
            case 0x00242DF4U:
                goto block_00242DF4;
            case 0x00242E14U:
                goto block_00242E14;
            case 0x00242E18U:
                goto block_00242E18;
            case 0x00242E64U:
                goto block_00242E64;
            case 0x00242E6CU:
                goto block_00242E6C;
            case 0x00242E7CU:
                goto block_00242E7C;
            case 0x00242E80U:
                goto block_00242E80;
            case 0x00242EA8U:
                goto block_00242EA8;
            case 0x00242F20U:
                goto block_00242F20;
            case 0x00242F70U:
                goto block_00242F70;
            case 0x00242F7CU:
                goto block_00242F7C;
            case 0x00242FB0U:
                goto block_00242FB0;
            case 0x00242FBCU:
                goto block_00242FBC;
            case 0x00242FCCU:
                goto block_00242FCC;
            case 0x00242FECU:
                goto block_00242FEC;
            case 0x00242FFCU:
                goto block_00242FFC;
            case 0x00243008U:
                goto block_00243008;
            case 0x00243018U:
                goto block_00243018;
            case 0x0024302CU:
                goto block_0024302C;
            case 0x00243074U:
                goto block_00243074;
            case 0x00243084U:
                goto block_00243084;
            case 0x00243090U:
                goto block_00243090;
            case 0x002430BCU:
                goto block_002430BC;
            case 0x002430D8U:
                goto block_002430D8;
            case 0x002430F4U:
                goto block_002430F4;
            case 0x00243108U:
                goto block_00243108;
            case 0x00243114U:
                goto block_00243114;
            case 0x00243120U:
                goto block_00243120;
            case 0x00243128U:
                goto block_00243128;
            case 0x00243140U:
                goto block_00243140;
            case 0x00243144U:
                goto block_00243144;
            case 0x00243158U:
                goto block_00243158;
            case 0x0024317CU:
                goto block_0024317C;
            case 0x00243188U:
                goto block_00243188;
            case 0x002431A0U:
                goto block_002431A0;
            case 0x002431B0U:
                goto block_002431B0;
            case 0x002431BCU:
                goto block_002431BC;
            case 0x002431E0U:
                goto block_002431E0;
            case 0x002431F0U:
                goto block_002431F0;
            case 0x00243200U:
                goto block_00243200;
            case 0x00243230U:
                goto block_00243230;
            case 0x0024323CU:
                goto block_0024323C;
            case 0x00243280U:
                goto block_00243280;
            case 0x0024329CU:
                goto block_0024329C;
            case 0x002432B0U:
                goto block_002432B0;
            case 0x002432C4U:
                goto block_002432C4;
            case 0x002432D0U:
                goto block_002432D0;
            case 0x00243314U:
                goto block_00243314;
            case 0x0024337CU:
                goto block_0024337C;
            case 0x00243390U:
                goto block_00243390;
            case 0x002433A0U:
                goto block_002433A0;
            case 0x002433B4U:
                goto block_002433B4;
            case 0x002433CCU:
                goto block_002433CC;
            case 0x002433D8U:
                goto block_002433D8;
            case 0x00243418U:
                goto block_00243418;
            case 0x0024342CU:
                goto block_0024342C;
            case 0x00243454U:
                goto block_00243454;
            case 0x00243468U:
                goto block_00243468;
            case 0x00243474U:
                goto block_00243474;
            case 0x002434B4U:
                goto block_002434B4;
            case 0x002434C8U:
                goto block_002434C8;
            case 0x002434E4U:
                goto block_002434E4;
            case 0x002434F8U:
                goto block_002434F8;
            case 0x00243510U:
                goto block_00243510;
            case 0x00243518U:
                goto block_00243518;
            case 0x00243528U:
                goto block_00243528;
            case 0x00243544U:
                goto block_00243544;
            case 0x00243560U:
                goto block_00243560;
            case 0x00243564U:
                goto block_00243564;
            case 0x00243570U:
                goto block_00243570;
            case 0x002435C4U:
                goto block_002435C4;
            case 0x002435D0U:
                goto block_002435D0;
            case 0x002435E0U:
                goto block_002435E0;
            case 0x002435F0U:
                goto block_002435F0;
            case 0x002435FCU:
                goto block_002435FC;
            case 0x00243608U:
                goto block_00243608;
            case 0x00243610U:
                goto block_00243610;
            case 0x0024361CU:
                goto block_0024361C;
            case 0x00243620U:
                goto block_00243620;
            case 0x0024364CU:
                goto block_0024364C;
            case 0x00243654U:
                goto block_00243654;
            case 0x00243660U:
                goto block_00243660;
            case 0x002436A4U:
                goto block_002436A4;
            case 0x002436DCU:
                goto block_002436DC;
            case 0x002436ECU:
                goto block_002436EC;
            case 0x002436F8U:
                goto block_002436F8;
            case 0x00243700U:
                goto block_00243700;
            case 0x0024370CU:
                goto block_0024370C;
            case 0x00243710U:
                goto block_00243710;
            case 0x0024371CU:
                goto block_0024371C;
            case 0x0024372CU:
                goto block_0024372C;
            case 0x00243738U:
                goto block_00243738;
            case 0x00243764U:
                goto block_00243764;
            case 0x0024376CU:
                goto block_0024376C;
            case 0x00243778U:
                goto block_00243778;
            case 0x002437E0U:
                goto block_002437E0;
            case 0x002437E8U:
                goto block_002437E8;
            case 0x002437F0U:
                goto block_002437F0;
            case 0x00243804U:
                goto block_00243804;
            case 0x0024381CU:
                goto block_0024381C;
            case 0x0024382CU:
                goto block_0024382C;
            case 0x00243838U:
                goto block_00243838;
            case 0x00243840U:
                goto block_00243840;
            case 0x00243848U:
                goto block_00243848;
            case 0x00243868U:
                goto block_00243868;
            case 0x00243874U:
                goto block_00243874;
            case 0x0024388CU:
                goto block_0024388C;
            case 0x00243898U:
                goto block_00243898;
            case 0x002438B4U:
                goto block_002438B4;
            case 0x002438C0U:
                goto block_002438C0;
            case 0x002438DCU:
                goto block_002438DC;
            case 0x002438E8U:
                goto block_002438E8;
            case 0x002438F0U:
                goto block_002438F0;
            case 0x002438F4U:
                goto block_002438F4;
            case 0x002438FCU:
                goto block_002438FC;
            case 0x00243920U:
                goto block_00243920;
            case 0x0024392CU:
                goto block_0024392C;
            case 0x0024393CU:
                goto block_0024393C;
            case 0x0024395CU:
                goto block_0024395C;
            case 0x00243968U:
                goto block_00243968;
            case 0x00243978U:
                goto block_00243978;
            case 0x002439A0U:
                goto block_002439A0;
            case 0x002439ACU:
                goto block_002439AC;
            case 0x002439CCU:
                goto block_002439CC;
            case 0x002439D8U:
                goto block_002439D8;
            case 0x002439FCU:
                goto block_002439FC;
            case 0x00243A08U:
                goto block_00243A08;
            case 0x00243A24U:
                goto block_00243A24;
            case 0x00243A48U:
                goto block_00243A48;
            case 0x00243A54U:
                goto block_00243A54;
            case 0x00243A78U:
                goto block_00243A78;
            case 0x00243A84U:
                goto block_00243A84;
            case 0x00243AA4U:
                goto block_00243AA4;
            case 0x00243AB0U:
                goto block_00243AB0;
            case 0x00243AB4U:
                goto block_00243AB4;
            case 0x00243ABCU:
                goto block_00243ABC;
            case 0x00243AE0U:
                goto block_00243AE0;
            case 0x00243AECU:
                goto block_00243AEC;
            case 0x00243B0CU:
                goto block_00243B0C;
            case 0x00243B28U:
                goto block_00243B28;
            case 0x00243B48U:
                goto block_00243B48;
            case 0x00243B5CU:
                goto block_00243B5C;
            case 0x00243B8CU:
                goto block_00243B8C;
            case 0x00243BA0U:
                goto block_00243BA0;
            case 0x00243BB8U:
                goto block_00243BB8;
            case 0x00243BC4U:
                goto block_00243BC4;
            case 0x00243BD8U:
                goto block_00243BD8;
            case 0x00243C04U:
                goto block_00243C04;
            case 0x00243C18U:
                goto block_00243C18;
            case 0x00243C2CU:
                goto block_00243C2C;
            case 0x00243C38U:
                goto block_00243C38;
            case 0x00243C44U:
                goto block_00243C44;
            case 0x00243C54U:
                goto block_00243C54;
            case 0x00243C80U:
                goto block_00243C80;
            case 0x00243C84U:
                goto block_00243C84;
            case 0x00243C90U:
                goto block_00243C90;
            case 0x00243CCCU:
                goto block_00243CCC;
            case 0x00243CE0U:
                goto block_00243CE0;
            case 0x00243D4CU:
                goto block_00243D4C;
            case 0x00243D50U:
                goto block_00243D50;
            case 0x00243D60U:
                goto block_00243D60;
            case 0x00243D78U:
                goto block_00243D78;
            case 0x00243D88U:
                goto block_00243D88;
            case 0x00243DA0U:
                goto block_00243DA0;
            case 0x00243DB0U:
                goto block_00243DB0;
            case 0x00243DC0U:
                goto block_00243DC0;
            case 0x00243DCCU:
                goto block_00243DCC;
            case 0x00243DDCU:
                goto block_00243DDC;
            case 0x00243DE0U:
                goto block_00243DE0;
            case 0x00243E1CU:
                goto block_00243E1C;
            case 0x00243E4CU:
                goto block_00243E4C;
            case 0x00243E68U:
                goto block_00243E68;
            case 0x00243E74U:
                goto block_00243E74;
            case 0x00243E80U:
                goto block_00243E80;
            case 0x00243E90U:
                goto block_00243E90;
            case 0x00243E98U:
                goto block_00243E98;
            case 0x00243EA4U:
                goto block_00243EA4;
            case 0x00243EC0U:
                goto block_00243EC0;
            case 0x00243F08U:
                goto block_00243F08;
            case 0x00243F18U:
                goto block_00243F18;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_00243778;
    }
block_00243778:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243778U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243778U);
        }
        goto block_00243B0C;
    }
block_002437E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002437E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002437E0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000010U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00243AEC; }
        goto block_002437E8;
    }
block_002437E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002437E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002437E8U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0024381C; }
        goto block_002437F0;
    }
block_002437F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002437F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002437F0U);
        }
        {
            const uint32_t operand = 0x0000000BU;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r1 = 0x0000000CU;
        }
        {
            r2 = 0x0000000EU;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x00243808U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243800U, address);
            }
            switch (value) {
            case 0x00242A94U:
                goto block_00242A94;
            case 0x00242ACCU:
                goto block_00242ACC;
            case 0x00242ADCU:
                goto block_00242ADC;
            case 0x00242AE0U:
                goto block_00242AE0;
            case 0x00242B08U:
                goto block_00242B08;
            case 0x00242B24U:
                goto block_00242B24;
            case 0x00242B6CU:
                goto block_00242B6C;
            case 0x00242B88U:
                goto block_00242B88;
            case 0x00242BA4U:
                goto block_00242BA4;
            case 0x00242BC0U:
                goto block_00242BC0;
            case 0x00242BF0U:
                goto block_00242BF0;
            case 0x00242BF8U:
                goto block_00242BF8;
            case 0x00242C04U:
                goto block_00242C04;
            case 0x00242C14U:
                goto block_00242C14;
            case 0x00242C1CU:
                goto block_00242C1C;
            case 0x00242C28U:
                goto block_00242C28;
            case 0x00242C34U:
                goto block_00242C34;
            case 0x00242C40U:
                goto block_00242C40;
            case 0x00242C48U:
                goto block_00242C48;
            case 0x00242C54U:
                goto block_00242C54;
            case 0x00242C60U:
                goto block_00242C60;
            case 0x00242C64U:
                goto block_00242C64;
            case 0x00242C6CU:
                goto block_00242C6C;
            case 0x00242C78U:
                goto block_00242C78;
            case 0x00242C84U:
                goto block_00242C84;
            case 0x00242CC8U:
                goto block_00242CC8;
            case 0x00242CD4U:
                goto block_00242CD4;
            case 0x00242CE0U:
                goto block_00242CE0;
            case 0x00242D14U:
                goto block_00242D14;
            case 0x00242D24U:
                goto block_00242D24;
            case 0x00242D38U:
                goto block_00242D38;
            case 0x00242D48U:
                goto block_00242D48;
            case 0x00242DB0U:
                goto block_00242DB0;
            case 0x00242DC4U:
                goto block_00242DC4;
            case 0x00242DD4U:
                goto block_00242DD4;
            case 0x00242DE4U:
                goto block_00242DE4;
            case 0x00242DF4U:
                goto block_00242DF4;
            case 0x00242E14U:
                goto block_00242E14;
            case 0x00242E18U:
                goto block_00242E18;
            case 0x00242E64U:
                goto block_00242E64;
            case 0x00242E6CU:
                goto block_00242E6C;
            case 0x00242E7CU:
                goto block_00242E7C;
            case 0x00242E80U:
                goto block_00242E80;
            case 0x00242EA8U:
                goto block_00242EA8;
            case 0x00242F20U:
                goto block_00242F20;
            case 0x00242F70U:
                goto block_00242F70;
            case 0x00242F7CU:
                goto block_00242F7C;
            case 0x00242FB0U:
                goto block_00242FB0;
            case 0x00242FBCU:
                goto block_00242FBC;
            case 0x00242FCCU:
                goto block_00242FCC;
            case 0x00242FECU:
                goto block_00242FEC;
            case 0x00242FFCU:
                goto block_00242FFC;
            case 0x00243008U:
                goto block_00243008;
            case 0x00243018U:
                goto block_00243018;
            case 0x0024302CU:
                goto block_0024302C;
            case 0x00243074U:
                goto block_00243074;
            case 0x00243084U:
                goto block_00243084;
            case 0x00243090U:
                goto block_00243090;
            case 0x002430BCU:
                goto block_002430BC;
            case 0x002430D8U:
                goto block_002430D8;
            case 0x002430F4U:
                goto block_002430F4;
            case 0x00243108U:
                goto block_00243108;
            case 0x00243114U:
                goto block_00243114;
            case 0x00243120U:
                goto block_00243120;
            case 0x00243128U:
                goto block_00243128;
            case 0x00243140U:
                goto block_00243140;
            case 0x00243144U:
                goto block_00243144;
            case 0x00243158U:
                goto block_00243158;
            case 0x0024317CU:
                goto block_0024317C;
            case 0x00243188U:
                goto block_00243188;
            case 0x002431A0U:
                goto block_002431A0;
            case 0x002431B0U:
                goto block_002431B0;
            case 0x002431BCU:
                goto block_002431BC;
            case 0x002431E0U:
                goto block_002431E0;
            case 0x002431F0U:
                goto block_002431F0;
            case 0x00243200U:
                goto block_00243200;
            case 0x00243230U:
                goto block_00243230;
            case 0x0024323CU:
                goto block_0024323C;
            case 0x00243280U:
                goto block_00243280;
            case 0x0024329CU:
                goto block_0024329C;
            case 0x002432B0U:
                goto block_002432B0;
            case 0x002432C4U:
                goto block_002432C4;
            case 0x002432D0U:
                goto block_002432D0;
            case 0x00243314U:
                goto block_00243314;
            case 0x0024337CU:
                goto block_0024337C;
            case 0x00243390U:
                goto block_00243390;
            case 0x002433A0U:
                goto block_002433A0;
            case 0x002433B4U:
                goto block_002433B4;
            case 0x002433CCU:
                goto block_002433CC;
            case 0x002433D8U:
                goto block_002433D8;
            case 0x00243418U:
                goto block_00243418;
            case 0x0024342CU:
                goto block_0024342C;
            case 0x00243454U:
                goto block_00243454;
            case 0x00243468U:
                goto block_00243468;
            case 0x00243474U:
                goto block_00243474;
            case 0x002434B4U:
                goto block_002434B4;
            case 0x002434C8U:
                goto block_002434C8;
            case 0x002434E4U:
                goto block_002434E4;
            case 0x002434F8U:
                goto block_002434F8;
            case 0x00243510U:
                goto block_00243510;
            case 0x00243518U:
                goto block_00243518;
            case 0x00243528U:
                goto block_00243528;
            case 0x00243544U:
                goto block_00243544;
            case 0x00243560U:
                goto block_00243560;
            case 0x00243564U:
                goto block_00243564;
            case 0x00243570U:
                goto block_00243570;
            case 0x002435C4U:
                goto block_002435C4;
            case 0x002435D0U:
                goto block_002435D0;
            case 0x002435E0U:
                goto block_002435E0;
            case 0x002435F0U:
                goto block_002435F0;
            case 0x002435FCU:
                goto block_002435FC;
            case 0x00243608U:
                goto block_00243608;
            case 0x00243610U:
                goto block_00243610;
            case 0x0024361CU:
                goto block_0024361C;
            case 0x00243620U:
                goto block_00243620;
            case 0x0024364CU:
                goto block_0024364C;
            case 0x00243654U:
                goto block_00243654;
            case 0x00243660U:
                goto block_00243660;
            case 0x002436A4U:
                goto block_002436A4;
            case 0x002436DCU:
                goto block_002436DC;
            case 0x002436ECU:
                goto block_002436EC;
            case 0x002436F8U:
                goto block_002436F8;
            case 0x00243700U:
                goto block_00243700;
            case 0x0024370CU:
                goto block_0024370C;
            case 0x00243710U:
                goto block_00243710;
            case 0x0024371CU:
                goto block_0024371C;
            case 0x0024372CU:
                goto block_0024372C;
            case 0x00243738U:
                goto block_00243738;
            case 0x00243764U:
                goto block_00243764;
            case 0x0024376CU:
                goto block_0024376C;
            case 0x00243778U:
                goto block_00243778;
            case 0x002437E0U:
                goto block_002437E0;
            case 0x002437E8U:
                goto block_002437E8;
            case 0x002437F0U:
                goto block_002437F0;
            case 0x00243804U:
                goto block_00243804;
            case 0x0024381CU:
                goto block_0024381C;
            case 0x0024382CU:
                goto block_0024382C;
            case 0x00243838U:
                goto block_00243838;
            case 0x00243840U:
                goto block_00243840;
            case 0x00243848U:
                goto block_00243848;
            case 0x00243868U:
                goto block_00243868;
            case 0x00243874U:
                goto block_00243874;
            case 0x0024388CU:
                goto block_0024388C;
            case 0x00243898U:
                goto block_00243898;
            case 0x002438B4U:
                goto block_002438B4;
            case 0x002438C0U:
                goto block_002438C0;
            case 0x002438DCU:
                goto block_002438DC;
            case 0x002438E8U:
                goto block_002438E8;
            case 0x002438F0U:
                goto block_002438F0;
            case 0x002438F4U:
                goto block_002438F4;
            case 0x002438FCU:
                goto block_002438FC;
            case 0x00243920U:
                goto block_00243920;
            case 0x0024392CU:
                goto block_0024392C;
            case 0x0024393CU:
                goto block_0024393C;
            case 0x0024395CU:
                goto block_0024395C;
            case 0x00243968U:
                goto block_00243968;
            case 0x00243978U:
                goto block_00243978;
            case 0x002439A0U:
                goto block_002439A0;
            case 0x002439ACU:
                goto block_002439AC;
            case 0x002439CCU:
                goto block_002439CC;
            case 0x002439D8U:
                goto block_002439D8;
            case 0x002439FCU:
                goto block_002439FC;
            case 0x00243A08U:
                goto block_00243A08;
            case 0x00243A24U:
                goto block_00243A24;
            case 0x00243A48U:
                goto block_00243A48;
            case 0x00243A54U:
                goto block_00243A54;
            case 0x00243A78U:
                goto block_00243A78;
            case 0x00243A84U:
                goto block_00243A84;
            case 0x00243AA4U:
                goto block_00243AA4;
            case 0x00243AB0U:
                goto block_00243AB0;
            case 0x00243AB4U:
                goto block_00243AB4;
            case 0x00243ABCU:
                goto block_00243ABC;
            case 0x00243AE0U:
                goto block_00243AE0;
            case 0x00243AECU:
                goto block_00243AEC;
            case 0x00243B0CU:
                goto block_00243B0C;
            case 0x00243B28U:
                goto block_00243B28;
            case 0x00243B48U:
                goto block_00243B48;
            case 0x00243B5CU:
                goto block_00243B5C;
            case 0x00243B8CU:
                goto block_00243B8C;
            case 0x00243BA0U:
                goto block_00243BA0;
            case 0x00243BB8U:
                goto block_00243BB8;
            case 0x00243BC4U:
                goto block_00243BC4;
            case 0x00243BD8U:
                goto block_00243BD8;
            case 0x00243C04U:
                goto block_00243C04;
            case 0x00243C18U:
                goto block_00243C18;
            case 0x00243C2CU:
                goto block_00243C2C;
            case 0x00243C38U:
                goto block_00243C38;
            case 0x00243C44U:
                goto block_00243C44;
            case 0x00243C54U:
                goto block_00243C54;
            case 0x00243C80U:
                goto block_00243C80;
            case 0x00243C84U:
                goto block_00243C84;
            case 0x00243C90U:
                goto block_00243C90;
            case 0x00243CCCU:
                goto block_00243CCC;
            case 0x00243CE0U:
                goto block_00243CE0;
            case 0x00243D4CU:
                goto block_00243D4C;
            case 0x00243D50U:
                goto block_00243D50;
            case 0x00243D60U:
                goto block_00243D60;
            case 0x00243D78U:
                goto block_00243D78;
            case 0x00243D88U:
                goto block_00243D88;
            case 0x00243DA0U:
                goto block_00243DA0;
            case 0x00243DB0U:
                goto block_00243DB0;
            case 0x00243DC0U:
                goto block_00243DC0;
            case 0x00243DCCU:
                goto block_00243DCC;
            case 0x00243DDCU:
                goto block_00243DDC;
            case 0x00243DE0U:
                goto block_00243DE0;
            case 0x00243E1CU:
                goto block_00243E1C;
            case 0x00243E4CU:
                goto block_00243E4C;
            case 0x00243E68U:
                goto block_00243E68;
            case 0x00243E74U:
                goto block_00243E74;
            case 0x00243E80U:
                goto block_00243E80;
            case 0x00243E90U:
                goto block_00243E90;
            case 0x00243E98U:
                goto block_00243E98;
            case 0x00243EA4U:
                goto block_00243EA4;
            case 0x00243EC0U:
                goto block_00243EC0;
            case 0x00243F08U:
                goto block_00243F08;
            case 0x00243F18U:
                goto block_00243F18;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_00243804;
    }
block_00243804:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243804U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243804U);
        }
        goto block_00243B0C;
    }
block_0024381C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024381CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024381CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00243820U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243824U, address);
            }
        }
        if (flags.Z()) { goto block_00243B0C; }
        goto block_0024382C;
    }
block_0024382C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024382CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024382CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000023U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00243830U, address);
            }
        }
        if (flags.Z()) { goto block_00243AB4; }
        goto block_00243838;
    }
block_00243838:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243838U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243838U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000041U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0024393C; }
        goto block_00243840;
    }
block_00243840:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243840U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243840U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00243B0C; }
        goto block_00243848;
    }
block_00243848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243848U);
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0024384CU, address);
            }
        }
        {
            r0 = 0x00000008U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243858U, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243868U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243868U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243868;
    }
block_00243868:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243868U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243868U);
        }
        {
        }
        {
        }
        goto block_00243B0C;
    }
block_00243874:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243874U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243874U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t address = 0x00243888U + 860U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243880U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0024388CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0024388CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0024388C;
    }
block_0024388C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024388CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024388CU);
        }
        {
        }
        {
        }
        goto block_00243B0C;
    }
block_00243898:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243898U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243898U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t address = 0x002438A8U + 832U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002438A0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002438A8U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002438B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002438B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002438B4;
    }
block_002438B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002438B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002438B4U);
        }
        {
        }
        {
        }
        goto block_00243B0C;
    }
block_002438C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002438C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002438C0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t address = 0x002438D0U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002438C8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002438D0U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002438DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002438DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002438DC;
    }
block_002438DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002438DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002438DCU);
        }
        {
        }
        {
        }
        goto block_00243B0C;
    }
block_002438E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002438E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002438E8U);
        }
        {
            r0 = 0x00000003U;
        }
        goto block_002438F4;
    }
block_002438F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002438F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002438F0U);
        }
        {
            r0 = 0x00000004U;
        }
        goto block_002438F4;
    }
block_002438F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002438F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002438F4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002438F4U, address);
            }
        }
        goto block_00243AB4;
    }
block_002438FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002438FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002438FCU);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243900U, address);
            }
        }
        {
            r0 = 0x00000003U;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243910U, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243920U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243920U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243920;
    }
block_00243920:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243920U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243920U);
        }
        {
        }
        {
        }
        goto block_00243B0C;
    }
block_0024392C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024392CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024392CU);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243930U, address);
            }
        }
        {
            const uint32_t address = r5 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00243934U, address);
            }
        }
        goto block_00243B0C;
    }
block_0024393C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024393CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024393CU);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243940U, address);
            }
        }
        {
            r0 = 0x00000006U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0024394CU, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0024395CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0024395CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0024395C;
    }
block_0024395C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0024395CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0024395CU);
        }
        {
        }
        {
        }
        goto block_00243B0C;
    }
block_00243968:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243968U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243968U);
        }
        {
            r0 = 0x00000007U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0024396CU, address);
            }
        }
        {
            const uint32_t address = r5 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00243970U, address);
            }
        }
        goto block_00243B0C;
    }
block_00243978:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243978U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243978U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243980U, address);
            }
        }
        {
            r0 = 0x00000009U;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0024398CU, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002439A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002439A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002439A0;
    }
block_002439A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002439A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002439A0U);
        }
        {
        }
        {
        }
        goto block_00243B0C;
    }
block_002439AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002439ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002439ACU);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002439B0U, address);
            }
        }
        {
            r0 = 0x0000000AU;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002439BCU, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002439CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002439CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002439CC;
    }
block_002439CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002439CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002439CCU);
        }
        {
        }
        {
        }
        goto block_00243B0C;
    }
block_002439D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002439D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002439D8U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = 0x00000003U;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002439E4U, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002439F4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002439FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002439FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002439FC;
    }
block_002439FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002439FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002439FCU);
        }
        {
            const uint32_t updatedAddress = r8 + 0xD0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002439FCU, address);
            }
        }
        {
        }
        goto block_00243B0C;
    }
block_00243A08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243A08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243A08U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00243A08U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00243A0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xD0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243A10U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            r0 = Oot3dAotLsl(r0, 11U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243A24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243A24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243A24;
    }
block_00243A24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243A24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243A24U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243A34U, 0xEE00BA80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[22], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[22], frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243A48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243A48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243A48;
    }
block_00243A48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243A48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243A48U);
        }
        {
        }
        {
        }
        goto block_00243B0C;
    }
block_00243A54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243A54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243A54U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = 0x00000003U;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00243A60U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243A64U, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243A78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243A78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243A78;
    }
block_00243A78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243A78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243A78U);
        }
        {
        }
        {
        }
        goto block_00243B0C;
    }
block_00243A84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243A84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243A84U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = 0x0000000DU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243A8CU, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t address = 0x00243A9CU + 336U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243A94U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243AA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243AA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243AA4;
    }
block_00243AA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243AA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243AA4U);
        }
        {
        }
        {
        }
        goto block_00243B0C;
    }
block_00243AB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243AB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243AB0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00243AB0U, address);
            }
        }
        goto block_00243AB4;
    }
block_00243AB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243AB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243AB4U);
        }
        {
            const uint32_t address = r5 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00243AB4U, address);
            }
        }
        goto block_00243B0C;
    }
block_00243ABC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243ABCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243ABCU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00243AC4U, address);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[28];
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243ACCU, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243AE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243AE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243AE0;
    }
block_00243AE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243AE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243AE0U);
        }
        {
        }
        {
        }
        goto block_00243B0C;
    }
block_00243AEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243AECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243AECU);
        }
        {
            r0 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243AF0U, address);
            }
        }
        {
            r0 = 0x0000000FU;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r5 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243AFCU, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243B0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243B0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243B0C;
    }
block_00243B0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243B0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243B0CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00243B0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243B10U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243B14U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = 0x000000FFU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243B1CU, 0xEEB40A69U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_00243B48; }
        goto block_00243B28;
    }
block_00243B28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243B28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243B28U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243B28U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x265U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00243B30U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x264U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243B34U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x263U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243B38U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x262U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243B3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x261U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243B40U, address);
            }
        }
        goto block_00243B8C;
    }
block_00243B48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243B48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243B48U);
        }
        {
            const uint32_t updatedAddress = r8 + 0xF0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243B48U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x265U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00243B50U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x261U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00243B54U, address);
            }
        }
        if (flags.Z()) { goto block_00243B8C; }
        goto block_00243B5C;
    }
block_00243B5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243B5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243B5CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x261U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243B5CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x264U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243B60U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x263U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243B64U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x262U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243B68U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xF0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243B6CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000064U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x265U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00243B78U, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x265U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243B7CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0xF0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243B80U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0xF0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243B88U, address);
            }
        }
        goto block_00243B8C;
    }
block_00243B8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243B8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243B8CU);
        }
        {
            const uint32_t operand = 0x00000F00U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00243B98U + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243B90U, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xF6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243B94U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00243C04; }
        goto block_00243BA0;
    }
block_00243BA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243BA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243BA0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xF6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243BA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFF4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243BA8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t address = 0x00243BB8U + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243BB0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) { goto block_00243BC4; }
        goto block_00243BB8;
    }
block_00243BB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243BB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243BB8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x00243BC4U + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243BBCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) {
            const uint32_t address = 0x00243BC8U + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243BC0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_00243BC4;
    }
block_00243BC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243BC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243BC4U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x00243BD4U + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243BCCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x000003F8U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243BD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243BD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243BD8;
    }
block_00243BD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243BD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243BD8U);
        }
        {
        }
        {
        }
        goto block_00243C2C;
    }
block_00243C04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243C04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243C04U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x00243C14U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243C0CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x000003F8U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243C18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243C18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243C18;
    }
block_00243C18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243C18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243C18U);
        }
        {
            const uint32_t address = r9 + 1016U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243C18U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243C1CU, 0xEEB40A69U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xFF4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00243C24U, address);
            }
        }
        if (flags.Z()) { goto block_00243C80; }
        goto block_00243C2C;
    }
block_00243C2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243C2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243C2CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFF4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243C2CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00243C80; }
        goto block_00243C38;
    }
block_00243C38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243C38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243C38U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243C3CU, address);
            }
        }
        if (!(flags.Z())) { goto block_00243C54; }
        goto block_00243C44;
    }
block_00243C44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243C44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243C44U);
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00243C50U + 0x2DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243C48U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00243C4CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00243C4CU,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00243C4CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00243C50U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00243C50U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00243C50U,
                                           firstAddress + 8U);
            }
        }
        goto block_00243C54;
    }
block_00243C54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243C54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243C54U);
        }
        {
            const uint32_t address = r9 + 1016U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243C54U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x00243C60U + 0x2D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243C58U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243C5CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x00243C6CU + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243C64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00243C68U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00243C74U + 0x2C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243C6CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00243C70U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00243C7CU + 0x2C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243C74U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00243C78U, address);
            }
        }
        goto block_00243C84;
    }
block_00243C80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243C80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243C80U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00243C80U, address);
            }
        }
        goto block_00243C84;
    }
block_00243C84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243C84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243C84U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBA8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243C84U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00243D50; }
        goto block_00243C90;
    }
block_00243C90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243C90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243C90U);
        }
        {
            const uint32_t address = r9 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243C90U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r5 = r4 + operand;
        }
        {
            const uint32_t address = 0x00243CA0U + 672U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243C98U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 940U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00243C9CU, address);
            }
        }
        {
            const uint32_t address = r9 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243CA0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r8 = r0 - operand;
        }
        {
            const uint32_t address = 0x00243CB0U + 660U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243CA8U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243CACU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 944U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00243CB0U, address);
            }
        }
        {
            const uint32_t address = r9 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243CB4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 948U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00243CB8U, address);
            }
        }
        {
            frame.Guest.vfp[0] = r8;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243CC0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243CC4U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243CCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243CCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243CCC;
    }
block_00243CCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243CCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243CCCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243CCCU, 0xEE208A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r8;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243CD4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243CD8U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243CE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243CE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243CE0;
    }
block_00243CE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243CE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243CE0U);
        }
        {
            frame.Guest.vfp[1] = r8;
        }
        {
            const uint32_t address = 0x00243CECU + 604U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243CE4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x000000FAU;
            r0 = r8 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243CECU, 0xEE200A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            r1 = 0x00006000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243CF8U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00243D00U, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00243D04U, address);
            }
        }
        {
            r3 = 0x000000E8U;
        }
        {
            r2 = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243D10U, 0xEE600A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243D14U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00243D24U, address);
            }
        }
        {
            const uint32_t address = r5 + 824U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243D28U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r7 + operand;
        }
        {
            r1 = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243D34U, 0xEE301A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243D38U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 820U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243D3CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243D44U, 0xEE300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243D4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243D4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243D4C;
    }
block_00243D4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243D4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243D4CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBA8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00243D4CU, address);
            }
        }
        goto block_00243D50;
    }
block_00243D50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243D50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243D50U);
        }
        {
            const uint32_t operand = 0x00001200U;
            r5 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x41U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243D54U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00243F18; }
        goto block_00243D60;
    }
block_00243D60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243D60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243D60U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243D60U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243D64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x00243D70U + 0x1DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243D68U, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00243F18; }
        goto block_00243D78;
    }
block_00243D78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243D78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243D78U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x40U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243D78U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            const uint32_t operand = 0x00000044U;
            r8 = r13 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00243DB0; }
        goto block_00243D88;
    }
block_00243D88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243D88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243D88U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r8 - operand;
        }
        {
            const uint32_t value = r1 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243D90U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r5 + 0x40U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243D94U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 2U, 1U, flags.C());
            r1 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r1, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00243DB0; }
        goto block_00243DA0;
    }
block_00243DA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243DA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243DA0U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243DA0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00243DA8U, address);
            }
            r0 = updatedAddress;
        }
        if (!(flags.Z())) { goto block_00243DA0; }
        goto block_00243DB0;
    }
block_00243DB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243DB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243DB0U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243DB0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00243DBCU + 0x194U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243DB4U, address);
            }
            r9 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00243E80; }
        goto block_00243DC0;
    }
block_00243DC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243DC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243DC0U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243DC0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r9, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00243E74; }
        goto block_00243DCC;
    }
block_00243DCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243DCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243DCCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x40U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243DCCU, address);
            }
            r12 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            r1 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00243E74; }
        goto block_00243DDC;
    }
block_00243DDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243DDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243DDCU);
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243DDCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_00243DE0;
    }
block_00243DE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243DE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243DE0U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r3 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r2 + operand;
        }
        {
            const uint32_t address = r2 + 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243DECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243DF0U, 0xEEB40A60U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            const uint32_t address = r0 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243DF8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (flags.Z()) {
            const uint32_t address = r2 + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243DFCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        if (flags.Z()) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243E00U, 0x0EF40A41U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[2],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        if (flags.Z()) {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243E08U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (flags.Z()) {
            const uint32_t address = r2 + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243E0CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        if (flags.Z()) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00243E10U, 0x0EF40A41U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[2],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        if (flags.Z()) {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z())) { goto block_00243E68; }
        goto block_00243E1C;
    }
block_00243E1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243E1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243E1CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00001100U;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243E24U, address);
            }
            r10 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r2 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243E28U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r10, r3, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + 0x16U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243E30U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r2 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243E34U, address);
            }
            r10 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r3, r10, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243E3CU, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r2 + 0xA4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243E40U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r3, r2, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00243E68; }
        goto block_00243E4C;
    }
block_00243E4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243E4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243E4CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00001200U;
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243E54U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r3 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243E58U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r3, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + r1;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00243E60U, address);
            }
        }
        if (flags.Z()) { goto block_00243E74; }
        goto block_00243E68;
    }
block_00243E68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243E68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243E68U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00243DE0; }
        goto block_00243E74;
    }
block_00243E74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243E74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243E74U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x130U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243E74U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00243DC0; }
        goto block_00243E80;
    }
block_00243E80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243E80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243E80U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x40U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243E80U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            r6 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00243F18; }
        goto block_00243E90;
    }
block_00243E90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243E90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243E90U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r10 = r7 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r10 = r10 + operand;
        }
        goto block_00243E98;
    }
block_00243E98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243E98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243E98U);
        }
        {
            const uint32_t updatedAddress = r8 + r6;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243E98U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00243F08; }
        goto block_00243EA4;
    }
block_00243EA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243EA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243EA4U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00001200U;
            r11 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243EACU, address);
            }
            r0 = value;
        }
        {
            r0 = Oot3dAotLsl(r0, 17U);
        }
        {
            r1 = Oot3dAotLsr(r0, 26U);
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243EC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00334914_00334914(frame, context, state, 0x00334914U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243EC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243EC0;
    }
block_00243EC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243EC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243EC0U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243EC0U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r11 = r6 + operand;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r11, 1U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00001100U;
            r12 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0xA4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243ED4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r12 + 0xA2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243ED8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00243EDCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00243EDCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00243EDCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00243EDCU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r11, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243EE8U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243EECU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r0 + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243EF0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243EF4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = r9;
        }
        {
            r1 = r7;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00243F08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Spawn_003738D0(frame, context, state, 0x003738D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00243F08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00243F08;
    }
block_00243F08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243F08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243F08U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x40U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00243F08U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00243E98; }
        goto block_00243F18;
    }
block_00243F18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00243F18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00243F18U);
        }
        {
            const uint32_t operand = 0x00000064U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 48U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 48U);
            }
            frame.Guest.vfp[28] = value12;
            uint32_t value13 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 52U, &value13)) {
                return Oot3dAotMemoryFault(context, 0x00243F1CU,
                                           firstAddress + 52U);
            }
            frame.Guest.vfp[29] = value13;
            r13 += 56U;
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00243F24U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00243F24U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00243F24U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00243F24U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00243F24U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00243F24U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00243F24U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00243F24U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00243F24U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Actor1D8_Update_002AD98C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002AD98CU:
        goto block_002AD98C;
    case 0x002AD9D4U:
        goto block_002AD9D4;
    case 0x002AD9D8U:
        goto block_002AD9D8;
    case 0x002ADA00U:
        goto block_002ADA00;
    case 0x002ADA10U:
        goto block_002ADA10;
    case 0x002ADA20U:
        goto block_002ADA20;
    case 0x002ADA34U:
        goto block_002ADA34;
    case 0x002ADA7CU:
        goto block_002ADA7C;
    case 0x002ADA8CU:
        goto block_002ADA8C;
    case 0x002ADA98U:
        goto block_002ADA98;
    case 0x002ADAC0U:
        goto block_002ADAC0;
    case 0x002ADAD8U:
        goto block_002ADAD8;
    case 0x002ADAF0U:
        goto block_002ADAF0;
    case 0x002ADB04U:
        goto block_002ADB04;
    case 0x002ADB10U:
        goto block_002ADB10;
    case 0x002ADB1CU:
        goto block_002ADB1C;
    case 0x002ADB20U:
        goto block_002ADB20;
    case 0x002ADB98U:
        goto block_002ADB98;
    case 0x002ADBA8U:
        goto block_002ADBA8;
    case 0x002ADBB8U:
        goto block_002ADBB8;
    case 0x002ADBC8U:
        goto block_002ADBC8;
    case 0x002ADBE8U:
        goto block_002ADBE8;
    case 0x002ADBF4U:
        goto block_002ADBF4;
    case 0x002ADC5CU:
        goto block_002ADC5C;
    case 0x002ADC74U:
        goto block_002ADC74;
    case 0x002ADC94U:
        goto block_002ADC94;
    case 0x002ADCA4U:
        goto block_002ADCA4;
    case 0x002ADCACU:
        goto block_002ADCAC;
    case 0x002ADCC8U:
        goto block_002ADCC8;
    case 0x002ADCDCU:
        goto block_002ADCDC;
    case 0x002ADCF0U:
        goto block_002ADCF0;
    case 0x002ADD04U:
        goto block_002ADD04;
    case 0x002ADD34U:
        goto block_002ADD34;
    case 0x002ADD3CU:
        goto block_002ADD3C;
    case 0x002ADD48U:
        goto block_002ADD48;
    case 0x002ADDB4U:
        goto block_002ADDB4;
    case 0x002ADDC0U:
        goto block_002ADDC0;
    case 0x002ADDC8U:
        goto block_002ADDC8;
    case 0x002ADDDCU:
        goto block_002ADDDC;
    case 0x002ADDF4U:
        goto block_002ADDF4;
    case 0x002ADE04U:
        goto block_002ADE04;
    case 0x002ADE10U:
        goto block_002ADE10;
    case 0x002ADE18U:
        goto block_002ADE18;
    case 0x002ADE20U:
        goto block_002ADE20;
    case 0x002ADE3CU:
        goto block_002ADE3C;
    case 0x002ADE48U:
        goto block_002ADE48;
    case 0x002ADE60U:
        goto block_002ADE60;
    case 0x002ADE6CU:
        goto block_002ADE6C;
    case 0x002ADE88U:
        goto block_002ADE88;
    case 0x002ADE94U:
        goto block_002ADE94;
    case 0x002ADEB0U:
        goto block_002ADEB0;
    case 0x002ADEBCU:
        goto block_002ADEBC;
    case 0x002ADEC0U:
        goto block_002ADEC0;
    case 0x002ADEC8U:
        goto block_002ADEC8;
    case 0x002ADED4U:
        goto block_002ADED4;
    case 0x002ADEF4U:
        goto block_002ADEF4;
    case 0x002ADF00U:
        goto block_002ADF00;
    case 0x002ADF10U:
        goto block_002ADF10;
    case 0x002ADF2CU:
        goto block_002ADF2C;
    case 0x002ADF38U:
        goto block_002ADF38;
    case 0x002ADF48U:
        goto block_002ADF48;
    case 0x002ADF6CU:
        goto block_002ADF6C;
    case 0x002ADF78U:
        goto block_002ADF78;
    case 0x002ADF94U:
        goto block_002ADF94;
    case 0x002ADFA0U:
        goto block_002ADFA0;
    case 0x002ADFC0U:
        goto block_002ADFC0;
    case 0x002ADFCCU:
        goto block_002ADFCC;
    case 0x002ADFE8U:
        goto block_002ADFE8;
    case 0x002AE00CU:
        goto block_002AE00C;
    case 0x002AE018U:
        goto block_002AE018;
    case 0x002AE038U:
        goto block_002AE038;
    case 0x002AE044U:
        goto block_002AE044;
    case 0x002AE064U:
        goto block_002AE064;
    case 0x002AE070U:
        goto block_002AE070;
    case 0x002AE090U:
        goto block_002AE090;
    case 0x002AE09CU:
        goto block_002AE09C;
    case 0x002AE0B8U:
        goto block_002AE0B8;
    case 0x002AE0D8U:
        goto block_002AE0D8;
    case 0x002AE0F4U:
        goto block_002AE0F4;
    case 0x002AE108U:
        goto block_002AE108;
    case 0x002AE120U:
        goto block_002AE120;
    case 0x002AE12CU:
        goto block_002AE12C;
    case 0x002AE140U:
        goto block_002AE140;
    case 0x002AE178U:
        goto block_002AE178;
    case 0x002AE18CU:
        goto block_002AE18C;
    case 0x002AE1A0U:
        goto block_002AE1A0;
    case 0x002AE1ACU:
        goto block_002AE1AC;
    case 0x002AE1B8U:
        goto block_002AE1B8;
    case 0x002AE1C8U:
        goto block_002AE1C8;
    case 0x002AE1F8U:
        goto block_002AE1F8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002AD98C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD98CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD98CU);
        }
        {
            const uint32_t firstAddress = r13 - 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002AD98CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x002AD98CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002AD98CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x002AD98CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002AD98CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002AD98CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002AD98CU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002AD98CU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r12)) {
                return Oot3dAotMemoryFault(context, 0x002AD98CU,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002AD98CU,
                                           firstAddress + 36U);
            }
            r13 = r13 - 40U;
        }
        {
            r5 = r0;
        }
        {
            r6 = r1;
        }
        {
            const uint32_t operand = 0x00000200U;
            r7 = r5 + operand;
        }
        {
            r13 -= 24U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x002AD99CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x002AD99CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x002AD99CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x002AD99CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x002AD99CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x002AD99CU,
                                           firstAddress + 20U);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD9A0U, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002AD9A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x40U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD9ACU, address);
            }
            r0 = value;
        }
        {
            r1 = r6;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002AD9B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD9BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x42U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002AD9C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x238U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD9C8U, address);
            }
            r2 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x002AD9D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AD9D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AD9D4;
    }
block_002AD9D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD9D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD9D4U);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_002AD9D8;
    }
block_002AD9D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AD9D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AD9D8U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000200U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AD9E4U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r2 = r2 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002AD9F4U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_002AD9D8; }
        goto block_002ADA00;
    }
block_002ADA00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADA00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADA00U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x23DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADA00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x002ADA0CU + 876U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADA04U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002ADA8C; }
        goto block_002ADA10;
    }
block_002ADA10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADA10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADA10U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADA10U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADA20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADA20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADA20;
    }
block_002ADA20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADA20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADA20U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADA20U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADA34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADA34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADA34;
    }
block_002ADA34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADA34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADA34U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r5 + 104U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADA3CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADA40U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x002ADA4CU + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADA44U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x40U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADA48U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x002ADA54U + 0x32CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADA4CU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADA50U, 0xEE612A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        {
            const int32_t left = static_cast<int16_t>(
                r0 >> 0U);
            const int32_t right = static_cast<int16_t>(
                r1 >> 0U);
            r0 = static_cast<uint32_t>(left * right);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADA5CU, 0xEE610A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADA64U, 0xEE402A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADA6CU, 0xEE400A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADA70U, 0xEE229A82U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[5], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADA74U, 0xEE609A82U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADA7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADA7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADA7C;
    }
block_002ADA7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADA7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADA7CU);
        }
        {
            const uint32_t address = 0x002ADA84U + 768U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADA7CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x002ADA88U + 768U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADA80U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADA84U, 0xEE108A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        goto block_002ADA98;
    }
block_002ADA8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADA8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADA8CU);
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[16];
        }
        goto block_002ADA98;
    }
block_002ADA98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADA98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADA98U);
        }
        {
            const uint32_t address = 0x002ADAA0U + 748U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADA98U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x002ADAA4U + 748U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADA9CU, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[21];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r10 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x0000036CU;
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x23DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002ADAB8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADAC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADAC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADAC0;
    }
block_002ADAC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADAC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADAC0U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[21];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x00000370U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADAD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADAD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADAD8;
    }
block_002ADAD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADAD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADAD8U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[21];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x002ADAECU + 680U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADAE4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000374U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADAF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADAF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADAF0;
    }
block_002ADAF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADAF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADAF0U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x58U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADAF0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x002ADB00U + 0x298U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADAF8U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADB04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADB04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADB04;
    }
block_002ADB04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADB04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADB04U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x58U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADB04U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000096U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002ADB20; }
        goto block_002ADB10;
    }
block_002ADB10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADB10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADB10U);
        }
        {
            const uint32_t updatedAddress = 0x002ADB18U + 0x284U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADB10U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADB1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADB1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADB1C;
    }
block_002ADB1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADB1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADB1CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002ADB1CU, address);
            }
        }
        goto block_002ADB20;
    }
block_002ADB20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADB20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADB20U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000000D8U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x000003C4U;
            r0 = r5 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002ADB2CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002ADB2CU,
                                           firstAddress + 4U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002ADB2CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r4 = value4;
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000000E4U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002ADB38U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002ADB38U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002ADB38U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002ADB40U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002ADB40U,
                                           firstAddress + 4U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002ADB40U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r4 = value4;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000074U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002ADB50U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002ADB50U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002ADB50U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000004F0U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r4 = r5 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002ADB5CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002ADB5CU,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002ADB5CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000000FCU;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000028U;
            r4 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002ADB6CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002ADB6CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002ADB6CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r5 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002ADB74U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002ADB74U,
                                           firstAddress + 4U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002ADB74U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r8 = value8;
        }
        {
            const uint32_t operand = 0x000000CCU;
            r1 = r1 + operand;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002ADB80U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002ADB80U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002ADB80U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000378U;
            r2 = r5 + operand;
        }
        {
            r8 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADB98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADB98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADB98;
    }
block_002ADB98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADB98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADB98U);
        }
        {
            const uint32_t operand = 0x000003D0U;
            r2 = r5 + operand;
        }
        {
            r1 = r8;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADBA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADBA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADBA8;
    }
block_002ADBA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADBA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADBA8U);
        }
        {
            r2 = r4;
        }
        {
            r1 = r8;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADBB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADBB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADBB8;
    }
block_002ADBB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADBB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADBB8U);
        }
        {
            const uint32_t operand = 0x00000480U;
            r2 = r5 + operand;
        }
        {
            r1 = r8;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADBC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADBC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADBC8;
    }
block_002ADBC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADBC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADBC8U);
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[21];
        }
        {
            const uint32_t updatedAddress = 0x002ADBD4U + 0x1CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADBCCU, address);
            }
            r4 = value;
        }
        {
            const uint32_t address = 0x002ADBD8U + 460U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADBD0U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x002ADBDCU + 460U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADBD4U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x002ADBE0U + 460U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADBD8U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            r11 = 0x00000000U;
        }
        {
            r9 = 0x000000FFU;
        }
        {
            r8 = 0x00000001U;
        }
        goto block_002ADBE8;
    }
block_002ADBE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADBE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADBE8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADBE8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_002ADCF0; }
        goto block_002ADBF4;
    }
block_002ADBF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADBF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADBF4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADBF4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002ADC00U, address);
            }
        }
        {
            const uint32_t address = r4 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADC04U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADC08U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADC0CU, 0xEE700A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002ADC10U, address);
            }
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADC14U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r4 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADC18U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADC1CU, 0xEE311A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002ADC20U, address);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADC24U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r4 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADC28U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADC2CU, 0xEE711A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x002ADC30U, address);
            }
        }
        {
            const uint32_t address = r4 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADC34U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADC38U, 0xEE300A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002ADC3CU, address);
            }
        }
        {
            const uint32_t address = r4 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADC40U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADC44U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002ADC48U, address);
            }
        }
        {
            const uint32_t address = r4 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADC4CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADC50U, 0xEE310A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002ADC54U, address);
            }
        }
        if (!(flags.Z())) { goto block_002ADCF0; }
        goto block_002ADC5C;
    }
block_002ADC5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADC5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADC5CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x30U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADC5CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ADC64U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADC68U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_002ADC94; }
        goto block_002ADC74;
    }
block_002ADC74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADC74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADC74U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADC74U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000011U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ADC84U, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r4 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002ADC88U, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r4 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002ADC8CU, address);
            }
        }
        goto block_002ADCC8;
    }
block_002ADC94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADC94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADC94U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000002U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ADC9CU, address);
            }
        }
        if (flags.Z()) { goto block_002ADCC8; }
        goto block_002ADCA4;
    }
block_002ADCA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADCA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADCA4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002ADCC8; }
        goto block_002ADCAC;
    }
block_002ADCAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADCACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADCACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADCACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000011U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ADCBCU, address);
            }
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r4 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002ADCC0U, address);
            }
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002ADCC4U, address);
            }
        }
        goto block_002ADCC8;
    }
block_002ADCC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADCC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADCC8U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r4 + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADCD0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000034U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADCDCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADCDCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADCDC;
    }
block_002ADCDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADCDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADCDCU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x00000040U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADCF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADCF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADCF0;
    }
block_002ADCF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADCF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADCF0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r11 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r4 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r11 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r11, 0x000000C8U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_002ADBE8; }
        goto block_002ADD04;
    }
block_002ADD04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADD04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADD04U);
        }
        {
            const uint32_t operand = 0x00003000U;
            r4 = r6 + operand;
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x237U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002ADD0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002ADD10U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x25CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002ADD14U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x3FU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADD18U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            const uint32_t address = 0x002ADD24U + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADD1CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r12 = 0x00000004U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r1 = 0x00000003U;
        }
        {
            r2 = 0x0000000BU;
        }
        if (flags.Z()) { goto block_002ADFA0; }
        goto block_002ADD34;
    }
block_002ADD34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADD34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADD34U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_002ADDB4; }
        goto block_002ADD3C;
    }
block_002ADD3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADD3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADD3CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x002ADD4CU + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADD44U, address);
            }
            switch (value) {
            case 0x002AD98CU:
                goto block_002AD98C;
            case 0x002AD9D4U:
                goto block_002AD9D4;
            case 0x002AD9D8U:
                goto block_002AD9D8;
            case 0x002ADA00U:
                goto block_002ADA00;
            case 0x002ADA10U:
                goto block_002ADA10;
            case 0x002ADA20U:
                goto block_002ADA20;
            case 0x002ADA34U:
                goto block_002ADA34;
            case 0x002ADA7CU:
                goto block_002ADA7C;
            case 0x002ADA8CU:
                goto block_002ADA8C;
            case 0x002ADA98U:
                goto block_002ADA98;
            case 0x002ADAC0U:
                goto block_002ADAC0;
            case 0x002ADAD8U:
                goto block_002ADAD8;
            case 0x002ADAF0U:
                goto block_002ADAF0;
            case 0x002ADB04U:
                goto block_002ADB04;
            case 0x002ADB10U:
                goto block_002ADB10;
            case 0x002ADB1CU:
                goto block_002ADB1C;
            case 0x002ADB20U:
                goto block_002ADB20;
            case 0x002ADB98U:
                goto block_002ADB98;
            case 0x002ADBA8U:
                goto block_002ADBA8;
            case 0x002ADBB8U:
                goto block_002ADBB8;
            case 0x002ADBC8U:
                goto block_002ADBC8;
            case 0x002ADBE8U:
                goto block_002ADBE8;
            case 0x002ADBF4U:
                goto block_002ADBF4;
            case 0x002ADC5CU:
                goto block_002ADC5C;
            case 0x002ADC74U:
                goto block_002ADC74;
            case 0x002ADC94U:
                goto block_002ADC94;
            case 0x002ADCA4U:
                goto block_002ADCA4;
            case 0x002ADCACU:
                goto block_002ADCAC;
            case 0x002ADCC8U:
                goto block_002ADCC8;
            case 0x002ADCDCU:
                goto block_002ADCDC;
            case 0x002ADCF0U:
                goto block_002ADCF0;
            case 0x002ADD04U:
                goto block_002ADD04;
            case 0x002ADD34U:
                goto block_002ADD34;
            case 0x002ADD3CU:
                goto block_002ADD3C;
            case 0x002ADD48U:
                goto block_002ADD48;
            case 0x002ADDB4U:
                goto block_002ADDB4;
            case 0x002ADDC0U:
                goto block_002ADDC0;
            case 0x002ADDC8U:
                goto block_002ADDC8;
            case 0x002ADDDCU:
                goto block_002ADDDC;
            case 0x002ADDF4U:
                goto block_002ADDF4;
            case 0x002ADE04U:
                goto block_002ADE04;
            case 0x002ADE10U:
                goto block_002ADE10;
            case 0x002ADE18U:
                goto block_002ADE18;
            case 0x002ADE20U:
                goto block_002ADE20;
            case 0x002ADE3CU:
                goto block_002ADE3C;
            case 0x002ADE48U:
                goto block_002ADE48;
            case 0x002ADE60U:
                goto block_002ADE60;
            case 0x002ADE6CU:
                goto block_002ADE6C;
            case 0x002ADE88U:
                goto block_002ADE88;
            case 0x002ADE94U:
                goto block_002ADE94;
            case 0x002ADEB0U:
                goto block_002ADEB0;
            case 0x002ADEBCU:
                goto block_002ADEBC;
            case 0x002ADEC0U:
                goto block_002ADEC0;
            case 0x002ADEC8U:
                goto block_002ADEC8;
            case 0x002ADED4U:
                goto block_002ADED4;
            case 0x002ADEF4U:
                goto block_002ADEF4;
            case 0x002ADF00U:
                goto block_002ADF00;
            case 0x002ADF10U:
                goto block_002ADF10;
            case 0x002ADF2CU:
                goto block_002ADF2C;
            case 0x002ADF38U:
                goto block_002ADF38;
            case 0x002ADF48U:
                goto block_002ADF48;
            case 0x002ADF6CU:
                goto block_002ADF6C;
            case 0x002ADF78U:
                goto block_002ADF78;
            case 0x002ADF94U:
                goto block_002ADF94;
            case 0x002ADFA0U:
                goto block_002ADFA0;
            case 0x002ADFC0U:
                goto block_002ADFC0;
            case 0x002ADFCCU:
                goto block_002ADFCC;
            case 0x002ADFE8U:
                goto block_002ADFE8;
            case 0x002AE00CU:
                goto block_002AE00C;
            case 0x002AE018U:
                goto block_002AE018;
            case 0x002AE038U:
                goto block_002AE038;
            case 0x002AE044U:
                goto block_002AE044;
            case 0x002AE064U:
                goto block_002AE064;
            case 0x002AE070U:
                goto block_002AE070;
            case 0x002AE090U:
                goto block_002AE090;
            case 0x002AE09CU:
                goto block_002AE09C;
            case 0x002AE0B8U:
                goto block_002AE0B8;
            case 0x002AE0D8U:
                goto block_002AE0D8;
            case 0x002AE0F4U:
                goto block_002AE0F4;
            case 0x002AE108U:
                goto block_002AE108;
            case 0x002AE120U:
                goto block_002AE120;
            case 0x002AE12CU:
                goto block_002AE12C;
            case 0x002AE140U:
                goto block_002AE140;
            case 0x002AE178U:
                goto block_002AE178;
            case 0x002AE18CU:
                goto block_002AE18C;
            case 0x002AE1A0U:
                goto block_002AE1A0;
            case 0x002AE1ACU:
                goto block_002AE1AC;
            case 0x002AE1B8U:
                goto block_002AE1B8;
            case 0x002AE1C8U:
                goto block_002AE1C8;
            case 0x002AE1F8U:
                goto block_002AE1F8;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_002ADD48;
    }
block_002ADD48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADD48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADD48U);
        }
        goto block_002AE0B8;
    }
block_002ADDB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADDB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADDB4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000010U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r11 = 0x0000000FU;
        }
        if (flags.Z()) { goto block_002AE09C; }
        goto block_002ADDC0;
    }
block_002ADDC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADDC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADDC0U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_002ADDF4; }
        goto block_002ADDC8;
    }
block_002ADDC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADDC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADDC8U);
        }
        {
            const uint32_t operand = 0x0000000BU;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r3 = 0x0000000CU;
        }
        {
            r12 = 0x0000000EU;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x002ADDE0U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADDD8U, address);
            }
            switch (value) {
            case 0x002AD98CU:
                goto block_002AD98C;
            case 0x002AD9D4U:
                goto block_002AD9D4;
            case 0x002AD9D8U:
                goto block_002AD9D8;
            case 0x002ADA00U:
                goto block_002ADA00;
            case 0x002ADA10U:
                goto block_002ADA10;
            case 0x002ADA20U:
                goto block_002ADA20;
            case 0x002ADA34U:
                goto block_002ADA34;
            case 0x002ADA7CU:
                goto block_002ADA7C;
            case 0x002ADA8CU:
                goto block_002ADA8C;
            case 0x002ADA98U:
                goto block_002ADA98;
            case 0x002ADAC0U:
                goto block_002ADAC0;
            case 0x002ADAD8U:
                goto block_002ADAD8;
            case 0x002ADAF0U:
                goto block_002ADAF0;
            case 0x002ADB04U:
                goto block_002ADB04;
            case 0x002ADB10U:
                goto block_002ADB10;
            case 0x002ADB1CU:
                goto block_002ADB1C;
            case 0x002ADB20U:
                goto block_002ADB20;
            case 0x002ADB98U:
                goto block_002ADB98;
            case 0x002ADBA8U:
                goto block_002ADBA8;
            case 0x002ADBB8U:
                goto block_002ADBB8;
            case 0x002ADBC8U:
                goto block_002ADBC8;
            case 0x002ADBE8U:
                goto block_002ADBE8;
            case 0x002ADBF4U:
                goto block_002ADBF4;
            case 0x002ADC5CU:
                goto block_002ADC5C;
            case 0x002ADC74U:
                goto block_002ADC74;
            case 0x002ADC94U:
                goto block_002ADC94;
            case 0x002ADCA4U:
                goto block_002ADCA4;
            case 0x002ADCACU:
                goto block_002ADCAC;
            case 0x002ADCC8U:
                goto block_002ADCC8;
            case 0x002ADCDCU:
                goto block_002ADCDC;
            case 0x002ADCF0U:
                goto block_002ADCF0;
            case 0x002ADD04U:
                goto block_002ADD04;
            case 0x002ADD34U:
                goto block_002ADD34;
            case 0x002ADD3CU:
                goto block_002ADD3C;
            case 0x002ADD48U:
                goto block_002ADD48;
            case 0x002ADDB4U:
                goto block_002ADDB4;
            case 0x002ADDC0U:
                goto block_002ADDC0;
            case 0x002ADDC8U:
                goto block_002ADDC8;
            case 0x002ADDDCU:
                goto block_002ADDDC;
            case 0x002ADDF4U:
                goto block_002ADDF4;
            case 0x002ADE04U:
                goto block_002ADE04;
            case 0x002ADE10U:
                goto block_002ADE10;
            case 0x002ADE18U:
                goto block_002ADE18;
            case 0x002ADE20U:
                goto block_002ADE20;
            case 0x002ADE3CU:
                goto block_002ADE3C;
            case 0x002ADE48U:
                goto block_002ADE48;
            case 0x002ADE60U:
                goto block_002ADE60;
            case 0x002ADE6CU:
                goto block_002ADE6C;
            case 0x002ADE88U:
                goto block_002ADE88;
            case 0x002ADE94U:
                goto block_002ADE94;
            case 0x002ADEB0U:
                goto block_002ADEB0;
            case 0x002ADEBCU:
                goto block_002ADEBC;
            case 0x002ADEC0U:
                goto block_002ADEC0;
            case 0x002ADEC8U:
                goto block_002ADEC8;
            case 0x002ADED4U:
                goto block_002ADED4;
            case 0x002ADEF4U:
                goto block_002ADEF4;
            case 0x002ADF00U:
                goto block_002ADF00;
            case 0x002ADF10U:
                goto block_002ADF10;
            case 0x002ADF2CU:
                goto block_002ADF2C;
            case 0x002ADF38U:
                goto block_002ADF38;
            case 0x002ADF48U:
                goto block_002ADF48;
            case 0x002ADF6CU:
                goto block_002ADF6C;
            case 0x002ADF78U:
                goto block_002ADF78;
            case 0x002ADF94U:
                goto block_002ADF94;
            case 0x002ADFA0U:
                goto block_002ADFA0;
            case 0x002ADFC0U:
                goto block_002ADFC0;
            case 0x002ADFCCU:
                goto block_002ADFCC;
            case 0x002ADFE8U:
                goto block_002ADFE8;
            case 0x002AE00CU:
                goto block_002AE00C;
            case 0x002AE018U:
                goto block_002AE018;
            case 0x002AE038U:
                goto block_002AE038;
            case 0x002AE044U:
                goto block_002AE044;
            case 0x002AE064U:
                goto block_002AE064;
            case 0x002AE070U:
                goto block_002AE070;
            case 0x002AE090U:
                goto block_002AE090;
            case 0x002AE09CU:
                goto block_002AE09C;
            case 0x002AE0B8U:
                goto block_002AE0B8;
            case 0x002AE0D8U:
                goto block_002AE0D8;
            case 0x002AE0F4U:
                goto block_002AE0F4;
            case 0x002AE108U:
                goto block_002AE108;
            case 0x002AE120U:
                goto block_002AE120;
            case 0x002AE12CU:
                goto block_002AE12C;
            case 0x002AE140U:
                goto block_002AE140;
            case 0x002AE178U:
                goto block_002AE178;
            case 0x002AE18CU:
                goto block_002AE18C;
            case 0x002AE1A0U:
                goto block_002AE1A0;
            case 0x002AE1ACU:
                goto block_002AE1AC;
            case 0x002AE1B8U:
                goto block_002AE1B8;
            case 0x002AE1C8U:
                goto block_002AE1C8;
            case 0x002AE1F8U:
                goto block_002AE1F8;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_002ADDDC;
    }
block_002ADDDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADDDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADDDCU);
        }
        goto block_002AE0B8;
    }
block_002ADDF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADDF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADDF4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002ADDF8U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002ADDFCU, address);
            }
        }
        if (flags.Z()) { goto block_002AE0B8; }
        goto block_002ADE04;
    }
block_002ADE04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADE04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADE04U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000023U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002ADE08U, address);
            }
        }
        if (flags.Z()) { goto block_002ADEC0; }
        goto block_002ADE10;
    }
block_002ADE10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADE10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADE10U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000041U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002ADF10; }
        goto block_002ADE18;
    }
block_002ADE18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADE18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADE18U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002AE0B8; }
        goto block_002ADE20;
    }
block_002ADE20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADE20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADE20U);
        }
        {
            r0 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x002ADE24U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ADE2CU, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADE3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADE3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADE3C;
    }
block_002ADE3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADE3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADE3CU);
        }
        {
        }
        {
        }
        goto block_002AE0B8;
    }
block_002ADE48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADE48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADE48U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t address = 0x002ADE5CU + 752U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADE54U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADE60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADE60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADE60;
    }
block_002ADE60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADE60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADE60U);
        }
        {
        }
        {
        }
        goto block_002AE0B8;
    }
block_002ADE6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADE6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADE6CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t address = 0x002ADE7CU + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADE74U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002ADE7CU, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADE88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADE88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADE88;
    }
block_002ADE88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADE88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADE88U);
        }
        {
        }
        {
        }
        goto block_002AE0B8;
    }
block_002ADE94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADE94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADE94U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t address = 0x002ADEA4U + 680U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADE9CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002ADEA4U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADEB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADEB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADEB0;
    }
block_002ADEB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADEB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADEB0U);
        }
        {
        }
        {
        }
        goto block_002AE0B8;
    }
block_002ADEBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADEBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADEBCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002ADEBCU, address);
            }
        }
        goto block_002ADEC0;
    }
block_002ADEC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADEC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADEC0U);
        }
        {
            const uint32_t address = r4 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x002ADEC0U, address);
            }
        }
        goto block_002AE0B8;
    }
block_002ADEC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADEC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADEC8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x002ADEC8U, address);
            }
        }
        {
            const uint32_t address = r4 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x002ADECCU, address);
            }
        }
        goto block_002AE0B8;
    }
block_002ADED4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADED4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADED4U);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ADED8U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t address = 0x002ADEECU + 616U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADEE4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002ADEECU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADEF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADEF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADEF4;
    }
block_002ADEF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADEF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADEF4U);
        }
        {
        }
        {
        }
        goto block_002AE0B8;
    }
block_002ADF00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADF00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADF00U);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ADF04U, address);
            }
        }
        {
            const uint32_t address = r4 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x002ADF08U, address);
            }
        }
        goto block_002AE0B8;
    }
block_002ADF10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADF10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADF10U);
        }
        {
            r0 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002ADF14U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ADF1CU, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADF2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADF2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADF2C;
    }
block_002ADF2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADF2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADF2CU);
        }
        {
        }
        {
        }
        goto block_002AE0B8;
    }
block_002ADF38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADF38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADF38U);
        }
        {
            r0 = 0x00000007U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ADF3CU, address);
            }
        }
        {
            const uint32_t address = r4 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x002ADF40U, address);
            }
        }
        goto block_002AE0B8;
    }
block_002ADF48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADF48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADF48U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r0 = 0x00000009U;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002ADF54U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ADF58U, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADF6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADF6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADF6C;
    }
block_002ADF6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADF6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADF6CU);
        }
        {
        }
        {
        }
        goto block_002AE0B8;
    }
block_002ADF78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADF78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADF78U);
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002ADF7CU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002ADF84U, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADF94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADF94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADF94;
    }
block_002ADF94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADF94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADF94U);
        }
        {
        }
        {
        }
        goto block_002AE0B8;
    }
block_002ADFA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADFA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADFA0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002ADFACU, address);
            }
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002ADFB4U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADFC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADFC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADFC0;
    }
block_002ADFC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADFC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADFC0U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x42U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002ADFC0U, address);
            }
        }
        {
        }
        goto block_002AE0B8;
    }
block_002ADFCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADFCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADFCCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002ADFCCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002ADFD0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADFD4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            r0 = Oot3dAotLsl(r0, 11U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002ADFE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002ADFE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002ADFE8;
    }
block_002ADFE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002ADFE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002ADFE8U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x002ADFF4U + 356U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002ADFECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002ADFFCU, 0xEE000A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002AE00CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AE00CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AE00C;
    }
block_002AE00C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE00CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE00CU);
        }
        {
        }
        {
        }
        goto block_002AE0B8;
    }
block_002AE018:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE018U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE018U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002AE024U, address);
            }
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002AE02CU, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002AE038U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AE038U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AE038;
    }
block_002AE038:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE038U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE038U);
        }
        {
        }
        {
        }
        goto block_002AE0B8;
    }
block_002AE044:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE044U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE044U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r0 = 0x0000000DU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002AE04CU, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t address = 0x002AE05CU + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE054U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002AE064U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AE064U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AE064;
    }
block_002AE064:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE064U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE064U);
        }
        {
        }
        {
        }
        goto block_002AE0B8;
    }
block_002AE070:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE070U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE070U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x002AE07CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x002AE084U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002AE090U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AE090U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AE090;
    }
block_002AE090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE090U);
        }
        {
        }
        {
        }
        goto block_002AE0B8;
    }
block_002AE09C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE09CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE09CU);
        }
        {
            r0 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002AE0A0U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x002AE0B0U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002AE0B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AE0B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AE0B8;
    }
block_002AE0B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE0B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE0B8U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r6 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x23FU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002AE0BCU, address);
            }
        }
        {
            const uint32_t address = r6 + 420U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE0C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002AE0C4U, 0xEEB40A68U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[17],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x265U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002AE0CCU, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x261U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002AE0D0U, address);
            }
        }
        if (flags.Z()) { goto block_002AE0F4; }
        goto block_002AE0D8;
    }
block_002AE0D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE0D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE0D8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002AE0D8U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0x265U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002AE0E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x264U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002AE0E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x263U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002AE0E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x262U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002AE0ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x261U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002AE0F0U, address);
            }
        }
        goto block_002AE0F4;
    }
block_002AE0F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE0F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE0F4U);
        }
        {
            const uint32_t operand = 0x00000500U;
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = 0x002AE100U + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE0F8U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE0FCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002AE178; }
        goto block_002AE108;
    }
block_002AE108:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE108U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE108U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002AE10CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x508U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE110U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t address = 0x002AE120U + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE118U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) { goto block_002AE12C; }
        goto block_002AE120;
    }
block_002AE120:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE120U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE120U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x002AE12CU + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE124U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) {
            const uint32_t address = 0x002AE130U + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE128U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_002AE12C;
    }
block_002AE12C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE12CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE12CU);
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = 0x002AE138U + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE130U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x002AE13CU + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE134U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x0000010CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002AE140U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AE140U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AE140;
    }
block_002AE140:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE140U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE140U);
        }
        {
        }
        {
        }
        goto block_002AE1A0;
    }
block_002AE178:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE178U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE178U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = 0x002AE188U + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE180U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x0000010CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002AE18CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002AE18CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002AE18C;
    }
block_002AE18C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE18CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE18CU);
        }
        {
            const uint32_t address = r6 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE18CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002AE190U, 0xEEB40A68U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[17],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x508U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002AE198U, address);
            }
        }
        if (flags.Z()) { goto block_002AE1F8; }
        goto block_002AE1A0;
    }
block_002AE1A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE1A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE1A0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x508U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE1A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002AE1F8; }
        goto block_002AE1AC;
    }
block_002AE1AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE1ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE1ACU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002AE1B0U, address);
            }
        }
        if (!(flags.Z())) { goto block_002AE1C8; }
        goto block_002AE1B8;
    }
block_002AE1B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE1B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE1B8U);
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = 0x002AE1C4U + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE1BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002AE1C0U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002AE1C0U,
                                           firstAddress + 4U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002AE1C0U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r4 = value4;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002AE1C4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002AE1C4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002AE1C4U,
                                           firstAddress + 8U);
            }
        }
        goto block_002AE1C8;
    }
block_002AE1C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE1C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE1C8U);
        }
        {
            const uint32_t address = r6 + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE1C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x002AE1D4U + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE1CCU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002AE1D0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x002AE1E0U + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE1D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002AE1DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002AE1E8U + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE1E0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002AE1E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002AE1F0U + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002AE1E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002AE1ECU, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F0U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F0U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F0U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F0U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F0U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F0U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            r13 += 24U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F4U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F4U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F4U,
                                           firstAddress + 28U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F4U,
                                           firstAddress + 32U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002AE1F4U,
                                           firstAddress + 36U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r12 = value12;
            r13 = r13 + 40U;
            return Oot3dAotReturned(value15);
        }
    }
block_002AE1F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002AE1F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002AE1F8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002AE1F8U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002AE1FCU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002AE1FCU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002AE1FCU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002AE1FCU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002AE1FCU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002AE1FCU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            r13 += 24U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002AE200U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002AE200U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002AE200U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002AE200U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002AE200U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002AE200U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002AE200U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002AE200U,
                                           firstAddress + 28U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x002AE200U,
                                           firstAddress + 32U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002AE200U,
                                           firstAddress + 36U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r12 = value12;
            r13 = r13 + 40U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Math_ApproachZeroF_0036FC20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0036FC20U:
        goto block_0036FC20;
    case 0x0036FC7CU:
        goto block_0036FC7C;
    case 0x0036FC8CU:
        goto block_0036FC8C;
    case 0x0036FC90U:
        goto block_0036FC90;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0036FC20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036FC20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036FC20U);
        }
        {
            const uint32_t updatedAddress = 0x0036FC28U + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036FC20U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0036FC2CU + 0x78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036FC24U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036FC28U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036FC30U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r1;
        }
        {
            frame.Guest.vfp[3] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036FC3CU, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036FC40U, 0xEEF81AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036FC44U, 0xEE211A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036FC48U, 0xEE210A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0036FC54U + 76U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036FC4CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036FC50U, 0xEE211A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036FC54U, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036FC58U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036FC5CU, 0xEEF01AC0U};
            frame.Guest.vfp[3] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r1 = frame.Guest.vfp[3];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036FC64U, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036FC70U, 0xEEF40AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0036FC8C; }
        goto block_0036FC7C;
    }
block_0036FC7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036FC7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036FC7CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036FC7CU, 0xEEB11A41U};
            frame.Guest.vfp[2] = frame.Guest.vfp[2] ^ 0x80000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036FC80U, 0xEEF40AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_0036FC90; }
        goto block_0036FC8C;
    }
block_0036FC8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036FC8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036FC8CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        goto block_0036FC90;
    }
block_0036FC90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036FC90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036FC90U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036FC90U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0036FC94U, address);
            }
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Math_SmoothStepToSUpdateRate_00370084(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00370084U:
        goto block_00370084;
    case 0x003700A4U:
        goto block_003700A4;
    case 0x003700C8U:
        goto block_003700C8;
    case 0x003700F0U:
        goto block_003700F0;
    case 0x003700F8U:
        goto block_003700F8;
    case 0x00370104U:
        goto block_00370104;
    case 0x00370130U:
        goto block_00370130;
    case 0x00370138U:
        goto block_00370138;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00370084:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00370084U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00370084U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00370084U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00370084U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00370084U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00370084U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            r5 = r0;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037008CU, address);
            }
            r6 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r4 = r3;
        }
        {
            const uint32_t operand = r6;
            r0 = r1 - operand;
        }
        {
            r1 = r2;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003700A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003700A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003700A4;
    }
block_003700A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003700A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003700A4U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x003700B0U + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003700A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003700B4U + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003700ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003700B8U + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003700B0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r4, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003700B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003700C0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003700F8; }
        goto block_003700C8;
    }
block_003700C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003700C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003700C8U);
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            frame.Guest.vfp[3] = r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003700D4U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003700D8U, 0xEEF81AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003700DCU, 0xEE211A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003700E0U, 0xDE510A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003700E4U, 0xCE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003700E8U, 0xEEBD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_003700F0;
    }
block_003700F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003700F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003700F0U);
        }
        {
            const uint32_t operand = r6;
            r0 = r0 + operand;
        }
        goto block_00370130;
    }
block_003700F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003700F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003700F8U);
        }
        {
            const uint32_t operand = 0x00000000U;
            r2 = operand - r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_00370138; }
        goto block_00370104;
    }
block_00370104:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00370104U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00370104U);
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            frame.Guest.vfp[3] = r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00370110U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00370114U, 0xEEF81AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00370118U, 0xEE211A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0037011CU, 0xDE510A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00370120U, 0xCE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00370124U, 0xEEBD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = r0;
            r0 = r6 - operand;
        }
        goto block_00370130;
    }
block_00370130:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00370130U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00370130U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00370130U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00370134U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00370134U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00370134U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00370134U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_00370138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00370138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00370138U);
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            frame.Guest.vfp[3] = r1;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00370144U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00370148U, 0xEEF81AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0037014CU, 0xEE211A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00370150U, 0xDE510A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00370154U, 0xCE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00370158U, 0xEEBD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_003700F0;
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_CollisionCheck_SetOC_003762A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003762A4U:
        goto block_003762A4;
    case 0x003762B8U:
        goto block_003762B8;
    case 0x003762C0U:
        goto block_003762C0;
    case 0x003762D8U:
        goto block_003762D8;
    case 0x003762E4U:
        goto block_003762E4;
    case 0x003762F0U:
        goto block_003762F0;
    case 0x003762FCU:
        goto block_003762FC;
    case 0x00376308U:
        goto block_00376308;
    case 0x00376310U:
        goto block_00376310;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003762A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003762A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003762A4U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x003762A4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003762A4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003762A4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003762A4U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            r6 = r0;
        }
        {
            r4 = r1;
        }
        {
            r5 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003762B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FrameAdvance_IsEnabled_00366738(frame, context, state, 0x00366738U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003762B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003762B8;
    }
block_003762B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003762B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003762B8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00376308; }
        goto block_003762C0;
    }
block_003762C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003762C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003762C0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x15U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003762C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003762CCU + 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003762C4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003762C8U, address);
            }
            r2 = value;
        }
        {
            r1 = r5;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x003762D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003762D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003762D8;
    }
block_003762D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003762D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003762D8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003762D8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003762F0; }
        goto block_003762E4;
    }
block_003762E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003762E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003762E4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x13CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003762E4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00376308; }
        goto block_003762F0;
    }
block_003762F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003762F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003762F0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003762F0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000032U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_00376308; }
        goto block_003762FC;
    }
block_003762FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003762FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003762FCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003762FCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00376310; }
        goto block_00376308;
    }
block_00376308:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376308U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376308U);
        }
        {
            r0 = ~(0x00000000U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0037630CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0037630CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0037630CU,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0037630CU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_00376310:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00376310U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00376310U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x1C4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x00376314U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00376318U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00376320U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00376324U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00376324U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00376324U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00376324U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Fishing_DrawRod_003CC884(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003CC884U:
        goto block_003CC884;
    case 0x003CC8ACU:
        goto block_003CC8AC;
    case 0x003CC8B4U:
        goto block_003CC8B4;
    case 0x003CC8BCU:
        goto block_003CC8BC;
    case 0x003CC8E0U:
        goto block_003CC8E0;
    case 0x003CC8F0U:
        goto block_003CC8F0;
    case 0x003CC904U:
        goto block_003CC904;
    case 0x003CC91CU:
        goto block_003CC91C;
    case 0x003CC938U:
        goto block_003CC938;
    case 0x003CC94CU:
        goto block_003CC94C;
    case 0x003CC960U:
        goto block_003CC960;
    case 0x003CC96CU:
        goto block_003CC96C;
    case 0x003CC97CU:
        goto block_003CC97C;
    case 0x003CC988U:
        goto block_003CC988;
    case 0x003CC99CU:
        goto block_003CC99C;
    case 0x003CC9B4U:
        goto block_003CC9B4;
    case 0x003CC9C4U:
        goto block_003CC9C4;
    case 0x003CC9D4U:
        goto block_003CC9D4;
    case 0x003CC9E8U:
        goto block_003CC9E8;
    case 0x003CC9F8U:
        goto block_003CC9F8;
    case 0x003CCA0CU:
        goto block_003CCA0C;
    case 0x003CCA18U:
        goto block_003CCA18;
    case 0x003CCA2CU:
        goto block_003CCA2C;
    case 0x003CCA38U:
        goto block_003CCA38;
    case 0x003CCA74U:
        goto block_003CCA74;
    case 0x003CCAACU:
        goto block_003CCAAC;
    case 0x003CCB20U:
        goto block_003CCB20;
    case 0x003CCB34U:
        goto block_003CCB34;
    case 0x003CCB4CU:
        goto block_003CCB4C;
    case 0x003CCB60U:
        goto block_003CCB60;
    case 0x003CCB70U:
        goto block_003CCB70;
    case 0x003CCBF8U:
        goto block_003CCBF8;
    case 0x003CCC0CU:
        goto block_003CCC0C;
    case 0x003CCC1CU:
        goto block_003CCC1C;
    case 0x003CCC30U:
        goto block_003CCC30;
    case 0x003CCC50U:
        goto block_003CCC50;
    case 0x003CCC60U:
        goto block_003CCC60;
    case 0x003CCC98U:
        goto block_003CCC98;
    case 0x003CCCBCU:
        goto block_003CCCBC;
    case 0x003CCCD0U:
        goto block_003CCCD0;
    case 0x003CCCDCU:
        goto block_003CCCDC;
    case 0x003CCCF0U:
        goto block_003CCCF0;
    case 0x003CCD00U:
        goto block_003CCD00;
    case 0x003CCD0CU:
        goto block_003CCD0C;
    case 0x003CCD18U:
        goto block_003CCD18;
    case 0x003CCD24U:
        goto block_003CCD24;
    case 0x003CCD38U:
        goto block_003CCD38;
    case 0x003CCD48U:
        goto block_003CCD48;
    case 0x003CCD54U:
        goto block_003CCD54;
    case 0x003CCD64U:
        goto block_003CCD64;
    case 0x003CCD74U:
        goto block_003CCD74;
    case 0x003CCD80U:
        goto block_003CCD80;
    case 0x003CCD8CU:
        goto block_003CCD8C;
    case 0x003CCD98U:
        goto block_003CCD98;
    case 0x003CCDA8U:
        goto block_003CCDA8;
    case 0x003CCDC4U:
        goto block_003CCDC4;
    case 0x003CCDE8U:
        goto block_003CCDE8;
    case 0x003CCE00U:
        goto block_003CCE00;
    case 0x003CCE44U:
        goto block_003CCE44;
    case 0x003CCE68U:
        goto block_003CCE68;
    case 0x003CCE8CU:
        goto block_003CCE8C;
    case 0x003CCE94U:
        goto block_003CCE94;
    case 0x003CCEA0U:
        goto block_003CCEA0;
    case 0x003CCF00U:
        goto block_003CCF00;
    case 0x003CCF14U:
        goto block_003CCF14;
    case 0x003CCF1CU:
        goto block_003CCF1C;
    case 0x003CCF28U:
        goto block_003CCF28;
    case 0x003CCF88U:
        goto block_003CCF88;
    case 0x003CD074U:
        goto block_003CD074;
    case 0x003CD098U:
        goto block_003CD098;
    case 0x003CD0A4U:
        goto block_003CD0A4;
    case 0x003CD0B0U:
        goto block_003CD0B0;
    case 0x003CD0F0U:
        goto block_003CD0F0;
    case 0x003CD0FCU:
        goto block_003CD0FC;
    case 0x003CD108U:
        goto block_003CD108;
    case 0x003CD184U:
        goto block_003CD184;
    case 0x003CD198U:
        goto block_003CD198;
    case 0x003CD1A4U:
        goto block_003CD1A4;
    case 0x003CD1C0U:
        goto block_003CD1C0;
    case 0x003CD1CCU:
        goto block_003CD1CC;
    case 0x003CD1DCU:
        goto block_003CD1DC;
    case 0x003CD1ECU:
        goto block_003CD1EC;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003CC884:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC884U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC884U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x003CC884U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003CC884U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003CC884U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x003CC884U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x003CC884U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x003CC884U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x003CC884U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x003CC884U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003CC884U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r5 = r1;
        }
        {
            r9 = r0;
        }
        {
            const uint32_t updatedAddress = 0x003CC898U + 0x2E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC890U, address);
            }
            r7 = value;
        }
        {
            r13 -= 48U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003CC894U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x003CC894U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x003CC894U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003CC894U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x003CC894U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x003CC894U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x003CC894U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x003CC894U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x003CC894U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x003CC894U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x003CC894U,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x003CC894U,
                                           firstAddress + 44U);
            }
        }
        {
            const uint32_t operand = 0x00000084U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC89CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003CC8A8U + 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC8A0U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003CC8E0; }
        goto block_003CC8AC;
    }
block_003CC8AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC8ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC8ACU);
        }
        {
            const uint32_t operand = 0x00000088U;
            r0 = r7 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CC8B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CC8B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CC8B4;
    }
block_003CC8B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC8B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC8B4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003CC8E0; }
        goto block_003CC8BC;
    }
block_003CC8BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC8BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC8BCU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = 0x003CC8C8U + 0x2BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC8C0U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[2];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003CC8CCU, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003CC8D0U, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x003CC8D4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000088U;
            r0 = r7 + operand;
        }
        {
            r0 = r0;
        }
        goto block_003CC8E0;
    }
block_003CC8E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC8E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC8E0U);
        }
        {
            const uint32_t updatedAddress = 0x003CC8E8U + 0x2A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC8E0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000014U;
            r8 = r9 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + r9;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC8E8U, address);
            }
            r4 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CC8F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseContext_GetState_003695F8(frame, context, state, 0x003695F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CC8F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CC8F0;
    }
block_003CC8F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC8F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC8F0U);
        }
        {
            const uint32_t address = 0x003CC8F8U + 660U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC8F0U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x003CC8FCU + 660U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC8F4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x003CC900U + 660U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC8F8U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (!(flags.Z())) { goto block_003CCCF0; }
        goto block_003CC904;
    }
block_003CC904:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC904U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC904U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x1BU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC904U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003CC910U + 648U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC908U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x003CC914U + 648U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC90CU, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x003CC918U + 648U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC910U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003CC96C; }
        goto block_003CC91C;
    }
block_003CC91C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC91CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC91CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r7 + 0x1BU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003CC924U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003CC930U + 0x27CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC928U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003CC934U + 624U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC92CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x003CC938U + 624U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC930U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CC938U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CC938U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CC938;
    }
block_003CC938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC938U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x003CC948U + 0x26CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC940U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003CC94CU + 612U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC944U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CC94CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CC94CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CC94C;
    }
block_003CC94C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC94CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC94CU);
        }
        {
            const uint32_t updatedAddress = 0x003CC954U + 0x264U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC94CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x003CC958U + 0x264U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC950U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CC960U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CC960U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CC960;
    }
block_003CC960:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC960U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC960U);
        }
        {
        }
        {
        }
        goto block_003CC9E8;
    }
block_003CC96C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC96CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC96CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC96CU, address);
            }
            r0 = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003CC9B4; }
        goto block_003CC97C;
    }
block_003CC97C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC97CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC97CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x1AU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC97CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003CC9B4; }
        goto block_003CC988;
    }
block_003CC988:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC988U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC988U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x32U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC988U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00006400U;
        }
        {
            const int32_t left = static_cast<int16_t>(
                r0 >> 0U);
            const int32_t right = static_cast<int16_t>(
                r1 >> 0U);
            r0 = static_cast<uint32_t>(left * right);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CC99CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CC99CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CC99C;
    }
block_003CC99C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC99CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC99CU);
        }
        {
            const uint32_t address = 0x003CC9A4U + 540U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC99CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CC9A0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CC9A4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r6 = value;
        }
        goto block_003CC9D4;
    }
block_003CC9B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC9B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC9B4U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            const uint32_t updatedAddress = 0x003CC9C0U + 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC9B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003CC9C4U + 512U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC9BCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CC9C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CC9C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CC9C4;
    }
block_003CC9C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC9C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC9C4U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x003CC9D4U + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC9CCU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CC9D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CC9D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CC9D4;
    }
block_003CC9D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC9D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC9D4U);
        }
        {
            r3 = 0x000003E8U;
        }
        {
            r2 = 0x00000005U;
        }
        {
            r1 = r6;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CC9E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CC9E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CC9E8;
    }
block_003CC9E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC9E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC9E8U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC9E8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003CCBF8; }
        goto block_003CC9F8;
    }
block_003CC9F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CC9F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CC9F8U);
        }
        {
            const uint32_t address = r8 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CC9F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CC9FCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003CCA18; }
        goto block_003CCA0C;
    }
block_003CCA0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCA0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCA0CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCA0CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t address = r7 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x003CCA14U, address);
            }
        }
        goto block_003CCA18;
    }
block_003CCA18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCA18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCA18U);
        }
        {
            const uint32_t address = r8 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCA18U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCA1CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003CCA38; }
        goto block_003CCA2C;
    }
block_003CCA2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCA2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCA2CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x22U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCA2CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t address = r7 + 104U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x003CCA34U, address);
            }
        }
        goto block_003CCA38;
    }
block_003CCA38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCA38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCA38U);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x003CCA44U + 388U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCA3CU, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x003CCA48U + 388U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCA40U, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x003CCA50U + 384U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCA48U, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r6 = r4 + operand;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCA5CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r6 + 580U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCA64U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t operand = 0x00000244U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCA6CU, 0xEE200A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCA74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCA74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCA74;
    }
block_003CCA74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCA74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCA74U);
        }
        {
            const uint32_t address = r6 + 580U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCA74U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCA80U, 0xEE709A69U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCA84U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            const uint32_t address = r6 + 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCA8CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCA90U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00002240U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCAA0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCAA4U, 0xEE200A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCAACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCAACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCAAC;
    }
block_003CCAAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCAACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCAACU);
        }
        {
            const uint32_t address = r6 + 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCAACU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x003CCAB8U + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCAB0U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCAB8U, 0xEE301ACAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x003CCAC4U + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCABCU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x003CCAD0U + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCAC8U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = r6 + 576U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003CCACCU, address);
            }
        }
        {
            const uint32_t address = r6 + 580U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCAD0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        if (flags.C()) {
            frame.Guest.vfp[1] = frame.Guest.vfp[3];
        }
        {
            const uint32_t address = r6 + 580U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003CCAF0U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) {
            frame.Guest.vfp[0] = frame.Guest.vfp[3];
        }
        {
            const uint32_t updatedAddress = 0x003CCB04U + 0xE0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCAFCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r6 + 576U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003CCB00U, address);
            }
        }
        {
            const uint32_t address = 0x003CCB0CU + 212U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCB04U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r6 + 580U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003CCB08U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCB0CU, 0xEE210A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCB10U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCB14U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCB20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCB20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCB20;
    }
block_003CCB20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCB20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCB20U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x003CCB34U + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCB2CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCB34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCB34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCB34;
    }
block_003CCB34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCB34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCB34U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCB34U, 0xEE290A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[19], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x003CCB44U + 0xA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCB3CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r7 + 104U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCB40U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCB44U, 0xEE200A2BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCB4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCB4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCB4C;
    }
block_003CCB4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCB4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCB4CU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x003CCB60U + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCB58U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCB60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCB60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCB60;
    }
block_003CCB60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCB60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCB60U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x003CCB70U + 0x84U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCB68U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCB70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCB70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCB70;
    }
block_003CCB70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCB70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCB70U);
        }
        {
        }
        {
        }
        goto block_003CCCF0;
    }
block_003CCBF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCBF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCBF8U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000244U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCC0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCC0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCC0C;
    }
block_003CCC0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCC0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCC0CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00002240U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCC1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCC1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCC1C;
    }
block_003CCC1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCC1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCC1CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x32U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCC1CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003CCC28U + 0x3E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCC20U, address);
            }
            r1 = value;
        }
        {
            const int32_t left = static_cast<int16_t>(
                r0 >> 0U);
            const int32_t right = static_cast<int16_t>(
                r1 >> 0U);
            r0 = static_cast<uint32_t>(left * right);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCC30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCC30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCC30;
    }
block_003CCC30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCC30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCC30U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x003CCC3CU + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCC34U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x003CCC40U + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCC38U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x003CCC44U - 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCC3CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCC40U, 0xEE000A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCC50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCC50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCC50;
    }
block_003CCC50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCC50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCC50U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x003CCC60U - 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCC58U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCC60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCC60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCC60;
    }
block_003CCC60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCC60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCC60U);
        }
        {
            const uint32_t updatedAddress = 0x003CCC68U + 0x3B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCC60U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000110U;
        }
        {
            const uint32_t address = 0x003CCC70U + 940U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCC68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCC6CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCC70U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCC74U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCC7CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCC80U, 0xEE800A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCC84U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCC88U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003CCCDC; }
        goto block_003CCC98;
    }
block_003CCC98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCC98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCC98U);
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            const uint32_t address = 0x003CCCA4U + 892U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCC9CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCCA0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCCA4U, 0xEE800A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCCA8U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCCACU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003CCCDC; }
        goto block_003CCCBC;
    }
block_003CCCBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCCBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCCBCU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x003CCCC8U - 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCCC0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003CCCCCU + 856U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCCC4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x003CCCD0U + 856U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCCC8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCCD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCCD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCCD0;
    }
block_003CCCD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCCD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCCD0U);
        }
        {
        }
        {
        }
        goto block_003CCCF0;
    }
block_003CCCDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCCDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCCDCU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = 0x003CCCF0U - 0xFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCCE8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCCF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCCF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCCF0;
    }
block_003CCCF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCCF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCCF0U);
        }
        {
            const uint32_t updatedAddress = 0x003CCCF8U + 0x334U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCCF0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCCF4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00100000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00100000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003CD1EC; }
        goto block_003CCD00;
    }
block_003CCD00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCD00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCD00U);
        }
        {
            r1 = 0x00000018U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCD0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCD0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCD0C;
    }
block_003CCD0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCD0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCD0CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_003CD1EC; }
        goto block_003CCD18;
    }
block_003CCD18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCD18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCD18U);
        }
        {
            const uint32_t operand = 0x00000054U;
            r1 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCD24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003720a4_003720A4(frame, context, state, 0x003720A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCD24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCD24;
    }
block_003CCD24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCD24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCD24U);
        }
        {
            const uint32_t updatedAddress = r7 + 0xDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCD24U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003CCD30U + 768U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCD28U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003CCD54; }
        goto block_003CCD38;
    }
block_003CCD38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCD38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCD38U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = 0x003CCD44U + 752U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCD3CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCD48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Mtx3x4_Translate_003713FC(frame, context, state, 0x003713FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCD48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCD48;
    }
block_003CCD48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCD48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCD48U);
        }
        {
        }
        {
        }
        goto block_003CCD64;
    }
block_003CCD54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCD54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCD54U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = 0x003CCD60U + 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCD58U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCD64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Mtx3x4_Translate_003713FC(frame, context, state, 0x003713FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCD64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCD64;
    }
block_003CCD64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCD64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCD64U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCD64U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003CCD8C; }
        goto block_003CCD74;
    }
block_003CCD74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCD74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCD74U);
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = 0x003CCD80U + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCD78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCD80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Matrix_RotateY_003735E8(frame, context, state, 0x003735E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCD80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCD80;
    }
block_003CCD80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCD80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCD80U);
        }
        {
        }
        {
        }
        goto block_003CCD98;
    }
block_003CCD8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCD8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCD8CU);
        }
        {
            const uint32_t address = 0x003CCD94U + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCD8CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCD98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Matrix_RotateY_003735E8(frame, context, state, 0x003735E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCD98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCD98;
    }
block_003CCD98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCD98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCD98U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t address = 0x003CCDA4U + 672U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCD9CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCDA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Matrix_RotateX_00369014(frame, context, state, 0x00369014U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCDA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCDA8;
    }
block_003CCDA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCDA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCDA8U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r4 = r4 + operand;
        }
        {
            const uint32_t address = 0x003CCDB4U + 660U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCDACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCDB0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCDBCU, 0xEE000A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCDC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Matrix_RotateZ_00371234(frame, context, state, 0x00371234U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCDC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCDC4;
    }
block_003CCDC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCDC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCDC4U);
        }
        {
            const uint32_t address = r7 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCDC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003CCDD0U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCDC8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x003CCDD4U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCDCCU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCDD4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCDDCU, 0xEE200A2BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCDE0U, 0xEE200A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCDE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Matrix_RotateX_00369014(frame, context, state, 0x00369014U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCDE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCDE8;
    }
block_003CCDE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCDE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCDE8U);
        }
        {
            const uint32_t address = 0x003CCDF0U + 612U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCDE8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCE00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Matrix_Scale_00371348(frame, context, state, 0x00371348U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCE00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCE00;
    }
block_003CCE00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCE00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCE00U);
        }
        {
            const uint32_t address = r7 + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCE00U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r7 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCE04U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[21] = frame.Guest.vfp[18];
        }
        {
            r1 = 0x00000001U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCE10U, 0xEE709A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 580U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCE14U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003CCE20U + 568U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCE18U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x003CCE24U + 568U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCE1CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCE20U, 0xEE300A48U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCE2CU, 0xEE40AA20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[21], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCE30U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCE34U, 0xEE409A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCE44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Mtx3x4_Translate_003713FC(frame, context, state, 0x003713FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCE44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCE44;
    }
block_003CCE44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCE44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCE44U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCE44U, 0xEE698A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[19], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = 0x003CCE50U + 0x210U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCE48U, address);
            }
            r11 = value;
        }
        {
            const uint32_t address = 0x003CCE54U + 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCE4CU, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t address = 0x003CCE58U + 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCE50U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x003CCE5CU + 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCE54U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            r4 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000054U;
            r8 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r9 = r13 + operand;
        }
        {
            r10 = 0x00000001U;
        }
        goto block_003CCE68;
    }
block_003CCE68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCE68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCE68U);
        }
        {
            const uint32_t address = r7 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCE68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x003CCE74U + 0x1FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCE6CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCE70U, 0xEE600A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r6 = r0 + operand;
        }
        {
            const uint32_t address = r6 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCE78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCE7CU, 0xEE20BA20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[22], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCE80U, 0xEEB4BA48U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[22], frame.Guest.vfp[16],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_003CCF00; }
        goto block_003CCE8C;
    }
block_003CCE8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCE8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCE8CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCE94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCE94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCE94;
    }
block_003CCE94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCE94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCE94U);
        }
        {
            frame.Guest.vfp[21] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCEA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCEA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCEA0;
    }
block_003CCEA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCEA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCEA0U);
        }
        {
            const uint32_t address = r13 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCEA0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCEA4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCEA8U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCEACU, 0xEE600AAAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCEB0U, 0xEE411A6AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCEB4U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x003CCEB8U, address);
            }
        }
        {
            const uint32_t address = r13 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003CCEBCU, address);
            }
        }
        {
            const uint32_t address = r13 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCEC0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCEC4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCEC8U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCECCU, 0xEE600AAAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCED0U, 0xEE411A6AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCED4U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x003CCED8U, address);
            }
        }
        {
            const uint32_t address = r13 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003CCEDCU, address);
            }
        }
        {
            const uint32_t address = r13 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCEE0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCEE4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCEE8U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCEECU, 0xEE600AAAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCEF0U, 0xEE411A6AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCEF4U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 116U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x003CCEF8U, address);
            }
        }
        {
            const uint32_t address = r13 + 124U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003CCEFCU, address);
            }
        }
        goto block_003CCF00;
    }
block_003CCF00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCF00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCF00U);
        }
        {
            const uint32_t address = r6 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCF00U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF04U, 0xEE60AA28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF08U, 0xEEF4AA48U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[21], frame.Guest.vfp[16],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_003CCF88; }
        goto block_003CCF14;
    }
block_003CCF14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCF14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCF14U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCF1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCF1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCF1C;
    }
block_003CCF1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCF1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCF1CU);
        }
        {
            frame.Guest.vfp[22] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CCF28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CCF28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CCF28;
    }
block_003CCF28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCF28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCF28U);
        }
        {
            const uint32_t address = r13 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCF28U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCF2CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF30U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF34U, 0xEE411A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF38U, 0xEE211A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x003CCF3CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF40U, 0xEE001ACBU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x003CCF44U, address);
            }
        }
        {
            const uint32_t address = r13 + 104U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCF48U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCF4CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF50U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF54U, 0xEE411A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF58U, 0xEE211A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 104U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x003CCF5CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF60U, 0xEE001ACBU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x003CCF64U, address);
            }
        }
        {
            const uint32_t address = r13 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCF68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCF6CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF70U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF74U, 0xEE210A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF78U, 0xEE411A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCF7CU, 0xEE000ACBU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 120U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x003CCF80U, address);
            }
        }
        {
            const uint32_t address = r13 + 124U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003CCF84U, address);
            }
        }
        goto block_003CCF88;
    }
block_003CCF88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CCF88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CCF88U);
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003CCF88U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003CCF88U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003CCF88U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003CCF88U,
                                           firstAddress + 12U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003CCF88U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003CCF88U,
                                           firstAddress + 20U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x003CCF88U,
                                           firstAddress + 24U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r12 = value12;
            r14 = value14;
            r8 = r8 + 28U;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x003CCF8CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003CCF8CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003CCF8CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003CCF8CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003CCF8CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r12)) {
                return Oot3dAotMemoryFault(context, 0x003CCF8CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003CCF8CU,
                                           firstAddress + 24U);
            }
            r9 = r9 + 28U;
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003CCF90U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003CCF90U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003CCF90U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003CCF90U,
                                           firstAddress + 12U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003CCF90U,
                                           firstAddress + 16U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r8 = r8 - operand;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x003CCF98U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003CCF98U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003CCF98U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003CCF98U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003CCF98U,
                                           firstAddress + 16U);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r11 + operand;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r9 = r9 - operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCFA4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCFA8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCFACU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003CCFB0U, address);
            }
        }
        {
            const uint32_t address = r13 + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCFB4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCFB8U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003CCFBCU, address);
            }
        }
        {
            const uint32_t address = r13 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCFC0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCFC4U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003CCFC8U, address);
            }
        }
        {
            const uint32_t address = r13 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCFCCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCFD0U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003CCFD4U, address);
            }
        }
        {
            const uint32_t address = r13 + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCFD8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCFDCU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003CCFE0U, address);
            }
        }
        {
            const uint32_t address = r13 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCFE4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCFE8U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003CCFECU, address);
            }
        }
        {
            const uint32_t address = r13 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCFF0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CCFF4U, 0xEE200A0CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[24], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003CCFF8U, address);
            }
        }
        {
            const uint32_t address = r13 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CCFFCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD000U, 0xEE200A0CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[24], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003CD004U, address);
            }
        }
        goto block_003CD074;
    }
block_003CD074:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD074U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD074U);
        }
        {
            const uint32_t address = r13 + 76U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD074U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r6 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r1 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD080U, 0xEE200A0CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[24], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003CD084U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x730U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD088U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xACU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x003CD08CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x730U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD090U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CD098U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_CopyOverrideTransform_003721E0(frame, context, state, 0x003721E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CD098U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CD098;
    }
block_003CD098:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD098U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD098U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x730U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD098U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CD0A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_Submit_00372170(frame, context, state, 0x00372170U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CD0A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CD0A4;
    }
block_003CD0A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD0A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD0A4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_003CD1A4; }
        goto block_003CD0B0;
    }
block_003CD0B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD0B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD0B0U);
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B0U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B0U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B0U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B0U,
                                           firstAddress + 12U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B0U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B0U,
                                           firstAddress + 20U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B0U,
                                           firstAddress + 24U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r12 = value12;
            r14 = value14;
            r8 = r8 + 28U;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r12)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B4U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B4U,
                                           firstAddress + 24U);
            }
            r9 = r9 + 28U;
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B8U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B8U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B8U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B8U,
                                           firstAddress + 12U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003CD0B8U,
                                           firstAddress + 16U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r8 = r8 - operand;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x003CD0C0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003CD0C0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003CD0C0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003CD0C0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003CD0C0U,
                                           firstAddress + 16U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r9 = r9 - operand;
        }
        {
            const uint32_t operand = 0x00000018U;
            r2 = r13 + operand;
        }
        {
            const uint32_t address = r7 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD0CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r7 + 144U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD0D0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r7 + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD0D4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003CD0D8U, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x003CD0DCU, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003CD0E0U, address);
            }
        }
        {
            r1 = r9;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CD0F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_translate_mtx3x4_local_00372070(frame, context, state, 0x00372070U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CD0F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CD0F0;
    }
block_003CD0F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD0F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD0F0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CD0FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CD0FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CD0FC;
    }
block_003CD0FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD0FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD0FCU);
        }
        {
            frame.Guest.vfp[21] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CD108U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CD108U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CD108;
    }
block_003CD108:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD108U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD108U);
        }
        {
            const uint32_t address = r13 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD108U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD10CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD114U, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r9;
        }
        {
            r0 = r9;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD120U, 0xEE411A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD124U, 0xEE211A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x003CD128U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD12CU, 0xEE001AEAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x003CD130U, address);
            }
        }
        {
            const uint32_t address = r13 + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD134U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD138U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD13CU, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD140U, 0xEE411A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD144U, 0xEE211A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x003CD148U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD14CU, 0xEE001AEAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x003CD150U, address);
            }
        }
        {
            const uint32_t address = r13 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD154U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD158U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD15CU, 0xEE601A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD160U, 0xEE210A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD164U, 0xEE411A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003CD168U, 0xEE000AEAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x003CD16CU, address);
            }
        }
        {
            const uint32_t address = r13 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003CD170U, address);
            }
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003CD174U, address);
            }
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003CD178U, address);
            }
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003CD17CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CD184U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_translate_mtx3x4_local_00372070(frame, context, state, 0x00372070U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CD184U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CD184;
    }
block_003CD184:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD184U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD184U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x72CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD184U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000024U;
            r1 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xACU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x003CD18CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x72CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD190U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CD198U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_CopyOverrideTransform_003721E0(frame, context, state, 0x003721E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CD198U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CD198;
    }
block_003CD198:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD198U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD198U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x72CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD198U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CD1A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_Submit_00372170(frame, context, state, 0x00372170U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CD1A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CD1A4;
    }
block_003CD1A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD1A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD1A4U);
        }
        {
            const uint32_t address = r13 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003CD1A4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003CD1ACU, address);
            }
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x003CD1B0U, address);
            }
        }
        {
            r2 = r13;
        }
        {
            r1 = r0;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CD1C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_translate_mtx3x4_local_00372070(frame, context, state, 0x00372070U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CD1C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CD1C0;
    }
block_003CD1C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD1C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD1C0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000015U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_003CD1DC; }
        goto block_003CD1CC;
    }
block_003CD1CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD1CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD1CCU);
        }
        {
            const uint32_t updatedAddress = 0x003CD1D4U - 0x650U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003CD1CCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00000054U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000090U;
            r0 = r2 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003CD1DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003CD1DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003CD1DC;
    }
block_003CD1DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD1DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD1DCU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000016U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_003CCE68; }
        goto block_003CD1EC;
    }
block_003CD1EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003CD1ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003CD1ECU);
        }
        {
            const uint32_t operand = 0x00000084U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F0U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F0U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F0U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F0U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F0U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F0U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F0U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F0U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F0U,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F0U,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F0U,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F0U,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            r13 += 48U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F4U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F4U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F4U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003CD1F4U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
