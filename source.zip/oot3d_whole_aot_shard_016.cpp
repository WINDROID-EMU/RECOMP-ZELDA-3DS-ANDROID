#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_FUN_001546ec_001546EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnGb_Init_00164114(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DemoGj_Init_001AA9C8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DemoGt_Init_001AAFE4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Fishing_Init_001C0AD8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CmbModelInstance_ResetMaterialState_003103A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererModelResource_CreateFromCmb_00340D00(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00340de8_00340DE8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelHandle_LoadAllWithOwner_00340E14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003430fc_003430FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DemoGj_InitSetIndexes_00343194(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_memcpy_0034338C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CmbRenderState_Construct_00347258(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererTextureStage_ConfigureTextureUnit_00348A64(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererTextureStageState_ConstructFromDescriptor_00348F34(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererModelResource_SetTextureTransform_0034EA48(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0034ea6c_0034EA6C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_LightContext_InsertLight_0034FAA8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Collider_SetCylinderType1_0034FB3C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_InitObjectBank_0034FE20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ActorTextureBinding_Configure_0034FEA8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererTexturedQuadResource_Construct_0034FF2C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ActorTextureBinding_Reset_003500C4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SystemArena_Malloc_0035010c_0035010C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_ProcessInitChain_003510B0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DynaPolyInfo_GetCollisionHeader_003532C0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DynaPolyActor_Init_003532E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_InitActor_00353C9C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Collider_InitCylinder_00353DD0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DynaPoly_SetBgActor_00353EC8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DynaPolyInfo_Alloc_00353FD4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_MaterialAnimation_NormalizeFrame_003586EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ZAR_GetCMBByIndex_00358EF8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Lights_PointNoGlowSetInfo_003591E4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_SetFaceAnimations_0035C358(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_SetBGM_003655D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererGlobalState_Init_0036788C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_StaticInitGuard_TryAcquire_003679B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelHandle_GetSharedResource_003687A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SpawnAsChild_0036AA20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Flags_GetSwitch_0036E864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_MorphToLoop_00370350(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Runtime_Memcpy_00371738(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroFloat_00371E50(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_CosF_Core_00372674(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SinF_003727F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ZAR_GetCTXBByIndex_00372C90(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ActorShape_Init_00372D4C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_MaterialAnimation_Init_00372D94(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ZAR_GetCMABByIndex_00372F0C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelHandle_LoadAll_00372F38(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_field_80x4_positive_00373074(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Spawn_003738D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Kill_00374428(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetScale_0037572C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroOne_003759D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_ChangeType_00375D3C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003f1510_003F1510(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FishingLineRenderer_Init_003FD018(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_MaterialAnimation_CreateRuntimeEntry_004BDCD0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_FUN_001546ec_001546EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001546ECU:
        goto block_001546EC;
    case 0x00154710U:
        goto block_00154710;
    case 0x00154718U:
        goto block_00154718;
    case 0x00154734U:
        goto block_00154734;
    case 0x00154750U:
        goto block_00154750;
    case 0x00154758U:
        goto block_00154758;
    case 0x00154760U:
        goto block_00154760;
    case 0x00154780U:
        goto block_00154780;
    case 0x0015479CU:
        goto block_0015479C;
    case 0x001547ACU:
        goto block_001547AC;
    case 0x001547F8U:
        goto block_001547F8;
    case 0x00154808U:
        goto block_00154808;
    case 0x0015481CU:
        goto block_0015481C;
    case 0x0015482CU:
        goto block_0015482C;
    case 0x00154844U:
        goto block_00154844;
    case 0x00154858U:
        goto block_00154858;
    case 0x00154868U:
        goto block_00154868;
    case 0x00154884U:
        goto block_00154884;
    case 0x0015489CU:
        goto block_0015489C;
    case 0x001548ACU:
        goto block_001548AC;
    case 0x001548B8U:
        goto block_001548B8;
    case 0x001548C4U:
        goto block_001548C4;
    case 0x001548C8U:
        goto block_001548C8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001546EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001546ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001546ECU);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001546ECU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001546ECU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001546ECU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001546ECU,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            r6 = r1;
        }
        {
            const uint32_t operand = 0x00000100U;
            r5 = r0 + operand;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00003800U;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154700U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 - operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154710U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_field_80x4_positive_00373074(frame, context, state, 0x00373074U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154710U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154710;
    }
block_00154710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154710U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00154758; }
        goto block_00154718;
    }
block_00154718:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154718U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154718U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154718U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00154724U + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015471CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154720U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x140U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00154724U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154728U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00154760; }
        goto block_00154734;
    }
block_00154734:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154734U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154734U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00154738U, address);
            }
        }
        {
            r3 = 0x0000000CU;
        }
        {
            const uint32_t operand = 0x0000021CU;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154750U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154750U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154750;
    }
block_00154750:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154750U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154750U);
        }
        {
            const uint32_t updatedAddress = 0x00154758U + 0x180U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154750U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154754U, address);
            }
        }
        goto block_00154758;
    }
block_00154758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154758U);
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0015475CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0015475CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0015475CU,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0015475CU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_00154760:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154760U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154760U);
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            r0 = r0;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154770U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154774U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001547F8; }
        goto block_00154780;
    }
block_00154780:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154780U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154780U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00154784U, address);
            }
        }
        {
            r3 = 0x0000001FU;
        }
        {
            const uint32_t operand = 0x0000021CU;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0015479CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0015479CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0015479C;
    }
block_0015479C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0015479CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0015479CU);
        }
        {
            r2 = 0x00000008U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001547ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001547ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001547AC;
    }
block_001547AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001547ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001547ACU);
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001547B4U, address);
            }
        }
        {
            const uint32_t address = 0x001547C0U + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001547B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 516U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001547BCU, address);
            }
        }
        {
            const uint32_t address = 0x001547C8U + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001547C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 520U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001547C4U, address);
            }
        }
        {
            const uint32_t address = 0x001547D0U + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001547C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 524U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001547CCU, address);
            }
        }
        {
            const uint32_t address = r4 + 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001547D0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001547DCU + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001547D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001547D8U, 0xEE700AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 528U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001547DCU, address);
            }
        }
        {
            const uint32_t address = r4 + 536U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001547E0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001547E4U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 536U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001547E8U, address);
            }
        }
        {
            const uint32_t address = 0x001547F4U + 248U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001547ECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 256U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001547F0U, address);
            }
        }
        goto block_00154884;
    }
block_001547F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001547F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001547F8U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00154800U, address);
            }
        }
        if (!(flags.Z())) { goto block_00154844; }
        goto block_00154808;
    }
block_00154808:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154808U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154808U);
        }
        {
            r3 = 0x0000000CU;
        }
        {
            const uint32_t operand = 0x0000021CU;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0015481CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0015481CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0015481C;
    }
block_0015481C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0015481CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0015481CU);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0015482CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0015482CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0015482C;
    }
block_0015482C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0015482CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0015482CU);
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154834U, address);
            }
        }
        {
            const uint32_t address = 0x00154840U + 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154838U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 524U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0015483CU, address);
            }
        }
        goto block_00154884;
    }
block_00154844:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154844U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154844U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x0000021CU;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154858U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154858U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154858;
    }
block_00154858:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154858U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154858U);
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154868U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154868U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154868;
    }
block_00154868:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154868U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154868U);
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154870U, address);
            }
        }
        {
            const uint32_t address = 0x0015487CU + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154874U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 516U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00154878U, address);
            }
        }
        {
            const uint32_t address = 0x00154884U + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015487CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 520U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00154880U, address);
            }
        }
        goto block_00154884;
    }
block_00154884:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154884U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154884U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154888U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            const uint32_t operand = 0x000002E8U;
            r1 = r1 + operand;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0015489CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPoly_SetBgActor_00353EC8(frame, context, state, 0x00353EC8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0015489CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0015489C;
    }
block_0015489C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0015489CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0015489CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0015489CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001548A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001548C4; }
        goto block_001548AC;
    }
block_001548AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001548ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001548ACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001548ACU, address);
            }
            r1 = value;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001548B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_GetSwitch_0036E864(frame, context, state, 0x0036E864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001548B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001548B8;
    }
block_001548B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001548B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001548B8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x001548C4U + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001548BCU, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_001548C8; }
        goto block_001548C4;
    }
block_001548C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001548C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001548C4U);
        }
        {
            const uint32_t updatedAddress = 0x001548CCU + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001548C4U, address);
            }
            r0 = value;
        }
        goto block_001548C8;
    }
block_001548C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001548C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001548C8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001548C8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001548D0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001548D0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001548D0U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001548D0U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_EnGb_Init_00164114(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00164114U:
        goto block_00164114;
    case 0x0016413CU:
        goto block_0016413C;
    case 0x00164148U:
        goto block_00164148;
    case 0x00164154U:
        goto block_00164154;
    case 0x00164174U:
        goto block_00164174;
    case 0x00164190U:
        goto block_00164190;
    case 0x001641BCU:
        goto block_001641BC;
    case 0x001641D0U:
        goto block_001641D0;
    case 0x001641E4U:
        goto block_001641E4;
    case 0x001641ECU:
        goto block_001641EC;
    case 0x0016420CU:
        goto block_0016420C;
    case 0x00164224U:
        goto block_00164224;
    case 0x00164230U:
        goto block_00164230;
    case 0x00164248U:
        goto block_00164248;
    case 0x001642B4U:
        goto block_001642B4;
    case 0x001642D0U:
        goto block_001642D0;
    case 0x001642DCU:
        goto block_001642DC;
    case 0x00164300U:
        goto block_00164300;
    case 0x00164324U:
        goto block_00164324;
    case 0x00164328U:
        goto block_00164328;
    case 0x00164354U:
        goto block_00164354;
    case 0x0016435CU:
        goto block_0016435C;
    case 0x00164384U:
        goto block_00164384;
    case 0x001643ACU:
        goto block_001643AC;
    case 0x001643B4U:
        goto block_001643B4;
    case 0x0016444CU:
        goto block_0016444C;
    case 0x00164484U:
        goto block_00164484;
    case 0x001644A0U:
        goto block_001644A0;
    case 0x001644ACU:
        goto block_001644AC;
    case 0x001644D0U:
        goto block_001644D0;
    case 0x001644D4U:
        goto block_001644D4;
    case 0x00164544U:
        goto block_00164544;
    case 0x00164550U:
        goto block_00164550;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00164114:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164114U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164114U);
        }
        {
            const uint32_t firstAddress = r13 - 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00164114U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00164114U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00164114U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00164114U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00164114U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00164114U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00164114U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00164114U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00164114U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00164114U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00164114U,
                                           firstAddress + 40U);
            }
            r13 = r13 - 44U;
        }
        {
            r10 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x00164124U + 0x444U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016411CU, address);
            }
            r1 = value;
        }
        {
            r13 -= 24U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00164120U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00164120U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00164120U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00164120U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x00164120U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x00164120U,
                                           firstAddress + 20U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164128U, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016412CU, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00164130U, address);
            }
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0016413CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProcessInitChain_003510B0(frame, context, state, 0x003510B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0016413CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0016413C;
    }
block_0016413C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016413CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016413CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016413CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00164148U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyActor_Init_003532E8(frame, context, state, 0x003532E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00164148U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00164148;
    }
block_00164148:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164148U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164148U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0016414CU, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00164154U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00164154U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00164154;
    }
block_00164154:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164154U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164154U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r1 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00164158U, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164160U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164164U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164168U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x000002E8U;
            r1 = r1 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00164174U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPoly_SetBgActor_00353EC8(frame, context, state, 0x00353EC8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00164174U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00164174;
    }
block_00164174:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164174U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164174U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00164178U, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00164180U, address);
            }
        }
        {
            const uint32_t operand = 0x0000008CU;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00164188U, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00164190U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00164190U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00164190;
    }
block_00164190:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164190U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164190U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00164194U, address);
            }
        }
        {
            r3 = 0x0000000AU;
        }
        {
            const uint32_t operand = 0x00000048U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000240U;
            r1 = r5 + operand;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001641A8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001641A8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001641A8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001641A8U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x000001BCU;
            r2 = r5 + operand;
        }
        {
            r3 = r0;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001641B4U, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001641BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_InitActor_00353C9C(frame, context, state, 0x00353C9CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001641BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001641BC;
    }
block_001641BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001641BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001641BCU);
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000254U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001641C4U, address);
            }
            r0 = value;
        }
        {
            r4 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001641D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitCylinder_00353DD0(frame, context, state, 0x00353DD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001641D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001641D0;
    }
block_001641D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001641D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001641D0U);
        }
        {
            const uint32_t updatedAddress = 0x001641D8U + 0x394U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001641D0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001641D4U, address);
            }
            r0 = value;
        }
        {
            r2 = r5;
        }
        {
            r1 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001641E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetCylinderType1_0034FB3C(frame, context, state, 0x0034FB3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001641E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001641E4;
    }
block_001641E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001641E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001641E4U);
        }
        {
            const uint32_t updatedAddress = 0x001641ECU + 0x384U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001641E4U, address);
            }
            r6 = value;
        }
        {
            r4 = 0x00000000U;
        }
        goto block_001641EC;
    }
block_001641EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001641ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001641ECU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 3U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r8 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r8 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164200U, address);
            }
            r0 = value;
        }
        {
            r1 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0016420CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitCylinder_00353DD0(frame, context, state, 0x00353DD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0016420CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0016420C;
    }
block_0016420C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016420CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016420CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 3U);
            r0 = operand - r4;
        }
        {
            r2 = r5;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r3 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164218U, address);
            }
            r0 = value;
        }
        {
            r1 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00164224U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetCylinderType1_0034FB3C(frame, context, state, 0x0034FB3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00164224U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00164224;
    }
block_00164224:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164224U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164224U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001641EC; }
        goto block_00164230;
    }
block_00164230:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164230U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164230U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000003B8U;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164238U, address);
            }
            r0 = value;
        }
        {
            r4 = r2;
        }
        {
            const uint32_t operand = 0x00000A70U;
            r1 = r7 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00164248U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_LightContext_InsertLight_0034FAA8(frame, context, state, 0x0034FAA8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00164248U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00164248;
    }
block_00164248:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164248U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164248U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x000000C8U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x7B4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00164250U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00164254U, faultAddress);
            }
        }
        {
            const uint32_t address = r5 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164258U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x000000FFU;
        }
        {
            r2 = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164264U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r3;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164278U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016427CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164280U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164290U, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164294U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164298U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001642ACU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001642B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Lights_PointNoGlowSetInfo_003591E4(frame, context, state, 0x003591E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001642B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001642B4;
    }
block_001642B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001642B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001642B4U);
        }
        {
            const uint32_t address = 0x001642BCU + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001642B4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001642B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001642C4U + 0x2B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001642BCU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x001642CCU + 680U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001642C4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001642D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorShape_Init_00372D4C(frame, context, state, 0x00372D4CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001642D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001642D0;
    }
block_001642D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001642D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001642D0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001642D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001642DCU + 676U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001642D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001642DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetScale_0037572C(frame, context, state, 0x0037572CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001642DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001642DC;
    }
block_001642DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001642DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001642DCU);
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t address = 0x001642E8U + 668U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001642E0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001642ECU + 668U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001642E4U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001642E8U, address);
            }
        }
        {
            const uint32_t address = r5 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001642ECU, address);
            }
        }
        {
            const uint32_t address = r5 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001642F0U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r5 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001642F8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00164300U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00164300U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00164300;
    }
block_00164300:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164300U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164300U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164300U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r4 = 0x00000064U;
        }
        {
            const uint32_t address = 0x00164310U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164308U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x00164314U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016430CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r4;
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00164354; }
        goto block_00164324;
    }
block_00164324:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164324U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164324U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00164328U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00164328U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00164328;
    }
block_00164328:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164328U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164328U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164328U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[17];
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r4;
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0016433CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164340U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164344U, 0xEE009A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164348U, 0xEEBD0AC9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_00164384;
    }
block_00164354:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164354U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164354U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0016435CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0016435CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0016435C;
    }
block_0016435C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016435CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016435CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0016435CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[17];
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r4;
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164370U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164374U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164378U, 0xEE109A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0016437CU, 0xEEBD0AC9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_00164384;
    }
block_00164384:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164384U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164384U);
        }
        {
            const uint32_t updatedAddress = 0x0016438CU + 0x20CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164384U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = 0x00000700U;
            r1 = r5 + operand;
        }
        {
            const uint32_t address = 0x00164394U + 512U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016438CU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x00164398U + 516U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164390U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x0016439CU + 516U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164394U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x001643A0U + 516U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164398U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0016439CU, address);
            }
        }
        {
            r6 = 0x00000000U;
        }
        {
            r8 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + 0xD4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001643A8U, address);
            }
        }
        goto block_001643AC;
    }
block_001643AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001643ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001643ACU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001643B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001643B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001643B4;
    }
block_001643B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001643B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001643B4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001643B4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = 0x001643C0U + 0x1E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001643B8U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t leftValue = r1;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 31U);
            r1 = r1 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r1 - operand;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r1 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 3U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r4 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r7 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x7DCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001643E0U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r0 = r6 + operand;
        }
        {
            const uint32_t address = r5 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001643E8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r11 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r1 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001643F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001643F8U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 996U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001643FCU, address);
            }
        }
        {
            const uint32_t address = r0 + 1008U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00164400U, address);
            }
        }
        {
            const uint32_t address = r5 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164404U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164408U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0016440CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 1000U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00164410U, address);
            }
        }
        {
            const uint32_t address = r0 + 1012U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00164414U, address);
            }
        }
        {
            const uint32_t address = r5 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164418U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016441CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164420U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 1004U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00164424U, address);
            }
        }
        {
            const uint32_t address = r0 + 1016U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00164428U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r4 + 0x7DDU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x00164430U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7DEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00164434U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7DFU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x00164438U, address);
            }
        }
        {
            const uint32_t address = r7 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0016443CU, address);
            }
        }
        {
            const uint32_t address = r0 + 1020U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00164440U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0016444CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0016444CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0016444C;
    }
block_0016444C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016444CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016444CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0016444CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = 0x00164458U + 0x154U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164450U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r1 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0016445CU, address);
            }
        }
        {
            r0 = r0 & 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x7E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00164464U, address);
            }
        }
        {
            const uint32_t address = r7 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00164468U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0016446CU, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 2U);
            r7 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000890U;
            r2 = r7 + operand;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0016447CU, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00164484U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00164484U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00164484;
    }
block_00164484:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164484U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164484U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x890U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164484U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00164490U + 0x120U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164488U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016448CU, address);
            }
            r9 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x7DCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164490U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164494U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164498U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001644A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001644A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001644A0;
    }
block_001644A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001644A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001644A0U);
        }
        {
            r1 = r0;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001644ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001644ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001644AC;
    }
block_001644AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001644ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001644ACU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x890U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001644ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001644B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001644BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x890U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001644C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001644C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001644C8U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_001643AC; }
        goto block_001644D0;
    }
block_001644D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001644D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001644D0U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001644D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001644D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001644D4;
    }
block_001644D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001644D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001644D4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001644D4U, 0xEE600A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            r1 = 0x000000E1U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001644DCU, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001644E4U, 0xEE600A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x7D6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001644ECU, address);
            }
        }
        {
            r1 = 0x0000009BU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001644F4U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            const uint32_t address = 0x00164504U + 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001644FCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164500U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x7D7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00164508U, address);
            }
        }
        {
            r1 = 0x0000005FU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00164510U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x7D8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0016451CU, address);
            }
        }
        {
            r0 = 0x000000C8U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x7D9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00164524U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00164530U + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164528U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x26U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016452CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000040U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164534U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x00164540U + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164538U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0xD0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0016453CU, address);
            }
        }
        if (!(flags.Z())) { goto block_00164550; }
        goto block_00164544;
    }
block_00164544:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164544U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164544U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164544U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00164550U + 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164548U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xD0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0016454CU, address);
            }
        }
        goto block_00164550;
    }
block_00164550:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00164550U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00164550U);
        }
        {
            const uint32_t updatedAddress = 0x00164558U + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00164550U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x650U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00164554U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0016455CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0016455CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0016455CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0016455CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0016455CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0016455CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            r13 += 24U;
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00164564U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00164564U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00164564U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00164564U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00164564U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00164564U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00164564U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00164564U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00164564U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_DemoGj_Init_001AA9C8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001AA9C8U:
        goto block_001AA9C8;
    case 0x001AA9E8U:
        goto block_001AA9E8;
    case 0x001AAA38U:
        goto block_001AAA38;
    case 0x001AAA48U:
        goto block_001AAA48;
    case 0x001AAA60U:
        goto block_001AAA60;
    case 0x001AAA78U:
        goto block_001AAA78;
    case 0x001AAA7CU:
        goto block_001AAA7C;
    case 0x001AAA8CU:
        goto block_001AAA8C;
    case 0x001AAAA4U:
        goto block_001AAAA4;
    case 0x001AAAC0U:
        goto block_001AAAC0;
    case 0x001AAAC4U:
        goto block_001AAAC4;
    case 0x001AAAD4U:
        goto block_001AAAD4;
    case 0x001AAAECU:
        goto block_001AAAEC;
    case 0x001AAB08U:
        goto block_001AAB08;
    case 0x001AAB0CU:
        goto block_001AAB0C;
    case 0x001AAB1CU:
        goto block_001AAB1C;
    case 0x001AAB34U:
        goto block_001AAB34;
    case 0x001AAB50U:
        goto block_001AAB50;
    case 0x001AAB54U:
        goto block_001AAB54;
    case 0x001AAB64U:
        goto block_001AAB64;
    case 0x001AAB7CU:
        goto block_001AAB7C;
    case 0x001AAB98U:
        goto block_001AAB98;
    case 0x001AAB9CU:
        goto block_001AAB9C;
    case 0x001AABACU:
        goto block_001AABAC;
    case 0x001AABC4U:
        goto block_001AABC4;
    case 0x001AABE0U:
        goto block_001AABE0;
    case 0x001AABE4U:
        goto block_001AABE4;
    case 0x001AABF4U:
        goto block_001AABF4;
    case 0x001AAC0CU:
        goto block_001AAC0C;
    case 0x001AAC28U:
        goto block_001AAC28;
    case 0x001AAC2CU:
        goto block_001AAC2C;
    case 0x001AAC48U:
        goto block_001AAC48;
    case 0x001AAC58U:
        goto block_001AAC58;
    case 0x001AAC6CU:
        goto block_001AAC6C;
    case 0x001AAC7CU:
        goto block_001AAC7C;
    case 0x001AAC90U:
        goto block_001AAC90;
    case 0x001AACA0U:
        goto block_001AACA0;
    case 0x001AACB4U:
        goto block_001AACB4;
    case 0x001AACD0U:
        goto block_001AACD0;
    case 0x001AACD4U:
        goto block_001AACD4;
    case 0x001AACF0U:
        goto block_001AACF0;
    case 0x001AAD00U:
        goto block_001AAD00;
    case 0x001AAD14U:
        goto block_001AAD14;
    case 0x001AAD24U:
        goto block_001AAD24;
    case 0x001AAD38U:
        goto block_001AAD38;
    case 0x001AAD48U:
        goto block_001AAD48;
    case 0x001AAD5CU:
        goto block_001AAD5C;
    case 0x001AAD78U:
        goto block_001AAD78;
    case 0x001AAD7CU:
        goto block_001AAD7C;
    case 0x001AAD98U:
        goto block_001AAD98;
    case 0x001AADA8U:
        goto block_001AADA8;
    case 0x001AADBCU:
        goto block_001AADBC;
    case 0x001AADD8U:
        goto block_001AADD8;
    case 0x001AADDCU:
        goto block_001AADDC;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001AA9C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AA9C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AA9C8U);
        }
        {
            const uint32_t firstAddress = r13 - 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001AA9C8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001AA9C8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001AA9C8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001AA9C8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001AA9C8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001AA9C8U,
                                           firstAddress + 20U);
            }
            r13 = r13 - 24U;
        }
        {
            r4 = r0;
        }
        {
            r6 = r1;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AA9D4U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x001AA9ECU + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AA9E4U, address);
            }
            switch (value) {
            case 0x001AA9C8U:
                goto block_001AA9C8;
            case 0x001AA9E8U:
                goto block_001AA9E8;
            case 0x001AAA38U:
                goto block_001AAA38;
            case 0x001AAA48U:
                goto block_001AAA48;
            case 0x001AAA60U:
                goto block_001AAA60;
            case 0x001AAA78U:
                goto block_001AAA78;
            case 0x001AAA7CU:
                goto block_001AAA7C;
            case 0x001AAA8CU:
                goto block_001AAA8C;
            case 0x001AAAA4U:
                goto block_001AAAA4;
            case 0x001AAAC0U:
                goto block_001AAAC0;
            case 0x001AAAC4U:
                goto block_001AAAC4;
            case 0x001AAAD4U:
                goto block_001AAAD4;
            case 0x001AAAECU:
                goto block_001AAAEC;
            case 0x001AAB08U:
                goto block_001AAB08;
            case 0x001AAB0CU:
                goto block_001AAB0C;
            case 0x001AAB1CU:
                goto block_001AAB1C;
            case 0x001AAB34U:
                goto block_001AAB34;
            case 0x001AAB50U:
                goto block_001AAB50;
            case 0x001AAB54U:
                goto block_001AAB54;
            case 0x001AAB64U:
                goto block_001AAB64;
            case 0x001AAB7CU:
                goto block_001AAB7C;
            case 0x001AAB98U:
                goto block_001AAB98;
            case 0x001AAB9CU:
                goto block_001AAB9C;
            case 0x001AABACU:
                goto block_001AABAC;
            case 0x001AABC4U:
                goto block_001AABC4;
            case 0x001AABE0U:
                goto block_001AABE0;
            case 0x001AABE4U:
                goto block_001AABE4;
            case 0x001AABF4U:
                goto block_001AABF4;
            case 0x001AAC0CU:
                goto block_001AAC0C;
            case 0x001AAC28U:
                goto block_001AAC28;
            case 0x001AAC2CU:
                goto block_001AAC2C;
            case 0x001AAC48U:
                goto block_001AAC48;
            case 0x001AAC58U:
                goto block_001AAC58;
            case 0x001AAC6CU:
                goto block_001AAC6C;
            case 0x001AAC7CU:
                goto block_001AAC7C;
            case 0x001AAC90U:
                goto block_001AAC90;
            case 0x001AACA0U:
                goto block_001AACA0;
            case 0x001AACB4U:
                goto block_001AACB4;
            case 0x001AACD0U:
                goto block_001AACD0;
            case 0x001AACD4U:
                goto block_001AACD4;
            case 0x001AACF0U:
                goto block_001AACF0;
            case 0x001AAD00U:
                goto block_001AAD00;
            case 0x001AAD14U:
                goto block_001AAD14;
            case 0x001AAD24U:
                goto block_001AAD24;
            case 0x001AAD38U:
                goto block_001AAD38;
            case 0x001AAD48U:
                goto block_001AAD48;
            case 0x001AAD5CU:
                goto block_001AAD5C;
            case 0x001AAD78U:
                goto block_001AAD78;
            case 0x001AAD7CU:
                goto block_001AAD7C;
            case 0x001AAD98U:
                goto block_001AAD98;
            case 0x001AADA8U:
                goto block_001AADA8;
            case 0x001AADBCU:
                goto block_001AADBC;
            case 0x001AADD8U:
                goto block_001AADD8;
            case 0x001AADDCU:
                goto block_001AADDC;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_001AA9E8;
    }
block_001AA9E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AA9E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AA9E8U);
        }
        goto block_001AADDC;
    }
block_001AAA38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAA38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAA38U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAA48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAA48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAA48;
    }
block_001AAA48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAA48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAA48U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001AAA48U, address);
            }
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAA60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DemoGj_InitSetIndexes_00343194(frame, context, state, 0x00343194U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAA60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAA60;
    }
block_001AAA60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAA60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAA60U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000002F4U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AAA70U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAA78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAA78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAA78;
    }
block_001AAA78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAA78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAA78U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001AAA78U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AAA78U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AAA78U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AAA78U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001AAA78U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AAA78U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AAA7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAA7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAA7CU);
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAA8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAA8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAA8C;
    }
block_001AAA8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAA8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAA8CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001AAA8CU, address);
            }
        }
        {
            r3 = 0x00000002U;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAAA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DemoGj_InitSetIndexes_00343194(frame, context, state, 0x00343194U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAAA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAAA4;
    }
block_001AAAA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAAA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAAA4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AAAA8U, address);
            }
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000002F8U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAAC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAAC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAAC0;
    }
block_001AAAC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAAC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAAC0U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001AAAC0U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AAAC0U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AAAC0U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AAAC0U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001AAAC0U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AAAC0U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AAAC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAAC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAAC4U);
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAAD4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAAD4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAAD4;
    }
block_001AAAD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAAD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAAD4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001AAAD4U, address);
            }
        }
        {
            r3 = 0x00000003U;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAAECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DemoGj_InitSetIndexes_00343194(frame, context, state, 0x00343194U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAAECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAAEC;
    }
block_001AAAEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAAECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAAECU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AAAF0U, address);
            }
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x000002FCU;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAB08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAB08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAB08;
    }
block_001AAB08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAB08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAB08U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001AAB08U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AAB08U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AAB08U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AAB08U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001AAB08U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AAB08U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AAB0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAB0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAB0CU);
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAB1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAB1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAB1C;
    }
block_001AAB1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAB1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAB1CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001AAB1CU, address);
            }
        }
        {
            r3 = 0x00000004U;
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAB34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DemoGj_InitSetIndexes_00343194(frame, context, state, 0x00343194U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAB34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAB34;
    }
block_001AAB34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAB34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAB34U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AAB38U, address);
            }
        }
        {
            r3 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x00000300U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAB50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAB50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAB50;
    }
block_001AAB50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAB50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAB50U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001AAB50U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AAB50U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AAB50U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AAB50U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001AAB50U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AAB50U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AAB54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAB54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAB54U);
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAB64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAB64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAB64;
    }
block_001AAB64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAB64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAB64U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001AAB64U, address);
            }
        }
        {
            r3 = 0x00000005U;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAB7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DemoGj_InitSetIndexes_00343194(frame, context, state, 0x00343194U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAB7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAB7C;
    }
block_001AAB7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAB7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAB7CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AAB80U, address);
            }
        }
        {
            r3 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x00000304U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAB98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAB98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAB98;
    }
block_001AAB98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAB98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAB98U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001AAB98U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AAB98U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AAB98U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AAB98U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001AAB98U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AAB98U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AAB9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAB9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAB9CU);
        }
        {
            r2 = 0x00000005U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AABACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AABACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AABAC;
    }
block_001AABAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AABACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AABACU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001AABACU, address);
            }
        }
        {
            r3 = 0x00000006U;
        }
        {
            r2 = 0x00000005U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AABC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DemoGj_InitSetIndexes_00343194(frame, context, state, 0x00343194U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AABC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AABC4;
    }
block_001AABC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AABC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AABC4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AABC8U, address);
            }
        }
        {
            r3 = 0x00000005U;
        }
        {
            const uint32_t operand = 0x00000308U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AABE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AABE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AABE0;
    }
block_001AABE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AABE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AABE0U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001AABE0U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AABE0U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AABE0U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AABE0U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001AABE0U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AABE0U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AABE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AABE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AABE4U);
        }
        {
            r2 = 0x00000006U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AABF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AABF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AABF4;
    }
block_001AABF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AABF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AABF4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001AABF4U, address);
            }
        }
        {
            r3 = 0x00000007U;
        }
        {
            r2 = 0x00000006U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAC0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DemoGj_InitSetIndexes_00343194(frame, context, state, 0x00343194U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAC0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAC0C;
    }
block_001AAC0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAC0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAC0CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AAC10U, address);
            }
        }
        {
            r3 = 0x00000006U;
        }
        {
            const uint32_t operand = 0x0000030CU;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAC28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAC28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAC28;
    }
block_001AAC28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAC28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAC28U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001AAC28U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AAC28U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AAC28U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AAC28U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001AAC28U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AAC28U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AAC2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAC2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAC2CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r5 = r4;
        }
        {
            r2 = 0x0000000FU;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AAC40U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAC48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DemoGj_InitSetIndexes_00343194(frame, context, state, 0x00343194U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAC48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAC48;
    }
block_001AAC48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAC48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAC48U);
        }
        {
            const uint32_t operand = 0x000001DCU;
            r7 = r5 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAC58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitCylinder_00353DD0(frame, context, state, 0x00353DD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAC58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAC58;
    }
block_001AAC58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAC58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAC58U);
        }
        {
            const uint32_t updatedAddress = 0x001AAC60U + 0x188U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AAC58U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r1 = r7;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAC6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetCylinderType1_0034FB3C(frame, context, state, 0x0034FB3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAC6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAC6C;
    }
block_001AAC6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAC6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAC6CU);
        }
        {
            const uint32_t operand = 0x00000234U;
            r7 = r5 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAC7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitCylinder_00353DD0(frame, context, state, 0x00353DD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAC7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAC7C;
    }
block_001AAC7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAC7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAC7CU);
        }
        {
            const uint32_t updatedAddress = 0x001AAC84U + 0x164U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AAC7CU, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r1 = r7;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAC90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetCylinderType1_0034FB3C(frame, context, state, 0x0034FB3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAC90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAC90;
    }
block_001AAC90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAC90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAC90U);
        }
        {
            const uint32_t operand = 0x0000028CU;
            r5 = r5 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AACA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitCylinder_00353DD0(frame, context, state, 0x00353DD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AACA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AACA0;
    }
block_001AACA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AACA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AACA0U);
        }
        {
            const uint32_t updatedAddress = 0x001AACA8U + 0x140U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AACA0U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r1 = r5;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AACB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetCylinderType1_0034FB3C(frame, context, state, 0x0034FB3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AACB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AACB4;
    }
block_001AACB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AACB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AACB4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AACB8U, address);
            }
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000002F8U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AACD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AACD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AACD0;
    }
block_001AACD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AACD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AACD0U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001AACD0U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AACD0U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AACD0U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AACD0U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001AACD0U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AACD0U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AACD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AACD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AACD4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r5 = r4;
        }
        {
            r2 = 0x00000010U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AACE8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AACF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DemoGj_InitSetIndexes_00343194(frame, context, state, 0x00343194U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AACF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AACF0;
    }
block_001AACF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AACF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AACF0U);
        }
        {
            const uint32_t operand = 0x000001DCU;
            r7 = r5 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAD00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitCylinder_00353DD0(frame, context, state, 0x00353DD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAD00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAD00;
    }
block_001AAD00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAD00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAD00U);
        }
        {
            const uint32_t updatedAddress = 0x001AAD08U + 0xE4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AAD00U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r1 = r7;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAD14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetCylinderType1_0034FB3C(frame, context, state, 0x0034FB3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAD14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAD14;
    }
block_001AAD14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAD14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAD14U);
        }
        {
            const uint32_t operand = 0x00000234U;
            r7 = r5 + operand;
        }
        {
            r1 = r7;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAD24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitCylinder_00353DD0(frame, context, state, 0x00353DD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAD24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAD24;
    }
block_001AAD24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAD24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAD24U);
        }
        {
            const uint32_t updatedAddress = 0x001AAD2CU + 0xC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AAD24U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r1 = r7;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAD38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetCylinderType1_0034FB3C(frame, context, state, 0x0034FB3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAD38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAD38;
    }
block_001AAD38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAD38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAD38U);
        }
        {
            const uint32_t operand = 0x0000028CU;
            r5 = r5 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAD48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitCylinder_00353DD0(frame, context, state, 0x00353DD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAD48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAD48;
    }
block_001AAD48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAD48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAD48U);
        }
        {
            const uint32_t updatedAddress = 0x001AAD50U + 0x9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AAD48U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r1 = r5;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAD5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetCylinderType1_0034FB3C(frame, context, state, 0x0034FB3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAD5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAD5C;
    }
block_001AAD5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAD5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAD5CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AAD60U, address);
            }
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x000002FCU;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAD78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAD78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAD78;
    }
block_001AAD78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAD78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAD78U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001AAD78U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AAD78U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AAD78U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AAD78U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001AAD78U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AAD78U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AAD7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAD7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAD7CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r5 = r4;
        }
        {
            r2 = 0x00000011U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AAD90U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AAD98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DemoGj_InitSetIndexes_00343194(frame, context, state, 0x00343194U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AAD98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AAD98;
    }
block_001AAD98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAD98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAD98U);
        }
        {
            const uint32_t operand = 0x000001DCU;
            r5 = r5 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AADA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_InitCylinder_00353DD0(frame, context, state, 0x00353DD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AADA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AADA8;
    }
block_001AADA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AADA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AADA8U);
        }
        {
            const uint32_t updatedAddress = 0x001AADB0U + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AADA8U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            r1 = r5;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AADBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Collider_SetCylinderType1_0034FB3C(frame, context, state, 0x0034FB3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AADBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AADBC;
    }
block_001AADBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AADBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AADBCU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AADC0U, address);
            }
        }
        {
            r3 = 0x00000007U;
        }
        {
            const uint32_t operand = 0x00000310U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AADD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AADD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AADD8;
    }
block_001AADD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AADD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AADD8U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001AADD8U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AADD8U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AADD8U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AADD8U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001AADD8U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AADD8U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AADDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AADDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AADDCU);
        }
        {
            r0 = r4;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001AADE0U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AADE0U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AADE0U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AADE0U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001AADE0U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001AADE0U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r14 = value14;
            r13 = r13 + 24U;
        }
        return Oot3dAotBranch(0x00374428U);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_DemoGt_Init_001AAFE4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001AAFE4U:
        goto block_001AAFE4;
    case 0x001AB004U:
        goto block_001AB004;
    case 0x001AB00CU:
        goto block_001AB00C;
    case 0x001AB018U:
        goto block_001AB018;
    case 0x001AB020U:
        goto block_001AB020;
    case 0x001AB028U:
        goto block_001AB028;
    case 0x001AB030U:
        goto block_001AB030;
    case 0x001AB070U:
        goto block_001AB070;
    case 0x001AB08CU:
        goto block_001AB08C;
    case 0x001AB094U:
        goto block_001AB094;
    case 0x001AB09CU:
        goto block_001AB09C;
    case 0x001AB0A4U:
        goto block_001AB0A4;
    case 0x001AB0ACU:
        goto block_001AB0AC;
    case 0x001AB0ECU:
        goto block_001AB0EC;
    case 0x001AB108U:
        goto block_001AB108;
    case 0x001AB110U:
        goto block_001AB110;
    case 0x001AB150U:
        goto block_001AB150;
    case 0x001AB178U:
        goto block_001AB178;
    case 0x001AB184U:
        goto block_001AB184;
    case 0x001AB198U:
        goto block_001AB198;
    case 0x001AB1B0U:
        goto block_001AB1B0;
    case 0x001AB1E4U:
        goto block_001AB1E4;
    case 0x001AB200U:
        goto block_001AB200;
    case 0x001AB204U:
        goto block_001AB204;
    case 0x001AB210U:
        goto block_001AB210;
    case 0x001AB228U:
        goto block_001AB228;
    case 0x001AB244U:
        goto block_001AB244;
    case 0x001AB250U:
        goto block_001AB250;
    case 0x001AB264U:
        goto block_001AB264;
    case 0x001AB278U:
        goto block_001AB278;
    case 0x001AB2ACU:
        goto block_001AB2AC;
    case 0x001AB2C8U:
        goto block_001AB2C8;
    case 0x001AB2CCU:
        goto block_001AB2CC;
    case 0x001AB2D8U:
        goto block_001AB2D8;
    case 0x001AB2F0U:
        goto block_001AB2F0;
    case 0x001AB30CU:
        goto block_001AB30C;
    case 0x001AB318U:
        goto block_001AB318;
    case 0x001AB32CU:
        goto block_001AB32C;
    case 0x001AB34CU:
        goto block_001AB34C;
    case 0x001AB38CU:
        goto block_001AB38C;
    case 0x001AB3A8U:
        goto block_001AB3A8;
    case 0x001AB3B0U:
        goto block_001AB3B0;
    case 0x001AB3F0U:
        goto block_001AB3F0;
    case 0x001AB40CU:
        goto block_001AB40C;
    case 0x001AB414U:
        goto block_001AB414;
    case 0x001AB454U:
        goto block_001AB454;
    case 0x001AB470U:
        goto block_001AB470;
    case 0x001AB478U:
        goto block_001AB478;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001AAFE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AAFE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AAFE4U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001AAFE4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001AAFE4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001AAFE4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001AAFE4U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AAFECU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001AAFF8U + 840U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AAFF0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r13 = r13 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r5 = r1;
        }
        if (flags.Z()) { goto block_001AB34C; }
        goto block_001AB004;
    }
block_001AB004:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB004U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB004U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001AB094; }
        goto block_001AB00C;
    }
block_001AB00C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB00CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB00CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r6 = 0x00000000U;
        }
        if (flags.Z()) { goto block_001AB110; }
        goto block_001AB018;
    }
block_001AB018:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB018U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB018U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001AB1B0; }
        goto block_001AB020;
    }
block_001AB020:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB020U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB020U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001AB278; }
        goto block_001AB028;
    }
block_001AB028:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB028U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB028U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001AB478; }
        goto block_001AB030;
    }
block_001AB030:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB030U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB030U);
        }
        {
            const uint32_t address = r4 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB030U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000003U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB03CU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t address = r4 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001AB048U, address);
            }
        }
        {
            const uint32_t address = r4 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB04CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB050U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001AB054U, address);
            }
        }
        {
            const uint32_t address = r4 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB058U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB05CU, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001AB060U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AB064U, address);
            }
        }
        {
            r3 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB070U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003430fc_003430FC(frame, context, state, 0x003430FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB070U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB070;
    }
block_001AB070:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB070U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB070U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AB074U, address);
            }
        }
        {
            r3 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x00000210U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB08CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB08CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB08C;
    }
block_001AB08C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB08CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB08CU);
        }
        {
            const uint32_t operand = 0x00000010U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AB090U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AB090U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AB090U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AB090U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AB094:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB094U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB094U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001AB3B0; }
        goto block_001AB09C;
    }
block_001AB09C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB09CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB09CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000017U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001AB414; }
        goto block_001AB0A4;
    }
block_001AB0A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB0A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB0A4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000018U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001AB478; }
        goto block_001AB0AC;
    }
block_001AB0AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB0ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB0ACU);
        }
        {
            const uint32_t address = r4 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB0ACU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000007U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB0B8U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t address = r4 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001AB0C4U, address);
            }
        }
        {
            const uint32_t address = r4 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB0C8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB0CCU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001AB0D0U, address);
            }
        }
        {
            const uint32_t address = r4 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB0D4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB0D8U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001AB0DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AB0E0U, address);
            }
        }
        {
            r3 = 0x00000008U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB0ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003430fc_003430FC(frame, context, state, 0x003430FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB0ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB0EC;
    }
block_001AB0EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB0ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB0ECU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AB0F0U, address);
            }
        }
        {
            r3 = 0x00000006U;
        }
        {
            const uint32_t operand = 0x00000218U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB108U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB108U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB108;
    }
block_001AB108:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB108U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB108U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AB10CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AB10CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AB10CU,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AB10CU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AB110:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB110U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB110U);
        }
        {
            const uint32_t address = r4 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB110U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB11CU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t address = r4 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001AB128U, address);
            }
        }
        {
            const uint32_t address = r4 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB12CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB130U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001AB134U, address);
            }
        }
        {
            const uint32_t address = r4 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB138U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB13CU, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001AB140U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AB144U, address);
            }
        }
        {
            r3 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB150U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003430fc_003430FC(frame, context, state, 0x003430FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB150U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB150;
    }
block_001AB150:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB150U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB150U);
        }
        {
            const uint32_t updatedAddress = 0x001AB158U + 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB150U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000204U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001AB160U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001AB164U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001AB164U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001AB164U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000200U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB178U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB178U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB178;
    }
block_001AB178:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB178U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB178U);
        }
        {
            r1 = 0x00000000U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB184U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB184U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB184;
    }
block_001AB184:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB184U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB184U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x204U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB184U, address);
            }
            r2 = value;
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r2 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB18CU, address);
            }
            r2 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB198U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB198U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB198;
    }
block_001AB198:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB198U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB198U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x204U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB198U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB1A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001AB1A4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000010U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AB1ACU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AB1ACU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AB1ACU,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AB1ACU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AB1B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB1B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB1B0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r4 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB1B4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB1B8U, 0xEE211A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001AB1BCU, address);
            }
        }
        {
            const uint32_t address = r4 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB1C0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB1C4U, 0xEE210A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001AB1C8U, address);
            }
        }
        {
            const uint32_t address = r4 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB1CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB1D0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001AB1D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB1D8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_001AB200; }
        goto block_001AB1E4;
    }
block_001AB1E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB1E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB1E4U);
        }
        {
            const uint32_t updatedAddress = 0x001AB1ECU + 0x15CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB1E4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 7U);
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB1ECU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00003800U;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x0000025CU;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) { goto block_001AB204; }
        goto block_001AB200;
    }
block_001AB200:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB200U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB200U);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_001AB204;
    }
block_001AB204:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB204U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB204U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r0 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB210U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_GetCollisionHeader_003532C0(frame, context, state, 0x003532C0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB210U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB210;
    }
block_001AB210:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB210U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB210U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001AB210U, address);
            }
        }
        {
            r3 = 0x00000002U;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB228U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003430fc_003430FC(frame, context, state, 0x003430FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB228U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB228;
    }
block_001AB228:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB228U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB228U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AB22CU, address);
            }
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x00000208U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB244U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB244U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB244;
    }
block_001AB244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB244U);
        }
        {
            r1 = 0x00000001U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB250U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB250U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB250;
    }
block_001AB250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB250U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x208U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB250U, address);
            }
            r2 = value;
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r2 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB258U, address);
            }
            r2 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB264U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB264U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB264;
    }
block_001AB264:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB264U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB264U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x208U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB264U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB268U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001AB26CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000010U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AB274U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AB274U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AB274U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AB274U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AB278:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB278U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB278U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r4 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB27CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB280U, 0xEE211A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001AB284U, address);
            }
        }
        {
            const uint32_t address = r4 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB288U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB28CU, 0xEE210A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001AB290U, address);
            }
        }
        {
            const uint32_t address = r4 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB294U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB298U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001AB29CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB2A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_001AB2C8; }
        goto block_001AB2AC;
    }
block_001AB2AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB2ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB2ACU);
        }
        {
            const uint32_t updatedAddress = 0x001AB2B4U + 0x94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB2ACU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 7U);
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB2B4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00003800U;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x0000025CU;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) { goto block_001AB2CC; }
        goto block_001AB2C8;
    }
block_001AB2C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB2C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB2C8U);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_001AB2CC;
    }
block_001AB2CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB2CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB2CCU);
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r0 + operand;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB2D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_GetCollisionHeader_003532C0(frame, context, state, 0x003532C0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB2D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB2D8;
    }
block_001AB2D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB2D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB2D8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001AB2D8U, address);
            }
        }
        {
            r3 = 0x00000003U;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB2F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003430fc_003430FC(frame, context, state, 0x003430FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB2F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB2F0;
    }
block_001AB2F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB2F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB2F0U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AB2F4U, address);
            }
        }
        {
            r3 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x0000020CU;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB30CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB30CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB30C;
    }
block_001AB30C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB30CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB30CU);
        }
        {
            r1 = 0x00000002U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB318U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB318U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB318;
    }
block_001AB318:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB318U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB318U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x20CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB318U, address);
            }
            r2 = value;
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r2 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB320U, address);
            }
            r2 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB32CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB32CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB32C;
    }
block_001AB32C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB32CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB32CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x20CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB32CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB330U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001AB334U, address);
            }
        }
        {
            const uint32_t operand = 0x00000010U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AB33CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AB33CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AB33CU,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AB33CU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AB34C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB34CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB34CU);
        }
        {
            const uint32_t address = r4 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB34CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000004U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB358U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t address = r4 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001AB364U, address);
            }
        }
        {
            const uint32_t address = r4 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB368U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB36CU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001AB370U, address);
            }
        }
        {
            const uint32_t address = r4 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB374U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB378U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001AB37CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AB380U, address);
            }
        }
        {
            r3 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB38CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003430fc_003430FC(frame, context, state, 0x003430FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB38CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB38C;
    }
block_001AB38C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB38CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB38CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AB390U, address);
            }
        }
        {
            r3 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x00000210U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB3A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB3A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB3A8;
    }
block_001AB3A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB3A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB3A8U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AB3ACU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AB3ACU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AB3ACU,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AB3ACU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AB3B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB3B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB3B0U);
        }
        {
            const uint32_t address = r4 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB3B0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000005U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB3BCU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t address = r4 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001AB3C8U, address);
            }
        }
        {
            const uint32_t address = r4 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB3CCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB3D0U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001AB3D4U, address);
            }
        }
        {
            const uint32_t address = r4 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB3D8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB3DCU, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001AB3E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AB3E4U, address);
            }
        }
        {
            r3 = 0x00000006U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB3F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003430fc_003430FC(frame, context, state, 0x003430FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB3F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB3F0;
    }
block_001AB3F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB3F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB3F0U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AB3F4U, address);
            }
        }
        {
            r3 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x00000210U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB40CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB40CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB40C;
    }
block_001AB40C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB40CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB40CU);
        }
        {
            const uint32_t operand = 0x00000010U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AB410U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AB410U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AB410U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AB410U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AB414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB414U);
        }
        {
            const uint32_t address = r4 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB414U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000006U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB420U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t address = r4 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001AB42CU, address);
            }
        }
        {
            const uint32_t address = r4 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB430U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB434U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001AB438U, address);
            }
        }
        {
            const uint32_t address = r4 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001AB43CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001AB440U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001AB444U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AB448U, address);
            }
        }
        {
            r3 = 0x00000007U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB454U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003430fc_003430FC(frame, context, state, 0x003430FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB454U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB454;
    }
block_001AB454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB454U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001AB458U, address);
            }
        }
        {
            r3 = 0x00000005U;
        }
        {
            const uint32_t operand = 0x00000214U;
            r2 = r4 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001AB470U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001AB470U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001AB470;
    }
block_001AB470:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB470U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB470U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AB474U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AB474U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AB474U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001AB474U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_001AB478:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001AB478U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001AB478U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r13 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001AB480U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001AB480U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001AB480U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001AB480U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
            r13 = r13 + 16U;
        }
        return Oot3dAotBranch(0x00374428U);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Fishing_Init_001C0AD8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001C0AD8U:
        goto block_001C0AD8;
    case 0x001C0AF4U:
        goto block_001C0AF4;
    case 0x001C0B0CU:
        goto block_001C0B0C;
    case 0x001C0B30U:
        goto block_001C0B30;
    case 0x001C0DC4U:
        goto block_001C0DC4;
    case 0x001C0DCCU:
        goto block_001C0DCC;
    case 0x001C0DE0U:
        goto block_001C0DE0;
    case 0x001C0DE8U:
        goto block_001C0DE8;
    case 0x001C0DF4U:
        goto block_001C0DF4;
    case 0x001C0DFCU:
        goto block_001C0DFC;
    case 0x001C0E14U:
        goto block_001C0E14;
    case 0x001C0E4CU:
        goto block_001C0E4C;
    case 0x001C0E5CU:
        goto block_001C0E5C;
    case 0x001C0E74U:
        goto block_001C0E74;
    case 0x001C0EFCU:
        goto block_001C0EFC;
    case 0x001C0F24U:
        goto block_001C0F24;
    case 0x001C0F4CU:
        goto block_001C0F4C;
    case 0x001C0F58U:
        goto block_001C0F58;
    case 0x001C0F6CU:
        goto block_001C0F6C;
    case 0x001C0F7CU:
        goto block_001C0F7C;
    case 0x001C0FA0U:
        goto block_001C0FA0;
    case 0x001C0FB0U:
        goto block_001C0FB0;
    case 0x001C0FB4U:
        goto block_001C0FB4;
    case 0x001C0FD8U:
        goto block_001C0FD8;
    case 0x001C0FE4U:
        goto block_001C0FE4;
    case 0x001C0FF8U:
        goto block_001C0FF8;
    case 0x001C0FFCU:
        goto block_001C0FFC;
    case 0x001C1020U:
        goto block_001C1020;
    case 0x001C102CU:
        goto block_001C102C;
    case 0x001C1040U:
        goto block_001C1040;
    case 0x001C104CU:
        goto block_001C104C;
    case 0x001C105CU:
        goto block_001C105C;
    case 0x001C1080U:
        goto block_001C1080;
    case 0x001C1090U:
        goto block_001C1090;
    case 0x001C10ACU:
        goto block_001C10AC;
    case 0x001C10C0U:
        goto block_001C10C0;
    case 0x001C10D0U:
        goto block_001C10D0;
    case 0x001C10DCU:
        goto block_001C10DC;
    case 0x001C10E4U:
        goto block_001C10E4;
    case 0x001C10FCU:
        goto block_001C10FC;
    case 0x001C110CU:
        goto block_001C110C;
    case 0x001C1134U:
        goto block_001C1134;
    case 0x001C1144U:
        goto block_001C1144;
    case 0x001C11A0U:
        goto block_001C11A0;
    case 0x001C11A8U:
        goto block_001C11A8;
    case 0x001C11B4U:
        goto block_001C11B4;
    case 0x001C11D4U:
        goto block_001C11D4;
    case 0x001C11E4U:
        goto block_001C11E4;
    case 0x001C11F4U:
        goto block_001C11F4;
    case 0x001C122CU:
        goto block_001C122C;
    case 0x001C1234U:
        goto block_001C1234;
    case 0x001C1240U:
        goto block_001C1240;
    case 0x001C1260U:
        goto block_001C1260;
    case 0x001C128CU:
        goto block_001C128C;
    case 0x001C12A0U:
        goto block_001C12A0;
    case 0x001C12B0U:
        goto block_001C12B0;
    case 0x001C12C0U:
        goto block_001C12C0;
    case 0x001C12D0U:
        goto block_001C12D0;
    case 0x001C1334U:
        goto block_001C1334;
    case 0x001C1340U:
        goto block_001C1340;
    case 0x001C135CU:
        goto block_001C135C;
    case 0x001C1380U:
        goto block_001C1380;
    case 0x001C1390U:
        goto block_001C1390;
    case 0x001C139CU:
        goto block_001C139C;
    case 0x001C13A8U:
        goto block_001C13A8;
    case 0x001C13C4U:
        goto block_001C13C4;
    case 0x001C13ECU:
        goto block_001C13EC;
    case 0x001C1434U:
        goto block_001C1434;
    case 0x001C1444U:
        goto block_001C1444;
    case 0x001C1468U:
        goto block_001C1468;
    case 0x001C1474U:
        goto block_001C1474;
    case 0x001C1494U:
        goto block_001C1494;
    case 0x001C14B8U:
        goto block_001C14B8;
    case 0x001C14C8U:
        goto block_001C14C8;
    case 0x001C14D8U:
        goto block_001C14D8;
    case 0x001C1528U:
        goto block_001C1528;
    case 0x001C1560U:
        goto block_001C1560;
    case 0x001C156CU:
        goto block_001C156C;
    case 0x001C158CU:
        goto block_001C158C;
    case 0x001C1598U:
        goto block_001C1598;
    case 0x001C15BCU:
        goto block_001C15BC;
    case 0x001C15CCU:
        goto block_001C15CC;
    case 0x001C15D4U:
        goto block_001C15D4;
    case 0x001C15E0U:
        goto block_001C15E0;
    case 0x001C15E8U:
        goto block_001C15E8;
    case 0x001C1600U:
        goto block_001C1600;
    case 0x001C1618U:
        goto block_001C1618;
    case 0x001C1624U:
        goto block_001C1624;
    case 0x001C1630U:
        goto block_001C1630;
    case 0x001C163CU:
        goto block_001C163C;
    case 0x001C1648U:
        goto block_001C1648;
    case 0x001C1668U:
        goto block_001C1668;
    case 0x001C168CU:
        goto block_001C168C;
    case 0x001C1698U:
        goto block_001C1698;
    case 0x001C16B0U:
        goto block_001C16B0;
    case 0x001C16B4U:
        goto block_001C16B4;
    case 0x001C16D4U:
        goto block_001C16D4;
    case 0x001C16E4U:
        goto block_001C16E4;
    case 0x001C1710U:
        goto block_001C1710;
    case 0x001C1720U:
        goto block_001C1720;
    case 0x001C1724U:
        goto block_001C1724;
    case 0x001C1748U:
        goto block_001C1748;
    case 0x001C1758U:
        goto block_001C1758;
    case 0x001C1794U:
        goto block_001C1794;
    case 0x001C17D4U:
        goto block_001C17D4;
    case 0x001C17ECU:
        goto block_001C17EC;
    case 0x001C1820U:
        goto block_001C1820;
    case 0x001C1834U:
        goto block_001C1834;
    case 0x001C1848U:
        goto block_001C1848;
    case 0x001C1878U:
        goto block_001C1878;
    case 0x001C1888U:
        goto block_001C1888;
    case 0x001C18A8U:
        goto block_001C18A8;
    case 0x001C18B4U:
        goto block_001C18B4;
    case 0x001C18C8U:
        goto block_001C18C8;
    case 0x001C18D8U:
        goto block_001C18D8;
    case 0x001C18E4U:
        goto block_001C18E4;
    case 0x001C18F4U:
        goto block_001C18F4;
    case 0x001C191CU:
        goto block_001C191C;
    case 0x001C1930U:
        goto block_001C1930;
    case 0x001C1938U:
        goto block_001C1938;
    case 0x001C194CU:
        goto block_001C194C;
    case 0x001C195CU:
        goto block_001C195C;
    case 0x001C1964U:
        goto block_001C1964;
    case 0x001C196CU:
        goto block_001C196C;
    case 0x001C1980U:
        goto block_001C1980;
    case 0x001C1990U:
        goto block_001C1990;
    case 0x001C1998U:
        goto block_001C1998;
    case 0x001C19ACU:
        goto block_001C19AC;
    case 0x001C19B8U:
        goto block_001C19B8;
    case 0x001C19CCU:
        goto block_001C19CC;
    case 0x001C19F0U:
        goto block_001C19F0;
    case 0x001C1A0CU:
        goto block_001C1A0C;
    case 0x001C1A1CU:
        goto block_001C1A1C;
    case 0x001C1A60U:
        goto block_001C1A60;
    case 0x001C1A70U:
        goto block_001C1A70;
    case 0x001C1AB8U:
        goto block_001C1AB8;
    case 0x001C1AE0U:
        goto block_001C1AE0;
    case 0x001C1B8CU:
        goto block_001C1B8C;
    case 0x001C1C30U:
        goto block_001C1C30;
    case 0x001C1C40U:
        goto block_001C1C40;
    case 0x001C1C58U:
        goto block_001C1C58;
    case 0x001C1C68U:
        goto block_001C1C68;
    case 0x001C1C78U:
        goto block_001C1C78;
    case 0x001C1C80U:
        goto block_001C1C80;
    case 0x001C1C88U:
        goto block_001C1C88;
    case 0x001C1C90U:
        goto block_001C1C90;
    case 0x001C1D38U:
        goto block_001C1D38;
    case 0x001C1D48U:
        goto block_001C1D48;
    case 0x001C1D64U:
        goto block_001C1D64;
    case 0x001C1D74U:
        goto block_001C1D74;
    case 0x001C1D7CU:
        goto block_001C1D7C;
    case 0x001C1D90U:
        goto block_001C1D90;
    case 0x001C1D94U:
        goto block_001C1D94;
    case 0x001C1DA8U:
        goto block_001C1DA8;
    case 0x001C1DE4U:
        goto block_001C1DE4;
    case 0x001C1E18U:
        goto block_001C1E18;
    case 0x001C1E2CU:
        goto block_001C1E2C;
    case 0x001C1E3CU:
        goto block_001C1E3C;
    case 0x001C1E48U:
        goto block_001C1E48;
    case 0x001C1E50U:
        goto block_001C1E50;
    case 0x001C1E58U:
        goto block_001C1E58;
    case 0x001C1EB4U:
        goto block_001C1EB4;
    case 0x001C1EC4U:
        goto block_001C1EC4;
    case 0x001C1ED0U:
        goto block_001C1ED0;
    case 0x001C1ED8U:
        goto block_001C1ED8;
    case 0x001C1EE0U:
        goto block_001C1EE0;
    case 0x001C1F08U:
        goto block_001C1F08;
    case 0x001C1F18U:
        goto block_001C1F18;
    case 0x001C1F24U:
        goto block_001C1F24;
    case 0x001C1F48U:
        goto block_001C1F48;
    case 0x001C1F58U:
        goto block_001C1F58;
    case 0x001C1F60U:
        goto block_001C1F60;
    case 0x001C1F70U:
        goto block_001C1F70;
    case 0x001C1F90U:
        goto block_001C1F90;
    case 0x001C1FB4U:
        goto block_001C1FB4;
    case 0x001C1FF4U:
        goto block_001C1FF4;
    case 0x001C2044U:
        goto block_001C2044;
    case 0x001C2060U:
        goto block_001C2060;
    case 0x001C2064U:
        goto block_001C2064;
    case 0x001C2074U:
        goto block_001C2074;
    case 0x001C207CU:
        goto block_001C207C;
    case 0x001C2088U:
        goto block_001C2088;
    case 0x001C2098U:
        goto block_001C2098;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001C0AD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0AD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0AD8U);
        }
        {
            const uint32_t firstAddress = r13 - 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001C0AD8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001C0AD8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001C0AD8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001C0AD8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001C0AD8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001C0AD8U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001C0AD8U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001C0AD8U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001C0AD8U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001C0AD8U,
                                           firstAddress + 36U);
            }
            r13 = r13 - 40U;
        }
        {
            r5 = r0;
        }
        {
            r10 = r1;
        }
        {
            const uint32_t updatedAddress = 0x001C0AECU + 0x3A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0AE4U, address);
            }
            r1 = value;
        }
        {
            r13 -= 48U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001C0AE8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C0AE8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001C0AE8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001C0AE8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x001C0AE8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x001C0AE8U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x001C0AE8U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x001C0AE8U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x001C0AE8U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x001C0AE8U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x001C0AE8U,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x001C0AE8U,
                                           firstAddress + 44U);
            }
        }
        {
            const uint32_t operand = 0x000004E0U;
            r13 = r13 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0AF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProcessInitChain_003510B0(frame, context, state, 0x003510B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0AF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0AF4;
    }
block_001C0AF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0AF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0AF4U);
        }
        {
            const uint32_t address = 0x001C0AFCU + 916U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0AF4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r5 + operand;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0B0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorShape_Init_00372D4C(frame, context, state, 0x00372D4CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0B0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0B0C;
    }
block_001C0B0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0B0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0B0CU);
        }
        {
            const uint32_t updatedAddress = 0x001C0B14U + 0x380U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0B0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001C0B18U + 0x380U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0B10U, address);
            }
            r1 = value;
        }
        {
            r4 = 0x0000000AU;
        }
        {
            r8 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0B1CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xDU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C0B20U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0B24U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000064U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001C1ED0; }
        goto block_001C0B30;
    }
block_001C0B30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0B30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0B30U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = 0x001C0B40U + 0x35CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0B38U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0B3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xC4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x001C0B40U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0B44U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0B48U, address);
            }
        }
        {
            const uint32_t address = r0 + 200U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0B4CU, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r0 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0B54U, address);
            }
        }
        {
            const uint32_t address = r0 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0B58U, address);
            }
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0B60U, address);
            }
        }
        {
            const uint32_t address = r0 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0B64U, address);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C0B6CU, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C0B70U, address);
            }
        }
        {
            r6 = 0x00000001U;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C0B7CU, address);
            }
        }
        {
            const uint32_t address = r0 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0B80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0B84U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0B88U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x11U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0B8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x12U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0B90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001C0B94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0B98U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x13U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0B9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BA4U, address);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0x3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BB0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BB4U, address);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BBCU, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BC4U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C0BC8U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C0BCCU, address);
            }
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C0BD4U, address);
            }
        }
        {
            const uint32_t operand = 0x0000012CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BDCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BE4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BE8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x15U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BF8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xCCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0BFCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0C00U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0C04U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0C08U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C0C14U + 0x28CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0C0CU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0C14U, address);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0C1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0C20U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0C24U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C0C28U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C0C2CU, address);
            }
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C0C30U, address);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C0C38U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C0C3CU, address);
            }
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C0C40U, address);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C0C48U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C0C4CU, address);
            }
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C0C50U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C0C64U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C0C68U, address);
            }
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C0C6CU, address);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C0C74U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C0C78U, address);
            }
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C0C7CU, address);
            }
        }
        {
            const uint32_t address = r0 + 208U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0C80U, address);
            }
        }
        {
            const uint32_t address = r0 + 212U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0C84U, address);
            }
        }
        {
            const uint32_t address = r0 + 216U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0C88U, address);
            }
        }
        {
            const uint32_t address = r0 + 220U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0C8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x17U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0C90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x3AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0C94U, address);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0C9CU, address);
            }
        }
        {
            const uint32_t address = r0 + 224U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0CA0U, address);
            }
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0x19U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0CA8U, address);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0CB0U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0CB8U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C0CBCU, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C0CC0U, address);
            }
        }
        {
            const uint32_t address = 0x001C0CCCU + 472U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0CC4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C0CC8U, address);
            }
        }
        {
            const uint32_t address = r0 + 228U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0CCCU, address);
            }
        }
        {
            const uint32_t address = r0 + 232U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0CD0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x3EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0CD4U, address);
            }
        }
        {
            const uint32_t address = r0 + 236U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0CD8U, address);
            }
        }
        {
            const uint32_t address = r0 + 240U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0CDCU, address);
            }
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[2];
        }
        {
            const uint32_t address = r0 + 244U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0CE4U, address);
            }
        }
        {
            const uint32_t address = r0 + 248U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0CE8U, address);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0CF0U, address);
            }
        }
        {
            const uint32_t address = r0 + 252U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0CF4U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C0CF8U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C0CFCU, address);
            }
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C0D04U, address);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r1 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C0D14U, address);
            }
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C0D1CU, address);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C0D24U, address);
            }
        }
        {
            const uint32_t operand = 0x0000013CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0D2CU, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0D30U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C0D34U, address);
            }
        }
        {
            const uint32_t address = r0 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0D38U, address);
            }
        }
        {
            const uint32_t address = r0 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0D3CU, address);
            }
        }
        {
            const uint32_t address = r0 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0D40U, address);
            }
        }
        {
            const uint32_t address = r0 + 104U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0D44U, address);
            }
        }
        {
            const uint32_t address = r0 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0D48U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C0D54U + 0x154U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0D4CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r0 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0D50U, address);
            }
        }
        {
            const uint32_t address = r0 + 116U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0D54U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r0 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0D5CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0D60U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C0D64U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C0D68U, address);
            }
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C0D6CU, address);
            }
        }
        {
            const uint32_t address = r0 + 260U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0D70U, address);
            }
        }
        {
            const uint32_t address = r0 + 264U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0D74U, address);
            }
        }
        {
            const uint32_t address = r0 + 268U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0D78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0D7CU, address);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0D84U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C0D88U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C0D8CU, address);
            }
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C0D90U, address);
            }
        }
        {
            const uint32_t address = r0 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C0D94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x42U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0D98U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0D9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C0DA8U + 0x13CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0DA0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001C0DA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C0DB0U + 0x138U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0DA8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x000000F8U;
            r2 = 0x001C0DB4U + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0DB0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0DB4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0DB8U, address);
            }
            r12 = value;
        }
        {
            r1 = 0x00000234U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x001C0DC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r12, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0DC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0DC4;
    }
block_001C0DC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0DC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0DC4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0DCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CmbRenderState_Construct_00347258(frame, context, state, 0x00347258U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0DCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0DCC;
    }
block_001C0DCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0DCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0DCCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x480U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C0DCCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C0DD8U + 0x114U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0DD0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0DD4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_001C0E14; }
        goto block_001C0DE0;
    }
block_001C0DE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0DE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0DE0U);
        }
        {
            const uint32_t updatedAddress = 0x001C0DE8U + 0x104U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0DE0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0DE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0DE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0DE8;
    }
block_001C0DE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0DE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0DE8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001C0E14; }
        goto block_001C0DF4;
    }
block_001C0DF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0DF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0DF4U);
        }
        {
            const uint32_t updatedAddress = 0x001C0DFCU + 0xF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0DF4U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0DFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0DFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0DFC;
    }
block_001C0DFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0DFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0DFCU);
        }
        {
            const uint32_t updatedAddress = 0x001C0E04U + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0DFCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x001C0E08U + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0E00U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x001C0E10U + 0xDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0E08U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_001C0E14;
    }
block_001C0E14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0E14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0E14U);
        }
        {
            const uint32_t updatedAddress = 0x001C0E1CU + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0E14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x174U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0E18U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x480U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0E1CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001C0E20U, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001C0E2CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C0E2CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C0E30U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C0E34U, address);
            }
        }
        {
            r3 = r0;
        }
        {
            const uint32_t operand = 0x00000230U;
            r2 = r5 + operand;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0E4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_InitObjectBank_0034FE20(frame, context, state, 0x0034FE20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0E4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0E4C;
    }
block_001C0E4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0E4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0E4CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000230U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0E5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0E5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0E5C;
    }
block_001C0E5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0E5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0E5CU);
        }
        {
            r3 = ~(0x00000000U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000230U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000002B4U;
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C0E6CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0E74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_SetFaceAnimations_0035C358(frame, context, state, 0x0035C358U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0E74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0E74;
    }
block_001C0E74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0E74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0E74U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r5 + operand;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x0000000DU;
        }
        {
            const uint32_t operand = 0x0000032CU;
            r1 = r1 + operand;
        }
        {
            r0 = 0x00000007U;
        }
        goto block_001C0EFC;
    }
block_001C0EFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0EFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0EFCU);
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001C0EFCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C0EFCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C0EFCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C0EFCU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r3 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000088U;
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C0F0CU, address);
            }
        }
        {
            r3 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x00000084U;
            r2 = r2 + operand;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0F24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0F24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0F24;
    }
block_001C0F24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0F24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0F24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4DCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C0F24U, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x0000000BU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001C0F30U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r3 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x480U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0F38U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x0000009CU;
            r3 = r3 + operand;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0F4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAllWithOwner_00340E14(frame, context, state, 0x00340E14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0F4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0F4C;
    }
block_001C0F4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0F4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0F4CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0F4CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0F58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0F58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0F58;
    }
block_001C0F58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0F58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0F58U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x49CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0F58U, address);
            }
            r2 = value;
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r2 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0F60U, address);
            }
            r2 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0F6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0F6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0F6C;
    }
block_001C0F6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0F6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0F6CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x49CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0F6CU, address);
            }
            r0 = value;
        }
        {
            r4 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0F74U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001C0F78U, address);
            }
        }
        goto block_001C0F7C;
    }
block_001C0F7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0F7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0F7CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r5 + operand;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C0F88U, address);
            }
        }
        {
            const uint32_t operand = 0x0000008CU;
            r2 = r2 + operand;
        }
        {
            r3 = 0x00000008U;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0FA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0FA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0FA0;
    }
block_001C0FA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0FA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0FA0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C0F7C; }
        goto block_001C0FB0;
    }
block_001C0FB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0FB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0FB0U);
        }
        {
            r4 = 0x00000000U;
        }
        goto block_001C0FB4;
    }
block_001C0FB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0FB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0FB4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001C0FBCU, faultAddress);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r7 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000004A0U;
            r3 = r7 + operand;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0FD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAllWithOwner_00340E14(frame, context, state, 0x00340E14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0FD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0FD8;
    }
block_001C0FD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0FD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0FD8U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x4A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C0FD8U, address);
            }
            r0 = value;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C0FE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_GetSharedResource_003687A8(frame, context, state, 0x003687A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C0FE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C0FE4;
    }
block_001C0FE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0FE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0FE4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x1BAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C0FE4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000020U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C0FB4; }
        goto block_001C0FF8;
    }
block_001C0FF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0FF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0FF8U);
        }
        {
            r4 = 0x00000000U;
        }
        goto block_001C0FFC;
    }
block_001C0FFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C0FFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C0FFCU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000009U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001C1004U, faultAddress);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r7 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000520U;
            r3 = r7 + operand;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1020U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAllWithOwner_00340E14(frame, context, state, 0x00340E14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1020U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1020;
    }
block_001C1020:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1020U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1020U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x520U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1020U, address);
            }
            r0 = value;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C102CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_GetSharedResource_003687A8(frame, context, state, 0x003687A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C102CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C102C;
    }
block_001C102C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C102CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C102CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x1BAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C102CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000047U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C0FFC; }
        goto block_001C1040;
    }
block_001C1040:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1040U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1040U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1040U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C104CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C104CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C104C;
    }
block_001C104C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C104CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C104CU);
        }
        {
            const uint32_t updatedAddress = 0x001C1054U + 0x3A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C104CU, address);
            }
            r9 = value;
        }
        {
            const uint32_t address = 0x001C1058U + 932U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1050U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            r11 = r0;
        }
        {
            r4 = 0x00000000U;
        }
        goto block_001C105C;
    }
block_001C105C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C105CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C105CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r7 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C1068U, address);
            }
        }
        {
            const uint32_t operand = 0x0000023CU;
            r2 = r2 + operand;
        }
        {
            r3 = 0x00000005U;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1080U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1080U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1080;
    }
block_001C1080:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1080U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1080U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x63CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1080U, address);
            }
            r0 = value;
        }
        {
            r1 = r11;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1088U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1090U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1090U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1090;
    }
block_001C1090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1090U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x63CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1090U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1098U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001C109CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x63CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C10A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C10A4U, address);
            }
            r7 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C10ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C10ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C10AC;
    }
block_001C10AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C10ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C10ACU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C10ACU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t address = r7 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C10B4U, address);
            }
        }
        if (flags.Z()) {
            r0 = r7;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x001C10C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_NormalizeFrame_003586EC(frame, context, state, 0x003586ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C10C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C10C0;
    }
block_001C10C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C10C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C10C0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C105C; }
        goto block_001C10D0;
    }
block_001C10D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C10D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C10D0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C10D0U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000002U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C10DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C10DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C10DC;
    }
block_001C10DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C10DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C10DCU);
        }
        {
            r11 = r0;
        }
        {
            r4 = 0x00000000U;
        }
        goto block_001C10E4;
    }
block_001C10E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C10E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C10E4U);
        }
        {
            r3 = 0x00000004U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r7 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000007E0U;
            r2 = r7 + operand;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C10FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C10FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C10FC;
    }
block_001C10FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C10FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C10FCU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x7E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C10FCU, address);
            }
            r0 = value;
        }
        {
            r1 = r11;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1104U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C110CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C110CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C110C;
    }
block_001C110C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C110CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C110CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x7E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C110CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1110U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001C1114U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x7E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1118U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C111CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001C1120U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C10E4; }
        goto block_001C1134;
    }
block_001C1134:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1134U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1134U);
        }
        {
            const uint32_t updatedAddress = 0x001C113CU + 0x2C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1134U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000120U;
        }
        {
            const uint32_t operand = 0x00000360U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1144U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_Memcpy_00371738(frame, context, state, 0x00371738U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1144U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1144;
    }
block_001C1144:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1144U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1144U);
        }
        {
            const uint32_t updatedAddress = 0x001C114CU + 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1144U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000330U;
            r11 = r13 + operand;
        }
        {
            const uint32_t address = 0x001C1154U + 696U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C114CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C1150U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C1150U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C1150U,
                                           firstAddress + 8U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C1150U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C1150U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001C1150U,
                                           firstAddress + 20U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001C1150U,
                                           firstAddress + 24U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r4 = value4;
            r7 = value7;
            r12 = value12;
            r14 = value14;
            r0 = r0 + 28U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C1164U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C1164U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C1164U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001C1164U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001C1164U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001C1164U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001C1164U,
                                           firstAddress + 24U);
            }
            r11 = r11 + 28U;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C1168U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C1168U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C1168U,
                                           firstAddress + 8U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C1168U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C1168U,
                                           firstAddress + 16U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r4 = value4;
            r7 = value7;
        }
        {
            const uint32_t operand = 0x00000300U;
            r0 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C1170U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C1170U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C1170U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001C1170U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001C1170U,
                                           firstAddress + 16U);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C117CU + 0x28CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1174U, address);
            }
            r4 = value;
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C1178U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C1178U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C1178U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C1178U,
                                           firstAddress + 12U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001C1178U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001C1178U,
                                           firstAddress + 20U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001C1178U,
                                           firstAddress + 24U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r7 = value7;
            r11 = value11;
            r12 = value12;
            r14 = value14;
            r4 = r4 + 28U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C117CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C117CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C117CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001C117CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001C117CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001C117CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001C117CU,
                                           firstAddress + 24U);
            }
            r0 = r0 + 28U;
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C1180U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C1180U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C1180U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C1180U,
                                           firstAddress + 12U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001C1180U,
                                           firstAddress + 16U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r7 = value7;
            r11 = value11;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C1184U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C1184U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C1184U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001C1184U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001C1184U,
                                           firstAddress + 16U);
            }
        }
        {
            r7 = 0x00000000U;
        }
        {
            const uint32_t address = r13 + 752U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C118CU, address);
            }
        }
        {
            const uint32_t address = r13 + 756U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C1190U, address);
            }
        }
        {
            const uint32_t address = r13 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001C1194U, address);
            }
        }
        {
            const uint32_t address = r13 + 764U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x001C1198U, address);
            }
        }
        {
            const uint32_t operand = 0x000002F0U;
            r11 = r13 + operand;
        }
        goto block_001C11A0;
    }
block_001C11A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C11A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C11A0U);
        }
        {
            r0 = 0x00000028U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C11A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SystemArena_Malloc_0035010c_0035010C(frame, context, state, 0x0035010CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C11A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C11A8;
    }
block_001C11A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C11A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C11A8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x001C11B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorTextureBinding_Reset_003500C4(frame, context, state, 0x003500C4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C11B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C11B4;
    }
block_001C11B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C11B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C11B4U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 2U);
            r4 = r5 + operand;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x7D8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C11BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C11C0U, address);
            }
            r3 = value;
        }
        {
            r1 = r2;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C11C8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000360U;
            r3 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C11D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FishingLineRenderer_Init_003FD018(frame, context, state, 0x003FD018U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C11D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C11D4;
    }
block_001C11D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C11D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C11D4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C11D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000330U;
            r1 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C11DCU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C11E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034ea6c_0034EA6C(frame, context, state, 0x0034EA6CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C11E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C11E4;
    }
block_001C11E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C11E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C11E4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C11E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000300U;
            r1 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C11ECU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C11F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00340de8_00340DE8(frame, context, state, 0x00340DE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C11F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C11F4;
    }
block_001C11F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C11F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C11F4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C11F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r11;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C11F8U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C11F8U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C11F8U,
                                           firstAddress + 8U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001C11F8U,
                                           firstAddress + 12U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C11FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x000000F0U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C1204U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C1204U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C1204U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001C1204U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1208U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C120CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1210U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 | 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001C1218U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r7 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r7 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C11A0; }
        goto block_001C122C;
    }
block_001C122C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C122CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C122CU);
        }
        {
            r0 = 0x00000028U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1234U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SystemArena_Malloc_0035010c_0035010C(frame, context, state, 0x0035010CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1234U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1234;
    }
block_001C1234:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1234U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1234U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1240U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorTextureBinding_Reset_003500C4(frame, context, state, 0x003500C4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1240U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1240;
    }
block_001C1240:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1240U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1240U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x870U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C1248U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001C124CU, faultAddress);
            }
        }
        {
            r3 = 0x0000001EU;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000002U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1260U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTexturedQuadResource_Construct_0034FF2C(frame, context, state, 0x0034FF2CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1260U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1260;
    }
block_001C1260:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1260U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1260U);
        }
        {
            const uint32_t updatedAddress = 0x001C1268U + 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1260U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = 0x001C126CU + 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1264U, address);
            }
            r11 = value;
        }
        {
            r3 = 0x00000015U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001C126CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001C1270U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001C1274U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001C1278U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x870U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C127CU, address);
            }
            r0 = value;
        }
        {
            r2 = r10;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C128CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorTextureBinding_Configure_0034FEA8(frame, context, state, 0x0034FEA8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C128CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C128C;
    }
block_001C128C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C128CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C128CU);
        }
        {
            const uint32_t operand = 0x000001D8U;
            r4 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = 0x001C1298U + 0x180U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1290U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000118U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C12A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_Memcpy_00371738(frame, context, state, 0x00371738U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C12A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C12A0;
    }
block_001C12A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C12A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C12A0U);
        }
        {
            const uint32_t updatedAddress = 0x001C12A8U + 0x174U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C12A0U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000028U;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C12B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_memcpy_0034338C(frame, context, state, 0x0034338CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C12B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C12B0;
    }
block_001C12B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C12B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C12B0U);
        }
        {
            const uint32_t updatedAddress = 0x001C12B8U + 0x168U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C12B0U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000028U;
        }
        {
            const uint32_t operand = 0x00000050U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C12C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_memcpy_0034338C(frame, context, state, 0x0034338CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C12C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C12C0;
    }
block_001C12C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C12C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C12C0U);
        }
        {
            const uint32_t updatedAddress = 0x001C12C8U + 0x15CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C12C0U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000028U;
        }
        {
            const uint32_t operand = 0x00000078U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C12D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_memcpy_0034338C(frame, context, state, 0x0034338CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C12D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C12D0;
    }
block_001C12D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C12D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C12D0U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r6 = r13 + operand;
        }
        {
            r0 = r6;
        }
        {
            r2 = r1;
        }
        {
            r3 = r1;
        }
        {
            r8 = r1;
        }
        {
            r12 = r1;
        }
        {
            r14 = r1;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C12F0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C12F0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C12F0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001C12F0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001C12F0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001C12F0U,
                                           firstAddress + 20U);
            }
            r0 = r0 + 24U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C12F4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C12F4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C12F4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001C12F4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001C12F4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001C12F4U,
                                           firstAddress + 20U);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C1300U + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C12F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001C1304U + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C12FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001C1308U + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1300U, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1304U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1308U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 424U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C130CU, address);
            }
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1310U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = 0x00000028U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1318U, 0xEE200A0DU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[26], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 436U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C131CU, address);
            }
        }
        {
            const uint32_t address = r13 + 448U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C1320U, address);
            }
        }
        {
            const uint32_t address = r13 + 456U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1324U, address);
            }
        }
        {
            const uint32_t address = r13 + 460U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1328U, address);
            }
        }
        {
            const uint32_t address = r13 + 468U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C132CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1334U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SystemArena_Malloc_0035010c_0035010C(frame, context, state, 0x0035010CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1334U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1334;
    }
block_001C1334:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1334U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1334U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1340U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorTextureBinding_Reset_003500C4(frame, context, state, 0x003500C4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1340U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1340;
    }
block_001C1340:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1340U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1340U);
        }
        {
            r2 = ~(0x00000000U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x864U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C1344U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C1348U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001C1348U,
                                           firstAddress + 4U);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r3 = 0x0000003CU;
        }
        {
            r1 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C135CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTexturedQuadResource_Construct_0034FF2C(frame, context, state, 0x0034FF2CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C135CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C135C;
    }
block_001C135C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C135CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C135CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001C135CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001C1360U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001C1364U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001C1368U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x864U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C136CU, address);
            }
            r0 = value;
        }
        {
            r3 = 0x0000000EU;
        }
        {
            r2 = r10;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1380U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorTextureBinding_Configure_0034FEA8(frame, context, state, 0x0034FEA8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1380U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1380;
    }
block_001C1380:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1380U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1380U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x864U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1380U, address);
            }
            r0 = value;
        }
        {
            r1 = r6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1388U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1390U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034ea6c_0034EA6C(frame, context, state, 0x0034EA6CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1390U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1390;
    }
block_001C1390:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1390U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1390U);
        }
        {
            r0 = 0x00000028U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C139CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SystemArena_Malloc_0035010c_0035010C(frame, context, state, 0x0035010CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C139CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C139C;
    }
block_001C139C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C139CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C139CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x001C13A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorTextureBinding_Reset_003500C4(frame, context, state, 0x003500C4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C13A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C13A8;
    }
block_001C13A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C13A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C13A8U);
        }
        {
            r2 = ~(0x00000000U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x87CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C13ACU, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C13B0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001C13B0U,
                                           firstAddress + 4U);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r3 = 0x0000003CU;
        }
        {
            r1 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C13C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTexturedQuadResource_Construct_0034FF2C(frame, context, state, 0x0034FF2CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C13C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C13C4;
    }
block_001C13C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C13C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C13C4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001C13C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001C13C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001C13CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001C13D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x87CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C13D4U, address);
            }
            r0 = value;
        }
        {
            r8 = r7;
        }
        {
            r3 = 0x0000000EU;
        }
        {
            r2 = r10;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C13ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorTextureBinding_Configure_0034FEA8(frame, context, state, 0x0034FEA8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C13ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C13EC;
    }
block_001C13EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C13ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C13ECU);
        }
        {
        }
        {
        }
        goto block_001C1434;
    }
block_001C1434:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1434U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1434U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x87CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1434U, address);
            }
            r0 = value;
        }
        {
            r1 = r6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C143CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1444U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034ea6c_0034EA6C(frame, context, state, 0x0034EA6CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1444U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1444;
    }
block_001C1444:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1444U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1444U);
        }
        {
            const uint32_t updatedAddress = 0x001C144CU + 0x69CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1444U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x000002C0U;
            r4 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C144CU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C144CU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C144CU,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C144CU,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C144CU,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001C144CU,
                                           firstAddress + 20U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001C144CU,
                                           firstAddress + 24U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r7 = value7;
            r12 = value12;
            r14 = value14;
            r0 = r0 + 28U;
        }
        {
            const uint32_t firstAddress = r4;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C1450U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C1450U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C1450U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001C1450U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001C1450U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001C1450U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001C1450U,
                                           firstAddress + 24U);
            }
            r4 = r4 + 28U;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C1454U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C1454U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C1454U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C1454U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C1454U,
                                           firstAddress + 16U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r7 = value7;
        }
        {
            r0 = 0x00000028U;
        }
        {
            const uint32_t firstAddress = r4;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C145CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C145CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C145CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001C145CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001C145CU,
                                           firstAddress + 16U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r4 = r4 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1468U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SystemArena_Malloc_0035010c_0035010C(frame, context, state, 0x0035010CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1468U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1468;
    }
block_001C1468:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1468U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1468U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1474U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorTextureBinding_Reset_003500C4(frame, context, state, 0x003500C4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1474U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1474;
    }
block_001C1474:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1474U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1474U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x880U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C147CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001C1480U, faultAddress);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r3 = 0x0000001EU;
        }
        {
            r1 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1494U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTexturedQuadResource_Construct_0034FF2C(frame, context, state, 0x0034FF2CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1494U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1494;
    }
block_001C1494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1494U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001C1494U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C1498U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001C149CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C14A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C14A4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            const uint32_t updatedAddress = r5 + 0x880U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C14A8U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C14B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorTextureBinding_Configure_0034FEA8(frame, context, state, 0x0034FEA8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C14B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C14B8;
    }
block_001C14B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C14B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C14B8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x880U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C14B8U, address);
            }
            r0 = value;
        }
        {
            r1 = r4;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C14C0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C14C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034ea6c_0034EA6C(frame, context, state, 0x0034EA6CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C14C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C14C8;
    }
block_001C14C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C14C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C14C8U);
        }
        {
            const uint32_t updatedAddress = 0x001C14D0U + 0x61CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C14C8U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000118U;
        }
        {
            const uint32_t operand = 0x00000070U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C14D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_Memcpy_00371738(frame, context, state, 0x00371738U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C14D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C14D8;
    }
block_001C14D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C14D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C14D8U);
        }
        {
            const uint32_t updatedAddress = 0x001C14E0U + 0x610U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C14D8U, address);
            }
            r4 = value;
        }
        {
            const uint32_t operand = 0x00000188U;
            r0 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C14E0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000040U;
            r7 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C14E8U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C14E8U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C14E8U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C14E8U,
                                           firstAddress + 12U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001C14E8U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001C14E8U,
                                           firstAddress + 20U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r12 = value12;
            r14 = value14;
            r4 = r4 + 24U;
        }
        {
            const uint32_t firstAddress = r7;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C14ECU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C14ECU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C14ECU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001C14ECU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001C14ECU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001C14ECU,
                                           firstAddress + 20U);
            }
            r7 = r7 + 24U;
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C14F0U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C14F0U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C14F0U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C14F0U,
                                           firstAddress + 12U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001C14F0U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001C14F0U,
                                           firstAddress + 20U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r12 = value12;
            r14 = value14;
        }
        {
            const uint32_t updatedAddress = 0x001C14FCU + 0x5F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C14F4U, address);
            }
            r4 = value;
        }
        {
            const uint32_t firstAddress = r7;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C14F8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C14F8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C14F8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001C14F8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001C14F8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001C14F8U,
                                           firstAddress + 20U);
            }
        }
        {
            const uint32_t operand = 0x00000020U;
            r7 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C1500U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C1500U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C1500U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C1500U,
                                           firstAddress + 12U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001C1500U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001C1500U,
                                           firstAddress + 20U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r12 = value12;
            r14 = value14;
            r4 = r4 + 24U;
        }
        {
            const uint32_t firstAddress = r7;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C1504U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C1504U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C1504U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001C1504U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r12)) {
                return Oot3dAotMemoryFault(context, 0x001C1504U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001C1504U,
                                           firstAddress + 20U);
            }
            r7 = r7 + 24U;
        }
        {
            r3 = 0x00000004U;
        }
        {
            r6 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C1510U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C1510U,
                                           firstAddress + 4U);
            }
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t updatedAddress = 0x001C151CU + 0x5DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1514U, address);
            }
            r4 = value;
        }
        {
            const uint32_t firstAddress = r7;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C1518U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C1518U,
                                           firstAddress + 4U);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            r2 = 0x0000001EU;
        }
        {
            r7 = 0x00000002U;
        }
        goto block_001C1528;
    }
block_001C1528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1528U);
        }
        {
            r12 = r4 & Oot3dAotLsl(r1, 2U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x001C152CU, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r12 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x001C1534U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r12 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x001C153CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x001C1540U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x001C1544U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r12 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x001C154CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        if (!(flags.Z())) { goto block_001C1528; }
        goto block_001C1560;
    }
block_001C1560:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1560U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1560U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1560U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C156CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCTXBByIndex_00372C90(frame, context, state, 0x00372C90U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C156CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C156C;
    }
block_001C156C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C156CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C156CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C156CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C1578U + 0x584U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1570U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x000001B8U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1578U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C157CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1580U, address);
            }
            r2 = value;
        }
        {
            r0 = r3;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x001C158CU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C158CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C158C;
    }
block_001C158C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C158CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C158CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000070U;
            r1 = r13 + operand;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1598U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStageState_ConstructFromDescriptor_00348F34(frame, context, state, 0x00348F34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1598U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1598;
    }
block_001C1598:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1598U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1598U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x858U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C1598U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C159CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C15A0U, address);
            }
            r2 = value;
        }
        {
            r4 = r8;
        }
        {
            r3 = r11;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C15B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001C15B4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C15BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStage_ConfigureTextureUnit_00348A64(frame, context, state, 0x00348A64U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C15BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C15BC;
    }
block_001C15BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C15BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C15BCU);
        }
        {
            const uint32_t updatedAddress = 0x001C15C4U - 0x6D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C15BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C15C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_001C1600; }
        goto block_001C15CC;
    }
block_001C15CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C15CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C15CCU);
        }
        {
            const uint32_t updatedAddress = 0x001C15D4U - 0x6E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C15CCU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C15D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C15D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C15D4;
    }
block_001C15D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C15D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C15D4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001C1600; }
        goto block_001C15E0;
    }
block_001C15E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C15E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C15E0U);
        }
        {
            const uint32_t updatedAddress = 0x001C15E8U - 0x6F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C15E0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C15E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C15E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C15E8;
    }
block_001C15E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C15E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C15E8U);
        }
        {
            const uint32_t updatedAddress = 0x001C15F0U - 0x6FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C15E8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x001C15F4U - 0x6FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C15ECU, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x001C15FCU - 0x710U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C15F4U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_001C1600;
    }
block_001C1600:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1600U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1600U);
        }
        {
            const uint32_t updatedAddress = 0x001C1608U + 0x4F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1600U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x858U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1608U, address);
            }
            r1 = value;
        }
        {
            r2 = r3;
        }
        {
            const uint32_t updatedAddress = r0 + 0x47CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1610U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1618U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererModelResource_CreateFromCmb_00340D00(frame, context, state, 0x00340D00U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1618U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1618;
    }
block_001C1618:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1618U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1618U);
        }
        {
            const uint32_t operand = 0x00000040U;
            r1 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x85CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C161CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1624U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034ea6c_0034EA6C(frame, context, state, 0x0034EA6CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1624U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1624;
    }
block_001C1624:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1624U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1624U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x85CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1624U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000020U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1630U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererModelResource_SetTextureTransform_0034EA48(frame, context, state, 0x0034EA48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1630U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1630;
    }
block_001C1630:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1630U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1630U);
        }
        {
            r0 = 0x00000028U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C163CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SystemArena_Malloc_0035010c_0035010C(frame, context, state, 0x0035010CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C163CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C163C;
    }
block_001C163C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C163CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C163CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1648U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorTextureBinding_Reset_003500C4(frame, context, state, 0x003500C4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1648U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1648;
    }
block_001C1648:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1648U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1648U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x868U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C1650U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001C1654U, faultAddress);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r3 = 0x0000001EU;
        }
        {
            r1 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1668U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTexturedQuadResource_Construct_0034FF2C(frame, context, state, 0x0034FF2CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1668U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1668;
    }
block_001C1668:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1668U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1668U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001C1668U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x001C166CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x001C1670U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x001C1674U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1678U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            const uint32_t updatedAddress = r5 + 0x868U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C167CU, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000002U;
        }
        {
            r2 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C168CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ActorTextureBinding_Configure_0034FEA8(frame, context, state, 0x0034FEA8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C168CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C168C;
    }
block_001C168C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C168CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C168CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C168CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1698U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1698U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1698;
    }
block_001C1698:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1698U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1698U);
        }
        {
            const uint32_t operand = 0x00000480U;
            r11 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4D8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C169CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C16A8U + 0x45CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C16A0U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000058U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C16B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_Memcpy_00371738(frame, context, state, 0x00371738U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C16B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C16B0;
    }
block_001C16B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C16B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C16B0U);
        }
        {
            r4 = 0x00000000U;
        }
        goto block_001C16B4;
    }
block_001C16B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C16B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C16B4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r8 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C16BCU, address);
            }
        }
        {
            const uint32_t operand = 0x00000730U;
            r2 = r8 + operand;
        }
        {
            r3 = 0x00000006U;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C16D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C16D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C16D4;
    }
block_001C16D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C16D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C16D4U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x730U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C16D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C16D8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C16DCU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C16E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C16E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C16E4;
    }
block_001C16E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C16E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C16E4U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x730U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C16E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C16E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001C16ECU, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C16F4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C16F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x730U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C16FCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1704U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1708U, address);
            }
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1710U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_NormalizeFrame_003586EC(frame, context, state, 0x003586ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1710U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1710;
    }
block_001C1710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1710U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000016U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C16B4; }
        goto block_001C1720;
    }
block_001C1720:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1720U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1720U);
        }
        {
            r4 = 0x00000000U;
        }
        goto block_001C1724;
    }
block_001C1724:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1724U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1724U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C1730U, address);
            }
        }
        {
            const uint32_t operand = 0x00000388U;
            r2 = r2 + operand;
        }
        {
            r3 = 0x0000000CU;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1748U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1748U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1748;
    }
block_001C1748:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1748U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1748U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C1724; }
        goto block_001C1758;
    }
block_001C1758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1758U);
        }
        {
            const uint32_t updatedAddress = 0x001C1760U + 0x3A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1758U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x001C1764U + 940U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C175CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r5 + 0x13CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001C1764U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C1770U + 0x39CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1768U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x140U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001C176CU, address);
            }
        }
        {
            const uint32_t address = r5 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1770U, address);
            }
        }
        {
            const uint32_t address = 0x001C177CU + 920U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1774U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = 0x0000A000U;
        }
        {
            const uint32_t address = r5 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C177CU, address);
            }
        }
        {
            const uint32_t address = 0x001C1788U + 912U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1780U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1784U, address);
            }
        }
        {
            const uint32_t address = 0x001C1790U + 908U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1788U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001C178CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1794U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetScale_0037572C(frame, context, state, 0x0037572CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1794U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1794;
    }
block_001C1794:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1794U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1794U);
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r5 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C179CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C179CU,
                                           firstAddress + 4U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C179CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r4 = value4;
        }
        {
            const uint32_t address = 0x001C17A8U + 888U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C17A0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x001C17ACU - 0x914U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C17A4U, address);
            }
            r9 = value;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C17A8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C17A8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001C17A8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r5 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C17ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C17B0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C17B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C17B8U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00000009U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C17C0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0xDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C17C4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x001C17CCU, address);
            }
        }
        if (flags.Z()) { goto block_001C17EC; }
        goto block_001C17D4;
    }
block_001C17D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C17D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C17D4U);
        }
        {
            const uint32_t updatedAddress = 0x001C17DCU - 0x948U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C17D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xED8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C17D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00001000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00001000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001C17E4U, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C17E8U, address);
            }
        }
        goto block_001C17EC;
    }
block_001C17EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C17ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C17ECU);
        }
        {
            r0 = 0x00000014U;
        }
        {
            const uint32_t updatedAddress = r9 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C17F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C17FCU + 0x32CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C17F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001C1800U + 0x324U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C17F8U, address);
            }
            r4 = value;
        }
        {
            r8 = 0x00000000U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + r10;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x001C1804U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C1810U + 0x31CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1808U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001C180CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C1810U, address);
            }
        }
        {
            r0 = r8;
        }
        {
            const uint32_t updatedAddress = r9 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001C1818U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1820U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_SetBGM_003655D0(frame, context, state, 0x003655D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1820U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1820;
    }
block_001C1820:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1820U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1820U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1820U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t updatedAddress = 0x001C1830U - 0x99CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1828U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xED8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C182CU, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_001C18A8; }
        goto block_001C1834;
    }
block_001C1834:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1834U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1834U);
        }
        {
            const uint32_t value = r0 & 0x0000007FU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            r0 = r0 & 0x0000007FU;
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[0] = r0;
        }
        if (flags.Z()) {
            const uint32_t address = 0x001C1848U + 744U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1840U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1844U, 0x1EB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        goto block_001C1848;
    }
block_001C1848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1848U);
        }
        {
            const uint32_t updatedAddress = 0x001C1850U - 0x9BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1848U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000007U;
        }
        {
            const uint32_t address = r9 + 200U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1850U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xED8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1854U, address);
            }
            r0 = value;
        }
        {
            r0 = Oot3dAotLsr(r0, 16U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x11U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C185CU, address);
            }
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r0, 0U, 0U, flags.C());
            r1 = r1 & ~(shifted.Value);
            Oot3dAotSetLogicalFlags(flags, r1, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x001C1870U + 0x2C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1868U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + r10;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C186CU, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r9 + 0xEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C1870U, address);
            }
        }
        if (!(flags.Z())) { goto block_001C1888; }
        goto block_001C1878;
    }
block_001C1878:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1878U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1878U);
        }
        {
            const uint32_t updatedAddress = 0x001C1880U + 0x2B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1878U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r2 + r10;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001C1880U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0xEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001C1884U, address);
            }
        }
        goto block_001C1888;
    }
block_001C1888:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1888U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1888U);
        }
        {
            r0 = r0 & 0x00000007U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x00000064U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r9 + 0xFU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C1894U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r9 + 0xFU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C1898U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r4 - operand;
        }
        {
            r1 = 0x00000041U;
        }
        goto block_001C18C8;
    }
block_001C18A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C18A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C18A8U);
        }
        {
            const uint32_t value = r0 & 0x7F000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x7F000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) {
            const uint32_t address = 0x001C18B4U + 644U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C18ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) { goto block_001C1848; }
        goto block_001C18B4;
    }
block_001C18B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C18B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C18B4U);
        }
        {
            r0 = r0 & 0x7F000000U;
        }
        {
            r0 = Oot3dAotLsr(r0, 24U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C18C0U, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        goto block_001C1848;
    }
block_001C18C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C18C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C18C8U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C18C8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C18D0U, address);
            }
            r0 = updatedAddress;
        }
        if (!(flags.Z())) { goto block_001C18C8; }
        goto block_001C18D8;
    }
block_001C18D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C18D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C18D8U);
        }
        {
            const uint32_t updatedAddress = 0x001C18E0U + 0x25CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C18D8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000033U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C18E0U, address);
            }
            r0 = updatedAddress;
        }
        goto block_001C18E4;
    }
block_001C18E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C18E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C18E4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C18E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C18ECU, address);
            }
            r0 = updatedAddress;
        }
        if (!(flags.Z())) { goto block_001C18E4; }
        goto block_001C18F4;
    }
block_001C18F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C18F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C18F4U);
        }
        {
            const uint32_t updatedAddress = 0x001C18FCU + 0x258U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C18F4U, address);
            }
            r11 = value;
        }
        {
            const uint32_t address = 0x001C1900U + 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C18F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001C1904U + 584U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C18FCU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = r9 + 288U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1900U, address);
            }
        }
        {
            const uint32_t address = 0x001C190CU + 568U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1904U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001C1910U + 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1908U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = r9 + 292U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C190CU, address);
            }
        }
        {
            const uint32_t address = 0x001C1918U + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1910U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r4 = 0x00000000U;
        }
        {
            const uint32_t address = r9 + 296U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1918U, address);
            }
        }
        goto block_001C191C;
    }
block_001C191C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C191CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C191CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 3U);
            r0 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r7 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001C1928U, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001C195C; }
        goto block_001C1930;
    }
block_001C1930:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1930U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1930U);
        }
        {
            const uint32_t address = r9 + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1930U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1938U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1938U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1938;
    }
block_001C1938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1938U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1938U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C193CU, address);
            }
        }
        {
            const uint32_t address = r7 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1940U, address);
            }
        }
        {
            const uint32_t address = r9 + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1944U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C194CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C194CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C194C;
    }
block_001C194C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C194CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C194CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C194CU, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1950U, address);
            }
        }
        {
            const uint32_t address = r7 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1954U, address);
            }
        }
        goto block_001C19B8;
    }
block_001C195C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C195CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C195CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000028U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001C1990; }
        goto block_001C1964;
    }
block_001C1964:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1964U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1964U);
        }
        {
            const uint32_t address = r9 + 292U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1964U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C196CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C196CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C196C;
    }
block_001C196C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C196CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C196CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C196CU, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1970U, address);
            }
        }
        {
            const uint32_t address = r7 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1974U, address);
            }
        }
        {
            const uint32_t address = r9 + 292U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1978U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1980U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1980U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1980;
    }
block_001C1980:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1980U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1980U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1980U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1984U, address);
            }
        }
        {
            const uint32_t address = r7 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1988U, address);
            }
        }
        goto block_001C19B8;
    }
block_001C1990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1990U);
        }
        {
            const uint32_t address = r9 + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1990U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1998U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1998U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1998;
    }
block_001C1998:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1998U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1998U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1998U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C199CU, address);
            }
        }
        {
            const uint32_t address = r7 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C19A0U, address);
            }
        }
        {
            const uint32_t address = r9 + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C19A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C19ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C19ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C19AC;
    }
block_001C19AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C19ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C19ACU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C19ACU, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C19B0U, address);
            }
        }
        {
            const uint32_t address = r7 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C19B4U, address);
            }
        }
        goto block_001C19B8;
    }
block_001C19B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C19B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C19B8U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = r7 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001C19BCU, address);
            }
        }
        {
            const uint32_t address = r7 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C19C0U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C19CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C19CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C19CC;
    }
block_001C19CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C19CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C19CCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C19CCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r7 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C19D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C19D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x3EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C19DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C19E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0xDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C19E4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001C1A0C; }
        goto block_001C19F0;
    }
block_001C19F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C19F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C19F0U);
        }
        {
            const uint32_t operand = 0x0000000FU;
            r0 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t operand = 0x00000023U;
            r0 = r4 - operand;
        }
        if ((flags.C()) && !(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t operand = 0x00000037U;
            r0 = r4 - operand;
        }
        if ((flags.C()) && !(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C1A08U, address);
            }
        }
        goto block_001C1A0C;
    }
block_001C1A0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1A0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1A0CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C191C; }
        goto block_001C1A1C;
    }
block_001C1A1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1A1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1A1CU);
        }
        {
            const uint32_t updatedAddress = 0x001C1A24U + 0x134U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A1CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x114U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001C1A20U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C1A2CU + 0x110U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A24U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x118U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C1A28U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C1A34U + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A2CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001C1A38U + 0x138U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A30U, address);
            }
            r11 = value;
        }
        {
            const uint32_t updatedAddress = 0x001C1A3CU + 0x138U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A34U, address);
            }
            r7 = value;
        }
        {
            const uint32_t address = 0x001C1A40U + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A38U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x001C1A44U + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A3CU, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x001C1A48U + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A40U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t address = 0x001C1A4CU + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A44U, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            const uint32_t address = 0x001C1A50U + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A48U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x001C1A54U + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A4CU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x001C1A58U + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A50U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x001C1A5CU + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A54U, address);
            }
            frame.Guest.vfp[27] = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r9 + 0x11CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C1A5CU, address);
            }
        }
        goto block_001C1A60;
    }
block_001C1A60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1A60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1A60U);
        }
        {
            const uint32_t updatedAddress = 0x001C1A68U + 0x120U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A60U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + Oot3dAotLsl(r6, 3U);
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A64U, address);
            }
            r1 = value;
            r0 = updatedAddress;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000023U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001C1DA8; }
        goto block_001C1A70;
    }
block_001C1A70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1A70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1A70U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001C1A70U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A74U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1A7CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1A80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A84U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1A8CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1A90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1A94U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1A9CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1AA0U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001C1AA8U, address);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1AACU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1AB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1AB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1AB8;
    }
block_001C1AB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1AB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1AB8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1AB8U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0x32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C1AC0U, address);
            }
        }
        {
            const uint32_t address = r4 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x001C1AC4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C1AC8U, address);
            }
        }
        {
            const uint32_t address = r4 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C1ACCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C1AD0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x30U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1AD4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001C1C80; }
        goto block_001C1AE0;
    }
block_001C1AE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1AE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1AE0U);
        }
        {
            r1 = 0x000000ABU;
        }
        goto block_001C1B8C;
    }
block_001C1B8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1B8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1B8CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x114U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1B8CU, address);
            }
            r0 = value;
        }
        {
            r12 = r8;
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r1);
        }
        {
            const uint32_t updatedAddress = 0x001C1BA0U + 0x424U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1B98U, address);
            }
            r1 = value;
        }
        {
            const uint32_t leftValue = r1;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r1, 13U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 31U);
            r1 = r2 - operand;
        }
        {
            const uint32_t updatedAddress = 0x001C1BB0U + 0x418U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1BA8U, address);
            }
            r2 = value;
        }
        {
            r2 = static_cast<uint32_t>(static_cast<uint64_t>(r2) * r1 + r0);
        }
        {
            r1 = 0x000000ACU;
        }
        {
            const uint32_t updatedAddress = r9 + 0x114U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001C1BB4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x118U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1BB8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r1);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1BC4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t leftValue = r11;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r3 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r3 = Oot3dAotAsr(r1, 13U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 31U);
            r1 = r3 - operand;
        }
        {
            const uint32_t updatedAddress = 0x001C1BDCU + 0x3F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1BD4U, address);
            }
            r3 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1BD8U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            r3 = static_cast<uint32_t>(static_cast<uint64_t>(r3) * r1 + r0);
        }
        {
            r1 = 0x000000AAU;
        }
        {
            const uint32_t updatedAddress = r9 + 0x118U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C1BE4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1BE8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = r3;
        }
        {
            r1 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r1);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1BF4U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = r1;
        }
        {
            const uint32_t leftValue = r7;
            const uint32_t rightValue = r1;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            value += (static_cast<uint64_t>(r0) << 32U) |
                     r12;
            r12 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r12 = Oot3dAotAsr(r0, 14U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r12 - operand;
        }
        {
            const uint32_t updatedAddress = 0x001C1C10U + 0x3C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1C08U, address);
            }
            r12 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1C0CU, 0xEE000AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r12 + r1);
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            const uint32_t updatedAddress = r9 + 0x11CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C1C18U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1C1CU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1C20U, 0xEE000A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C1C40; }
        goto block_001C1C30;
    }
block_001C1C30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1C30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1C30U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1C30U, 0xEE300A68U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001C1C30; }
        goto block_001C1C40;
    }
block_001C1C40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1C40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1C40U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1C40U, 0xEEF00AC0U};
            frame.Guest.vfp[1] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1C48U, 0xEE000AABU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1C4CU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[27];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1C58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1C58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1C58;
    }
block_001C1C58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1C58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1C58U);
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1C58U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0xDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1C5CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001C1C78; }
        goto block_001C1C68;
    }
block_001C1C68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1C68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1C68U);
        }
        {
            const uint32_t address = r4 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1C68U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001C1C74U + 864U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1C6CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1C70U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1C74U, address);
            }
        }
        goto block_001C1C78;
    }
block_001C1C78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1C78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1C78U);
        }
        {
            const uint32_t address = r4 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x001C1C78U, address);
            }
        }
        goto block_001C1D94;
    }
block_001C1C80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1C80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1C80U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001C1D90; }
        goto block_001C1C88;
    }
block_001C1C88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1C88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1C88U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001C1D90; }
        goto block_001C1C90;
    }
block_001C1C90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1C90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1C90U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x114U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1C90U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x000000ABU;
        }
        {
            r12 = r8;
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r1);
        }
        {
            const uint32_t updatedAddress = 0x001C1CA8U + 0x31CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1CA0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t leftValue = r1;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r1, 13U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 31U);
            r1 = r2 - operand;
        }
        {
            const uint32_t updatedAddress = 0x001C1CB8U + 0x310U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1CB0U, address);
            }
            r2 = value;
        }
        {
            r2 = static_cast<uint32_t>(static_cast<uint64_t>(r2) * r1 + r0);
        }
        {
            r1 = 0x000000ACU;
        }
        {
            const uint32_t updatedAddress = r9 + 0x114U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001C1CBCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x118U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1CC0U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r1);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1CCCU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t leftValue = r11;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r3 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r3 = Oot3dAotAsr(r1, 13U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 31U);
            r1 = r3 - operand;
        }
        {
            const uint32_t updatedAddress = 0x001C1CE4U + 0x2E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1CDCU, address);
            }
            r3 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1CE0U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            r3 = static_cast<uint32_t>(static_cast<uint64_t>(r3) * r1 + r0);
        }
        {
            r1 = 0x000000AAU;
        }
        {
            const uint32_t updatedAddress = r9 + 0x118U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C1CECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1CF0U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = r3;
        }
        {
            r1 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r1);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1CFCU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = r1;
        }
        {
            const uint32_t leftValue = r7;
            const uint32_t rightValue = r1;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            value += (static_cast<uint64_t>(r0) << 32U) |
                     r12;
            r12 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r12 = Oot3dAotAsr(r0, 14U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r12 - operand;
        }
        {
            const uint32_t updatedAddress = 0x001C1D18U + 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1D10U, address);
            }
            r12 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1D14U, 0xEE000AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r12 + r1);
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            const uint32_t updatedAddress = r9 + 0x11CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C1D20U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1D24U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1D28U, 0xEE000A8AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C1D48; }
        goto block_001C1D38;
    }
block_001C1D38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1D38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1D38U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1D38U, 0xEE300A68U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001C1D38; }
        goto block_001C1D48;
    }
block_001C1D48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1D48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1D48U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1D48U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            const uint32_t address = 0x001C1D58U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1D50U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1D54U, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[27];
        }
        {
            const uint32_t address = r4 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001C1D5CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1D64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1D64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1D64;
    }
block_001C1D64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1D64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1D64U);
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1D64U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0xDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1D68U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) { goto block_001C1D94; }
        goto block_001C1D74;
    }
block_001C1D74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1D74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1D74U);
        }
        {
            const uint32_t value = r6 & 0x00000003U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001C1D90; }
        goto block_001C1D7C;
    }
block_001C1D7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1D7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1D7CU);
        }
        {
            const uint32_t address = r4 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1D7CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001C1D88U + 588U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1D80U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1D84U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C1D88U, address);
            }
        }
        goto block_001C1D94;
    }
block_001C1D90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1D90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1D90U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C1D90U, address);
            }
        }
        goto block_001C1D94;
    }
block_001C1D94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1D94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1D94U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000040U;
            r4 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r6 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000067U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C1A60; }
        goto block_001C1DA8;
    }
block_001C1DA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1DA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1DA8U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            r3 = 0x00000300U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001C1DB0U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r10 + operand;
        }
        {
            r1 = r5;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001C1DC0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001C1DC4U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001C1DD0U + 0x218U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1DC8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t address = 0x001C1DD4U + 520U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1DCCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x001C1DD8U + 520U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1DD0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001C1DDCU + 520U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1DD4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = r10;
        }
        {
            r5 = r0;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1DE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1DE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1DE4;
    }
block_001C1DE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1DE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1DE4U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000000U;
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = 0x000000C8U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001C1DF4U, address);
            }
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C1DF8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C1DF8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C1DF8U,
                                           firstAddress + 8U);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            r3 = r1;
        }
        {
            r2 = 0x000000FEU;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1E18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Spawn_003738D0(frame, context, state, 0x003738D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1E18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1E18;
    }
block_001C1E18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1E18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1E18U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x11U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1E18U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r0, 0U, 0U, flags.C());
            r0 = r1 & ~(shifted.Value);
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r6 = 0x0000000FU;
        }
        if (!(flags.Z())) { goto block_001C1E3C; }
        goto block_001C1E2C;
    }
block_001C1E2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1E2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1E2CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0xDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1E2CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r6 = 0x00000011U;
        }
        if (!(flags.Z())) {
            r6 = 0x00000010U;
        }
        goto block_001C1E3C;
    }
block_001C1E3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1E3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1E3CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r4 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001C1EC4; }
        goto block_001C1E48;
    }
block_001C1E48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1E48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1E48U);
        }
        {
            const uint32_t updatedAddress = 0x001C1E50U + 0x1A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1E48U, address);
            }
            r7 = value;
        }
        {
            const uint32_t address = 0x001C1E54U + 408U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1E4CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        goto block_001C1E50;
    }
block_001C1E50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1E50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1E50U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1E58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1E58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1E58;
    }
block_001C1E58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1E58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1E58U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1E58U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000064U;
            r1 = r4 + operand;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001C1E74U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C1E74U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C1E74U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C1E74U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 4U);
            r0 = r7 + operand;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1E80U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x000000FEU;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1E8CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1E90U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1E94U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            r1 = r10;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1EA0U, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = r5;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C1EACU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1EB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Spawn_003738D0(frame, context, state, 0x003738D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1EB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1EB4;
    }
block_001C1EB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1EB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1EB4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C1E50; }
        goto block_001C1EC4;
    }
block_001C1EC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1EC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1EC4U);
        }
        {
            const uint32_t operand = 0x000004E0U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001C1EC8U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C1EC8U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C1EC8U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C1EC8U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C1EC8U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C1EC8U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C1EC8U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C1EC8U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001C1EC8U,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001C1EC8U,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001C1EC8U,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001C1EC8U,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            r13 += 48U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C1ECCU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C1ECCU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C1ECCU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C1ECCU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001C1ECCU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001C1ECCU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001C1ECCU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001C1ECCU,
                                           firstAddress + 28U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001C1ECCU,
                                           firstAddress + 32U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001C1ECCU,
                                           firstAddress + 36U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r12 = value12;
            r13 = r13 + 40U;
            return Oot3dAotReturned(value15);
        }
    }
block_001C1ED0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1ED0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1ED0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000073U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C1EE0; }
        goto block_001C1ED8;
    }
block_001C1ED8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1ED8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1ED8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000C8U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001C1F24; }
        goto block_001C1EE0;
    }
block_001C1EE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1EE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1EE0U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C1EE4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C1EE8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C1EECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C1EF0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000230U;
            r2 = r5 + operand;
        }
        {
            r3 = 0x00000002U;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1F08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_InitObjectBank_0034FE20(frame, context, state, 0x0034FE20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1F08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1F08;
    }
block_001C1F08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1F08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1F08U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000230U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1F18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1F18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1F18;
    }
block_001C1F18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1F18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1F18U);
        }
        {
        }
        {
        }
        goto block_001C1F58;
    }
block_001C1F24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1F24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1F24U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001C1F2CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C1F2CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000230U;
            r2 = r5 + operand;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C1F3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001C1F40U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1F48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_InitObjectBank_0034FE20(frame, context, state, 0x0034FE20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1F48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1F48;
    }
block_001C1F48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1F48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1F48U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x00000230U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1F58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1F58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1F58;
    }
block_001C1F58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1F58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1F58U);
        }
        {
            const uint32_t operand = 0x00000230U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1F60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1F60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1F60;
    }
block_001C1F60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1F60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1F60U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1F60U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r5 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000C8U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001C1FF4; }
        goto block_001C1F70;
    }
block_001C1F70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1F70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1F70U);
        }
        {
            r1 = 0x00000064U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xB0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001C1F74U, address);
            }
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r10 + operand;
        }
        {
            r3 = 0x00000006U;
        }
        {
            r2 = r5;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r1 + operand;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1F90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ChangeType_00375D3C(frame, context, state, 0x00375D3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1F90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1F90;
    }
block_001C1F90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1F90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1F90U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1F90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000088U;
            r2 = r2 + operand;
        }
        {
            r1 = r0 | 0x00000009U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001C1FA0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000A70U;
            r1 = r10 + operand;
        }
        {
            r0 = r10;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1FU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C1FACU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C1FB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_LightContext_InsertLight_0034FAA8(frame, context, state, 0x0034FAA8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C1FB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C1FB4;
    }
block_001C1FB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1FB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1FB4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x884U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C1FB4U, address);
            }
        }
        {
            const uint32_t operand = 0x000004E0U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001C1FBCU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C1FBCU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C1FBCU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C1FBCU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C1FBCU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C1FBCU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C1FBCU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C1FBCU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001C1FBCU,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001C1FBCU,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001C1FBCU,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001C1FBCU,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            r13 += 48U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C1FC0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C1FC0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C1FC0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C1FC0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001C1FC0U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001C1FC0U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001C1FC0U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001C1FC0U,
                                           firstAddress + 28U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001C1FC0U,
                                           firstAddress + 32U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001C1FC0U,
                                           firstAddress + 36U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r12 = value12;
            r13 = r13 + 40U;
            return Oot3dAotReturned(value15);
        }
    }
block_001C1FF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C1FF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C1FF4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xB0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x001C1FF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xB2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x001C1FF8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C1FFCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x001C2008U - 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C2000U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r1 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 - 0x640U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C2008U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001C200CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C2010U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r1 - operand;
        }
        {
            const uint32_t address = r1 + 460U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C201CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 512U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C2020U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C2024U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x638U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C202CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C2034U, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 516U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C2038U, address);
            }
        }
        {
            const uint32_t address = 0x001C2044U + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C203CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C2044U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C2044U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C2044;
    }
block_001C2044:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C2044U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C2044U);
        }
        {
            const uint32_t address = r5 + 516U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C2044U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x001C2050U + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C2048U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C204CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r5 + 516U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C2054U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C2088; }
        goto block_001C2060;
    }
block_001C2060:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C2060U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C2060U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C2064U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C2064U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C2064;
    }
block_001C2064:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C2064U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C2064U);
        }
        {
            const uint32_t updatedAddress = 0x001C206CU + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C2064U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001C2088; }
        goto block_001C2074;
    }
block_001C2074:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C2074U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C2074U);
        }
        {
            const uint32_t address = 0x001C207CU + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C2074U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C207CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C207CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C207C;
    }
block_001C207C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C207CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C207CU);
        }
        {
            const uint32_t address = r5 + 516U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C207CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C2080U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 516U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C2084U, address);
            }
        }
        goto block_001C2088;
    }
block_001C2088:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C2088U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C2088U);
        }
        {
            const uint32_t updatedAddress = 0x001C2090U + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C2088U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C208CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001C1EC4; }
        goto block_001C2098;
    }
block_001C2098:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C2098U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C2098U);
        }
        {
            const uint32_t address = r5 + 516U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C2098U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001C20A4U + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C209CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C20A0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 516U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C20A4U, address);
            }
        }
        {
            const uint32_t operand = 0x000004E0U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001C20ACU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C20ACU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C20ACU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C20ACU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C20ACU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C20ACU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C20ACU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C20ACU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001C20ACU,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001C20ACU,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001C20ACU,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001C20ACU,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            r13 += 48U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C20B0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C20B0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C20B0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C20B0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001C20B0U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001C20B0U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001C20B0U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001C20B0U,
                                           firstAddress + 28U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x001C20B0U,
                                           firstAddress + 32U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001C20B0U,
                                           firstAddress + 36U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r12 = value12;
            r13 = r13 + 40U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_003430fc_003430FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003430FCU:
        goto block_003430FC;
    case 0x0034311CU:
        goto block_0034311C;
    case 0x00343124U:
        goto block_00343124;
    case 0x0034312CU:
        goto block_0034312C;
    case 0x0034313CU:
        goto block_0034313C;
    case 0x00343148U:
        goto block_00343148;
    case 0x00343154U:
        goto block_00343154;
    case 0x00343180U:
        goto block_00343180;
    case 0x00343184U:
        goto block_00343184;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003430FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003430FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003430FCU);
        }
        {
            const uint32_t firstAddress = r13 - 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003430FCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x003430FCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003430FCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003430FCU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r7)) {
                return Oot3dAotMemoryFault(context, 0x003430FCU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003430FCU,
                                           firstAddress + 20U);
            }
            r13 = r13 - 24U;
        }
        {
            r4 = r0;
        }
        {
            r5 = r1;
        }
        {
            const uint32_t updatedAddress = 0x00343110U + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00343108U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034310CU, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00343110U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0034312C; }
        goto block_0034311C;
    }
block_0034311C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0034311CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0034311CU);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00343124U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00343124U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00343124;
    }
block_00343124:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00343124U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00343124U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00343128U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00343128U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00343128U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00343128U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00343128U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00343128U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_0034312C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0034312CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0034312CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0034312CU, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00343134U, address);
            }
        }
        if (flags.Z()) { goto block_00343184; }
        goto block_0034313C;
    }
block_0034313C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0034313CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0034313CU);
        }
        {
            const uint32_t updatedAddress = 0x00343144U + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034313CU, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00343148U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProcessInitChain_003510B0(frame, context, state, 0x003510B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00343148U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00343148;
    }
block_00343148:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00343148U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00343148U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00343154U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyActor_Init_003532E8(frame, context, state, 0x003532E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00343154U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00343154;
    }
block_00343154:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00343154U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00343154U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00343158U, address);
            }
        }
        {
            r1 = r13;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00343164U, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034316CU, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            const uint32_t operand = 0x000002E8U;
            r1 = r1 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00343180U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPoly_SetBgActor_00353EC8(frame, context, state, 0x00353EC8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00343180U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00343180;
    }
block_00343180:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00343180U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00343180U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00343180U, address);
            }
        }
        goto block_00343184;
    }
block_00343184:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00343184U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00343184U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00343188U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00343188U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00343188U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00343188U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00343188U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00343188U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_DemoGj_InitSetIndexes_00343194(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00343194U:
        goto block_00343194;
    case 0x003431B4U:
        goto block_003431B4;
    case 0x003431C4U:
        goto block_003431C4;
    case 0x003431D0U:
        goto block_003431D0;
    case 0x003431DCU:
        goto block_003431DC;
    case 0x00343208U:
        goto block_00343208;
    case 0x0034320CU:
        goto block_0034320C;
    case 0x00343214U:
        goto block_00343214;
    case 0x0034321CU:
        goto block_0034321C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00343194:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00343194U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00343194U);
        }
        {
            const uint32_t firstAddress = r13 - 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00343194U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00343194U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00343194U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00343194U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00343194U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00343194U,
                                           firstAddress + 20U);
            }
            r13 = r13 - 24U;
        }
        {
            r4 = r0;
        }
        {
            r5 = r1;
        }
        {
            const uint32_t updatedAddress = 0x003431A8U + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003431A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003431A4U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003431A8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_00343214; }
        goto block_003431B4;
    }
block_003431B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003431B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003431B4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003431B4U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003431BCU, address);
            }
        }
        if (flags.Z()) { goto block_0034320C; }
        goto block_003431C4;
    }
block_003431C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003431C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003431C4U);
        }
        {
            const uint32_t updatedAddress = 0x003431CCU + 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003431C4U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003431D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProcessInitChain_003510B0(frame, context, state, 0x003510B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003431D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003431D0;
    }
block_003431D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003431D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003431D0U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003431DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyActor_Init_003532E8(frame, context, state, 0x003532E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003431DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003431DC;
    }
block_003431DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003431DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003431DCU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003431E0U, address);
            }
        }
        {
            r1 = r13;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003431ECU, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003431F4U, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            const uint32_t operand = 0x000002E8U;
            r1 = r1 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00343208U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPoly_SetBgActor_00353EC8(frame, context, state, 0x00353EC8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00343208U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00343208;
    }
block_00343208:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00343208U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00343208U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00343208U, address);
            }
        }
        goto block_0034320C;
    }
block_0034320C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0034320CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0034320CU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00343210U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00343210U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00343210U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00343210U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00343210U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00343210U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_00343214:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00343214U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00343214U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0034321CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0034321CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0034321C;
    }
block_0034321C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0034321CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0034321CU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00343220U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00343220U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00343220U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00343220U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00343220U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00343220U,
                                           firstAddress + 20U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Collider_SetCylinderType1_0034FB3C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0034FB3CU:
        goto block_0034FB3C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0034FB3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0034FB3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0034FB3CU);
        }
        {
            const uint32_t updatedAddress = r13 - 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0034FB3CU, address);
            }
            r13 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0034FB40U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FB44U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000020U;
            r4 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FB4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FB50U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FB54U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FB58U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x11U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FB5CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FB60U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x12U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FB64U, address);
            }
        }
        {
            r0 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x13U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FB6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FB70U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x15U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FB74U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FB78U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FB7CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FB80U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FB84U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x10U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FB88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FB8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x11U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FB90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x1DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FB94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FB98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FB9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x18U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FBA0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FBA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x19U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FBA8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x25U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FBACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FBB0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x2DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FBB4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x1DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FBB8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FBBCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FBC0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x2FU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0034FBC4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000040U;
            r0 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0034FBCCU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0034FBCCU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0034FBCCU,
                                           firstAddress + 8U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0034FBCCU,
                                           firstAddress + 12U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
            r4 = r4 + 16U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0034FBD0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0034FBD0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0034FBD0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0034FBD0U,
                                           firstAddress + 12U);
            }
            r0 = r0 + 16U;
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0034FBD4U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0034FBD4U,
                                           firstAddress + 4U);
            }
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0034FBD8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0034FBD8U,
                                           firstAddress + 4U);
            }
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = r13;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034FBE0U, address);
            }
            r4 = value;
            r13 = updatedAddress;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Collider_InitCylinder_00353DD0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r8 = state.R[8];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00353DD0U:
        goto block_00353DD0;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00353DD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00353DD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00353DD0U);
        }
        {
            const uint32_t updatedAddress = 0x00353DD8U + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00353DD0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r13 - 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00353DD4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00353DD4U,
                                           firstAddress + 4U);
            }
            r13 = r13 - 8U;
        }
        {
            r4 = r1;
        }
        {
            const uint32_t operand = 0x00000018U;
            r13 = r13 - operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00353DE0U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00353DE0U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00353DE0U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00353DE0U,
                                           firstAddress + 12U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00353DE0U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00353DE0U,
                                           firstAddress + 20U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r5 = value5;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r4;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00353DE4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00353DE4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00353DE4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00353DE4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00353DE4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00353DE4U,
                                           firstAddress + 20U);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00353DF4U + 0x78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00353DECU, address);
            }
            r5 = value;
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00353DF0U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00353DF0U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00353DF0U,
                                           firstAddress + 8U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00353DF0U,
                                           firstAddress + 12U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
            r5 = r5 + 16U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00353DF4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00353DF4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00353DF4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00353DF4U,
                                           firstAddress + 12U);
            }
            r0 = r0 + 16U;
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00353DF8U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00353DF8U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00353DF8U,
                                           firstAddress + 8U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00353DF8U,
                                           firstAddress + 12U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
            r5 = r5 + 16U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00353DFCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00353DFCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00353DFCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00353DFCU,
                                           firstAddress + 12U);
            }
            r0 = r0 + 16U;
        }
        {
            const uint32_t firstAddress = r5;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00353E00U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00353E00U,
                                           firstAddress + 4U);
            }
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00353E04U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00353E04U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = 0x00353E10U + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00353E08U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00353E0CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00353E10U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 - 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00353E14U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00353E20U + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00353E18U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 - 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00353E1CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r0 - operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00353E24U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00353E24U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00353E24U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r12 = r1;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00353E30U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00353E30U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00353E30U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000040U;
            r0 = r4 + operand;
        }
        {
            r4 = r13;
        }
        {
            r2 = r1;
        }
        {
            r3 = r1;
        }
        {
            r5 = r1;
        }
        {
            const uint32_t firstAddress = r4;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00353E48U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00353E48U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00353E48U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00353E48U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00353E48U,
                                           firstAddress + 16U);
            }
            r4 = r4 + 20U;
        }
        {
            const uint32_t updatedAddress = r4 - 0x14U;
            const uint32_t address = r4;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00353E4CU, address);
            }
            r4 = updatedAddress;
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00353E50U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00353E50U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00353E50U,
                                           firstAddress + 8U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00353E50U,
                                           firstAddress + 12U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00353E50U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x00353E50U,
                                           firstAddress + 20U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00353E54U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00353E54U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00353E54U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00353E54U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00353E54U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r12)) {
                return Oot3dAotMemoryFault(context, 0x00353E54U,
                                           firstAddress + 20U);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r13 = r13 + operand;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00353E60U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00353E60U,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r5 = value5;
            r13 = r13 + 8U;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_DynaPolyInfo_Alloc_00353FD4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00353FD4U:
        goto block_00353FD4;
    case 0x00353FE8U:
        goto block_00353FE8;
    case 0x00354004U:
        goto block_00354004;
    case 0x00354008U:
        goto block_00354008;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00353FD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00353FD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00353FD4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00353FD4U, address);
            }
            r0 = value;
        }
        {
            r3 = r1;
        }
        {
            r1 = r2;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_00354004; }
        goto block_00353FE8;
    }
block_00353FE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00353FE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00353FE8U);
        }
        {
            const uint32_t updatedAddress = 0x00353FF0U + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00353FE8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 7U);
            r0 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + r0;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00353FF0U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00003800U;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x0000025CU;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) { goto block_00354008; }
        goto block_00354004;
    }
block_00354004:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00354004U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00354004U);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_00354008;
    }
block_00354008:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00354008U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00354008U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r0 + operand;
        }
        return Oot3dAotBranch(0x003532C0U);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_MaterialAnimation_Init_00372D94(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00372D94U:
        goto block_00372D94;
    case 0x00372DB0U:
        goto block_00372DB0;
    case 0x00372DD8U:
        goto block_00372DD8;
    case 0x00372DE4U:
        goto block_00372DE4;
    case 0x00372DF0U:
        goto block_00372DF0;
    case 0x00372DFCU:
        goto block_00372DFC;
    case 0x00372E08U:
        goto block_00372E08;
    case 0x00372E50U:
        goto block_00372E50;
    case 0x00372E60U:
        goto block_00372E60;
    case 0x00372E74U:
        goto block_00372E74;
    case 0x00372E8CU:
        goto block_00372E8C;
    case 0x00372EA0U:
        goto block_00372EA0;
    case 0x00372EC0U:
        goto block_00372EC0;
    case 0x00372ED0U:
        goto block_00372ED0;
    case 0x00372EE0U:
        goto block_00372EE0;
    case 0x00372EECU:
        goto block_00372EEC;
    case 0x00372F04U:
        goto block_00372F04;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00372D94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372D94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372D94U);
        }
        {
            const uint32_t firstAddress = r13 - 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00372D94U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00372D94U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00372D94U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00372D94U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00372D94U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00372D94U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00372D94U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00372D94U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00372D94U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00372D94U,
                                           firstAddress + 36U);
            }
            r13 = r13 - 40U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t address = 0x00372DA4U + 356U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372D9CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00372DA0U, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00372DA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372DA8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00372DB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CmbModelInstance_ResetMaterialState_003103A4(frame, context, state, 0x003103A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00372DB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00372DB0;
    }
block_00372DB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372DB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372DB0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372DB0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372DB4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372DB8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372DC0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r0;
            r5 = r1 + operand;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372DCCU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00372E60; }
        goto block_00372DD8;
    }
block_00372DD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372DD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372DD8U);
        }
        {
            r12 = 0x0000011CU;
        }
        {
            r6 = 0x00000118U;
        }
        {
            r7 = 0x00000120U;
        }
        goto block_00372DE4;
    }
block_00372DE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372DE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372DE4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r1 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00372DFC; }
        goto block_00372DF0;
    }
block_00372DF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372DF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372DF0U);
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372DF4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r5;
            r1 = r1 + operand;
        }
        goto block_00372DFC;
    }
block_00372DFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372DFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372DFCU);
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372DFCU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00372E50; }
        goto block_00372E08;
    }
block_00372E08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372E08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372E08U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E08U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E0CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E10U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E14U, address);
            }
            r9 = value;
            r2 = updatedAddress;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 3U);
            r10 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E1CU, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E20U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 6U);
            r1 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r10 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + r10;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x00372E2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E30U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r3 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + r3;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00372E3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00372E40U, faultAddress);
            }
            r2 = static_cast<uint32_t>(value);
            r3 = static_cast<uint32_t>(value >> 32U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E44U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E48U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r2 + r1;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00372E4CU, address);
            }
        }
        goto block_00372E50;
    }
block_00372E50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372E50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372E50U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E50U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00372DE4; }
        goto block_00372E60;
    }
block_00372E60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372E60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372E60U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E60U, address);
            }
            r0 = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            r8 = r6;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00372EA0; }
        goto block_00372E74;
    }
block_00372E74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372E74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372E74U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 2U);
            r7 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E78U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E80U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E84U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            ++context.Stats.IndirectCalls;
            r14 = 0x00372E8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r1, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00372E8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00372E8C;
    }
block_00372E8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372E8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372E8CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x00372E8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372E90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00372E74; }
        goto block_00372EA0;
    }
block_00372EA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372EA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372EA0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372EA0U, address);
            }
            r0 = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00372EACU, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00372EB8U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00372F04; }
        goto block_00372EC0;
    }
block_00372EC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372EC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372EC0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372EC0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x00372EC8U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00372EE0; }
        goto block_00372ED0;
    }
block_00372ED0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372ED0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372ED0U);
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + Oot3dAotLsl(r6, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372ED4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r5;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00372EDCU, address);
            }
        }
        goto block_00372EE0;
    }
block_00372EE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372EE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372EE0U);
        }
        {
            r1 = r13;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00372EECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_CreateRuntimeEntry_004BDCD0(frame, context, state, 0x004BDCD0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00372EECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00372EEC;
    }
block_00372EEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372EECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372EECU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00372EF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372EF8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00372EC0; }
        goto block_00372F04;
    }
block_00372F04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372F04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372F04U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00372F04U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00372F04U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00372F04U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00372F04U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00372F04U,
                                           firstAddress + 16U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00372F04U,
                                           firstAddress + 20U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00372F04U,
                                           firstAddress + 24U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00372F04U,
                                           firstAddress + 28U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00372F04U,
                                           firstAddress + 32U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00372F04U,
                                           firstAddress + 36U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 40U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_ZAR_GetCMABByIndex_00372F0C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r8 = state.R[8];
    uint32_t& r12 = state.R[12];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00372F0CU:
        goto block_00372F0C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00372F0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372F0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372F0CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372F0CU, address);
            }
            r2 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            Oot3dAotSetAddFlags(flags, r2, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372F18U, address);
            }
            r12 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r12 + Oot3dAotLsl(r2, 4U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372F1CU, address);
            }
            r2 = value;
        }
        if (flags.Z()) {
            r2 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372F28U, address);
            }
            r0 = value;
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t updatedAddress = r0 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372F2CU, address);
            }
            r3 = value;
        }
        {
            r0 = r3;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_ModelHandle_LoadAll_00372F38(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00372F38U:
        goto block_00372F38;
    case 0x00372F60U:
        goto block_00372F60;
    case 0x00372F7CU:
        goto block_00372F7C;
    case 0x00372F80U:
        goto block_00372F80;
    case 0x00372F94U:
        goto block_00372F94;
    case 0x00372F9CU:
        goto block_00372F9C;
    case 0x00372FA8U:
        goto block_00372FA8;
    case 0x00372FB0U:
        goto block_00372FB0;
    case 0x00372FC8U:
        goto block_00372FC8;
    case 0x00372FE0U:
        goto block_00372FE0;
    case 0x00372FF0U:
        goto block_00372FF0;
    case 0x00373014U:
        goto block_00373014;
    case 0x00373024U:
        goto block_00373024;
    case 0x0037302CU:
        goto block_0037302C;
    case 0x00373044U:
        goto block_00373044;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00372F38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372F38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372F38U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00372F38U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00372F38U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00372F38U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00372F38U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            const uint32_t firstAddress = r13 - 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00372F3CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00372F3CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00372F3CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00372F3CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00372F3CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00372F3CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00372F3CU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00372F3CU,
                                           firstAddress + 28U);
            }
            r13 = r13 - 32U;
        }
        {
            r4 = r0;
        }
        {
            r0 = 0x00000001U;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372F4CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x19AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00372F50U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372F54U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000013U, static_cast<Oot3dAotFlagMask>(0x3U));
        }
        if (flags.C()) { goto block_00372F7C; }
        goto block_00372F60;
    }
block_00372F60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372F60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372F60U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 7U);
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00372F6CU + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372F64U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372F68U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00003800U;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x0000025CU;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) { goto block_00372F80; }
        goto block_00372F7C;
    }
block_00372F7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372F7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372F7CU);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_00372F80;
    }
block_00372F80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372F80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372F80U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r9 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00372F8CU + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372F84U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372F88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00372FC8; }
        goto block_00372F94;
    }
block_00372F94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372F94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372F94U);
        }
        {
            const uint32_t updatedAddress = 0x00372F9CU + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372F94U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00372F9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00372F9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00372F9C;
    }
block_00372F9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372F9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372F9CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00372FC8; }
        goto block_00372FA8;
    }
block_00372FA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372FA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372FA8U);
        }
        {
            const uint32_t updatedAddress = 0x00372FB0U + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372FA8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00372FB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00372FB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00372FB0;
    }
block_00372FB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372FB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372FB0U);
        }
        {
            const uint32_t updatedAddress = 0x00372FB8U + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372FB0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00372FBCU + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372FB4U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x00372FC4U + 0x9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372FBCU, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_00372FC8;
    }
block_00372FC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372FC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372FC8U);
        }
        {
            const uint32_t updatedAddress = 0x00372FD0U + 0x94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372FC8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00372FD4U + 0x9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372FCCU, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r5 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x17CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372FD4U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372FD8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00372FDCU, address);
            }
        }
        goto block_00372FE0;
    }
block_00372FE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372FE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372FE0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372FE0U, address);
            }
            r4 = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r5 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00373014; }
        goto block_00372FF0;
    }
block_00372FF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00372FF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00372FF0U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r7 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00372FF8U, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r8 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00372FFCU, address);
            }
            r0 = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r8 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00373004U, address);
            }
        }
        {
            r0 = r9;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0037300CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0037300CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0037300CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0037300CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0037300CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0037300CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0037300CU,
                                           firstAddress + 24U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r13 = r13 + 28U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = r13;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00373010U, address);
            }
            r13 = updatedAddress;
            switch (value) {
            case 0x00372F38U:
                goto block_00372F38;
            case 0x00372F60U:
                goto block_00372F60;
            case 0x00372F7CU:
                goto block_00372F7C;
            case 0x00372F80U:
                goto block_00372F80;
            case 0x00372F94U:
                goto block_00372F94;
            case 0x00372F9CU:
                goto block_00372F9C;
            case 0x00372FA8U:
                goto block_00372FA8;
            case 0x00372FB0U:
                goto block_00372FB0;
            case 0x00372FC8U:
                goto block_00372FC8;
            case 0x00372FE0U:
                goto block_00372FE0;
            case 0x00372FF0U:
                goto block_00372FF0;
            case 0x00373014U:
                goto block_00373014;
            case 0x00373024U:
                goto block_00373024;
            case 0x0037302CU:
                goto block_0037302C;
            case 0x00373044U:
                goto block_00373044;
            default:
                return Oot3dAotBranch(value);
            }
        }
    }
block_00373014:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00373014U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00373014U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00373014U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r5 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00372FE0; }
        goto block_00373024;
    }
block_00373024:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00373024U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00373024U);
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0037302CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMBByIndex_00358EF8(frame, context, state, 0x00358EF8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0037302CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0037302C;
    }
block_0037302C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037302CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037302CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037302CU, address);
            }
            r2 = value;
        }
        {
            r1 = r0;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00373038U, address);
            }
            r3 = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x00373044U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r3, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00373044U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00373044;
    }
block_00373044:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00373044U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00373044U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00373044U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00373048U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00373054U, address);
            }
        }
        goto block_00372FE0;
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_003f1510_003F1510(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003F1510U:
        goto block_003F1510;
    case 0x003F1534U:
        goto block_003F1534;
    case 0x003F153CU:
        goto block_003F153C;
    case 0x003F1560U:
        goto block_003F1560;
    case 0x003F15B4U:
        goto block_003F15B4;
    case 0x003F167CU:
        goto block_003F167C;
    case 0x003F1690U:
        goto block_003F1690;
    case 0x003F16B0U:
        goto block_003F16B0;
    case 0x003F16BCU:
        goto block_003F16BC;
    case 0x003F16E0U:
        goto block_003F16E0;
    case 0x003F16ECU:
        goto block_003F16EC;
    case 0x003F1700U:
        goto block_003F1700;
    case 0x003F1718U:
        goto block_003F1718;
    case 0x003F1724U:
        goto block_003F1724;
    case 0x003F177CU:
        goto block_003F177C;
    case 0x003F1788U:
        goto block_003F1788;
    case 0x003F1798U:
        goto block_003F1798;
    case 0x003F17C8U:
        goto block_003F17C8;
    case 0x003F17D8U:
        goto block_003F17D8;
    case 0x003F1800U:
        goto block_003F1800;
    case 0x003F1810U:
        goto block_003F1810;
    case 0x003F1838U:
        goto block_003F1838;
    case 0x003F1848U:
        goto block_003F1848;
    case 0x003F1870U:
        goto block_003F1870;
    case 0x003F1880U:
        goto block_003F1880;
    case 0x003F18A8U:
        goto block_003F18A8;
    case 0x003F18BCU:
        goto block_003F18BC;
    case 0x003F18E0U:
        goto block_003F18E0;
    case 0x003F190CU:
        goto block_003F190C;
    case 0x003F1918U:
        goto block_003F1918;
    case 0x003F1928U:
        goto block_003F1928;
    case 0x003F1940U:
        goto block_003F1940;
    case 0x003F1954U:
        goto block_003F1954;
    case 0x003F1974U:
        goto block_003F1974;
    case 0x003F19B8U:
        goto block_003F19B8;
    case 0x003F19D0U:
        goto block_003F19D0;
    case 0x003F19E0U:
        goto block_003F19E0;
    case 0x003F1A10U:
        goto block_003F1A10;
    case 0x003F1A20U:
        goto block_003F1A20;
    case 0x003F1A4CU:
        goto block_003F1A4C;
    case 0x003F1A5CU:
        goto block_003F1A5C;
    case 0x003F1A88U:
        goto block_003F1A88;
    case 0x003F1A9CU:
        goto block_003F1A9C;
    case 0x003F1AC0U:
        goto block_003F1AC0;
    case 0x003F1AE0U:
        goto block_003F1AE0;
    case 0x003F1AECU:
        goto block_003F1AEC;
    case 0x003F1B00U:
        goto block_003F1B00;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003F1510:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1510U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1510U);
        }
        {
            const uint32_t firstAddress = r13 - 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x003F1510U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003F1510U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003F1510U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x003F1510U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x003F1510U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x003F1510U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x003F1510U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003F1510U,
                                           firstAddress + 28U);
            }
            r13 = r13 - 32U;
        }
        {
            r6 = r1;
        }
        {
            r4 = r0;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003F151CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x003F151CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000088U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2F2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1524U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00003800U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1534U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_field_80x4_positive_00373074(frame, context, state, 0x00373074U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1534U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1534;
    }
block_003F1534:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1534U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1534U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003F1718; }
        goto block_003F153C;
    }
block_003F153C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F153CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F153CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2F2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F153CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003F1540U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1544U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x140U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003F1548U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F154CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2E8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003F1550U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1554U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x003F1564U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F155CU, address);
            }
            switch (value) {
            case 0x003F1510U:
                goto block_003F1510;
            case 0x003F1534U:
                goto block_003F1534;
            case 0x003F153CU:
                goto block_003F153C;
            case 0x003F1560U:
                goto block_003F1560;
            case 0x003F15B4U:
                goto block_003F15B4;
            case 0x003F167CU:
                goto block_003F167C;
            case 0x003F1690U:
                goto block_003F1690;
            case 0x003F16B0U:
                goto block_003F16B0;
            case 0x003F16BCU:
                goto block_003F16BC;
            case 0x003F16E0U:
                goto block_003F16E0;
            case 0x003F16ECU:
                goto block_003F16EC;
            case 0x003F1700U:
                goto block_003F1700;
            case 0x003F1718U:
                goto block_003F1718;
            case 0x003F1724U:
                goto block_003F1724;
            case 0x003F177CU:
                goto block_003F177C;
            case 0x003F1788U:
                goto block_003F1788;
            case 0x003F1798U:
                goto block_003F1798;
            case 0x003F17C8U:
                goto block_003F17C8;
            case 0x003F17D8U:
                goto block_003F17D8;
            case 0x003F1800U:
                goto block_003F1800;
            case 0x003F1810U:
                goto block_003F1810;
            case 0x003F1838U:
                goto block_003F1838;
            case 0x003F1848U:
                goto block_003F1848;
            case 0x003F1870U:
                goto block_003F1870;
            case 0x003F1880U:
                goto block_003F1880;
            case 0x003F18A8U:
                goto block_003F18A8;
            case 0x003F18BCU:
                goto block_003F18BC;
            case 0x003F18E0U:
                goto block_003F18E0;
            case 0x003F190CU:
                goto block_003F190C;
            case 0x003F1918U:
                goto block_003F1918;
            case 0x003F1928U:
                goto block_003F1928;
            case 0x003F1940U:
                goto block_003F1940;
            case 0x003F1954U:
                goto block_003F1954;
            case 0x003F1974U:
                goto block_003F1974;
            case 0x003F19B8U:
                goto block_003F19B8;
            case 0x003F19D0U:
                goto block_003F19D0;
            case 0x003F19E0U:
                goto block_003F19E0;
            case 0x003F1A10U:
                goto block_003F1A10;
            case 0x003F1A20U:
                goto block_003F1A20;
            case 0x003F1A4CU:
                goto block_003F1A4C;
            case 0x003F1A5CU:
                goto block_003F1A5C;
            case 0x003F1A88U:
                goto block_003F1A88;
            case 0x003F1A9CU:
                goto block_003F1A9C;
            case 0x003F1AC0U:
                goto block_003F1AC0;
            case 0x003F1AE0U:
                goto block_003F1AE0;
            case 0x003F1AECU:
                goto block_003F1AEC;
            case 0x003F1B00U:
                goto block_003F1B00;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_003F1560;
    }
block_003F1560:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1560U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1560U);
        }
        goto block_003F1718;
    }
block_003F15B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F15B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F15B4U);
        }
        {
            r7 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2F4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x003F15B8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000358U;
            r1 = r4 + operand;
        }
        {
            r2 = 0x00000039U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x78U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003F15C4U, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x74U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003F15CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x7CU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003F15D0U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000350U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003F15D8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000354U;
            r3 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003F15E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003F15E4U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000348U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003F15ECU, address);
            }
        }
        {
            const uint32_t operand = 0x0000034CU;
            r3 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003F15F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x5CU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003F15F8U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000340U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003F1600U, address);
            }
        }
        {
            const uint32_t operand = 0x00000344U;
            r3 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003F1608U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003F160CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000338U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003F1614U, address);
            }
        }
        {
            const uint32_t operand = 0x0000033CU;
            r3 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003F161CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003F1620U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000330U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003F1628U, address);
            }
        }
        {
            const uint32_t operand = 0x00000334U;
            r3 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003F1630U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003F1634U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000328U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003F163CU, address);
            }
        }
        {
            const uint32_t operand = 0x0000032CU;
            r3 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003F1644U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003F1648U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000320U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003F1650U, address);
            }
        }
        {
            const uint32_t operand = 0x00000324U;
            r3 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003F1658U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003F165CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x0000031CU;
            r3 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003F1664U, address);
            }
        }
        {
            r3 = r2;
        }
        {
            const uint32_t operand = 0x00000318U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F167CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F167CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F167C;
    }
block_003F167C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F167CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F167CU);
        }
        {
            const uint32_t updatedAddress = 0x003F1684U + 0x2E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F167CU, address);
            }
            r8 = value;
        }
        {
            const uint32_t address = 0x003F1688U + 744U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1680U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r9 = r0;
        }
        {
            r5 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003F168CU, address);
            }
        }
        goto block_003F1690;
    }
block_003F1690:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1690U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1690U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 2U);
            r6 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x318U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1694U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1698U, address);
            }
            r10 = value;
        }
        {
            const uint32_t operand = r5;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2D4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F16A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r8 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F16A4U, address);
            }
            r1 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F16B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F16B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F16B0;
    }
block_003F16B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F16B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F16B0U);
        }
        {
            r1 = r0;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F16BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F16BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F16BC;
    }
block_003F16BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F16BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F16BCU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x318U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F16BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000010U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F16C8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x003F16CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x318U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F16D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F16D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003F16D8U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_003F1690; }
        goto block_003F16E0;
    }
block_003F16E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F16E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F16E0U);
        }
        {
            r1 = 0x00000034U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F16ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F16ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F16EC;
    }
block_003F16EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F16ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F16ECU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F16ECU, address);
            }
            r2 = value;
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r2 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F16F4U, address);
            }
            r2 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1700U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1700U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1700;
    }
block_003F1700:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1700U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1700U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1700U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1704U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x003F1708U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F170CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1710U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003F1714U, address);
            }
        }
        goto block_003F1718;
    }
block_003F1718:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1718U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1718U);
        }
        {
            const uint32_t operand = 0x00000088U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003F171CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003F171CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003F1720U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003F1720U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003F1720U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003F1720U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003F1720U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003F1720U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003F1720U,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003F1720U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
block_003F1724:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1724U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1724U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r2 = r1;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2F4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003F172CU, address);
            }
        }
        {
            const uint32_t operand = 0x0000030CU;
            r1 = r4 + operand;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003F1738U, faultAddress);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003F1740U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000304U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003F1748U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000308U;
            r3 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003F1750U, address);
            }
        }
        {
            const uint32_t operand = 0x00000300U;
            r3 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003F1758U, address);
            }
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x003F175CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003F175CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x000002FCU;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003F1764U, address);
            }
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000002F8U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F177CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F177CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F177C;
    }
block_003F177C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F177CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F177CU);
        }
        {
            r6 = r0;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1788U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1788U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1788;
    }
block_003F1788:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1788U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1788U);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F178CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1790U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1798U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1798U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1798;
    }
block_003F1798:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1798U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1798U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1798U, address);
            }
            r0 = value;
        }
        {
            r5 = 0x00000000U;
        }
        {
            const uint32_t address = 0x003F17A8U + 456U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F17A0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r1 = r5;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F17A8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F17B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F17B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F17B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003F17BCU, address);
            }
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F17C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F17C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F17C8;
    }
block_003F17C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F17C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F17C8U);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F17CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F17D0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F17D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F17D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F17D8;
    }
block_003F17D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F17D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F17D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F17D8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F17E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F17E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F17ECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F17F0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003F17F4U, address);
            }
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1800U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1800U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1800;
    }
block_003F1800:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1800U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1800U);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x300U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1804U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1808U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1810U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1810U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1810;
    }
block_003F1810:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1810U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1810U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x300U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1810U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F181CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F1820U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x300U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1824U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1828U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003F182CU, address);
            }
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1838U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1838U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1838;
    }
block_003F1838:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1838U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1838U);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x304U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F183CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1840U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1848U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1848U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1848;
    }
block_003F1848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1848U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x304U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1848U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1854U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F1858U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x304U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F185CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1860U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003F1864U, address);
            }
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1870U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1870U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1870;
    }
block_003F1870:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1870U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1870U);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x308U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1874U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1878U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1880U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1880U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1880;
    }
block_003F1880:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1880U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1880U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x308U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1880U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F188CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F1890U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x308U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1894U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1898U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003F189CU, address);
            }
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F18A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F18A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F18A8;
    }
block_003F18A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F18A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F18A8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x30CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F18A8U, address);
            }
            r2 = value;
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r2 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F18B0U, address);
            }
            r2 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F18BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F18BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F18BC;
    }
block_003F18BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F18BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F18BCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x30CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F18BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F18C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F18C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x30CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F18C8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F18CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003F18D0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000088U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003F18D8U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003F18D8U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003F18DCU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003F18DCU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003F18DCU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003F18DCU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003F18DCU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003F18DCU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003F18DCU,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003F18DCU,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
block_003F18E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F18E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F18E0U);
        }
        {
            r5 = 0x00000001U;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000310U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2F4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F18ECU, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003F18F0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003F18F0U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003F18F4U, address);
            }
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x00000314U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F190CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F190CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F190C;
    }
block_003F190C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F190CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F190CU);
        }
        {
            r6 = r0;
        }
        {
            r1 = 0x00000002U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1918U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1918U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1918;
    }
block_003F1918:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1918U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1918U);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x314U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F191CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1920U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1928U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1928U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1928;
    }
block_003F1928:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1928U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1928U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x314U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1928U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1930U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F1934U, address);
            }
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1940U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1940U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1940;
    }
block_003F1940:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1940U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1940U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x310U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1940U, address);
            }
            r2 = value;
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r2 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1948U, address);
            }
            r2 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1954U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1954U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1954;
    }
block_003F1954:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1954U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1954U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x310U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1954U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1958U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F195CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000088U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003F1964U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003F1964U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003F1968U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003F1968U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003F1968U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003F1968U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003F1968U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003F1968U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003F1968U,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003F1968U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
block_003F1974:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1974U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1974U);
        }
        {
            r5 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2F4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F1978U, address);
            }
        }
        {
            const uint32_t operand = 0x00000360U;
            r1 = r4 + operand;
        }
        {
            r2 = 0x00000038U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003F1984U, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003F198CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003F1990U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x0000035CU;
            r3 = r4 + operand;
        }
        {
            r2 = 0x00000039U;
        }
        {
            const uint32_t operand = 0x0000031CU;
            r1 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003F19A0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003F19A0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003F19A0U,
                                           firstAddress + 8U);
            }
        }
        {
            r3 = r2;
        }
        {
            const uint32_t operand = 0x00000318U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F19B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F19B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F19B8;
    }
block_003F19B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F19B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F19B8U);
        }
        {
            r7 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2F3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F19BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003F19C8U - 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F19C0U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r6 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F19C4U, address);
            }
            r1 = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F19D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F19D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F19D0;
    }
block_003F19D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F19D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F19D0U);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x318U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F19D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F19D8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F19E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F19E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F19E0;
    }
block_003F19E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F19E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F19E0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x318U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F19E0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003F19ECU - 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F19E4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F19E8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F19F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x318U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F19F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F19F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003F19FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2F3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A04U, address);
            }
            r1 = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1A10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1A10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1A10;
    }
block_003F1A10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1A10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1A10U);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x31CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A18U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1A20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1A20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1A20;
    }
block_003F1A20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1A20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1A20U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x31CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A20U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A28U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F1A2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x31CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A30U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A34U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003F1A38U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2F3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A3CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A40U, address);
            }
            r1 = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1A4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1A4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1A4C;
    }
block_003F1A4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1A4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1A4CU);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x35CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A50U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A54U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1A5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1A5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1A5C;
    }
block_003F1A5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1A5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1A5CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x35CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A5CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A64U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F1A68U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x35CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A6CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A70U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003F1A74U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2F3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A78U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A7CU, address);
            }
            r1 = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1A88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1A88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1A88;
    }
block_003F1A88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1A88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1A88U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x360U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A88U, address);
            }
            r2 = value;
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r2 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A90U, address);
            }
            r2 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1A9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1A9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1A9C;
    }
block_003F1A9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1A9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1A9CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x360U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1A9CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1AA0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F1AA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x360U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1AA8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1AACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003F1AB0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000088U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003F1AB8U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003F1AB8U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003F1ABCU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003F1ABCU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003F1ABCU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003F1ABCU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003F1ABCU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003F1ABCU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003F1ABCU,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003F1ABCU,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
block_003F1AC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1AC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1AC0U);
        }
        {
            r5 = 0x00000001U;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2F4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F1AC8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000364U;
            r2 = r4 + operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003F1AD8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1AE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1AE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1AE0;
    }
block_003F1AE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1AE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1AE0U);
        }
        {
            r1 = 0x00000000U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1AECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMABByIndex_00372F0C(frame, context, state, 0x00372F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1AECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1AEC;
    }
block_003F1AEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1AECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1AECU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x364U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1AECU, address);
            }
            r2 = value;
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r2 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1AF4U, address);
            }
            r2 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003F1B00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MaterialAnimation_Init_00372D94(frame, context, state, 0x00372D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003F1B00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003F1B00;
    }
block_003F1B00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F1B00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F1B00U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x364U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1B00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003F1B0CU - 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1B04U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1B08U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x003F1B0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x364U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1B10U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F1B14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003F1B18U, address);
            }
        }
        {
            const uint32_t operand = 0x00000088U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003F1B20U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003F1B20U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003F1B24U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003F1B24U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003F1B24U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003F1B24U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003F1B24U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003F1B24U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003F1B24U,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003F1B24U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
