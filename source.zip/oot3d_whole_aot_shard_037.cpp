#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_RendererTextureSlot_BuildFromOwner_002CCF04(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseUiEightQuadOverlay_Construct_002D1AF8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseUiTwentyFiveQuadOverlay_Construct_002D1E30(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseUiSixteenQuadOverlay_Construct_002D2190(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderBuffer_SetAllQuadAlpha_002DB368(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseCounter_Construct_002DB6A0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererStreamBuffer_GetColorWriteAddress_002DF594(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_002df6ac_002DF6AC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererTextureDescriptor_GetBuiltin_002E11D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseIconGroup_SetPageMode_002E64FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseIconGroup_SetSlotRect_002E6CD4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererResourceOwner_Build_002E76B8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererResourceArrayOwner_Construct_002E77E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseItemsPage_ResetState_002EB05C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseItemsPage_ResetInteractionState_002EB628(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FileSelect_EnsureOverlayLoaded_002EE864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FileSelect_GetSlotBuffer_002EEE84(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseQuadGroup_Construct_002F2448(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_UpdateKeyboardPageGeometry_002F43F8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_UpdateGlyphOverlayTransition_002F4700(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_CloseToFileSelect_002F4794(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_copy_u16x4_002F48D4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntryGlyphOverlay_Init_002F48F8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_UpdateKeyboardTransitionGeometry_002F4B64(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseMapOverlay_Init_002F57F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderGroup_SubmitModels_002F7684(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseQuadGroup_SetScale_002F79B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseQuadGroup_SetPosition_002F7AF4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderBuffer_SetQuadAlphaRange_002F8B80(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseIconGroup_SetSlotAlpha_002F8CE0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseIconGroup_SetSlotItemId_002F8D74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseIconGroup_Init_002F8EE4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderBuffer_SetVec2Range_002F9430(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseInput_ReadTouch_002F9484(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseQuadGroup_UpdateAndSubmit_002F94A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererStreamBuffer_CopyColors_002F9934(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_first_word_lsl_6_002F99F4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_first_word_lsl_5_002F9A00(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_first_word_mul_48_002F9A0C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderBuffer_ApplyPositionOffsets_002F9A1C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_offset_from_field_18_stride_40_002FC3E4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_offset_from_field_14_stride_20_002FC3F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_offset_from_field_c_stride_30_002FC3FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderBuffer_SetQuadTexcoords_002FC40C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderBuffer_SetQuadRects_002FC534(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderBuffer_Init_002FC694(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseCounter_UpdateDigitPositions_002FCC88(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderBuffer_SetQuadAlphaValues_002FCDEC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererScratchStateEE4_Init_002FFA20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererResourceGroup_Destroy_00305830(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DateTime_FromFieldsMilliseconds_003061A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PicaTexture_ConvertFormat_0030807C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PicaTexture_ConvertType_00308200(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PicaTextureConfig_SetLodBias_0030828C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PicaTextureConfig_SetMaxLod_00308328(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PicaTextureConfig_SetMinLod_0030835C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PicaTexture_ConvertWrapMode_00308390(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PicaTexture_ConvertMinFilter_003083FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PicaTexture_ConvertMagFilter_00308474(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ResourceMemory_Allocate_00313CE0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PicaMaterialState_Construct_00313CEC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererStreamBuffer_CopyTexcoords_00317D1C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Runtime_Memzero_ReturnEnd_0032B184(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Input_GetPressedButtonMask_0033B5EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ResourceMemory_ReleaseLocked_0033DDD4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ResourceMemory_AllocateLocked_0033DE14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_TouchInput_IsRectActive_0033F428(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Runtime_Memzero_00343280(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererResourceOwner_BuildGeneratedTexture_003446E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererModelResource_Create_0034897C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererTextureStage_ConfigureTextureUnit_00348A64(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererTextureStageState_ConstructFromDescriptor_00348F34(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ResourceMemory_Release_003525D4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_copy_u16x3_0035FB94(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererStreamBuffer_CopyPositions_0036759C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererGlobalState_Init_0036788C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_StaticInitGuard_TryAcquire_003679B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Runtime_Memcpy_00371738(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlaySoundGeneral_0037547C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_Update_00427CE4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_UpdateLatinKeyboard_0043C8D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_UpdateJapaneseKeyboard_0043D478(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_InitRenderGeometry_0043DA34(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_UpdateConfirmation_0043DDB4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_UpdateConfirmationTransitionIn_0043DF50(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_UpdateSaveCommit_0043E088(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_UpdateKeyboardTransitionOut_0043E240(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_UpdateEuropeanKeyboard_0043E3E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_UpdateTouchHighlightGeometry_0043E9B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_NameEntry_UpdateCursorTransform_0043F10C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0044cbd8_0044CBD8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0044ce90_0044CE90(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtonPanel_Init_0046ACB8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseItemsPage_Init_0046B554(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseItemsPage_InitAuxiliaryQuadGroup_0048046C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_PauseIconGroup_SetPageMode_002E64FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r8 = state.R[8];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002E64FCU:
        goto block_002E64FC;
    case 0x002E6510U:
        goto block_002E6510;
    case 0x002E6520U:
        goto block_002E6520;
    case 0x002E6524U:
        goto block_002E6524;
    case 0x002E6528U:
        goto block_002E6528;
    case 0x002E6530U:
        goto block_002E6530;
    case 0x002E6540U:
        goto block_002E6540;
    case 0x002E655CU:
        goto block_002E655C;
    case 0x002E6564U:
        goto block_002E6564;
    case 0x002E6570U:
        goto block_002E6570;
    case 0x002E6580U:
        goto block_002E6580;
    case 0x002E658CU:
        goto block_002E658C;
    case 0x002E6594U:
        goto block_002E6594;
    case 0x002E65A0U:
        goto block_002E65A0;
    case 0x002E65B0U:
        goto block_002E65B0;
    case 0x002E65BCU:
        goto block_002E65BC;
    case 0x002E65C4U:
        goto block_002E65C4;
    case 0x002E65D0U:
        goto block_002E65D0;
    case 0x002E65E0U:
        goto block_002E65E0;
    case 0x002E65ECU:
        goto block_002E65EC;
    case 0x002E65F4U:
        goto block_002E65F4;
    case 0x002E6600U:
        goto block_002E6600;
    case 0x002E6610U:
        goto block_002E6610;
    case 0x002E6618U:
        goto block_002E6618;
    case 0x002E6630U:
        goto block_002E6630;
    case 0x002E6634U:
        goto block_002E6634;
    case 0x002E6640U:
        goto block_002E6640;
    case 0x002E6650U:
        goto block_002E6650;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002E64FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E64FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E64FCU);
        }
        {
            const uint32_t firstAddress = r13 - 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002E64FCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002E64FCU,
                                           firstAddress + 4U);
            }
            r13 = r13 - 8U;
        }
        {
            const uint32_t updatedAddress = 0x002E6508U + 0x154U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E6500U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E6504U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002E6540; }
        goto block_002E6510;
    }
block_002E6510:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6510U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6510U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E6510U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E6514U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002E6530; }
        goto block_002E6520;
    }
block_002E6520:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6520U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6520U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E6524U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererResourceGroup_Destroy_00305830(frame, context, state, 0x00305830U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E6524U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E6524;
    }
block_002E6524:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6524U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6524U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E6528U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Release_003525D4(frame, context, state, 0x003525D4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E6528U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E6528;
    }
block_002E6528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6528U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E652CU, address);
            }
        }
        goto block_002E6530;
    }
block_002E6530:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6530U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6530U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E6530U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x002E653CU + 0x124U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E6534U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x002E6544U + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E653CU, address);
            }
            switch (value) {
            case 0x002E64FCU:
                goto block_002E64FC;
            case 0x002E6510U:
                goto block_002E6510;
            case 0x002E6520U:
                goto block_002E6520;
            case 0x002E6524U:
                goto block_002E6524;
            case 0x002E6528U:
                goto block_002E6528;
            case 0x002E6530U:
                goto block_002E6530;
            case 0x002E6540U:
                goto block_002E6540;
            case 0x002E655CU:
                goto block_002E655C;
            case 0x002E6564U:
                goto block_002E6564;
            case 0x002E6570U:
                goto block_002E6570;
            case 0x002E6580U:
                goto block_002E6580;
            case 0x002E658CU:
                goto block_002E658C;
            case 0x002E6594U:
                goto block_002E6594;
            case 0x002E65A0U:
                goto block_002E65A0;
            case 0x002E65B0U:
                goto block_002E65B0;
            case 0x002E65BCU:
                goto block_002E65BC;
            case 0x002E65C4U:
                goto block_002E65C4;
            case 0x002E65D0U:
                goto block_002E65D0;
            case 0x002E65E0U:
                goto block_002E65E0;
            case 0x002E65ECU:
                goto block_002E65EC;
            case 0x002E65F4U:
                goto block_002E65F4;
            case 0x002E6600U:
                goto block_002E6600;
            case 0x002E6610U:
                goto block_002E6610;
            case 0x002E6618U:
                goto block_002E6618;
            case 0x002E6630U:
                goto block_002E6630;
            case 0x002E6634U:
                goto block_002E6634;
            case 0x002E6640U:
                goto block_002E6640;
            case 0x002E6650U:
                goto block_002E6650;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_002E6540;
    }
block_002E6540:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6540U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6540U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E6540U,
                                           firstAddress + 0U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E6540U,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r13 = r13 + 8U;
            return Oot3dAotReturned(value15);
        }
    }
block_002E655C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E655CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E655CU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E6564U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E6564U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E6564;
    }
block_002E6564:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6564U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6564U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E6610; }
        goto block_002E6570;
    }
block_002E6570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6570U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E6580U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_Init_002F8EE4(frame, context, state, 0x002F8EE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E6580U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E6580;
    }
block_002E6580:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6580U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6580U);
        }
        {
        }
        {
        }
        goto block_002E6610;
    }
block_002E658C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E658CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E658CU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E6594U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E6594U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E6594;
    }
block_002E6594:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6594U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6594U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E6610; }
        goto block_002E65A0;
    }
block_002E65A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E65A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E65A0U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E65B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_Init_002F8EE4(frame, context, state, 0x002F8EE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E65B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E65B0;
    }
block_002E65B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E65B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E65B0U);
        }
        {
        }
        {
        }
        goto block_002E6610;
    }
block_002E65BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E65BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E65BCU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E65C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E65C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E65C4;
    }
block_002E65C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E65C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E65C4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E6610; }
        goto block_002E65D0;
    }
block_002E65D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E65D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E65D0U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E65E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_Init_002F8EE4(frame, context, state, 0x002F8EE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E65E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E65E0;
    }
block_002E65E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E65E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E65E0U);
        }
        {
        }
        {
        }
        goto block_002E6610;
    }
block_002E65EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E65ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E65ECU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E65F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E65F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E65F4;
    }
block_002E65F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E65F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E65F4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E6610; }
        goto block_002E6600;
    }
block_002E6600:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6600U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6600U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000005U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E6610U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_Init_002F8EE4(frame, context, state, 0x002F8EE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E6610U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E6610;
    }
block_002E6610:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6610U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6610U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E6610U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E6614U,
                                           firstAddress + 0U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E6614U,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r13 = r13 + 8U;
            return Oot3dAotReturned(value15);
        }
    }
block_002E6618:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6618U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6618U);
        }
        {
            const uint32_t updatedAddress = 0x002E6620U + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E6618U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x002E6624U + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E661CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E6620U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r2;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E6624U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002E6540; }
        goto block_002E6630;
    }
block_002E6630:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6630U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6630U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E6634U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E6634U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E6634;
    }
block_002E6634:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6634U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6634U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E6610; }
        goto block_002E6640;
    }
block_002E6640:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6640U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6640U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000006U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E6650U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_Init_002F8EE4(frame, context, state, 0x002F8EE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E6650U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E6650;
    }
block_002E6650:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E6650U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E6650U);
        }
        {
        }
        {
        }
        goto block_002E6610;
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FileSelect_EnsureOverlayLoaded_002EE864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002EE864U:
        goto block_002EE864;
    case 0x002EE880U:
        goto block_002EE880;
    case 0x002EE888U:
        goto block_002EE888;
    case 0x002EE8F0U:
        goto block_002EE8F0;
    case 0x002EE900U:
        goto block_002EE900;
    case 0x002EE908U:
        goto block_002EE908;
    case 0x002EE918U:
        goto block_002EE918;
    case 0x002EE924U:
        goto block_002EE924;
    case 0x002EE938U:
        goto block_002EE938;
    case 0x002EE948U:
        goto block_002EE948;
    case 0x002EE958U:
        goto block_002EE958;
    case 0x002EE964U:
        goto block_002EE964;
    case 0x002EE990U:
        goto block_002EE990;
    case 0x002EE9B4U:
        goto block_002EE9B4;
    case 0x002EE9BCU:
        goto block_002EE9BC;
    case 0x002EE9C4U:
        goto block_002EE9C4;
    case 0x002EE9CCU:
        goto block_002EE9CC;
    case 0x002EE9D8U:
        goto block_002EE9D8;
    case 0x002EE9F0U:
        goto block_002EE9F0;
    case 0x002EE9F8U:
        goto block_002EE9F8;
    case 0x002EEA04U:
        goto block_002EEA04;
    case 0x002EEA1CU:
        goto block_002EEA1C;
    case 0x002EEA2CU:
        goto block_002EEA2C;
    case 0x002EEA34U:
        goto block_002EEA34;
    case 0x002EEA40U:
        goto block_002EEA40;
    case 0x002EEA64U:
        goto block_002EEA64;
    case 0x002EEA74U:
        goto block_002EEA74;
    case 0x002EEA7CU:
        goto block_002EEA7C;
    case 0x002EEA88U:
        goto block_002EEA88;
    case 0x002EEAA0U:
        goto block_002EEAA0;
    case 0x002EEAB0U:
        goto block_002EEAB0;
    case 0x002EEAB8U:
        goto block_002EEAB8;
    case 0x002EEAC4U:
        goto block_002EEAC4;
    case 0x002EEADCU:
        goto block_002EEADC;
    case 0x002EEAE0U:
        goto block_002EEAE0;
    case 0x002EEAF0U:
        goto block_002EEAF0;
    case 0x002EEAF8U:
        goto block_002EEAF8;
    case 0x002EEB04U:
        goto block_002EEB04;
    case 0x002EEB1CU:
        goto block_002EEB1C;
    case 0x002EEB2CU:
        goto block_002EEB2C;
    case 0x002EEB34U:
        goto block_002EEB34;
    case 0x002EEB40U:
        goto block_002EEB40;
    case 0x002EEB58U:
        goto block_002EEB58;
    case 0x002EEB68U:
        goto block_002EEB68;
    case 0x002EEB70U:
        goto block_002EEB70;
    case 0x002EEB7CU:
        goto block_002EEB7C;
    case 0x002EEB94U:
        goto block_002EEB94;
    case 0x002EEBA4U:
        goto block_002EEBA4;
    case 0x002EEBACU:
        goto block_002EEBAC;
    case 0x002EEBB8U:
        goto block_002EEBB8;
    case 0x002EEBD0U:
        goto block_002EEBD0;
    case 0x002EEBE0U:
        goto block_002EEBE0;
    case 0x002EEBE8U:
        goto block_002EEBE8;
    case 0x002EEBF4U:
        goto block_002EEBF4;
    case 0x002EEC0CU:
        goto block_002EEC0C;
    case 0x002EEC1CU:
        goto block_002EEC1C;
    case 0x002EEC24U:
        goto block_002EEC24;
    case 0x002EEC30U:
        goto block_002EEC30;
    case 0x002EEC48U:
        goto block_002EEC48;
    case 0x002EEC58U:
        goto block_002EEC58;
    case 0x002EEC60U:
        goto block_002EEC60;
    case 0x002EEC6CU:
        goto block_002EEC6C;
    case 0x002EEC84U:
        goto block_002EEC84;
    case 0x002EEC94U:
        goto block_002EEC94;
    case 0x002EEC9CU:
        goto block_002EEC9C;
    case 0x002EECA8U:
        goto block_002EECA8;
    case 0x002EECC0U:
        goto block_002EECC0;
    case 0x002EECD0U:
        goto block_002EECD0;
    case 0x002EECD8U:
        goto block_002EECD8;
    case 0x002EECE4U:
        goto block_002EECE4;
    case 0x002EECFCU:
        goto block_002EECFC;
    case 0x002EED0CU:
        goto block_002EED0C;
    case 0x002EED14U:
        goto block_002EED14;
    case 0x002EED20U:
        goto block_002EED20;
    case 0x002EED38U:
        goto block_002EED38;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002EE864:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE864U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE864U);
        }
        {
            const uint32_t firstAddress = r13 - 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002EE864U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x002EE864U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002EE864U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x002EE864U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002EE864U,
                                           firstAddress + 16U);
            }
            r13 = r13 - 20U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = 0x002EE878U + 0x4D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE870U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE874U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002EE9BC; }
        goto block_002EE880;
    }
block_002EE880:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE880U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE880U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000019U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x002EE88CU + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE884U, address);
            }
            switch (value) {
            case 0x002EE864U:
                goto block_002EE864;
            case 0x002EE880U:
                goto block_002EE880;
            case 0x002EE888U:
                goto block_002EE888;
            case 0x002EE8F0U:
                goto block_002EE8F0;
            case 0x002EE900U:
                goto block_002EE900;
            case 0x002EE908U:
                goto block_002EE908;
            case 0x002EE918U:
                goto block_002EE918;
            case 0x002EE924U:
                goto block_002EE924;
            case 0x002EE938U:
                goto block_002EE938;
            case 0x002EE948U:
                goto block_002EE948;
            case 0x002EE958U:
                goto block_002EE958;
            case 0x002EE964U:
                goto block_002EE964;
            case 0x002EE990U:
                goto block_002EE990;
            case 0x002EE9B4U:
                goto block_002EE9B4;
            case 0x002EE9BCU:
                goto block_002EE9BC;
            case 0x002EE9C4U:
                goto block_002EE9C4;
            case 0x002EE9CCU:
                goto block_002EE9CC;
            case 0x002EE9D8U:
                goto block_002EE9D8;
            case 0x002EE9F0U:
                goto block_002EE9F0;
            case 0x002EE9F8U:
                goto block_002EE9F8;
            case 0x002EEA04U:
                goto block_002EEA04;
            case 0x002EEA1CU:
                goto block_002EEA1C;
            case 0x002EEA2CU:
                goto block_002EEA2C;
            case 0x002EEA34U:
                goto block_002EEA34;
            case 0x002EEA40U:
                goto block_002EEA40;
            case 0x002EEA64U:
                goto block_002EEA64;
            case 0x002EEA74U:
                goto block_002EEA74;
            case 0x002EEA7CU:
                goto block_002EEA7C;
            case 0x002EEA88U:
                goto block_002EEA88;
            case 0x002EEAA0U:
                goto block_002EEAA0;
            case 0x002EEAB0U:
                goto block_002EEAB0;
            case 0x002EEAB8U:
                goto block_002EEAB8;
            case 0x002EEAC4U:
                goto block_002EEAC4;
            case 0x002EEADCU:
                goto block_002EEADC;
            case 0x002EEAE0U:
                goto block_002EEAE0;
            case 0x002EEAF0U:
                goto block_002EEAF0;
            case 0x002EEAF8U:
                goto block_002EEAF8;
            case 0x002EEB04U:
                goto block_002EEB04;
            case 0x002EEB1CU:
                goto block_002EEB1C;
            case 0x002EEB2CU:
                goto block_002EEB2C;
            case 0x002EEB34U:
                goto block_002EEB34;
            case 0x002EEB40U:
                goto block_002EEB40;
            case 0x002EEB58U:
                goto block_002EEB58;
            case 0x002EEB68U:
                goto block_002EEB68;
            case 0x002EEB70U:
                goto block_002EEB70;
            case 0x002EEB7CU:
                goto block_002EEB7C;
            case 0x002EEB94U:
                goto block_002EEB94;
            case 0x002EEBA4U:
                goto block_002EEBA4;
            case 0x002EEBACU:
                goto block_002EEBAC;
            case 0x002EEBB8U:
                goto block_002EEBB8;
            case 0x002EEBD0U:
                goto block_002EEBD0;
            case 0x002EEBE0U:
                goto block_002EEBE0;
            case 0x002EEBE8U:
                goto block_002EEBE8;
            case 0x002EEBF4U:
                goto block_002EEBF4;
            case 0x002EEC0CU:
                goto block_002EEC0C;
            case 0x002EEC1CU:
                goto block_002EEC1C;
            case 0x002EEC24U:
                goto block_002EEC24;
            case 0x002EEC30U:
                goto block_002EEC30;
            case 0x002EEC48U:
                goto block_002EEC48;
            case 0x002EEC58U:
                goto block_002EEC58;
            case 0x002EEC60U:
                goto block_002EEC60;
            case 0x002EEC6CU:
                goto block_002EEC6C;
            case 0x002EEC84U:
                goto block_002EEC84;
            case 0x002EEC94U:
                goto block_002EEC94;
            case 0x002EEC9CU:
                goto block_002EEC9C;
            case 0x002EECA8U:
                goto block_002EECA8;
            case 0x002EECC0U:
                goto block_002EECC0;
            case 0x002EECD0U:
                goto block_002EECD0;
            case 0x002EECD8U:
                goto block_002EECD8;
            case 0x002EECE4U:
                goto block_002EECE4;
            case 0x002EECFCU:
                goto block_002EECFC;
            case 0x002EED0CU:
                goto block_002EED0C;
            case 0x002EED14U:
                goto block_002EED14;
            case 0x002EED20U:
                goto block_002EED20;
            case 0x002EED38U:
                goto block_002EED38;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_002EE888;
    }
block_002EE888:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE888U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE888U);
        }
        goto block_002EE9BC;
    }
block_002EE8F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE8F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE8F0U);
        }
        {
            const uint32_t updatedAddress = 0x002EE8F8U + 0x454U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE8F0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE8F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002EE9C4; }
        goto block_002EE900;
    }
block_002EE900:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE900U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE900U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EE908U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FileSelect_GetSlotBuffer_002EEE84(frame, context, state, 0x002EEE84U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EE908U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EE908;
    }
block_002EE908:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE908U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE908U);
        }
        {
            r5 = r0;
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EE918U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EE918U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EE918;
    }
block_002EE918:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE918U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE918U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EE938; }
        goto block_002EE924;
    }
block_002EE924:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE924U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE924U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EE928U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE92CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r1 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EE938U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0044cbd8_0044CBD8(frame, context, state, 0x0044CBD8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EE938U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EE938;
    }
block_002EE938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE938U);
        }
        {
            const uint32_t updatedAddress = 0x002EE940U + 0x408U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE938U, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r5 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EE93CU, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EE948U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FileSelect_GetSlotBuffer_002EEE84(frame, context, state, 0x002EEE84U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EE948U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EE948;
    }
block_002EE948:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE948U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE948U);
        }
        {
            r7 = r0;
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EE958U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EE958U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EE958;
    }
block_002EE958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE958U);
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r0, 0U, 0U, flags.C());
            r6 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r6, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
        }
        if (flags.Z()) { goto block_002EE9B4; }
        goto block_002EE964;
    }
block_002EE964:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE964U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE964U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r12 = r7 + operand;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r12 + 0x3C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE96CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x3CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE970U, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x002EE974U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002EE974U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002EE974U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EE97CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r12 + 0x3BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE980U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x3C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE984U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x3C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE988U, address);
            }
            r3 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EE990U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DateTime_FromFieldsMilliseconds_003061A8(frame, context, state, 0x003061A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EE990U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EE990;
    }
block_002EE990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE990U);
        }
        {
            const uint32_t updatedAddress = 0x002EE998U + 0x3B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE990U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x38U;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x002EE994U, faultAddress);
            }
            r2 = static_cast<uint32_t>(value);
            r3 = static_cast<uint32_t>(value >> 32U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x002EE998U, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x002EE99CU, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x002EE9A0U, faultAddress);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r2;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EE9B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0044ce90_0044CE90(frame, context, state, 0x0044CE90U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EE9B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EE9B4;
    }
block_002EE9B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE9B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE9B4U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EE9B8U, address);
            }
        }
        goto block_002EE9BC;
    }
block_002EE9BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE9BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE9BCU);
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EE9C0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EE9C0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EE9C0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EE9C0U,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EE9C0U,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EE9C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE9C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE9C4U);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EE9CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EE9CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EE9CC;
    }
block_002EE9CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE9CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE9CCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EEAE0; }
        goto block_002EE9D8;
    }
block_002EE9D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE9D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE9D8U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EE9DCU, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x002EE9ECU + 0x368U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EE9E4U, address);
            }
            r1 = value;
        }
        {
            r2 = r3;
        }
        goto block_002EEADC;
    }
block_002EE9F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE9F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE9F0U);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EE9F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EE9F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EE9F8;
    }
block_002EE9F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EE9F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EE9F8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EEA1C; }
        goto block_002EEA04;
    }
block_002EEA04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEA04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEA04U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EEA08U, address);
            }
        }
        {
            r3 = 0x00000010U;
        }
        {
            r2 = 0x0000003EU;
        }
        {
            r1 = 0x00000950U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEA1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEA1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEA1C;
    }
block_002EEA1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEA1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEA1CU);
        }
        {
            const uint32_t updatedAddress = 0x002EEA24U + 0x324U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEA1CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EEA20U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EEA28U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EEA28U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EEA28U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EEA28U,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EEA28U,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EEA2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEA2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEA2CU);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEA34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEA34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEA34;
    }
block_002EEA34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEA34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEA34U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EEA64; }
        goto block_002EEA40;
    }
block_002EEA40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEA40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEA40U);
        }
        {
            const uint32_t updatedAddress = 0x002EEA48U + 0x308U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEA40U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EEA48U, address);
            }
        }
        {
            r3 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEA50U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000076U;
        }
        {
            const uint32_t operand = 0x00000900U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x0000005DU;
            r1 = r1 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEA64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEA64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEA64;
    }
block_002EEA64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEA64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEA64U);
        }
        {
            const uint32_t updatedAddress = 0x002EEA6CU + 0x2DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEA64U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EEA68U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EEA70U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EEA70U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EEA70U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EEA70U,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EEA70U,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EEA74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEA74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEA74U);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEA7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEA7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEA7C;
    }
block_002EEA7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEA7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEA7CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EEAA0; }
        goto block_002EEA88;
    }
block_002EEA88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEA88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEA88U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EEA8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002EEA98U + 0x2C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEA90U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x00000010U;
        }
        {
            r2 = 0x0000003EU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEAA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEAA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEAA0;
    }
block_002EEAA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEAA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEAA0U);
        }
        {
            const uint32_t updatedAddress = 0x002EEAA8U + 0x2A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEAA0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EEAA4U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EEAACU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EEAACU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EEAACU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EEAACU,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EEAACU,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EEAB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEAB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEAB0U);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEAB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEAB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEAB8;
    }
block_002EEAB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEAB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEAB8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EEAE0; }
        goto block_002EEAC4;
    }
block_002EEAC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEAC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEAC4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000900U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EEACCU, address);
            }
        }
        {
            r3 = 0x00000010U;
        }
        {
            r2 = 0x0000003EU;
        }
        {
            const uint32_t operand = 0x00000049U;
            r1 = r1 + operand;
        }
        goto block_002EEADC;
    }
block_002EEADC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEADCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEADCU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEAE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEAE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEAE0;
    }
block_002EEAE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEAE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEAE0U);
        }
        {
            const uint32_t updatedAddress = 0x002EEAE8U + 0x260U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEAE0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EEAE4U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EEAECU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EEAECU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EEAECU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EEAECU,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EEAECU,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EEAF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEAF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEAF0U);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEAF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEAF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEAF8;
    }
block_002EEAF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEAF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEAF8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EEB1C; }
        goto block_002EEB04;
    }
block_002EEB04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEB04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEB04U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EEB08U, address);
            }
        }
        {
            r3 = 0x00000010U;
        }
        {
            r2 = 0x0000003EU;
        }
        {
            r1 = 0x000009D0U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEB1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEB1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEB1C;
    }
block_002EEB1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEB1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEB1CU);
        }
        {
            const uint32_t updatedAddress = 0x002EEB24U + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEB1CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EEB20U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EEB28U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EEB28U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EEB28U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EEB28U,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EEB28U,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EEB2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEB2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEB2CU);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEB34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEB34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEB34;
    }
block_002EEB34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEB34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEB34U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EEB58; }
        goto block_002EEB40;
    }
block_002EEB40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEB40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEB40U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EEB44U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002EEB50U + 0x20CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEB48U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x000000C3U;
        }
        {
            r2 = 0x0000005EU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEB58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEB58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEB58;
    }
block_002EEB58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEB58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEB58U);
        }
        {
            const uint32_t updatedAddress = 0x002EEB60U + 0x1E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEB58U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EEB5CU, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EEB64U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EEB64U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EEB64U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EEB64U,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EEB64U,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EEB68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEB68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEB68U);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEB70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEB70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEB70;
    }
block_002EEB70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEB70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEB70U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EEB94; }
        goto block_002EEB7C;
    }
block_002EEB7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEB7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEB7CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EEB80U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002EEB8CU + 0x1D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEB84U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x00000010U;
        }
        {
            r2 = 0x0000003EU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEB94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEB94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEB94;
    }
block_002EEB94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEB94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEB94U);
        }
        {
            const uint32_t updatedAddress = 0x002EEB9CU + 0x1ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEB94U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EEB98U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EEBA0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EEBA0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EEBA0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EEBA0U,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EEBA0U,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EEBA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEBA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEBA4U);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEBACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEBACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEBAC;
    }
block_002EEBAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEBACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEBACU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EEBD0; }
        goto block_002EEBB8;
    }
block_002EEBB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEBB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEBB8U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EEBBCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002EEBC8U + 0x19CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEBC0U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x00000010U;
        }
        {
            r2 = 0x0000003EU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEBD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEBD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEBD0;
    }
block_002EEBD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEBD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEBD0U);
        }
        {
            const uint32_t updatedAddress = 0x002EEBD8U + 0x170U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEBD0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EEBD4U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EEBDCU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EEBDCU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EEBDCU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EEBDCU,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EEBDCU,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EEBE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEBE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEBE0U);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEBE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEBE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEBE8;
    }
block_002EEBE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEBE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEBE8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EEC0C; }
        goto block_002EEBF4;
    }
block_002EEBF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEBF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEBF4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EEBF8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002EEC04U + 0x164U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEBFCU, address);
            }
            r1 = value;
        }
        {
            r3 = 0x00000010U;
        }
        {
            r2 = 0x0000003EU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEC0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEC0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEC0C;
    }
block_002EEC0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEC0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEC0CU);
        }
        {
            const uint32_t updatedAddress = 0x002EEC14U + 0x134U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEC0CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x4CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EEC10U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EEC18U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EEC18U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EEC18U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EEC18U,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EEC18U,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EEC1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEC1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEC1CU);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEC24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEC24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEC24;
    }
block_002EEC24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEC24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEC24U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EEC48; }
        goto block_002EEC30;
    }
block_002EEC30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEC30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEC30U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x0000003EU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EEC38U, address);
            }
        }
        {
            r3 = 0x00000010U;
        }
        {
            const uint32_t operand = 0x00000990U;
            r1 = r2 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEC48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEC48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEC48;
    }
block_002EEC48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEC48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEC48U);
        }
        {
            const uint32_t updatedAddress = 0x002EEC50U + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEC48U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EEC4CU, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EEC54U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EEC54U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EEC54U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EEC54U,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EEC54U,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EEC58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEC58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEC58U);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEC60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEC60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEC60;
    }
block_002EEC60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEC60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEC60U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EEC84; }
        goto block_002EEC6C;
    }
block_002EEC6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEC6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEC6CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EEC70U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002EEC7CU + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEC74U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x000000C3U;
        }
        {
            r2 = 0x0000005EU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEC84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEC84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEC84;
    }
block_002EEC84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEC84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEC84U);
        }
        {
            const uint32_t updatedAddress = 0x002EEC8CU + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EEC84U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EEC88U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EEC90U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EEC90U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EEC90U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EEC90U,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EEC90U,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EEC94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEC94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEC94U);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EEC9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EEC9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EEC9C;
    }
block_002EEC9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EEC9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EEC9CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EECC0; }
        goto block_002EECA8;
    }
block_002EECA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EECA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EECA8U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EECACU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002EECB8U + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EECB0U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x00000010U;
        }
        {
            r2 = 0x0000003EU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EECC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EECC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EECC0;
    }
block_002EECC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EECC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EECC0U);
        }
        {
            const uint32_t updatedAddress = 0x002EECC8U + 0x80U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EECC0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EECC4U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EECCCU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EECCCU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EECCCU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EECCCU,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EECCCU,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EECD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EECD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EECD0U);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EECD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EECD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EECD8;
    }
block_002EECD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EECD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EECD8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EECFC; }
        goto block_002EECE4;
    }
block_002EECE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EECE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EECE4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EECE8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002EECF4U + 0x80U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EECECU, address);
            }
            r1 = value;
        }
        {
            r3 = 0x00000010U;
        }
        {
            r2 = 0x0000003EU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EECFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EECFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EECFC;
    }
block_002EECFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EECFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EECFCU);
        }
        {
            const uint32_t updatedAddress = 0x002EED04U + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EECFCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EED00U, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EED08U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EED08U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EED08U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EED08U,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EED08U,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
block_002EED0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EED0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EED0CU);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EED14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EED14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EED14;
    }
block_002EED14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EED14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EED14U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002EED38; }
        goto block_002EED20;
    }
block_002EED20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EED20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EED20U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002EED24U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002EED30U + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EED28U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x000000C3U;
        }
        {
            r2 = 0x0000005EU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002EED38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002EED38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002EED38;
    }
block_002EED38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002EED38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002EED38U);
        }
        {
            const uint32_t updatedAddress = 0x002EED40U + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002EED38U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002EED3CU, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002EED44U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002EED44U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002EED44U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002EED44U,
                                           firstAddress + 12U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002EED44U,
                                           firstAddress + 16U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r13 = r13 + 20U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_PauseQuadGroup_Construct_002F2448(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002F2448U:
        goto block_002F2448;
    case 0x002F2468U:
        goto block_002F2468;
    case 0x002F2478U:
        goto block_002F2478;
    case 0x002F249CU:
        goto block_002F249C;
    case 0x002F2508U:
        goto block_002F2508;
    case 0x002F2530U:
        goto block_002F2530;
    case 0x002F253CU:
        goto block_002F253C;
    case 0x002F2548U:
        goto block_002F2548;
    case 0x002F2570U:
        goto block_002F2570;
    case 0x002F2598U:
        goto block_002F2598;
    case 0x002F25A0U:
        goto block_002F25A0;
    case 0x002F25A8U:
        goto block_002F25A8;
    case 0x002F25C8U:
        goto block_002F25C8;
    case 0x002F25D4U:
        goto block_002F25D4;
    case 0x002F25DCU:
        goto block_002F25DC;
    case 0x002F25E4U:
        goto block_002F25E4;
    case 0x002F2604U:
        goto block_002F2604;
    case 0x002F2608U:
        goto block_002F2608;
    case 0x002F2610U:
        goto block_002F2610;
    case 0x002F2618U:
        goto block_002F2618;
    case 0x002F2638U:
        goto block_002F2638;
    case 0x002F263CU:
        goto block_002F263C;
    case 0x002F2644U:
        goto block_002F2644;
    case 0x002F264CU:
        goto block_002F264C;
    case 0x002F266CU:
        goto block_002F266C;
    case 0x002F2670U:
        goto block_002F2670;
    case 0x002F26D4U:
        goto block_002F26D4;
    case 0x002F2718U:
        goto block_002F2718;
    case 0x002F2730U:
        goto block_002F2730;
    case 0x002F2778U:
        goto block_002F2778;
    case 0x002F277CU:
        goto block_002F277C;
    case 0x002F27C0U:
        goto block_002F27C0;
    case 0x002F27D8U:
        goto block_002F27D8;
    case 0x002F2820U:
        goto block_002F2820;
    case 0x002F282CU:
        goto block_002F282C;
    case 0x002F2838U:
        goto block_002F2838;
    case 0x002F2848U:
        goto block_002F2848;
    case 0x002F28A8U:
        goto block_002F28A8;
    case 0x002F28B0U:
        goto block_002F28B0;
    case 0x002F28CCU:
        goto block_002F28CC;
    case 0x002F28D8U:
        goto block_002F28D8;
    case 0x002F28E8U:
        goto block_002F28E8;
    case 0x002F2908U:
        goto block_002F2908;
    case 0x002F291CU:
        goto block_002F291C;
    case 0x002F2930U:
        goto block_002F2930;
    case 0x002F2940U:
        goto block_002F2940;
    case 0x002F2954U:
        goto block_002F2954;
    case 0x002F2964U:
        goto block_002F2964;
    case 0x002F299CU:
        goto block_002F299C;
    case 0x002F29BCU:
        goto block_002F29BC;
    case 0x002F29D0U:
        goto block_002F29D0;
    case 0x002F29E0U:
        goto block_002F29E0;
    case 0x002F29F0U:
        goto block_002F29F0;
    case 0x002F29FCU:
        goto block_002F29FC;
    case 0x002F2A0CU:
        goto block_002F2A0C;
    case 0x002F2A1CU:
        goto block_002F2A1C;
    case 0x002F2A58U:
        goto block_002F2A58;
    case 0x002F2A64U:
        goto block_002F2A64;
    case 0x002F2A70U:
        goto block_002F2A70;
    case 0x002F2A98U:
        goto block_002F2A98;
    case 0x002F2AA8U:
        goto block_002F2AA8;
    case 0x002F2AB0U:
        goto block_002F2AB0;
    case 0x002F2ABCU:
        goto block_002F2ABC;
    case 0x002F2AC4U:
        goto block_002F2AC4;
    case 0x002F2ADCU:
        goto block_002F2ADC;
    case 0x002F2AF4U:
        goto block_002F2AF4;
    case 0x002F2B18U:
        goto block_002F2B18;
    case 0x002F2B24U:
        goto block_002F2B24;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002F2448:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2448U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2448U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002F2448U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x002F2448U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002F2448U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x002F2448U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002F2448U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F2448U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F2448U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F2448U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002F2448U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            const uint32_t operand = 0x00000364U;
            r13 = r13 - operand;
        }
        {
            r4 = r0;
        }
        {
            r6 = r1;
        }
        {
            r5 = r2;
        }
        {
            r1 = 0x000000A0U;
        }
        {
            const uint32_t operand = 0x000002C4U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2468U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_Memzero_00343280(frame, context, state, 0x00343280U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2468U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2468;
    }
block_002F2468:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2468U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2468U);
        }
        {
            r1 = 0x00000060U;
        }
        {
            const uint32_t operand = 0x00000224U;
            r7 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000264U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2478U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_Memzero_00343280(frame, context, state, 0x00343280U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2478U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2478;
    }
block_002F2478:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2478U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2478U);
        }
        {
            const uint32_t updatedAddress = 0x002F2480U + 0x3E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2478U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F247CU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F247CU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F247CU,
                                           firstAddress + 8U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002F247CU,
                                           firstAddress + 12U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F247CU,
                                           firstAddress + 16U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F247CU,
                                           firstAddress + 20U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F247CU,
                                           firstAddress + 24U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x002F247CU,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x002F247CU,
                                           firstAddress + 32U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r12 = value12;
            r14 = value14;
            r0 = r0 + 36U;
        }
        {
            const uint32_t firstAddress = r7;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F2480U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F2480U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F2480U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002F2480U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F2480U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F2480U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F2480U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r12)) {
                return Oot3dAotMemoryFault(context, 0x002F2480U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002F2480U,
                                           firstAddress + 32U);
            }
            r7 = r7 + 36U;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F2484U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F2484U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F2484U,
                                           firstAddress + 8U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002F2484U,
                                           firstAddress + 12U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F2484U,
                                           firstAddress + 16U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F2484U,
                                           firstAddress + 20U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F2484U,
                                           firstAddress + 24U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
        }
        {
            const uint32_t operand = 0x000001C4U;
            r0 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r7;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F248CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F248CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F248CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002F248CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F248CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F248CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F248CU,
                                           firstAddress + 24U);
            }
        }
        {
            r1 = 0x00000060U;
        }
        {
            const uint32_t operand = 0x00000184U;
            r8 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F249CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_Memzero_00343280(frame, context, state, 0x00343280U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F249CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F249C;
    }
block_002F249C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F249CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F249CU);
        }
        {
            const uint32_t updatedAddress = 0x002F24A4U + 0x3C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F249CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x002F24A8U + 960U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F24A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t address = 0x002F24B0U + 956U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F24A8U, address);
            }
            frame.Guest.vfp[6] = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F24ACU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F24ACU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F24ACU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002F24ACU,
                                           firstAddress + 12U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F24ACU,
                                           firstAddress + 16U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F24ACU,
                                           firstAddress + 20U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F24ACU,
                                           firstAddress + 24U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x002F24ACU,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x002F24ACU,
                                           firstAddress + 32U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r7 = value7;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r12 = value12;
            r14 = value14;
            r0 = r0 + 36U;
        }
        {
            const uint32_t address = 0x002F24B8U + 952U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F24B0U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            const uint32_t address = 0x002F24BCU + 952U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F24B4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F24B8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F24B8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F24B8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x002F24B8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F24B8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F24B8U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F24B8U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r12)) {
                return Oot3dAotMemoryFault(context, 0x002F24B8U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002F24B8U,
                                           firstAddress + 32U);
            }
            r8 = r8 + 36U;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F24BCU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F24BCU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F24BCU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002F24BCU,
                                           firstAddress + 12U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F24BCU,
                                           firstAddress + 16U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F24BCU,
                                           firstAddress + 20U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F24BCU,
                                           firstAddress + 24U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r7 = value7;
            r9 = value9;
            r10 = value10;
            r11 = value11;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t address = 0x002F24CCU + 944U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F24C4U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            const uint32_t address = 0x002F24D0U + 944U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F24C8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F24CCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F24CCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F24CCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x002F24CCU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F24CCU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F24CCU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F24CCU,
                                           firstAddress + 24U);
            }
        }
        {
            const uint32_t operand = 0x00000024U;
            r8 = r8 - operand;
        }
        {
            r1 = 0x00000004U;
        }
        {
            r7 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F24DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002F24E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002F24E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F24E8U, address);
            }
        }
        {
            const uint32_t address = r4 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F24ECU, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r5 = 0x00000014U;
        }
        {
            const uint32_t address = 0x002F24FCU + 892U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F24F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x002F2500U + 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F24F8U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002F2500U, address);
            }
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x002F250CU + Oot3dAotLsl(r6, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2504U, address);
            }
            switch (value) {
            case 0x002F2448U:
                goto block_002F2448;
            case 0x002F2468U:
                goto block_002F2468;
            case 0x002F2478U:
                goto block_002F2478;
            case 0x002F249CU:
                goto block_002F249C;
            case 0x002F2508U:
                goto block_002F2508;
            case 0x002F2530U:
                goto block_002F2530;
            case 0x002F253CU:
                goto block_002F253C;
            case 0x002F2548U:
                goto block_002F2548;
            case 0x002F2570U:
                goto block_002F2570;
            case 0x002F2598U:
                goto block_002F2598;
            case 0x002F25A0U:
                goto block_002F25A0;
            case 0x002F25A8U:
                goto block_002F25A8;
            case 0x002F25C8U:
                goto block_002F25C8;
            case 0x002F25D4U:
                goto block_002F25D4;
            case 0x002F25DCU:
                goto block_002F25DC;
            case 0x002F25E4U:
                goto block_002F25E4;
            case 0x002F2604U:
                goto block_002F2604;
            case 0x002F2608U:
                goto block_002F2608;
            case 0x002F2610U:
                goto block_002F2610;
            case 0x002F2618U:
                goto block_002F2618;
            case 0x002F2638U:
                goto block_002F2638;
            case 0x002F263CU:
                goto block_002F263C;
            case 0x002F2644U:
                goto block_002F2644;
            case 0x002F264CU:
                goto block_002F264C;
            case 0x002F266CU:
                goto block_002F266C;
            case 0x002F2670U:
                goto block_002F2670;
            case 0x002F26D4U:
                goto block_002F26D4;
            case 0x002F2718U:
                goto block_002F2718;
            case 0x002F2730U:
                goto block_002F2730;
            case 0x002F2778U:
                goto block_002F2778;
            case 0x002F277CU:
                goto block_002F277C;
            case 0x002F27C0U:
                goto block_002F27C0;
            case 0x002F27D8U:
                goto block_002F27D8;
            case 0x002F2820U:
                goto block_002F2820;
            case 0x002F282CU:
                goto block_002F282C;
            case 0x002F2838U:
                goto block_002F2838;
            case 0x002F2848U:
                goto block_002F2848;
            case 0x002F28A8U:
                goto block_002F28A8;
            case 0x002F28B0U:
                goto block_002F28B0;
            case 0x002F28CCU:
                goto block_002F28CC;
            case 0x002F28D8U:
                goto block_002F28D8;
            case 0x002F28E8U:
                goto block_002F28E8;
            case 0x002F2908U:
                goto block_002F2908;
            case 0x002F291CU:
                goto block_002F291C;
            case 0x002F2930U:
                goto block_002F2930;
            case 0x002F2940U:
                goto block_002F2940;
            case 0x002F2954U:
                goto block_002F2954;
            case 0x002F2964U:
                goto block_002F2964;
            case 0x002F299CU:
                goto block_002F299C;
            case 0x002F29BCU:
                goto block_002F29BC;
            case 0x002F29D0U:
                goto block_002F29D0;
            case 0x002F29E0U:
                goto block_002F29E0;
            case 0x002F29F0U:
                goto block_002F29F0;
            case 0x002F29FCU:
                goto block_002F29FC;
            case 0x002F2A0CU:
                goto block_002F2A0C;
            case 0x002F2A1CU:
                goto block_002F2A1C;
            case 0x002F2A58U:
                goto block_002F2A58;
            case 0x002F2A64U:
                goto block_002F2A64;
            case 0x002F2A70U:
                goto block_002F2A70;
            case 0x002F2A98U:
                goto block_002F2A98;
            case 0x002F2AA8U:
                goto block_002F2AA8;
            case 0x002F2AB0U:
                goto block_002F2AB0;
            case 0x002F2ABCU:
                goto block_002F2ABC;
            case 0x002F2AC4U:
                goto block_002F2AC4;
            case 0x002F2ADCU:
                goto block_002F2ADC;
            case 0x002F2AF4U:
                goto block_002F2AF4;
            case 0x002F2B18U:
                goto block_002F2B18;
            case 0x002F2B24U:
                goto block_002F2B24;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_002F2508;
    }
block_002F2508:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2508U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2508U);
        }
        goto block_002F2820;
    }
block_002F2530:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2530U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2530U);
        }
        {
            r1 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F2534U, address);
            }
        }
        goto block_002F2820;
    }
block_002F253C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F253CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F253CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F253CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r8 - operand;
        }
        {
            r1 = 0x00000002U;
        }
        goto block_002F2548;
    }
block_002F2548:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2548U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2548U);
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2548U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = r0;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F2554U, 0xEE300A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2558U, address);
            }
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F255CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F2564U, 0xEE300A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2568U, address);
            }
        }
        if (!(flags.Z())) { goto block_002F2548; }
        goto block_002F2570;
    }
block_002F2570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2570U);
        }
        {
            const uint32_t address = 0x002F2578U + 784U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2570U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 420U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2574U, address);
            }
        }
        {
            const uint32_t address = r13 + 424U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[4])) {
                return Oot3dAotMemoryFault(context, 0x002F2578U, address);
            }
        }
        {
            const uint32_t address = r13 + 428U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[6])) {
                return Oot3dAotMemoryFault(context, 0x002F257CU, address);
            }
        }
        {
            const uint32_t address = r13 + 432U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[4])) {
                return Oot3dAotMemoryFault(context, 0x002F2580U, address);
            }
        }
        {
            const uint32_t address = r13 + 436U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2584U, address);
            }
        }
        {
            const uint32_t address = r13 + 440U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002F2588U, address);
            }
        }
        {
            const uint32_t address = r13 + 444U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[6])) {
                return Oot3dAotMemoryFault(context, 0x002F258CU, address);
            }
        }
        {
            const uint32_t address = r13 + 448U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002F2590U, address);
            }
        }
        goto block_002F2820;
    }
block_002F2598:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2598U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2598U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002F25C8; }
        goto block_002F25A0;
    }
block_002F25A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F25A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F25A0U);
        }
        {
            const uint32_t operand = 0x00000224U;
            r0 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000184U;
            r1 = r13 + operand;
        }
        goto block_002F25A8;
    }
block_002F25A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F25A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F25A8U);
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F25A8U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F25ACU, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[4])) {
                return Oot3dAotMemoryFault(context, 0x002F25B0U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[5])) {
                return Oot3dAotMemoryFault(context, 0x002F25B4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r5, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r5 = r5 - operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r1 + operand;
        }
        if (!(flags.Z())) { goto block_002F25A8; }
        goto block_002F25C8;
    }
block_002F25C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F25C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F25C8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F25C8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F25CCU, address);
            }
        }
        goto block_002F2820;
    }
block_002F25D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F25D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F25D4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002F25C8; }
        goto block_002F25DC;
    }
block_002F25DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F25DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F25DCU);
        }
        {
            const uint32_t operand = 0x00000224U;
            r0 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000184U;
            r1 = r13 + operand;
        }
        goto block_002F25E4;
    }
block_002F25E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F25E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F25E4U);
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002F25E4U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002F25E8U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002F25ECU, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x002F25F0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r5, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r5 = r5 - operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r1 + operand;
        }
        if (!(flags.Z())) { goto block_002F25E4; }
        goto block_002F2604;
    }
block_002F2604:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2604U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2604U);
        }
        goto block_002F25C8;
    }
block_002F2608:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2608U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2608U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002F25C8; }
        goto block_002F2610;
    }
block_002F2610:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2610U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2610U);
        }
        {
            const uint32_t operand = 0x00000224U;
            r0 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000184U;
            r1 = r13 + operand;
        }
        goto block_002F2618;
    }
block_002F2618:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2618U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2618U);
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2618U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F261CU, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2620U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[5])) {
                return Oot3dAotMemoryFault(context, 0x002F2624U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r5, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r5 = r5 - operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r1 + operand;
        }
        if (!(flags.Z())) { goto block_002F2618; }
        goto block_002F2638;
    }
block_002F2638:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2638U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2638U);
        }
        goto block_002F25C8;
    }
block_002F263C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F263CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F263CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002F25C8; }
        goto block_002F2644;
    }
block_002F2644:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2644U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2644U);
        }
        {
            const uint32_t operand = 0x00000224U;
            r0 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000184U;
            r1 = r13 + operand;
        }
        goto block_002F264C;
    }
block_002F264C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F264CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F264CU);
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002F264CU, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002F2650U, address);
            }
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x002F2654U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x002F2658U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r5, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r5 = r5 - operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r1 + operand;
        }
        if (!(flags.Z())) { goto block_002F264C; }
        goto block_002F266C;
    }
block_002F266C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F266CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F266CU);
        }
        goto block_002F25C8;
    }
block_002F2670:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2670U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2670U);
        }
        {
            const uint32_t address = 0x002F2678U + 532U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2670U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 548U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2674U, address);
            }
        }
        {
            const uint32_t address = r13 + 552U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2678U, address);
            }
        }
        {
            const uint32_t address = 0x002F2684U + 524U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F267CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 576U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2680U, address);
            }
        }
        {
            const uint32_t address = r13 + 572U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2684U, address);
            }
        }
        {
            const uint32_t address = r13 + 568U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2688U, address);
            }
        }
        {
            const uint32_t address = r13 + 564U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F268CU, address);
            }
        }
        {
            const uint32_t address = r13 + 560U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2690U, address);
            }
        }
        {
            const uint32_t address = r13 + 556U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2694U, address);
            }
        }
        {
            const uint32_t address = r13 + 396U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[4])) {
                return Oot3dAotMemoryFault(context, 0x002F2698U, address);
            }
        }
        {
            const uint32_t address = r13 + 400U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[6])) {
                return Oot3dAotMemoryFault(context, 0x002F269CU, address);
            }
        }
        {
            const uint32_t address = r13 + 404U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002F26A0U, address);
            }
        }
        {
            const uint32_t address = r13 + 408U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[6])) {
                return Oot3dAotMemoryFault(context, 0x002F26A4U, address);
            }
        }
        {
            const uint32_t address = r13 + 412U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002F26A8U, address);
            }
        }
        {
            const uint32_t address = r13 + 416U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[6])) {
                return Oot3dAotMemoryFault(context, 0x002F26ACU, address);
            }
        }
        {
            const uint32_t address = 0x002F26B8U + 476U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F26B0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x002F26BCU + 476U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F26B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F26B8U, address);
            }
        }
        {
            const uint32_t address = r4 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002F26BCU, address);
            }
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F26C0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F26C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F26C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F26CCU, address);
            }
        }
        goto block_002F2820;
    }
block_002F26D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F26D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F26D4U);
        }
        {
            const uint32_t updatedAddress = 0x002F26DCU + 0x1C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F26D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F26D8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000044U;
            r5 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F26E0U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F26E0U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F26E0U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002F26E0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002F26E0U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F26E0U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F26E0U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F26E0U,
                                           firstAddress + 28U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
        }
        {
            const uint32_t operand = 0x00000020U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r5;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F26E8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F26E8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F26E8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002F26E8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002F26E8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F26E8U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F26E8U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F26E8U,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t operand = 0x00000024U;
            r5 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F26F0U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F26F0U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F26F0U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002F26F0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002F26F0U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F26F0U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F26F0U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F26F0U,
                                           firstAddress + 28U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
        }
        {
            const uint32_t operand = 0x00000020U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r5;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F26F8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F26F8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F26F8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002F26F8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002F26F8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F26F8U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F26F8U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F26F8U,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t operand = 0x00000004U;
            r5 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F2700U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F2700U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F2700U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002F2700U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002F2700U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F2700U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F2700U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F2700U,
                                           firstAddress + 28U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
        }
        {
            const uint32_t firstAddress = r5;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F2704U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F2704U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F2704U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002F2704U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002F2704U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F2704U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F2704U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F2704U,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2708U, address);
            }
            r0 = value;
        }
        {
            r8 = Oot3dAotLsl(r0, 1U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002F2820; }
        goto block_002F2718;
    }
block_002F2718:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2718U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2718U);
        }
        {
            const uint32_t operand = 0x00000044U;
            r0 = r13 + operand;
        }
        {
            const uint32_t operand = 0x000002C4U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000224U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r5 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000184U;
            r6 = r13 + operand;
        }
        goto block_002F2730;
    }
block_002F2730:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2730U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2730U);
        }
        {
            r11 = r5;
        }
        {
            r9 = r0;
        }
        {
            const uint32_t address = r11 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2738U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r10 = r1;
        }
        {
            const uint32_t firstAddress = r2;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002F2740U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[0] = value0;
            r2 = r2 + 4U;
        }
        {
            const uint32_t address = r9 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2744U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r11 = r3;
        }
        {
            r14 = r6;
        }
        {
            const uint32_t address = r10 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002F2750U, address);
            }
        }
        {
            const uint32_t address = r11 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2754U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r8, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r8 = r8 - operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r6 = r6 + operand;
        }
        {
            const uint32_t address = r14 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002F2770U, address);
            }
        }
        if (!(flags.Z())) { goto block_002F2730; }
        goto block_002F2778;
    }
block_002F2778:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2778U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2778U);
        }
        goto block_002F2820;
    }
block_002F277C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F277CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F277CU);
        }
        {
            const uint32_t updatedAddress = 0x002F2784U + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F277CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F2780U, address);
            }
        }
        {
            const uint32_t operand = 0x00000044U;
            r5 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F2788U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F2788U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F2788U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002F2788U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002F2788U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F2788U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F2788U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F2788U,
                                           firstAddress + 28U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
        }
        {
            const uint32_t operand = 0x00000020U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r5;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F2790U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F2790U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F2790U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002F2790U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002F2790U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F2790U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F2790U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F2790U,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t operand = 0x00000024U;
            r5 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F2798U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F2798U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F2798U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002F2798U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002F2798U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F2798U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F2798U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F2798U,
                                           firstAddress + 28U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
        }
        {
            const uint32_t operand = 0x00000020U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r5;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F27A0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F27A0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F27A0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002F27A0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002F27A0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F27A0U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F27A0U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F27A0U,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t operand = 0x00000004U;
            r5 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F27A8U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F27A8U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F27A8U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002F27A8U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002F27A8U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F27A8U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F27A8U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F27A8U,
                                           firstAddress + 28U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r6 = value6;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
        }
        {
            const uint32_t firstAddress = r5;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F27ACU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F27ACU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F27ACU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002F27ACU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002F27ACU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F27ACU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F27ACU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F27ACU,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F27B0U, address);
            }
            r0 = value;
        }
        {
            r8 = Oot3dAotLsl(r0, 1U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002F2820; }
        goto block_002F27C0;
    }
block_002F27C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F27C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F27C0U);
        }
        {
            const uint32_t operand = 0x00000044U;
            r0 = r13 + operand;
        }
        {
            const uint32_t operand = 0x000002C4U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000224U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r5 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000184U;
            r6 = r13 + operand;
        }
        goto block_002F27D8;
    }
block_002F27D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F27D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F27D8U);
        }
        {
            r11 = r5;
        }
        {
            r9 = r0;
        }
        {
            const uint32_t address = r11 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F27E0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r10 = r1;
        }
        {
            const uint32_t firstAddress = r2;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002F27E8U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[0] = value0;
            r2 = r2 + 4U;
        }
        {
            const uint32_t address = r9 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F27ECU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r11 = r3;
        }
        {
            r14 = r6;
        }
        {
            const uint32_t address = r10 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002F27F8U, address);
            }
        }
        {
            const uint32_t address = r11 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F27FCU, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r8, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r8 = r8 - operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r6 = r6 + operand;
        }
        {
            const uint32_t address = r14 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002F2818U, address);
            }
        }
        if (!(flags.Z())) { goto block_002F27D8; }
        goto block_002F2820;
    }
block_002F2820:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2820U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2820U);
        }
        {
            r1 = r4;
        }
        {
            r0 = 0x00000020U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F282CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F282CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F282C;
    }
block_002F282C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F282CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F282CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002F2848; }
        goto block_002F2838;
    }
block_002F2838:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2838U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2838U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2838U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x002F2844U + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F283CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2848U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_Init_002FC694(frame, context, state, 0x002FC694U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2848U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2848;
    }
block_002F2848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2848U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F284CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000224U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x000002C4U;
            r1 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F2858U, address);
            }
        }
        goto block_002F28A8;
    }
block_002F28A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F28A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F28A8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F28A8U, address);
            }
            r3 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F28B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadRects_002FC534(frame, context, state, 0x002FC534U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F28B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F28B0;
    }
block_002F28B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F28B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F28B0U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F28B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F28B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F28BCU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000224U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000184U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F28CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadTexcoords_002FC40C(frame, context, state, 0x002FC40CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F28CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F28CC;
    }
block_002F28CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F28CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F28CCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F28CCU, address);
            }
            r0 = value;
        }
        {
            r0 = Oot3dAotLsl(r0, 2U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F28D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_AllocateLocked_0033DE14(frame, context, state, 0x0033DE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F28D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F28D8;
    }
block_002F28D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F28D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F28D8U);
        }
        {
            r8 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F28DCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002F291C; }
        goto block_002F28E8;
    }
block_002F28E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F28E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F28E8U);
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r8 - operand;
        }
        {
            const uint32_t address = 0x002F28F8U + 568U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F28F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000004U;
            r1 = r1 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F28F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F28FCU, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r0, 2U, 1U, flags.C());
            r2 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r2, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_002F291C; }
        goto block_002F2908;
    }
block_002F2908:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2908U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2908U);
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2908U, address);
            }
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F2914U, address);
            }
        }
        if (!(flags.Z())) { goto block_002F2908; }
        goto block_002F291C;
    }
block_002F291C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F291CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F291CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F291CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2920U, address);
            }
            r2 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r1 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2930U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaValues_002FCDEC(frame, context, state, 0x002FCDECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2930U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2930;
    }
block_002F2930:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2930U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2930U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2930U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            r0 = Oot3dAotLsl(r0, 2U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2940U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_AllocateLocked_0033DE14(frame, context, state, 0x0033DE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2940U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2940;
    }
block_002F2940:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2940U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2940U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2940U, address);
            }
            r3 = value;
        }
        {
            r9 = r0;
        }
        {
            r6 = 0x00000002U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002F299C; }
        goto block_002F2954;
    }
block_002F2954:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2954U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2954U);
        }
        {
            const uint32_t updatedAddress = 0x002F295CU + 0x1D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2954U, address);
            }
            r10 = value;
        }
        {
            r5 = r9;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r12 = 0x00000003U;
        }
        goto block_002F2964;
    }
block_002F2964:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2964U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2964U);
        }
        {
            r0 = r10 & Oot3dAotLsl(r1, 2U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F2968U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r2 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F2974U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F2978U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F297CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F2980U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F2988U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r3, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r3 = r3 - operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        if (!(flags.Z())) { goto block_002F2964; }
        goto block_002F299C;
    }
block_002F299C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F299CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F299CU);
        }
        {
            const uint32_t updatedAddress = 0x002F29A4U + 0x194U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F299CU, address);
            }
            r0 = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x002F29A4U, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x17CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F29A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x180U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F29ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F29B0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002F29E0; }
        goto block_002F29BC;
    }
block_002F29BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F29BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F29BCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F29BCU, address);
            }
            r0 = value;
        }
        {
            r3 = r6;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000017CU;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F29D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F29D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F29D0;
    }
block_002F29D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F29D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F29D0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F29D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_002F29BC; }
        goto block_002F29E0;
    }
block_002F29E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F29E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F29E0U);
        }
        {
            const uint32_t updatedAddress = 0x002F29E8U + 0x154U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F29E0U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000118U;
        }
        {
            const uint32_t operand = 0x00000064U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F29F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_Memcpy_00371738(frame, context, state, 0x00371738U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F29F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F29F0;
    }
block_002F29F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F29F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F29F0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F29F0U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F29FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_c_stride_30_002FC3FC(frame, context, state, 0x002FC3FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F29FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F29FC;
    }
block_002F29FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F29FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F29FCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F29FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2A00U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2A0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_14_stride_20_002FC3F0(frame, context, state, 0x002FC3F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2A0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2A0C;
    }
block_002F2A0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2A0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2A0CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F2A0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2A10U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2A1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_18_stride_40_002FC3E4(frame, context, state, 0x002FC3E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2A1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2A1C;
    }
block_002F2A1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2A1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2A1CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F2A1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2A20U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x74U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002F2A24U, address);
            }
        }
        {
            r0 = Oot3dAotLsl(r0, 2U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F2A2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2A30U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            r0 = Oot3dAotLsl(r0, 1U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x78U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F2A3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002F2A48U + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2A40U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2A44U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2A48U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2A4CU, address);
            }
            r2 = value;
        }
        {
            r1 = 0x000001B8U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x002F2A58U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2A58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2A58;
    }
block_002F2A58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2A58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2A58U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000064U;
            r1 = r13 + operand;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2A64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStageState_ConstructFromDescriptor_00348F34(frame, context, state, 0x00348F34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2A64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2A64;
    }
block_002F2A64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2A64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2A64U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F2A64U, address);
            }
        }
        {
            r0 = 0x0000000DU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2A70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureDescriptor_GetBuiltin_002E11D0(frame, context, state, 0x002E11D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2A70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2A70;
    }
block_002F2A70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2A70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2A70U);
        }
        {
            const uint32_t updatedAddress = 0x002F2A78U + 0xD0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2A70U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x002F2A7CU + 0xC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2A74U, address);
            }
            r2 = value;
        }
        {
            r3 = r1;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F2A7CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F2A7CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F2A80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2A84U, address);
            }
            r12 = value;
        }
        {
            r2 = r0;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r12;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2A98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStage_ConfigureTextureUnit_00348A64(frame, context, state, 0x00348A64U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2A98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2A98;
    }
block_002F2A98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2A98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2A98U);
        }
        {
            const uint32_t updatedAddress = 0x002F2AA0U + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2A98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2A9CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_002F2ADC; }
        goto block_002F2AA8;
    }
block_002F2AA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2AA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2AA8U);
        }
        {
            const uint32_t updatedAddress = 0x002F2AB0U + 0x9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2AA8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2AB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2AB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2AB0;
    }
block_002F2AB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2AB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2AB0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002F2ADC; }
        goto block_002F2ABC;
    }
block_002F2ABC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2ABCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2ABCU);
        }
        {
            const uint32_t updatedAddress = 0x002F2AC4U + 0x8CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2ABCU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2AC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2AC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2AC4;
    }
block_002F2AC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2AC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2AC4U);
        }
        {
            const uint32_t updatedAddress = 0x002F2ACCU + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2AC4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x002F2AD0U + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2AC8U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x002F2AD8U + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2AD0U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_002F2ADC;
    }
block_002F2ADC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2ADCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2ADCU);
        }
        {
            const uint32_t updatedAddress = 0x002F2AE4U + 0x78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2ADCU, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2AE4U, address);
            }
            r1 = value;
        }
        {
            r2 = r3;
        }
        {
            const uint32_t updatedAddress = r0 + 0x47CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2AECU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2AF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererModelResource_Create_0034897C(frame, context, state, 0x0034897CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2AF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2AF4;
    }
block_002F2AF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2AF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2AF4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F2AF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2AF8U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 | 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F2B00U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F2B04U, address);
            }
            r0 = value;
        }
        {
            r1 = r1 | 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F2B0CU, address);
            }
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2B18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_ReleaseLocked_0033DDD4(frame, context, state, 0x0033DDD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2B18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2B18;
    }
block_002F2B18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2B18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2B18U);
        }
        {
            r0 = r8;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F2B24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_ReleaseLocked_0033DDD4(frame, context, state, 0x0033DDD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F2B24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F2B24;
    }
block_002F2B24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F2B24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F2B24U);
        }
        {
            const uint32_t operand = 0x00000364U;
            r13 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002F2B2CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002F2B2CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002F2B2CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002F2B2CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002F2B2CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F2B2CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F2B2CU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F2B2CU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002F2B2CU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_NameEntryGlyphOverlay_Init_002F48F8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002F48F8U:
        goto block_002F48F8;
    case 0x002F4920U:
        goto block_002F4920;
    case 0x002F4928U:
        goto block_002F4928;
    case 0x002F4940U:
        goto block_002F4940;
    case 0x002F4970U:
        goto block_002F4970;
    case 0x002F49CCU:
        goto block_002F49CC;
    case 0x002F49E4U:
        goto block_002F49E4;
    case 0x002F49F0U:
        goto block_002F49F0;
    case 0x002F4A10U:
        goto block_002F4A10;
    case 0x002F4A18U:
        goto block_002F4A18;
    case 0x002F4A2CU:
        goto block_002F4A2C;
    case 0x002F4A4CU:
        goto block_002F4A4C;
    case 0x002F4A5CU:
        goto block_002F4A5C;
    case 0x002F4A64U:
        goto block_002F4A64;
    case 0x002F4A70U:
        goto block_002F4A70;
    case 0x002F4A78U:
        goto block_002F4A78;
    case 0x002F4A90U:
        goto block_002F4A90;
    case 0x002F4AA4U:
        goto block_002F4AA4;
    case 0x002F4AC8U:
        goto block_002F4AC8;
    case 0x002F4AD4U:
        goto block_002F4AD4;
    case 0x002F4AECU:
        goto block_002F4AEC;
    case 0x002F4AF0U:
        goto block_002F4AF0;
    case 0x002F4B1CU:
        goto block_002F4B1C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002F48F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F48F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F48F8U);
        }
        {
            const uint32_t firstAddress = r13 - 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x002F48F8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F48F8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F48F8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F48F8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002F48F8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r5)) {
                return Oot3dAotMemoryFault(context, 0x002F48F8U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002F48F8U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r7)) {
                return Oot3dAotMemoryFault(context, 0x002F48F8U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002F48F8U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F48F8U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F48F8U,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F48F8U,
                                           firstAddress + 44U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 48U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002F48F8U,
                                           firstAddress + 48U);
            }
            r13 = r13 - 52U;
        }
        {
            r4 = r0;
        }
        {
            r8 = r2;
        }
        {
            r9 = r3;
        }
        {
            const uint32_t updatedAddress = 0x002F4910U + 0x220U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4908U, address);
            }
            r2 = value;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x002F490CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x002F490CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x0000012CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F4914U, address);
            }
        }
        {
            r0 = 0x000001C4U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F4920U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F4920U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F4920;
    }
block_002F4920:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4920U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4920U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x002F4928U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererResourceArrayOwner_Construct_002E77E8(frame, context, state, 0x002E77E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F4928U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F4928;
    }
block_002F4928:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4928U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4928U);
        }
        {
            r3 = 0x00000100U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F492CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000038U;
            r1 = r4 + operand;
        }
        {
            r2 = r3;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F4938U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F4940U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererResourceOwner_Build_002E76B8(frame, context, state, 0x002E76B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F4940U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F4940;
    }
block_002F4940:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4940U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4940U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t address = 0x002F494CU + 488U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4944U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x002F4950U + 488U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4948U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F494CU, address);
            }
        }
        {
            const uint32_t address = r4 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F4950U, address);
            }
        }
        {
            const uint32_t address = r4 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F4954U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = 0x002F4964U + 0x1D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F495CU, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = 0x002F4968U + 0x1DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4960U, address);
            }
            r7 = value;
        }
        {
            const uint32_t address = 0x002F496CU + 468U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4964U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r5 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00002600U;
            r11 = r0 + operand;
        }
        goto block_002F4970;
    }
block_002F4970:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4970U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4970U);
        }
        {
            frame.Guest.vfp[2] = r9;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F4978U, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r2 = r13 + operand;
        }
        {
            r1 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F4984U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F4988U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F498CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F4990U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x138U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4994U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F499CU, 0xEE710A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F49A0U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r3 = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[1] = r8;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F49ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F49B0U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F49B4U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F49B8U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F49BCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r3 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F49CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002df6ac_002DF6AC(frame, context, state, 0x002DF6ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F49CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F49CC;
    }
block_002F49CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F49CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F49CCU);
        }
        {
            const uint32_t updatedAddress = 0x002F49D4U + 0x174U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F49CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F49D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F49D4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F49D8U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x000001B8U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x002F49E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F49E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F49E4;
    }
block_002F49E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F49E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F49E4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000014U;
            r1 = r13 + operand;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x002F49F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStageState_ConstructFromDescriptor_00348F34(frame, context, state, 0x00348F34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F49F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F49F0;
    }
block_002F49F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F49F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F49F0U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 2U);
            r6 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F49F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002F4A00U + 0x14CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F49F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F49FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A00U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A04U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000054U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x002F4A10U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F4A10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F4A10;
    }
block_002F4A10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4A10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4A10U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x002F4A18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererScratchStateEE4_Init_002FFA20(frame, context, state, 0x002FFA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F4A18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F4A18;
    }
block_002F4A18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4A18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4A18U);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + Oot3dAotLsl(r5, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F4A1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A20U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F4A2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureSlot_BuildFromOwner_002CCF04(frame, context, state, 0x002CCF04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F4A2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F4A2C;
    }
block_002F4A2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4A2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4A2CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002F4A2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x002F4A30U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002F4A34U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + Oot3dAotLsl(r5, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A38U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A3CU, address);
            }
            r0 = value;
        }
        {
            r3 = r11;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F4A4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStage_ConfigureTextureUnit_00348A64(frame, context, state, 0x00348A64U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F4A4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F4A4C;
    }
block_002F4A4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4A4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4A4CU);
        }
        {
            const uint32_t updatedAddress = 0x002F4A54U + 0xFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A4CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A50U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_002F4A90; }
        goto block_002F4A5C;
    }
block_002F4A5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4A5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4A5CU);
        }
        {
            const uint32_t updatedAddress = 0x002F4A64U + 0xECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A5CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F4A64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F4A64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F4A64;
    }
block_002F4A64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4A64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4A64U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002F4A90; }
        goto block_002F4A70;
    }
block_002F4A70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4A70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4A70U);
        }
        {
            const uint32_t updatedAddress = 0x002F4A78U + 0xDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A70U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F4A78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F4A78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F4A78;
    }
block_002F4A78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4A78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4A78U);
        }
        {
            const uint32_t updatedAddress = 0x002F4A80U + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A78U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x002F4A84U + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A7CU, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x002F4A8CU + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A84U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_002F4A90;
    }
block_002F4A90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4A90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4A90U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x47CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A94U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4A98U, address);
            }
            r1 = value;
        }
        {
            r2 = r3;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F4AA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererModelResource_Create_0034897C(frame, context, state, 0x0034897CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F4AA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F4AA4;
    }
block_002F4AA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4AA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4AA4U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r6 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F4AA8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4AACU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r1 = r1 | 0x00000002U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F4AC0U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_002F4970; }
        goto block_002F4AC8;
    }
block_002F4AC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4AC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4AC8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4AC8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F4AD4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererStreamBuffer_GetColorWriteAddress_002DF594(frame, context, state, 0x002DF594U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F4AD4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F4AD4;
    }
block_002F4AD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4AD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4AD4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4AD4U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r2 + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4ADCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4AE0U, address);
            }
            r2 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r2, 0U, 2U, flags.C());
            r2 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r2, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_002F4B1C; }
        goto block_002F4AEC;
    }
block_002F4AEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4AECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4AECU);
        }
        {
            const uint32_t address = 0x002F4AF4U + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4AECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_002F4AF0;
    }
block_002F4AF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4AF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4AF0U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r2 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t address = r2 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F4AF8U, address);
            }
        }
        {
            const uint32_t address = r2 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F4AFCU, address);
            }
        }
        {
            const uint32_t address = r2 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F4B00U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4B04U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4B08U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F4B0CU, address);
            }
            r2 = value;
        }
        {
            r2 = Oot3dAotLsl(r2, 2U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_002F4AF0; }
        goto block_002F4B1C;
    }
block_002F4B1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F4B1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F4B1CU);
        }
        {
            const uint32_t operand = 0x0000012CU;
            r13 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002F4B24U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F4B24U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t operand = 0x00000010U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002F4B2CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002F4B2CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002F4B2CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002F4B2CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002F4B2CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F4B2CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F4B2CU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F4B2CU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002F4B2CU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_PauseMapOverlay_Init_002F57F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002F57F0U:
        goto block_002F57F0;
    case 0x002F5820U:
        goto block_002F5820;
    case 0x002F5828U:
        goto block_002F5828;
    case 0x002F5840U:
        goto block_002F5840;
    case 0x002F5868U:
        goto block_002F5868;
    case 0x002F5894U:
        goto block_002F5894;
    case 0x002F58C8U:
        goto block_002F58C8;
    case 0x002F58E4U:
        goto block_002F58E4;
    case 0x002F58F0U:
        goto block_002F58F0;
    case 0x002F5914U:
        goto block_002F5914;
    case 0x002F592CU:
        goto block_002F592C;
    case 0x002F5938U:
        goto block_002F5938;
    case 0x002F5958U:
        goto block_002F5958;
    case 0x002F5964U:
        goto block_002F5964;
    case 0x002F596CU:
        goto block_002F596C;
    case 0x002F5970U:
        goto block_002F5970;
    case 0x002F5980U:
        goto block_002F5980;
    case 0x002F59A4U:
        goto block_002F59A4;
    case 0x002F59B4U:
        goto block_002F59B4;
    case 0x002F59BCU:
        goto block_002F59BC;
    case 0x002F59C8U:
        goto block_002F59C8;
    case 0x002F59D0U:
        goto block_002F59D0;
    case 0x002F59E8U:
        goto block_002F59E8;
    case 0x002F59FCU:
        goto block_002F59FC;
    case 0x002F5A14U:
        goto block_002F5A14;
    case 0x002F5A20U:
        goto block_002F5A20;
    case 0x002F5A38U:
        goto block_002F5A38;
    case 0x002F5A3CU:
        goto block_002F5A3C;
    case 0x002F5A68U:
        goto block_002F5A68;
    case 0x002F5A6CU:
        goto block_002F5A6C;
    case 0x002F5A98U:
        goto block_002F5A98;
    case 0x002F5AB0U:
        goto block_002F5AB0;
    case 0x002F5ABCU:
        goto block_002F5ABC;
    case 0x002F5AD8U:
        goto block_002F5AD8;
    case 0x002F5AE4U:
        goto block_002F5AE4;
    case 0x002F5AECU:
        goto block_002F5AEC;
    case 0x002F5AF0U:
        goto block_002F5AF0;
    case 0x002F5B00U:
        goto block_002F5B00;
    case 0x002F5B28U:
        goto block_002F5B28;
    case 0x002F5B34U:
        goto block_002F5B34;
    case 0x002F5B6CU:
        goto block_002F5B6C;
    case 0x002F5B78U:
        goto block_002F5B78;
    case 0x002F5B80U:
        goto block_002F5B80;
    case 0x002F5B8CU:
        goto block_002F5B8C;
    case 0x002F5B94U:
        goto block_002F5B94;
    case 0x002F5BACU:
        goto block_002F5BAC;
    case 0x002F5BC0U:
        goto block_002F5BC0;
    case 0x002F5C0CU:
        goto block_002F5C0C;
    case 0x002F5C64U:
        goto block_002F5C64;
    case 0x002F5C84U:
        goto block_002F5C84;
    case 0x002F5CA8U:
        goto block_002F5CA8;
    case 0x002F5CB4U:
        goto block_002F5CB4;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002F57F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F57F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F57F0U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002F57F0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x002F57F0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002F57F0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x002F57F0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002F57F0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F57F0U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F57F0U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F57F0U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002F57F0U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r7 = r3;
        }
        {
            r9 = r2;
        }
        {
            r10 = r1;
        }
        {
            const uint32_t updatedAddress = 0x002F580CU + 0x40CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5804U, address);
            }
            r2 = value;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x002F5808U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x002F5808U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x002F5808U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x002F5808U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000174U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5810U, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F5814U, address);
            }
        }
        {
            r0 = 0x000001C4U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5820U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5820U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5820;
    }
block_002F5820:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5820U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5820U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5828U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererResourceArrayOwner_Construct_002E77E8(frame, context, state, 0x002E77E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5828U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5828;
    }
block_002F5828:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5828U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5828U);
        }
        {
            r3 = 0x00000100U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F582CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000038U;
            r1 = r4 + operand;
        }
        {
            r2 = r3;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F5838U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5840U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererResourceOwner_Build_002E76B8(frame, context, state, 0x002E76B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5840U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5840;
    }
block_002F5840:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5840U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5840U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = 0x002F584CU + 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5844U, address);
            }
            r11 = value;
        }
        {
            const uint32_t updatedAddress = 0x002F5850U + 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5848U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x002F5854U + 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F584CU, address);
            }
            r8 = value;
        }
        {
            const uint32_t address = 0x002F5858U + 976U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5850U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x002F585CU + 976U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5854U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        if (!(flags.Z())) {
            r3 = 0x00000002U;
        }
        if (!(flags.Z())) {
            r5 = 0x00000000U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F5860U, address);
            }
        }
        if (!(flags.Z())) { goto block_002F5A6C; }
        goto block_002F5868;
    }
block_002F5868:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5868U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5868U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t address = 0x002F5878U + 952U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5870U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F5874U, address);
            }
        }
        {
            const uint32_t address = r4 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002F5878U, address);
            }
        }
        {
            const uint32_t address = 0x002F5884U + 944U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F587CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        {
            const uint32_t address = 0x002F588CU + 940U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5884U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = r4 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002F5888U, address);
            }
        }
        {
            r5 = r3;
        }
        {
            r11 = r1;
        }
        goto block_002F5894;
    }
block_002F5894:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5894U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5894U);
        }
        {
            frame.Guest.vfp[2] = r7;
        }
        {
            const uint32_t operand = 0x00000900U;
            r0 = r10 - operand;
        }
        {
            const uint32_t operand = 0x0000004FU;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x0000005CU;
            r2 = r13 + operand;
        }
        {
            r1 = 0x00000010U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F58ACU, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            r0 = 0x00000100U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x002F58B4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F58B4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F58B4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F58B4U,
                                           firstAddress + 12U);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F58B8U, 0xEE710A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F58BCU, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r3 = frame.Guest.vfp[1];
        }
        if (flags.Z()) { goto block_002F58F0; }
        goto block_002F58C8;
    }
block_002F58C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F58C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F58C8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F58C8U, 0xEE300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F58CCU, address);
            }
            r0 = value;
        }
        {
            r1 = r10;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F58D4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F58E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererResourceOwner_BuildGeneratedTexture_003446E8(frame, context, state, 0x003446E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F58E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F58E4;
    }
block_002F58E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F58E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F58E4U);
        }
        {
        }
        {
        }
        goto block_002F5914;
    }
block_002F58F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F58F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F58F0U);
        }
        {
            frame.Guest.vfp[1] = r9;
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F58F4U, address);
            }
            r0 = value;
        }
        {
            r1 = r10;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F58FCU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F5900U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F5904U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5914U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererResourceOwner_BuildGeneratedTexture_003446E8(frame, context, state, 0x003446E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5914U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5914;
    }
block_002F5914:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5914U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5914U);
        }
        {
            const uint32_t updatedAddress = 0x002F591CU + 0x320U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5914U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5918U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F591CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5920U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x000001B8U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x002F592CU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F592CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F592C;
    }
block_002F592C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F592CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F592CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x0000005CU;
            r1 = r13 + operand;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5938U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStageState_ConstructFromDescriptor_00348F34(frame, context, state, 0x00348F34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5938U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5938;
    }
block_002F5938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5938U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 2U);
            r6 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F593CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002F5948U + 0x2D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5940U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5944U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5948U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F594CU, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000054U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x002F5958U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5958U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5958;
    }
block_002F5958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5958U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r1 = 0x00000000U;
        }
        if (flags.Z()) { goto block_002F5970; }
        goto block_002F5964;
    }
block_002F5964:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5964U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5964U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F596CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererScratchStateEE4_Init_002FFA20(frame, context, state, 0x002FFA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F596CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F596C;
    }
block_002F596C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F596CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F596CU);
        }
        {
            r1 = r0;
        }
        goto block_002F5970;
    }
block_002F5970:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5970U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5970U);
        }
        {
            const uint32_t updatedAddress = r4 + Oot3dAotLsl(r5, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F5970U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5974U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5980U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureSlot_BuildFromOwner_002CCF04(frame, context, state, 0x002CCF04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5980U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5980;
    }
block_002F5980:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5980U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5980U);
        }
        {
            const uint32_t updatedAddress = 0x002F5988U + 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5980U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x002F5984U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x002F5988U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x002F598CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + Oot3dAotLsl(r5, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5990U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5994U, address);
            }
            r0 = value;
        }
        {
            r3 = r12;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F59A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStage_ConfigureTextureUnit_00348A64(frame, context, state, 0x00348A64U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F59A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F59A4;
    }
block_002F59A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F59A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F59A4U);
        }
        {
            const uint32_t updatedAddress = 0x002F59ACU + 0x298U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F59A4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F59A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_002F59E8; }
        goto block_002F59B4;
    }
block_002F59B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F59B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F59B4U);
        }
        {
            const uint32_t updatedAddress = 0x002F59BCU + 0x288U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F59B4U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F59BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F59BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F59BC;
    }
block_002F59BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F59BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F59BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002F59E8; }
        goto block_002F59C8;
    }
block_002F59C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F59C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F59C8U);
        }
        {
            const uint32_t updatedAddress = 0x002F59D0U + 0x278U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F59C8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F59D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F59D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F59D0;
    }
block_002F59D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F59D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F59D0U);
        }
        {
            const uint32_t updatedAddress = 0x002F59D8U + 0x274U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F59D0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x002F59DCU + 0x274U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F59D4U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x002F59E4U + 0x260U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F59DCU, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_002F59E8;
    }
block_002F59E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F59E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F59E8U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r8 + 0x47CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F59ECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F59F0U, address);
            }
            r1 = value;
        }
        {
            r2 = r3;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F59FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererModelResource_Create_0034897C(frame, context, state, 0x0034897CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F59FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F59FC;
    }
block_002F59FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F59FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F59FCU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r6 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F5A08U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        if ((flags.N()) != (flags.V())) { goto block_002F5894; }
        goto block_002F5A14;
    }
block_002F5A14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5A14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5A14U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5A14U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5A20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererStreamBuffer_GetColorWriteAddress_002DF594(frame, context, state, 0x002DF594U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5A20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5A20;
    }
block_002F5A20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5A20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5A20U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5A20U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r2 + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5A28U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5A2CU, address);
            }
            r2 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r2, 0U, 2U, flags.C());
            r2 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r2, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_002F5CB4; }
        goto block_002F5A38;
    }
block_002F5A38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5A38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5A38U);
        }
        {
            const uint32_t address = 0x002F5A40U + 532U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5A38U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_002F5A3C;
    }
block_002F5A3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5A3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5A3CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r2 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t address = r2 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F5A44U, address);
            }
        }
        {
            const uint32_t address = r2 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F5A48U, address);
            }
        }
        {
            const uint32_t address = r2 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F5A4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5A50U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5A54U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5A58U, address);
            }
            r2 = value;
        }
        {
            r2 = Oot3dAotLsl(r2, 2U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_002F5A3C; }
        goto block_002F5A68;
    }
block_002F5A68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5A68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5A68U);
        }
        goto block_002F5CB4;
    }
block_002F5A6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5A6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5A6CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x0000005CU;
            r2 = r13 + operand;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = 0x00000100U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x002F5A7CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F5A7CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F5A7CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F5A7CU,
                                           firstAddress + 12U);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5A84U, address);
            }
            r0 = value;
        }
        {
            r3 = r7;
        }
        {
            r2 = r9;
        }
        {
            r1 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5A98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererResourceOwner_BuildGeneratedTexture_003446E8(frame, context, state, 0x003446E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5A98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5A98;
    }
block_002F5A98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5A98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5A98U);
        }
        {
            const uint32_t updatedAddress = 0x002F5AA0U + 0x19CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5A98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5A9CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5AA0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5AA4U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x000001B8U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x002F5AB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5AB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5AB0;
    }
block_002F5AB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5AB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5AB0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x0000005CU;
            r1 = r13 + operand;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5ABCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStageState_ConstructFromDescriptor_00348F34(frame, context, state, 0x00348F34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5ABCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5ABC;
    }
block_002F5ABC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5ABCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5ABCU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 2U);
            r6 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F5AC0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5AC4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5AC8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5ACCU, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000054U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x002F5AD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5AD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5AD8;
    }
block_002F5AD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5AD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5AD8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r1 = 0x00000000U;
        }
        if (flags.Z()) { goto block_002F5AF0; }
        goto block_002F5AE4;
    }
block_002F5AE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5AE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5AE4U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5AECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererScratchStateEE4_Init_002FFA20(frame, context, state, 0x002FFA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5AECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5AEC;
    }
block_002F5AEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5AECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5AECU);
        }
        {
            r1 = r0;
        }
        goto block_002F5AF0;
    }
block_002F5AF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5AF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5AF0U);
        }
        {
            const uint32_t updatedAddress = r4 + Oot3dAotLsl(r5, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F5AF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5AF4U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5B00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureSlot_BuildFromOwner_002CCF04(frame, context, state, 0x002CCF04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5B00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5B00;
    }
block_002F5B00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5B00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5B00U);
        }
        {
            const uint32_t updatedAddress = 0x002F5B08U + 0x118U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5B00U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x002F5B0CU + 0x134U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5B04U, address);
            }
            r12 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F5B0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x002F5B10U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F5B14U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + Oot3dAotLsl(r5, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5B18U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5B1CU, address);
            }
            r0 = value;
        }
        {
            r3 = r12;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5B28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStage_ConfigureTextureUnit_00348A64(frame, context, state, 0x00348A64U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5B28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5B28;
    }
block_002F5B28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5B28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5B28U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_002F5A6C; }
        goto block_002F5B34;
    }
block_002F5B34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5B34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5B34U);
        }
        {
            const uint32_t updatedAddress = 0x002F5B3CU + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5B34U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000038U;
            r10 = r13 + operand;
        }
        {
            const uint32_t address = 0x002F5B44U + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5B3CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002F5B40U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F5B40U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F5B40U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F5B40U,
                                           firstAddress + 12U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002F5B40U,
                                           firstAddress + 16U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002F5B40U,
                                           firstAddress + 20U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F5B40U,
                                           firstAddress + 24U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x002F5B40U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x002F5B40U,
                                           firstAddress + 32U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r5 = value5;
            r6 = value6;
            r11 = value11;
            r12 = value12;
            r14 = value14;
        }
        {
            const uint32_t firstAddress = r10;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x002F5B44U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F5B44U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F5B44U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F5B44U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r5)) {
                return Oot3dAotMemoryFault(context, 0x002F5B44U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002F5B44U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F5B44U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r12)) {
                return Oot3dAotMemoryFault(context, 0x002F5B44U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002F5B44U,
                                           firstAddress + 32U);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r11 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = 0x002F5B54U + 0x108U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5B4CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F5B50U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F5B50U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F5B50U,
                                           firstAddress + 8U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002F5B50U,
                                           firstAddress + 12U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002F5B50U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x002F5B50U,
                                           firstAddress + 20U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x002F5B50U,
                                           firstAddress + 24U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r5 = value5;
            r6 = value6;
            r12 = value12;
            r14 = value14;
            r0 = r0 + 28U;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F5B54U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F5B54U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002F5B54U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r5)) {
                return Oot3dAotMemoryFault(context, 0x002F5B54U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002F5B54U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r12)) {
                return Oot3dAotMemoryFault(context, 0x002F5B54U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002F5B54U,
                                           firstAddress + 24U);
            }
            r11 = r11 + 28U;
        }
        {
            r5 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F5B5CU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F5B5CU,
                                           firstAddress + 4U);
            }
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t updatedAddress = 0x002F5B68U + 0xDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5B60U, address);
            }
            r6 = value;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F5B64U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F5B64U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r11 = r11 - operand;
        }
        goto block_002F5B6C;
    }
block_002F5B6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5B6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5B6CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5B6CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_002F5BAC; }
        goto block_002F5B78;
    }
block_002F5B78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5B78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5B78U);
        }
        {
            const uint32_t updatedAddress = 0x002F5B80U + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5B78U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5B80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5B80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5B80;
    }
block_002F5B80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5B80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5B80U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002F5BAC; }
        goto block_002F5B8C;
    }
block_002F5B8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5B8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5B8CU);
        }
        {
            const uint32_t updatedAddress = 0x002F5B94U + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5B8CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5B94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5B94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5B94;
    }
block_002F5B94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5B94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5B94U);
        }
        {
            const uint32_t updatedAddress = 0x002F5B9CU + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5B94U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x002F5BA0U + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5B98U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x002F5BA8U + 0x9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5BA0U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_002F5BAC;
    }
block_002F5BAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5BACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5BACU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r8 + 0x47CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5BB0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5BB4U, address);
            }
            r1 = value;
        }
        {
            r2 = r3;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F5BC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererModelResource_Create_0034897C(frame, context, state, 0x0034897CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F5BC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F5BC0;
    }
block_002F5BC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5BC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5BC0U);
        }
        {
            frame.Guest.vfp[1] = r9;
        }
        {
            frame.Guest.vfp[2] = r7;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 2U);
            r2 = r10 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F5BD0U, address);
            }
        }
        {
            const uint32_t address = r2 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5BD4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F5BD8U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F5BDCU, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 2U);
            r2 = r11 + operand;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F5BECU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5BF0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002F5BF4U, 0xEE700A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002F5BFCU, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002F5C00U, address);
            }
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F5C04U, address);
            }
        }
        if (!(flags.Z())) { goto block_002F5C84; }
        goto block_002F5C0C;
    }
block_002F5C0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5C0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5C0CU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        goto block_002F5C64;
    }
block_002F5C64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5C64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5C64U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5C64U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r0 + 240U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002F5C70U, address);
            }
        }
        {
            const uint32_t address = r0 + 244U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F5C74U, address);
            }
        }
        {
            const uint32_t address = r0 + 248U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002F5C78U, address);
            }
        }
        {
            const uint32_t address = r0 + 252U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x002F5C7CU, address);
            }
        }
        goto block_002F5CA8;
    }
block_002F5C84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5C84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5C84U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F5C88U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            const uint32_t address = r0 + 240U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002F5C98U, address);
            }
        }
        {
            const uint32_t address = r0 + 244U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x002F5C9CU, address);
            }
        }
        {
            const uint32_t address = r0 + 248U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002F5CA0U, address);
            }
        }
        {
            const uint32_t address = r0 + 252U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F5CA4U, address);
            }
        }
        goto block_002F5CA8;
    }
block_002F5CA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5CA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5CA8U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_002F5B6C; }
        goto block_002F5CB4;
    }
block_002F5CB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F5CB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F5CB4U);
        }
        {
            const uint32_t operand = 0x00000174U;
            r13 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002F5CBCU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F5CBCU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F5CBCU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F5CBCU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002F5CC0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002F5CC0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002F5CC0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002F5CC0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002F5CC0U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F5CC0U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F5CC0U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F5CC0U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002F5CC0U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_PauseIconGroup_Init_002F8EE4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002F8EE4U:
        goto block_002F8EE4;
    case 0x002F8F1CU:
        goto block_002F8F1C;
    case 0x002F8F24U:
        goto block_002F8F24;
    case 0x002F8F34U:
        goto block_002F8F34;
    case 0x002F8F4CU:
        goto block_002F8F4C;
    case 0x002F8F64U:
        goto block_002F8F64;
    case 0x002F8F74U:
        goto block_002F8F74;
    case 0x002F8F80U:
        goto block_002F8F80;
    case 0x002F8F98U:
        goto block_002F8F98;
    case 0x002F8FA8U:
        goto block_002F8FA8;
    case 0x002F8FE0U:
        goto block_002F8FE0;
    case 0x002F8FF0U:
        goto block_002F8FF0;
    case 0x002F8FFCU:
        goto block_002F8FFC;
    case 0x002F900CU:
        goto block_002F900C;
    case 0x002F901CU:
        goto block_002F901C;
    case 0x002F9064U:
        goto block_002F9064;
    case 0x002F9070U:
        goto block_002F9070;
    case 0x002F907CU:
        goto block_002F907C;
    case 0x002F90A4U:
        goto block_002F90A4;
    case 0x002F90B4U:
        goto block_002F90B4;
    case 0x002F90BCU:
        goto block_002F90BC;
    case 0x002F90C8U:
        goto block_002F90C8;
    case 0x002F90D0U:
        goto block_002F90D0;
    case 0x002F90E8U:
        goto block_002F90E8;
    case 0x002F9100U:
        goto block_002F9100;
    case 0x002F912CU:
        goto block_002F912C;
    case 0x002F9144U:
        goto block_002F9144;
    case 0x002F9158U:
        goto block_002F9158;
    case 0x002F9174U:
        goto block_002F9174;
    case 0x002F917CU:
        goto block_002F917C;
    case 0x002F9188U:
        goto block_002F9188;
    case 0x002F9190U:
        goto block_002F9190;
    case 0x002F91A8U:
        goto block_002F91A8;
    case 0x002F91C0U:
        goto block_002F91C0;
    case 0x002F91C8U:
        goto block_002F91C8;
    case 0x002F91D4U:
        goto block_002F91D4;
    case 0x002F9204U:
        goto block_002F9204;
    case 0x002F9210U:
        goto block_002F9210;
    case 0x002F9220U:
        goto block_002F9220;
    case 0x002F9230U:
        goto block_002F9230;
    case 0x002F927CU:
        goto block_002F927C;
    case 0x002F928CU:
        goto block_002F928C;
    case 0x002F9298U:
        goto block_002F9298;
    case 0x002F92A4U:
        goto block_002F92A4;
    case 0x002F92ACU:
        goto block_002F92AC;
    case 0x002F92D4U:
        goto block_002F92D4;
    case 0x002F92E4U:
        goto block_002F92E4;
    case 0x002F92F0U:
        goto block_002F92F0;
    case 0x002F92FCU:
        goto block_002F92FC;
    case 0x002F9304U:
        goto block_002F9304;
    case 0x002F9310U:
        goto block_002F9310;
    case 0x002F9334U:
        goto block_002F9334;
    case 0x002F9358U:
        goto block_002F9358;
    case 0x002F9364U:
        goto block_002F9364;
    case 0x002F9388U:
        goto block_002F9388;
    case 0x002F9398U:
        goto block_002F9398;
    case 0x002F93A4U:
        goto block_002F93A4;
    case 0x002F93ACU:
        goto block_002F93AC;
    case 0x002F93F0U:
        goto block_002F93F0;
    case 0x002F940CU:
        goto block_002F940C;
    case 0x002F9414U:
        goto block_002F9414;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002F8EE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F8EE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F8EE4U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002F8EE4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x002F8EE4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002F8EE4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x002F8EE4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002F8EE4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002F8EE4U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002F8EE4U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002F8EE4U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002F8EE4U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r10 = 0x00000000U;
        }
        {
            r11 = r3;
        }
        {
            const uint32_t address = 0x002F8EFCU + 832U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F8EF4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x002F8EF8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x002F8EF8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x002F8EF8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x002F8EF8U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000134U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x224U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F8F00U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x428U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F8F04U, address);
            }
        }
        {
            const uint32_t address = r0 + 536U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F8F08U, address);
            }
        }
        {
            const uint32_t address = r0 + 540U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002F8F0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x42CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002F8F10U, address);
            }
        }
        {
            r0 = 0x00000020U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F8F1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F8F1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F8F1C;
    }
block_002F8F1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F8F1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F8F1CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002F8F34; }
        goto block_002F8F24;
    }
block_002F8F24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F8F24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F8F24U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F8F24U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x002F8F30U + 784U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F8F28U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F8F34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_Init_002FC694(frame, context, state, 0x002FC694U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F8F34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F8F34;
    }
block_002F8F34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F8F34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F8F34U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x10CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F8F34U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F8F38U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x002F8F44U + 768U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F8F3CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r5 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002F8F74; }
        goto block_002F8F4C;
    }
block_002F8F4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F8F4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F8F4CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r4 + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F8F50U, address);
            }
            r0 = value;
        }
        {
            r2 = r5;
        }
        {
            r1 = 0x00000001U;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F8F64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaRange_002F8B80(frame, context, state, 0x002F8B80U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F8F64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F8F64;
    }
block_002F8F64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F8F64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F8F64U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F8F64U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r5, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_002F8F4C; }
        goto block_002F8F74;
    }
block_002F8F74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F8F74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F8F74U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            r0 = Oot3dAotLsl(r0, 2U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F8F80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_AllocateLocked_0033DE14(frame, context, state, 0x0033DE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F8F80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F8F80;
    }
block_002F8F80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F8F80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F8F80U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F8F80U, address);
            }
            r3 = value;
        }
        {
            r6 = r0;
        }
        {
            r7 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r8 = 0x00000002U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002F8FE0; }
        goto block_002F8F98;
    }
block_002F8F98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F8F98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F8F98U);
        }
        {
            r5 = r6;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 16U);
            r12 = operand - r7;
        }
        {
            r9 = 0x00000003U;
        }
        goto block_002F8FA8;
    }
block_002F8FA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F8FA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F8FA8U);
        }
        {
            r0 = r12 & Oot3dAotLsl(r1, 2U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F8FACU, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r2 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F8FB8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F8FBCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F8FC0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F8FC4U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r9 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F8FCCU, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r3, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r3 = r3 - operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        if (!(flags.Z())) { goto block_002F8FA8; }
        goto block_002F8FE0;
    }
block_002F8FE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F8FE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F8FE0U);
        }
        {
            const uint32_t updatedAddress = 0x002F8FE8U + 0x260U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F8FE0U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000118U;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F8FF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_Memcpy_00371738(frame, context, state, 0x00371738U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F8FF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F8FF0;
    }
block_002F8FF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F8FF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F8FF0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F8FF0U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F8FFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_c_stride_30_002FC3FC(frame, context, state, 0x002FC3FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F8FFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F8FFC;
    }
block_002F8FFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F8FFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F8FFCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F8FFCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9000U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F900CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_14_stride_20_002FC3F0(frame, context, state, 0x002FC3F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F900CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F900C;
    }
block_002F900C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F900CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F900CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F900CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9010U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F901CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_18_stride_40_002FC3E4(frame, context, state, 0x002FC3E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F901CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F901C;
    }
block_002F901C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F901CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F901CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F901CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9020U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002F9024U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r11, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r0 = Oot3dAotLsl(r0, 2U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F9030U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9034U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            r0 = Oot3dAotLsl(r0, 1U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F9040U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002F904CU + 0x200U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9044U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x220U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x002F9048U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002F904CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9050U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9054U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9058U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x000001B8U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x002F9064U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F9064U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F9064;
    }
block_002F9064:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9064U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9064U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x0000001CU;
            r1 = r13 + operand;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x002F9070U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStageState_ConstructFromDescriptor_00348F34(frame, context, state, 0x00348F34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F9070U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F9070;
    }
block_002F9070:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9070U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9070U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F9070U, address);
            }
        }
        {
            r0 = 0x0000000AU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F907CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureDescriptor_GetBuiltin_002E11D0(frame, context, state, 0x002E11D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F907CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F907C;
    }
block_002F907C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F907CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F907CU);
        }
        {
            const uint32_t updatedAddress = 0x002F9084U + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F907CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x002F9088U + 0x1C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9080U, address);
            }
            r2 = value;
        }
        {
            r3 = r1;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x002F9088U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002F9088U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F908CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9090U, address);
            }
            r12 = value;
        }
        {
            r2 = r0;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r12;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F90A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStage_ConfigureTextureUnit_00348A64(frame, context, state, 0x00348A64U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F90A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F90A4;
    }
block_002F90A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F90A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F90A4U);
        }
        {
            const uint32_t updatedAddress = 0x002F90ACU + 0x1ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F90A4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F90A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_002F90E8; }
        goto block_002F90B4;
    }
block_002F90B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F90B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F90B4U);
        }
        {
            const uint32_t updatedAddress = 0x002F90BCU + 0x19CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F90B4U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F90BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F90BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F90BC;
    }
block_002F90BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F90BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F90BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002F90E8; }
        goto block_002F90C8;
    }
block_002F90C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F90C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F90C8U);
        }
        {
            const uint32_t updatedAddress = 0x002F90D0U + 0x18CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F90C8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F90D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F90D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F90D0;
    }
block_002F90D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F90D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F90D0U);
        }
        {
            const uint32_t updatedAddress = 0x002F90D8U + 0x188U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F90D0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x002F90DCU + 0x188U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F90D4U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x002F90E4U + 0x174U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F90DCU, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_002F90E8;
    }
block_002F90E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F90E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F90E8U);
        }
        {
            const uint32_t updatedAddress = 0x002F90F0U + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F90E8U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F90F0U, address);
            }
            r1 = value;
        }
        {
            r2 = r3;
        }
        {
            const uint32_t updatedAddress = r0 + 0x47CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F90F8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F9100U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererModelResource_Create_0034897C(frame, context, state, 0x0034897CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F9100U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F9100;
    }
block_002F9100:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9100U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9100U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F9100U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9104U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000040U;
        }
        {
            r3 = ~(0x00000000U);
        }
        {
            r1 = r1 | 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F9114U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9118U, address);
            }
            r0 = value;
        }
        {
            r1 = r1 | 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F9120U, address);
            }
        }
        {
            const uint32_t operand = 0x00000328U;
            r0 = r4 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        goto block_002F912C;
    }
block_002F912C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F912CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F912CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F912CU, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r12 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r2 = r2 - operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002F913CU, address);
            }
        }
        if (!(flags.Z())) { goto block_002F912C; }
        goto block_002F9144;
    }
block_002F9144:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9144U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9144U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9144U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x002F9150U + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9148U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r5 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002F91A8; }
        goto block_002F9158;
    }
block_002F9158:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9158U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9158U);
        }
        {
            const uint32_t operand = r5;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x434U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002F915CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x428U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9160U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r4 + 0x220U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9168U, address);
            }
            r0 = value;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002F9190; }
        goto block_002F9174;
    }
block_002F9174:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9174U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9174U);
        }
        {
            r0 = 0x00000014U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F917CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F917CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F917C;
    }
block_002F917C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F917CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F917CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r1 = 0x00000000U;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x002F9188U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseCounter_Construct_002DB6A0(frame, context, state, 0x002DB6A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F9188U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F9188;
    }
block_002F9188:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9188U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9188U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F918CU, address);
            }
        }
        goto block_002F9190;
    }
block_002F9190:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9190U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9190U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x002F9198U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F919CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r5, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_002F9158; }
        goto block_002F91A8;
    }
block_002F91A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F91A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F91A8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x428U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F91A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x002F91B4U + 0xC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F91ACU, address);
            }
            r5 = value;
        }
        {
            const uint32_t address = 0x002F91B8U + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F91B0U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002F92A4; }
        goto block_002F91C0;
    }
block_002F91C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F91C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F91C0U);
        }
        {
            r0 = 0x00000014U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F91C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F91C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F91C8;
    }
block_002F91C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F91C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F91C8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r1 = 0x00000000U;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x002F91D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseCounter_Construct_002DB6A0(frame, context, state, 0x002DB6A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F91D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F91D4;
    }
block_002F91D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F91D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F91D4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F91D4U, address);
            }
        }
        {
            const uint32_t address = r4 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x002F91D8U, address);
            }
        }
        {
            r3 = 0x0000002AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x434U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x002F91E0U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F91E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F91ECU, address);
            }
        }
        {
            r3 = 0x000000C5U;
        }
        {
            r2 = r5;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F9204U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_SetSlotRect_002E6CD4(frame, context, state, 0x002E6CD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F9204U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F9204;
    }
block_002F9204:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9204U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9204U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x428U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9204U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002F927C; }
        goto block_002F9210;
    }
block_002F9210:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9210U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9210U);
        }
        {
            const uint32_t updatedAddress = 0x002F9218U + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9210U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9214U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002F9388; }
        goto block_002F9220;
    }
block_002F9220:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9220U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9220U);
        }
        {
            r2 = 0x00000006U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F9230U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_SetSlotItemId_002F8D74(frame, context, state, 0x002F8D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F9230U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F9230;
    }
block_002F9230:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9230U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9230U);
        }
        {
        }
        {
        }
        goto block_002F928C;
    }
block_002F927C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F927CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F927CU);
        }
        {
            r2 = 0x00000009U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F928CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_SetSlotItemId_002F8D74(frame, context, state, 0x002F8D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F928CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F928C;
    }
block_002F928C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F928CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F928CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9290U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F9298U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetAllQuadAlpha_002DB368(frame, context, state, 0x002DB368U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F9298U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F9298;
    }
block_002F9298:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9298U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9298U);
        }
        {
        }
        {
        }
        goto block_002F940C;
    }
block_002F92A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F92A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F92A4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002F92F0; }
        goto block_002F92AC;
    }
block_002F92AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F92ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F92ACU);
        }
        {
            r3 = 0x0000002AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x434U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002F92B0U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F92B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F92BCU, address);
            }
        }
        {
            r3 = 0x000000C5U;
        }
        {
            r2 = r5;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F92D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_SetSlotRect_002E6CD4(frame, context, state, 0x002E6CD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F92D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F92D4;
    }
block_002F92D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F92D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F92D4U);
        }
        {
            r2 = 0x00000059U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F92E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_SetSlotItemId_002F8D74(frame, context, state, 0x002F8D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F92E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F92E4;
    }
block_002F92E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F92E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F92E4U);
        }
        {
        }
        {
        }
        goto block_002F940C;
    }
block_002F92F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F92F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F92F0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002F93A4; }
        goto block_002F92FC;
    }
block_002F92FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F92FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F92FCU);
        }
        {
            r0 = 0x00000014U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F9304U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F9304U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F9304;
    }
block_002F9304:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9304U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9304U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r1 = 0x00000000U;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x002F9310U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseCounter_Construct_002DB6A0(frame, context, state, 0x002DB6A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F9310U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F9310;
    }
block_002F9310:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9310U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9310U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002F9310U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002F931CU + 0x108U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9314U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 272U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x002F9318U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x434U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x002F931CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002F9328U + 0x100U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9320U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9324U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F9328U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002F9364; }
        goto block_002F9334;
    }
block_002F9334:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9334U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9334U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F933CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F9340U, address);
            }
        }
        {
            r3 = 0x000000F0U;
        }
        {
            r2 = 0x00000190U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F9358U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_SetSlotRect_002E6CD4(frame, context, state, 0x002E6CD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F9358U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F9358;
    }
block_002F9358:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9358U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9358U);
        }
        {
        }
        {
        }
        goto block_002F9388;
    }
block_002F9364:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9364U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9364U);
        }
        {
            r3 = 0x0000002AU;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F936CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F9370U, address);
            }
        }
        {
            r3 = 0x000000C5U;
        }
        {
            r2 = r5;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F9388U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_SetSlotRect_002E6CD4(frame, context, state, 0x002E6CD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F9388U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F9388;
    }
block_002F9388:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9388U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9388U);
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F9398U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_SetSlotItemId_002F8D74(frame, context, state, 0x002F8D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F9398U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F9398;
    }
block_002F9398:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9398U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9398U);
        }
        {
        }
        {
        }
        goto block_002F928C;
    }
block_002F93A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F93A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F93A4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002F940C; }
        goto block_002F93AC;
    }
block_002F93AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F93ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F93ACU);
        }
        {
            const uint32_t updatedAddress = 0x002F93B4U + 0x78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F93ACU, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F93B4U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F93B4U,
                                           firstAddress + 4U);
            }
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F93B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F93BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F93C0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F93C4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002F93C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002F93CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x002F93D0U, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x002F93D8U, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F93DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F93E0U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000014U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F93F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadRects_002FC534(frame, context, state, 0x002FC534U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F93F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F93F0;
    }
block_002F93F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F93F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F93F0U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002F93F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F93F8U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F940CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadTexcoords_002FC40C(frame, context, state, 0x002FC40CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F940CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F940C;
    }
block_002F940C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F940CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F940CU);
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002F9414U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_ReleaseLocked_0033DDD4(frame, context, state, 0x0033DDD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002F9414U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002F9414;
    }
block_002F9414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F9414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F9414U);
        }
        {
            const uint32_t operand = 0x00000134U;
            r13 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x002F941CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x002F941CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x002F941CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x002F941CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002F9420U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002F9420U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002F9420U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002F9420U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002F9420U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002F9420U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002F9420U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002F9420U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002F9420U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_ResourceMemory_Allocate_00313CE0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r4 = state.R[4];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00313CE0U:
        goto block_00313CE0;
    case 0x00313CE8U:
        goto block_00313CE8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00313CE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00313CE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00313CE0U);
        }
        {
            const uint32_t firstAddress = r13 - 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00313CE0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00313CE0U,
                                           firstAddress + 4U);
            }
            r13 = r13 - 8U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00313CE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_AllocateLocked_0033DE14(frame, context, state, 0x0033DE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00313CE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00313CE8;
    }
block_00313CE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00313CE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00313CE8U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00313CE8U,
                                           firstAddress + 0U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00313CE8U,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r13 = r13 + 8U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_RendererTextureStage_ConfigureTextureUnit_00348A64(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00348A64U:
        goto block_00348A64;
    case 0x00348A90U:
        goto block_00348A90;
    case 0x00348A98U:
        goto block_00348A98;
    case 0x00348AACU:
        goto block_00348AAC;
    case 0x00348AB8U:
        goto block_00348AB8;
    case 0x00348AC4U:
        goto block_00348AC4;
    case 0x00348AD8U:
        goto block_00348AD8;
    case 0x00348AF4U:
        goto block_00348AF4;
    case 0x00348B00U:
        goto block_00348B00;
    case 0x00348B44U:
        goto block_00348B44;
    case 0x00348B70U:
        goto block_00348B70;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00348A64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00348A64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00348A64U);
        }
        {
            const uint32_t firstAddress = r13 - 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00348A64U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00348A64U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00348A64U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00348A64U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00348A64U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00348A64U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00348A64U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00348A64U,
                                           firstAddress + 28U);
            }
            r13 = r13 - 32U;
        }
        {
            const uint32_t operand = 0x00000038U;
            r13 = r13 - operand;
        }
        {
            r4 = r0;
        }
        {
            r6 = r1;
        }
        {
            const uint32_t updatedAddress = r13 + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348A74U, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348A78U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348A7CU, address);
            }
            r10 = value;
        }
        {
            r7 = r2;
        }
        {
            r9 = r3;
        }
        {
            r0 = r13;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00348A90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PicaMaterialState_Construct_00313CEC(frame, context, state, 0x00313CECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00348A90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00348A90;
    }
block_00348A90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00348A90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00348A90U);
        }
        {
            const uint32_t source = Oot3dAotRor(r10, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00348A98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PicaTexture_ConvertMagFilter_00308474(frame, context, state, 0x00308474U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00348A98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00348A98;
    }
block_00348A98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00348A98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00348A98U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r1 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r4 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x13CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00348AA0U, address);
            }
        }
        {
            const uint32_t source = Oot3dAotRor(r9, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00348AACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PicaTexture_ConvertMinFilter_003083FC(frame, context, state, 0x003083FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00348AACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00348AAC;
    }
block_00348AAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00348AACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00348AACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x140U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00348AACU, address);
            }
        }
        {
            const uint32_t source = Oot3dAotRor(r8, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00348AB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PicaTexture_ConvertWrapMode_00308390(frame, context, state, 0x00308390U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00348AB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00348AB8;
    }
block_00348AB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00348AB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00348AB8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x144U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00348AB8U, address);
            }
        }
        {
            const uint32_t source = Oot3dAotRor(r5, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00348AC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PicaTexture_ConvertWrapMode_00308390(frame, context, state, 0x00308390U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00348AC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00348AC4;
    }
block_00348AC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00348AC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00348AC4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x148U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00348AC4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x140U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348AC8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x00348AD4U + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348ACCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x0000013CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00348AD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PicaTextureConfig_SetMinLod_0030835C(frame, context, state, 0x0030835CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00348AD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00348AD8;
    }
block_00348AD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00348AD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00348AD8U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t operand = 0x00000024U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348AE4U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r4 + 0x140U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348AE8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x0000013CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00348AF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PicaTextureConfig_SetMaxLod_00308328(frame, context, state, 0x00308328U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00348AF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00348AF4;
    }
block_00348AF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00348AF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00348AF4U);
        }
        {
            const uint32_t operand = 0x0000013CU;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x00348B00U + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348AF8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00348B00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PicaTextureConfig_SetLodBias_0030828C(frame, context, state, 0x0030828CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00348B00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00348B00;
    }
block_00348B00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00348B00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00348B00U);
        }
        {
            r0 = r7;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348B04U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x158U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00348B08U, address);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t operand = 0x00000024U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348B18U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r5 = r4 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00348B24U, address);
            }
        }
        {
            r0 = r7;
        }
        {
            const uint32_t operand = 0x00000024U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348B30U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00348B3CU + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348B34U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00348B38U, address);
            }
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00348B44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PicaTexture_ConvertType_00308200(frame, context, state, 0x00308200U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00348B44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00348B44;
    }
block_00348B44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00348B44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00348B44U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x160U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00348B44U, address);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t operand = 0x00000024U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348B54U, address);
            }
            r5 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t operand = 0x00000024U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00348B64U, address);
            }
            r0 = value;
        }
        {
            r1 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00348B70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PicaTexture_ConvertFormat_0030807C(frame, context, state, 0x0030807CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00348B70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00348B70;
    }
block_00348B70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00348B70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00348B70U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x164U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00348B70U, address);
            }
        }
        {
            r0 = r13;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t operand = 0x00000038U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00348B80U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00348B80U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00348B80U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00348B80U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00348B80U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00348B80U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00348B80U,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00348B80U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_NameEntry_Update_00427CE4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00427CE4U:
        goto block_00427CE4;
    case 0x00427D08U:
        goto block_00427D08;
    case 0x00427D18U:
        goto block_00427D18;
    case 0x00427D28U:
        goto block_00427D28;
    case 0x00427D58U:
        goto block_00427D58;
    case 0x00427D60U:
        goto block_00427D60;
    case 0x00427DDCU:
        goto block_00427DDC;
    case 0x00427DE8U:
        goto block_00427DE8;
    case 0x00427DF4U:
        goto block_00427DF4;
    case 0x00427E08U:
        goto block_00427E08;
    case 0x00427E14U:
        goto block_00427E14;
    case 0x00427E30U:
        goto block_00427E30;
    case 0x00427E44U:
        goto block_00427E44;
    case 0x00427E50U:
        goto block_00427E50;
    case 0x00427E60U:
        goto block_00427E60;
    case 0x00427E74U:
        goto block_00427E74;
    case 0x00427E80U:
        goto block_00427E80;
    case 0x00427E90U:
        goto block_00427E90;
    case 0x00427EA0U:
        goto block_00427EA0;
    case 0x00427EACU:
        goto block_00427EAC;
    case 0x00427EBCU:
        goto block_00427EBC;
    case 0x00427EC4U:
        goto block_00427EC4;
    case 0x00427EE0U:
        goto block_00427EE0;
    case 0x00427EF4U:
        goto block_00427EF4;
    case 0x00427F00U:
        goto block_00427F00;
    case 0x00427F10U:
        goto block_00427F10;
    case 0x00427F24U:
        goto block_00427F24;
    case 0x00427F30U:
        goto block_00427F30;
    case 0x00427F40U:
        goto block_00427F40;
    case 0x00427F50U:
        goto block_00427F50;
    case 0x00427F5CU:
        goto block_00427F5C;
    case 0x00427F6CU:
        goto block_00427F6C;
    case 0x00427F7CU:
        goto block_00427F7C;
    case 0x00427F88U:
        goto block_00427F88;
    case 0x00427F98U:
        goto block_00427F98;
    case 0x00427F9CU:
        goto block_00427F9C;
    case 0x00427FA4U:
        goto block_00427FA4;
    case 0x00427FACU:
        goto block_00427FAC;
    case 0x00427FB8U:
        goto block_00427FB8;
    case 0x00427FCCU:
        goto block_00427FCC;
    case 0x00427FD0U:
        goto block_00427FD0;
    case 0x00427FDCU:
        goto block_00427FDC;
    case 0x00427FE4U:
        goto block_00427FE4;
    case 0x00427FF0U:
        goto block_00427FF0;
    case 0x00427FF8U:
        goto block_00427FF8;
    case 0x0042800CU:
        goto block_0042800C;
    case 0x0042801CU:
        goto block_0042801C;
    case 0x00428024U:
        goto block_00428024;
    case 0x00428038U:
        goto block_00428038;
    case 0x00428040U:
        goto block_00428040;
    case 0x0042804CU:
        goto block_0042804C;
    case 0x00428064U:
        goto block_00428064;
    case 0x0042807CU:
        goto block_0042807C;
    case 0x00428084U:
        goto block_00428084;
    case 0x00428090U:
        goto block_00428090;
    case 0x00428098U:
        goto block_00428098;
    case 0x004280ACU:
        goto block_004280AC;
    case 0x004280C8U:
        goto block_004280C8;
    case 0x004280E0U:
        goto block_004280E0;
    case 0x004280ECU:
        goto block_004280EC;
    case 0x00428124U:
        goto block_00428124;
    case 0x0042816CU:
        goto block_0042816C;
    case 0x00428178U:
        goto block_00428178;
    case 0x004281A8U:
        goto block_004281A8;
    case 0x004281B4U:
        goto block_004281B4;
    case 0x004281CCU:
        goto block_004281CC;
    case 0x004281D8U:
        goto block_004281D8;
    case 0x004281DCU:
        goto block_004281DC;
    case 0x004281E4U:
        goto block_004281E4;
    case 0x004281F8U:
        goto block_004281F8;
    case 0x0042820CU:
        goto block_0042820C;
    case 0x00428220U:
        goto block_00428220;
    case 0x0042822CU:
        goto block_0042822C;
    case 0x00428234U:
        goto block_00428234;
    case 0x00428244U:
        goto block_00428244;
    case 0x00428250U:
        goto block_00428250;
    case 0x0042825CU:
        goto block_0042825C;
    case 0x0042828CU:
        goto block_0042828C;
    case 0x00428298U:
        goto block_00428298;
    case 0x004282B0U:
        goto block_004282B0;
    case 0x004282BCU:
        goto block_004282BC;
    case 0x004282C0U:
        goto block_004282C0;
    case 0x004282D4U:
        goto block_004282D4;
    case 0x004282E0U:
        goto block_004282E0;
    case 0x004282ECU:
        goto block_004282EC;
    case 0x00428304U:
        goto block_00428304;
    case 0x00428318U:
        goto block_00428318;
    case 0x00428324U:
        goto block_00428324;
    case 0x0042833CU:
        goto block_0042833C;
    case 0x0042835CU:
        goto block_0042835C;
    case 0x00428374U:
        goto block_00428374;
    case 0x00428380U:
        goto block_00428380;
    case 0x0042838CU:
        goto block_0042838C;
    case 0x004283C0U:
        goto block_004283C0;
    case 0x004283DCU:
        goto block_004283DC;
    case 0x004283E8U:
        goto block_004283E8;
    case 0x00428400U:
        goto block_00428400;
    case 0x0042840CU:
        goto block_0042840C;
    case 0x00428410U:
        goto block_00428410;
    case 0x0042841CU:
        goto block_0042841C;
    case 0x00428420U:
        goto block_00428420;
    case 0x0042842CU:
        goto block_0042842C;
    case 0x00428434U:
        goto block_00428434;
    case 0x00428438U:
        goto block_00428438;
    case 0x00428444U:
        goto block_00428444;
    case 0x0042844CU:
        goto block_0042844C;
    case 0x00428450U:
        goto block_00428450;
    case 0x0042845CU:
        goto block_0042845C;
    case 0x00428464U:
        goto block_00428464;
    case 0x00428468U:
        goto block_00428468;
    case 0x00428474U:
        goto block_00428474;
    case 0x0042847CU:
        goto block_0042847C;
    case 0x00428480U:
        goto block_00428480;
    case 0x0042848CU:
        goto block_0042848C;
    case 0x00428494U:
        goto block_00428494;
    case 0x00428498U:
        goto block_00428498;
    case 0x004284A4U:
        goto block_004284A4;
    case 0x004284C0U:
        goto block_004284C0;
    case 0x004284D0U:
        goto block_004284D0;
    case 0x004284D4U:
        goto block_004284D4;
    case 0x004284F0U:
        goto block_004284F0;
    case 0x004284FCU:
        goto block_004284FC;
    case 0x00428508U:
        goto block_00428508;
    case 0x0042851CU:
        goto block_0042851C;
    case 0x00428528U:
        goto block_00428528;
    case 0x0042854CU:
        goto block_0042854C;
    case 0x00428560U:
        goto block_00428560;
    case 0x0042857CU:
        goto block_0042857C;
    case 0x00428598U:
        goto block_00428598;
    case 0x004285A4U:
        goto block_004285A4;
    case 0x004285CCU:
        goto block_004285CC;
    case 0x004285E0U:
        goto block_004285E0;
    case 0x004285F8U:
        goto block_004285F8;
    case 0x00428614U:
        goto block_00428614;
    case 0x0042861CU:
        goto block_0042861C;
    case 0x00428628U:
        goto block_00428628;
    case 0x0042862CU:
        goto block_0042862C;
    case 0x00428638U:
        goto block_00428638;
    case 0x00428658U:
        goto block_00428658;
    case 0x00428664U:
        goto block_00428664;
    case 0x00428670U:
        goto block_00428670;
    case 0x00428678U:
        goto block_00428678;
    case 0x00428684U:
        goto block_00428684;
    case 0x0042870CU:
        goto block_0042870C;
    case 0x00428720U:
        goto block_00428720;
    case 0x00428728U:
        goto block_00428728;
    case 0x00428734U:
        goto block_00428734;
    case 0x00428740U:
        goto block_00428740;
    case 0x00428750U:
        goto block_00428750;
    case 0x00428758U:
        goto block_00428758;
    case 0x00428764U:
        goto block_00428764;
    case 0x004287D4U:
        goto block_004287D4;
    case 0x004287E0U:
        goto block_004287E0;
    case 0x00428808U:
        goto block_00428808;
    case 0x00428810U:
        goto block_00428810;
    case 0x00428828U:
        goto block_00428828;
    case 0x0042883CU:
        goto block_0042883C;
    case 0x00428848U:
        goto block_00428848;
    case 0x00428854U:
        goto block_00428854;
    case 0x00428868U:
        goto block_00428868;
    case 0x00428874U:
        goto block_00428874;
    case 0x00428880U:
        goto block_00428880;
    case 0x00428894U:
        goto block_00428894;
    case 0x004288B0U:
        goto block_004288B0;
    case 0x004288BCU:
        goto block_004288BC;
    case 0x004288C4U:
        goto block_004288C4;
    case 0x004288D0U:
        goto block_004288D0;
    case 0x004288DCU:
        goto block_004288DC;
    case 0x004288E4U:
        goto block_004288E4;
    case 0x004288F0U:
        goto block_004288F0;
    case 0x004288FCU:
        goto block_004288FC;
    case 0x00428934U:
        goto block_00428934;
    case 0x0042893CU:
        goto block_0042893C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00427CE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427CE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427CE4U);
        }
        {
            const uint32_t firstAddress = r13 - 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00427CE4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00427CE4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00427CE4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00427CE4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00427CE4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00427CE4U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00427CE4U,
                                           firstAddress + 24U);
            }
            r13 = r13 - 28U;
        }
        {
            r5 = r0;
        }
        {
            r4 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x00427CF8U + 0x438U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427CF0U, address);
            }
            r6 = value;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00427CF4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00427CF4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00427CF4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00427CF4U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000054U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427CFCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00427FD0; }
        goto block_00427D08;
    }
block_00427D08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427D08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427D08U);
        }
        {
            const uint32_t operand = 0x00000040U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000044U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000048U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427D18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseInput_ReadTouch_002F9484(frame, context, state, 0x002F9484U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427D18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427D18;
    }
block_00427D18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427D18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427D18U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x00427D18U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427D1CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x00427D2CU + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427D24U, address);
            }
            switch (value) {
            case 0x00427CE4U:
                goto block_00427CE4;
            case 0x00427D08U:
                goto block_00427D08;
            case 0x00427D18U:
                goto block_00427D18;
            case 0x00427D28U:
                goto block_00427D28;
            case 0x00427D58U:
                goto block_00427D58;
            case 0x00427D60U:
                goto block_00427D60;
            case 0x00427DDCU:
                goto block_00427DDC;
            case 0x00427DE8U:
                goto block_00427DE8;
            case 0x00427DF4U:
                goto block_00427DF4;
            case 0x00427E08U:
                goto block_00427E08;
            case 0x00427E14U:
                goto block_00427E14;
            case 0x00427E30U:
                goto block_00427E30;
            case 0x00427E44U:
                goto block_00427E44;
            case 0x00427E50U:
                goto block_00427E50;
            case 0x00427E60U:
                goto block_00427E60;
            case 0x00427E74U:
                goto block_00427E74;
            case 0x00427E80U:
                goto block_00427E80;
            case 0x00427E90U:
                goto block_00427E90;
            case 0x00427EA0U:
                goto block_00427EA0;
            case 0x00427EACU:
                goto block_00427EAC;
            case 0x00427EBCU:
                goto block_00427EBC;
            case 0x00427EC4U:
                goto block_00427EC4;
            case 0x00427EE0U:
                goto block_00427EE0;
            case 0x00427EF4U:
                goto block_00427EF4;
            case 0x00427F00U:
                goto block_00427F00;
            case 0x00427F10U:
                goto block_00427F10;
            case 0x00427F24U:
                goto block_00427F24;
            case 0x00427F30U:
                goto block_00427F30;
            case 0x00427F40U:
                goto block_00427F40;
            case 0x00427F50U:
                goto block_00427F50;
            case 0x00427F5CU:
                goto block_00427F5C;
            case 0x00427F6CU:
                goto block_00427F6C;
            case 0x00427F7CU:
                goto block_00427F7C;
            case 0x00427F88U:
                goto block_00427F88;
            case 0x00427F98U:
                goto block_00427F98;
            case 0x00427F9CU:
                goto block_00427F9C;
            case 0x00427FA4U:
                goto block_00427FA4;
            case 0x00427FACU:
                goto block_00427FAC;
            case 0x00427FB8U:
                goto block_00427FB8;
            case 0x00427FCCU:
                goto block_00427FCC;
            case 0x00427FD0U:
                goto block_00427FD0;
            case 0x00427FDCU:
                goto block_00427FDC;
            case 0x00427FE4U:
                goto block_00427FE4;
            case 0x00427FF0U:
                goto block_00427FF0;
            case 0x00427FF8U:
                goto block_00427FF8;
            case 0x0042800CU:
                goto block_0042800C;
            case 0x0042801CU:
                goto block_0042801C;
            case 0x00428024U:
                goto block_00428024;
            case 0x00428038U:
                goto block_00428038;
            case 0x00428040U:
                goto block_00428040;
            case 0x0042804CU:
                goto block_0042804C;
            case 0x00428064U:
                goto block_00428064;
            case 0x0042807CU:
                goto block_0042807C;
            case 0x00428084U:
                goto block_00428084;
            case 0x00428090U:
                goto block_00428090;
            case 0x00428098U:
                goto block_00428098;
            case 0x004280ACU:
                goto block_004280AC;
            case 0x004280C8U:
                goto block_004280C8;
            case 0x004280E0U:
                goto block_004280E0;
            case 0x004280ECU:
                goto block_004280EC;
            case 0x00428124U:
                goto block_00428124;
            case 0x0042816CU:
                goto block_0042816C;
            case 0x00428178U:
                goto block_00428178;
            case 0x004281A8U:
                goto block_004281A8;
            case 0x004281B4U:
                goto block_004281B4;
            case 0x004281CCU:
                goto block_004281CC;
            case 0x004281D8U:
                goto block_004281D8;
            case 0x004281DCU:
                goto block_004281DC;
            case 0x004281E4U:
                goto block_004281E4;
            case 0x004281F8U:
                goto block_004281F8;
            case 0x0042820CU:
                goto block_0042820C;
            case 0x00428220U:
                goto block_00428220;
            case 0x0042822CU:
                goto block_0042822C;
            case 0x00428234U:
                goto block_00428234;
            case 0x00428244U:
                goto block_00428244;
            case 0x00428250U:
                goto block_00428250;
            case 0x0042825CU:
                goto block_0042825C;
            case 0x0042828CU:
                goto block_0042828C;
            case 0x00428298U:
                goto block_00428298;
            case 0x004282B0U:
                goto block_004282B0;
            case 0x004282BCU:
                goto block_004282BC;
            case 0x004282C0U:
                goto block_004282C0;
            case 0x004282D4U:
                goto block_004282D4;
            case 0x004282E0U:
                goto block_004282E0;
            case 0x004282ECU:
                goto block_004282EC;
            case 0x00428304U:
                goto block_00428304;
            case 0x00428318U:
                goto block_00428318;
            case 0x00428324U:
                goto block_00428324;
            case 0x0042833CU:
                goto block_0042833C;
            case 0x0042835CU:
                goto block_0042835C;
            case 0x00428374U:
                goto block_00428374;
            case 0x00428380U:
                goto block_00428380;
            case 0x0042838CU:
                goto block_0042838C;
            case 0x004283C0U:
                goto block_004283C0;
            case 0x004283DCU:
                goto block_004283DC;
            case 0x004283E8U:
                goto block_004283E8;
            case 0x00428400U:
                goto block_00428400;
            case 0x0042840CU:
                goto block_0042840C;
            case 0x00428410U:
                goto block_00428410;
            case 0x0042841CU:
                goto block_0042841C;
            case 0x00428420U:
                goto block_00428420;
            case 0x0042842CU:
                goto block_0042842C;
            case 0x00428434U:
                goto block_00428434;
            case 0x00428438U:
                goto block_00428438;
            case 0x00428444U:
                goto block_00428444;
            case 0x0042844CU:
                goto block_0042844C;
            case 0x00428450U:
                goto block_00428450;
            case 0x0042845CU:
                goto block_0042845C;
            case 0x00428464U:
                goto block_00428464;
            case 0x00428468U:
                goto block_00428468;
            case 0x00428474U:
                goto block_00428474;
            case 0x0042847CU:
                goto block_0042847C;
            case 0x00428480U:
                goto block_00428480;
            case 0x0042848CU:
                goto block_0042848C;
            case 0x00428494U:
                goto block_00428494;
            case 0x00428498U:
                goto block_00428498;
            case 0x004284A4U:
                goto block_004284A4;
            case 0x004284C0U:
                goto block_004284C0;
            case 0x004284D0U:
                goto block_004284D0;
            case 0x004284D4U:
                goto block_004284D4;
            case 0x004284F0U:
                goto block_004284F0;
            case 0x004284FCU:
                goto block_004284FC;
            case 0x00428508U:
                goto block_00428508;
            case 0x0042851CU:
                goto block_0042851C;
            case 0x00428528U:
                goto block_00428528;
            case 0x0042854CU:
                goto block_0042854C;
            case 0x00428560U:
                goto block_00428560;
            case 0x0042857CU:
                goto block_0042857C;
            case 0x00428598U:
                goto block_00428598;
            case 0x004285A4U:
                goto block_004285A4;
            case 0x004285CCU:
                goto block_004285CC;
            case 0x004285E0U:
                goto block_004285E0;
            case 0x004285F8U:
                goto block_004285F8;
            case 0x00428614U:
                goto block_00428614;
            case 0x0042861CU:
                goto block_0042861C;
            case 0x00428628U:
                goto block_00428628;
            case 0x0042862CU:
                goto block_0042862C;
            case 0x00428638U:
                goto block_00428638;
            case 0x00428658U:
                goto block_00428658;
            case 0x00428664U:
                goto block_00428664;
            case 0x00428670U:
                goto block_00428670;
            case 0x00428678U:
                goto block_00428678;
            case 0x00428684U:
                goto block_00428684;
            case 0x0042870CU:
                goto block_0042870C;
            case 0x00428720U:
                goto block_00428720;
            case 0x00428728U:
                goto block_00428728;
            case 0x00428734U:
                goto block_00428734;
            case 0x00428740U:
                goto block_00428740;
            case 0x00428750U:
                goto block_00428750;
            case 0x00428758U:
                goto block_00428758;
            case 0x00428764U:
                goto block_00428764;
            case 0x004287D4U:
                goto block_004287D4;
            case 0x004287E0U:
                goto block_004287E0;
            case 0x00428808U:
                goto block_00428808;
            case 0x00428810U:
                goto block_00428810;
            case 0x00428828U:
                goto block_00428828;
            case 0x0042883CU:
                goto block_0042883C;
            case 0x00428848U:
                goto block_00428848;
            case 0x00428854U:
                goto block_00428854;
            case 0x00428868U:
                goto block_00428868;
            case 0x00428874U:
                goto block_00428874;
            case 0x00428880U:
                goto block_00428880;
            case 0x00428894U:
                goto block_00428894;
            case 0x004288B0U:
                goto block_004288B0;
            case 0x004288BCU:
                goto block_004288BC;
            case 0x004288C4U:
                goto block_004288C4;
            case 0x004288D0U:
                goto block_004288D0;
            case 0x004288DCU:
                goto block_004288DC;
            case 0x004288E4U:
                goto block_004288E4;
            case 0x004288F0U:
                goto block_004288F0;
            case 0x004288FCU:
                goto block_004288FC;
            case 0x00428934U:
                goto block_00428934;
            case 0x0042893CU:
                goto block_0042893C;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_00427D28;
    }
block_00427D28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427D28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427D28U);
        }
        goto block_00428720;
    }
block_00427D58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427D58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427D58U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427D60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_InitRenderGeometry_0043DA34(frame, context, state, 0x0043DA34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427D60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427D60;
    }
block_00427D60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427D60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427D60U);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00427D64U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427D68U, address);
            }
            r1 = value;
        }
        {
            r4 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00427D78U, address);
            }
        }
        {
            r1 = ~(0x00000000U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00427D80U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00427D8CU + 0x3A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427D84U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427D88U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427D8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427D90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427D94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427D98U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427D9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427DA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427DA4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000020U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00427DACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427DB0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427DB4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427DB8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427DBCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427DC0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427DC4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427DC8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427DCCU, address);
            }
        }
        {
            r1 = 0x00000012U;
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r0 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427DDCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_Memzero_ReturnEnd_0032B184(frame, context, state, 0x0032B184U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427DDCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427DDC;
    }
block_00427DDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427DDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427DDCU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00427DDCU, address);
            }
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427DE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateKeyboardTransitionGeometry_002F4B64(frame, context, state, 0x002F4B64U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427DE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427DE8;
    }
block_00427DE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427DE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427DE8U);
        }
        {
        }
        {
        }
        goto block_00428720;
    }
block_00427DF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427DF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427DF4U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427DF4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00427E00U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00427FA4; }
        goto block_00427E08;
    }
block_00427E08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427E08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427E08U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427E08U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00427EC4; }
        goto block_00427E14;
    }
block_00427E14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427E14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427E14U);
        }
        {
            const uint32_t operand = 0x0000031CU;
            r0 = 0x00427E1CU + operand;
        }
        {
            const uint32_t updatedAddress = 0x00427E20U + 0x320U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427E18U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00427E1CU, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00427E20U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000038U;
            r1 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427E30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u16x3_0035FB94(frame, context, state, 0x0035FB94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427E30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427E30;
    }
block_00427E30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427E30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427E30U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00427E34U, address);
            }
        }
        {
            r1 = r7;
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427E44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427E44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427E44;
    }
block_00427E44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427E44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427E44U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00427E60; }
        goto block_00427E50;
    }
block_00427E50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427E50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427E50U);
        }
        {
            r3 = 0x0000000AU;
        }
        {
            r2 = 0x0000004BU;
        }
        {
            const uint32_t operand = 0x00000000U;
            r1 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427E60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntryGlyphOverlay_Init_002F48F8(frame, context, state, 0x002F48F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427E60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427E60;
    }
block_00427E60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427E60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427E60U);
        }
        {
            const uint32_t updatedAddress = 0x00427E68U + 0x2DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427E60U, address);
            }
            r5 = value;
        }
        {
            r1 = r7;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00427E68U, address);
            }
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427E74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427E74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427E74;
    }
block_00427E74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427E74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427E74U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00427E90; }
        goto block_00427E80;
    }
block_00427E80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427E80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427E80U);
        }
        {
            r3 = 0x0000000AU;
        }
        {
            r2 = 0x00000061U;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427E90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntryGlyphOverlay_Init_002F48F8(frame, context, state, 0x002F48F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427E90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427E90;
    }
block_00427E90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427E90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427E90U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00427E90U, address);
            }
        }
        {
            r1 = r7;
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427EA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427EA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427EA0;
    }
block_00427EA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427EA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427EA0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00427EBC; }
        goto block_00427EAC;
    }
block_00427EAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427EACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427EACU);
        }
        {
            r3 = 0x0000000AU;
        }
        {
            r2 = 0x00000077U;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427EBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntryGlyphOverlay_Init_002F48F8(frame, context, state, 0x002F48F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427EBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427EBC;
    }
block_00427EBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427EBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427EBCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00427EBCU, address);
            }
        }
        goto block_00427F9C;
    }
block_00427EC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427EC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427EC4U);
        }
        {
            const uint32_t operand = 0x0000027CU;
            r0 = 0x00427ECCU + operand;
        }
        {
            const uint32_t operand = 0x00000034U;
            r1 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00427ECCU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00427ECCU,
                                           firstAddress + 4U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00427ECCU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r4 = value4;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00427ED0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00427ED0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00427ED0U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = 0x00427EDCU + 0x264U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427ED4U, address);
            }
            r4 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427EE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u16x4_002F48D4(frame, context, state, 0x002F48D4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427EE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427EE0;
    }
block_00427EE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427EE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427EE0U);
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00427EE4U, address);
            }
        }
        {
            r1 = r7;
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427EF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427EF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427EF4;
    }
block_00427EF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427EF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427EF4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00427F10; }
        goto block_00427F00;
    }
block_00427F00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427F00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427F00U);
        }
        {
            r3 = 0x0000000AU;
        }
        {
            r2 = 0x0000004BU;
        }
        {
            const uint32_t operand = 0x00000000U;
            r1 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427F10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntryGlyphOverlay_Init_002F48F8(frame, context, state, 0x002F48F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427F10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427F10;
    }
block_00427F10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427F10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427F10U);
        }
        {
            const uint32_t updatedAddress = 0x00427F18U + 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427F10U, address);
            }
            r5 = value;
        }
        {
            r1 = r7;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00427F18U, address);
            }
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427F24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427F24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427F24;
    }
block_00427F24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427F24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427F24U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00427F40; }
        goto block_00427F30;
    }
block_00427F30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427F30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427F30U);
        }
        {
            r3 = 0x0000000AU;
        }
        {
            r2 = 0x00000061U;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427F40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntryGlyphOverlay_Init_002F48F8(frame, context, state, 0x002F48F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427F40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427F40;
    }
block_00427F40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427F40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427F40U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00427F40U, address);
            }
        }
        {
            r1 = r7;
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427F50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427F50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427F50;
    }
block_00427F50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427F50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427F50U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00427F6C; }
        goto block_00427F5C;
    }
block_00427F5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427F5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427F5CU);
        }
        {
            r3 = 0x0000000AU;
        }
        {
            r2 = 0x00000077U;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427F6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntryGlyphOverlay_Init_002F48F8(frame, context, state, 0x002F48F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427F6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427F6C;
    }
block_00427F6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427F6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427F6CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00427F6CU, address);
            }
        }
        {
            r1 = r7;
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427F7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427F7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427F7C;
    }
block_00427F7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427F7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427F7CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00427F98; }
        goto block_00427F88;
    }
block_00427F88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427F88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427F88U);
        }
        {
            r3 = 0x0000000AU;
        }
        {
            r2 = 0x0000008DU;
        }
        {
            const uint32_t operand = 0x00000006U;
            r1 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427F98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntryGlyphOverlay_Init_002F48F8(frame, context, state, 0x002F48F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427F98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427F98;
    }
block_00427F98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427F98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427F98U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00427F98U, address);
            }
        }
        goto block_00427F9C;
    }
block_00427F9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427F9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427F9CU);
        }
        {
            r0 = 0x00000004U;
        }
        goto block_0042822C;
    }
block_00427FA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427FA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427FA4U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427FACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateKeyboardTransitionGeometry_002F4B64(frame, context, state, 0x002F4B64U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427FACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427FAC;
    }
block_00427FAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427FACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427FACU);
        }
        {
        }
        {
        }
        goto block_00428720;
    }
block_00427FB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427FB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427FB8U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427FB8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00427FC4U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00427FDC; }
        goto block_00427FCC;
    }
block_00427FCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427FCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427FCCU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427FD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_CloseToFileSelect_002F4794(frame, context, state, 0x002F4794U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427FD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427FD0;
    }
block_00427FD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427FD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427FD0U);
        }
        {
            const uint32_t operand = 0x00000054U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00427FD4U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00427FD4U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00427FD4U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00427FD4U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00427FD8U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00427FD8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00427FD8U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00427FD8U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00427FD8U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00427FD8U,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00427FD8U,
                                           firstAddress + 24U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
block_00427FDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427FDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427FDCU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427FE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateKeyboardTransitionOut_0043E240(frame, context, state, 0x0043E240U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427FE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427FE4;
    }
block_00427FE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427FE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427FE4U);
        }
        {
        }
        {
        }
        goto block_00428720;
    }
block_00427FF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427FF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427FF0U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00427FF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateGlyphOverlayTransition_002F4700(frame, context, state, 0x002F4700U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00427FF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00427FF8;
    }
block_00427FF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00427FF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00427FF8U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00427FF8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00428004U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00427FDC; }
        goto block_0042800C;
    }
block_0042800C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042800CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042800CU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00428010U, address);
            }
        }
        {
            r0 = 0x00000006U;
        }
        goto block_0042822C;
    }
block_0042801C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042801CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042801CU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428024U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateGlyphOverlayTransition_002F4700(frame, context, state, 0x002F4700U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428024U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428024;
    }
block_00428024:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428024U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428024U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428024U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00428030U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0042807C; }
        goto block_00428038;
    }
block_00428038:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428038U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428038U);
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428040U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428040U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428040;
    }
block_00428040:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428040U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428040U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00428064; }
        goto block_0042804C;
    }
block_0042804C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042804CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042804CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00428050U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0042805CU + 0xF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428054U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x00000011U;
        }
        {
            r2 = 0x00000038U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428064U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428064U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428064;
    }
block_00428064:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428064U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428064U);
        }
        {
            const uint32_t updatedAddress = 0x0042806CU + 0xC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428064U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00428068U, address);
            }
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00428070U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00428074U, address);
            }
        }
        goto block_00428720;
    }
block_0042807C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042807CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042807CU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428084U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateConfirmationTransitionIn_0043DF50(frame, context, state, 0x0043DF50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428084U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428084;
    }
block_00428084:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428084U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428084U);
        }
        {
        }
        {
        }
        goto block_00428720;
    }
block_00428090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428090U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428098U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateGlyphOverlayTransition_002F4700(frame, context, state, 0x002F4700U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428098U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428098;
    }
block_00428098:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428098U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428098U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428098U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004280A4U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_004280C8; }
        goto block_004280AC;
    }
block_004280AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004280ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004280ACU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004280B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004280B4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004280BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004280C0U, address);
            }
        }
        goto block_00428720;
    }
block_004280C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004280C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004280C8U);
        }
        {
            const uint32_t updatedAddress = 0x004280D0U + 0x98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004280C8U, address);
            }
            r5 = value;
        }
        {
            const uint32_t address = 0x004280D4U + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004280CCU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x004280D8U + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004280D0U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x004280DCU + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004280D4U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x004280E0U + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004280D8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r4 = 0x00000000U;
        }
        goto block_004280E0;
    }
block_004280E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004280E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004280E0U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0042816C; }
        goto block_004280EC;
    }
block_004280EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004280ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004280ECU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004280ECU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            r3 = r4;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000034U;
            r1 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00428104U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00428108U, 0xEE000AE8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0042810CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00428110U, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00428118U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042811CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428124U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaValues_002FCDEC(frame, context, state, 0x002FCDECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428124U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428124;
    }
block_00428124:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428124U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428124U);
        }
        {
        }
        {
        }
        goto block_004281CC;
    }
block_0042816C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042816CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042816CU);
        }
        {
            const uint32_t operand = 0x0000001AU;
            r0 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_004281B4; }
        goto block_00428178;
    }
block_00428178:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428178U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428178U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428178U, address);
            }
            r0 = value;
        }
        {
            r1 = ~(0x0000004FU);
        }
        {
            r3 = r4;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r1);
        }
        {
            const uint32_t operand = 0x00000038U;
            r1 = r13 + operand;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00428194U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00428198U, address);
            }
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0042819CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004281A0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004281A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004281A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004281A8;
    }
block_004281A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004281A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004281A8U);
        }
        {
        }
        {
        }
        goto block_004281CC;
    }
block_004281B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004281B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004281B4U);
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x004281B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004281B8U, address);
            }
            r0 = value;
        }
        {
            r3 = r4;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000038U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004281CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004281CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004281CC;
    }
block_004281CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004281CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004281CCU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000003EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_004280E0; }
        goto block_004281D8;
    }
block_004281D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004281D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004281D8U);
        }
        goto block_00428720;
    }
block_004281DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004281DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004281DCU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004281E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateGlyphOverlayTransition_002F4700(frame, context, state, 0x002F4700U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004281E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004281E4;
    }
block_004281E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004281E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004281E4U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004281E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004281F0U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00427FA4; }
        goto block_004281F8;
    }
block_004281F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004281F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004281F8U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004281FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00428200U, address);
            }
        }
        {
            r0 = 0x00000004U;
        }
        goto block_0042822C;
    }
block_0042820C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042820CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042820CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042820CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00428218U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00428234; }
        goto block_00428220;
    }
block_00428220:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428220U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428220U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00428224U, address);
            }
        }
        {
            r0 = 0x0000000AU;
        }
        goto block_0042822C;
    }
block_0042822C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042822CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042822CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042822CU, address);
            }
        }
        goto block_00428720;
    }
block_00428234:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428234U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428234U);
        }
        {
            const uint32_t updatedAddress = 0x0042823CU - 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428234U, address);
            }
            r5 = value;
        }
        {
            const uint32_t address = 0x00428240U - 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428238U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x00428244U - 224U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042823CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r4 = 0x00000000U;
        }
        goto block_00428244;
    }
block_00428244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428244U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) { goto block_004282B0; }
        goto block_00428250;
    }
block_00428250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428250U);
        }
        {
            const uint32_t operand = 0x0000001AU;
            r0 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_00428298; }
        goto block_0042825C;
    }
block_0042825C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042825CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042825CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042825CU, address);
            }
            r0 = value;
        }
        {
            r1 = ~(0x0000004FU);
        }
        {
            r3 = r4;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r1);
        }
        {
            const uint32_t operand = 0x00000038U;
            r1 = r13 + operand;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00428278U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0042827CU, address);
            }
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00428280U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428284U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042828CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042828CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042828C;
    }
block_0042828C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042828CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042828CU);
        }
        {
        }
        {
        }
        goto block_004282B0;
    }
block_00428298:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428298U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428298U);
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00428298U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042829CU, address);
            }
            r0 = value;
        }
        {
            r3 = r4;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000038U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004282B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004282B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004282B0;
    }
block_004282B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004282B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004282B0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000003EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00428244; }
        goto block_004282BC;
    }
block_004282BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004282BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004282BCU);
        }
        goto block_00428720;
    }
block_004282C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004282C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004282C0U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004282C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004282CCU, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0042835C; }
        goto block_004282D4;
    }
block_004282D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004282D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004282D4U);
        }
        {
            r1 = r5;
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004282E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004282E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004282E0;
    }
block_004282E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004282E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004282E0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00428304; }
        goto block_004282EC;
    }
block_004282EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004282ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004282ECU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x004282F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x004282FCU + 0x604U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004282F4U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x00000011U;
        }
        {
            r2 = 0x00000038U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428304U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428304U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428304;
    }
block_00428304:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428304U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428304U);
        }
        {
            const uint32_t updatedAddress = 0x0042830CU - 0x1D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428304U, address);
            }
            r4 = value;
        }
        {
            r1 = r5;
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042830CU, address);
            }
        }
        {
            r0 = 0x0000004CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428318U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428318U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428318;
    }
block_00428318:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428318U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428318U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042833C; }
        goto block_00428324;
    }
block_00428324:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428324U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428324U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00428328U, address);
            }
        }
        {
            r3 = 0x000000C2U;
        }
        {
            r2 = 0x00000020U;
        }
        {
            const uint32_t operand = 0x000008B0U;
            r1 = r3 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042833CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseMapOverlay_Init_002F57F0(frame, context, state, 0x002F57F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042833CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042833C;
    }
block_0042833C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042833CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042833CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042833CU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00428344U, address);
            }
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042834CU, address);
            }
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00428354U, address);
            }
        }
        goto block_00428720;
    }
block_0042835C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042835CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042835CU);
        }
        {
            const uint32_t updatedAddress = 0x00428364U - 0x1FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042835CU, address);
            }
            r5 = value;
        }
        {
            const uint32_t address = 0x00428368U - 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428360U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0042836CU - 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428364U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x00428370U - 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428368U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x00428374U - 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042836CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r4 = 0x00000000U;
        }
        goto block_00428374;
    }
block_00428374:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428374U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428374U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) { goto block_00428400; }
        goto block_00428380;
    }
block_00428380:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428380U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428380U);
        }
        {
            const uint32_t operand = 0x00000030U;
            r0 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_004283E8; }
        goto block_0042838C;
    }
block_0042838C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042838CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042838CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042838CU, address);
            }
            r0 = value;
        }
        {
            r3 = r4;
        }
        {
            r2 = 0x00000001U;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000034U;
            r1 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x004283A0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x004283A4U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x004283ACU, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x004283B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004283B8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004283C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaValues_002FCDEC(frame, context, state, 0x002FCDECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004283C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004283C0;
    }
block_004283C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004283C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004283C0U);
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x004283C0U, address);
            }
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x004283C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004283C8U, address);
            }
            r0 = value;
        }
        {
            r3 = r4;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000038U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004283DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004283DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004283DC;
    }
block_004283DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004283DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004283DCU);
        }
        {
        }
        {
        }
        goto block_00428400;
    }
block_004283E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004283E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004283E8U);
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x004283E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004283ECU, address);
            }
            r0 = value;
        }
        {
            r3 = r4;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000038U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428400U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428400U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428400;
    }
block_00428400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428400U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x0000003EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00428374; }
        goto block_0042840C;
    }
block_0042840C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042840CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042840CU);
        }
        goto block_00428720;
    }
block_00428410:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428410U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428410U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428410U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0042842C; }
        goto block_0042841C;
    }
block_0042841C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042841CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042841CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428420U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateJapaneseKeyboard_0043D478(frame, context, state, 0x0043D478U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428420U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428420;
    }
block_00428420:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428420U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428420U);
        }
        {
        }
        {
        }
        goto block_00428670;
    }
block_0042842C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042842CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042842CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00428444; }
        goto block_00428434;
    }
block_00428434:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428434U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428434U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428438U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateLatinKeyboard_0043C8D8(frame, context, state, 0x0043C8D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428438U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428438;
    }
block_00428438:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428438U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428438U);
        }
        {
        }
        {
        }
        goto block_00428670;
    }
block_00428444:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428444U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428444U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042845C; }
        goto block_0042844C;
    }
block_0042844C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042844CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042844CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428450U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateEuropeanKeyboard_0043E3E0(frame, context, state, 0x0043E3E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428450U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428450;
    }
block_00428450:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428450U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428450U);
        }
        {
        }
        {
        }
        goto block_00428670;
    }
block_0042845C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042845CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042845CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00428474; }
        goto block_00428464;
    }
block_00428464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428464U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428468U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateConfirmation_0043DDB4(frame, context, state, 0x0043DDB4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428468U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428468;
    }
block_00428468:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428468U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428468U);
        }
        {
        }
        {
        }
        goto block_00428670;
    }
block_00428474:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428474U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428474U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042848C; }
        goto block_0042847C;
    }
block_0042847C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042847CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042847CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428480U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateSaveCommit_0043E088(frame, context, state, 0x0043E088U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428480U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428480;
    }
block_00428480:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428480U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428480U);
        }
        {
        }
        {
        }
        goto block_00428670;
    }
block_0042848C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042848CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042848CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00428670; }
        goto block_00428494;
    }
block_00428494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428494U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428498U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateKeyboardPageGeometry_002F43F8(frame, context, state, 0x002F43F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428498U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428498;
    }
block_00428498:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428498U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428498U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428498U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_004284D4; }
        goto block_004284A4;
    }
block_004284A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004284A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004284A4U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x004284A8U, address);
            }
        }
        {
            r3 = 0x00000020U;
        }
        {
            r2 = 0x00000034U;
        }
        {
            r1 = 0x000000CCU;
        }
        {
            r0 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004284C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004284C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004284C0;
    }
block_004284C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004284C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004284C0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004284C8U, address);
            }
        }
        if (!(flags.Z())) { goto block_00428528; }
        goto block_004284D0;
    }
block_004284D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004284D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004284D0U);
        }
        goto block_0042851C;
    }
block_004284D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004284D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004284D4U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x004284D8U, address);
            }
        }
        {
            r3 = 0x00000020U;
        }
        {
            r2 = 0x00000034U;
        }
        {
            r1 = 0x000000CCU;
        }
        {
            r0 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004284F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004284F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004284F0;
    }
block_004284F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004284F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004284F0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_00428508; }
        goto block_004284FC;
    }
block_004284FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004284FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004284FCU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004284FCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r4 = 0x00000001U;
        }
        goto block_00428508;
    }
block_00428508:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428508U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428508U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428508U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = ~(0x00000000U);
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r6 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00428514U, address);
            }
        }
        if (flags.Z()) { goto block_004285A4; }
        goto block_0042851C;
    }
block_0042851C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042851CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042851CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042851CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_004285A4; }
        goto block_00428528;
    }
block_00428528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428528U);
        }
        {
            const uint32_t updatedAddress = 0x00428530U - 0x3C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428528U, address);
            }
            r5 = value;
        }
        {
            const uint32_t address = 0x00428534U - 976U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042852CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x0000003CU;
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00428534U, address);
            }
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00428538U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042853CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042854CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042854CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042854C;
    }
block_0042854C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042854CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042854CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042854CU, address);
            }
            r0 = value;
        }
        {
            r3 = 0x0000003DU;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428560U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428560U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428560;
    }
block_00428560:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428560U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428560U);
        }
        {
            const uint32_t address = 0x00428568U + 924U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428560U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x0000003BU;
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00428568U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042856CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042857CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042857CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042857C;
    }
block_0042857C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042857CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042857CU);
        }
        {
            const uint32_t address = 0x00428584U + 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042857CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x0000003BU;
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00428584U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428588U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428598U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaValues_002FCDEC(frame, context, state, 0x002FCDECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428598U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428598;
    }
block_00428598:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428598U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428598U);
        }
        {
        }
        {
        }
        goto block_00428614;
    }
block_004285A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004285A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004285A4U);
        }
        {
            const uint32_t updatedAddress = 0x004285ACU - 0x444U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004285A4U, address);
            }
            r5 = value;
        }
        {
            const uint32_t address = 0x004285B0U + 860U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004285A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x004285B4U + 860U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004285ACU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x004285B0U, address);
            }
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x004285B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004285B8U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x0000003CU;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004285CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004285CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004285CC;
    }
block_004285CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004285CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004285CCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004285CCU, address);
            }
            r0 = value;
        }
        {
            r3 = 0x0000003DU;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004285E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004285E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004285E0;
    }
block_004285E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004285E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004285E0U);
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x004285E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004285E4U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x0000003BU;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004285F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004285F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004285F8;
    }
block_004285F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004285F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004285F8U);
        }
        {
            const uint32_t address = 0x00428600U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004285F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x0000003BU;
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00428600U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428604U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428614U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaValues_002FCDEC(frame, context, state, 0x002FCDECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428614U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428614;
    }
block_00428614:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428614U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428614U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042861CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Input_GetPressedButtonMask_0033B5EC(frame, context, state, 0x0033B5ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042861CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042861C;
    }
block_0042861C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042861CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042861CU);
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00428638; }
        goto block_00428628;
    }
block_00428628:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428628U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428628U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042862CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Input_GetPressedButtonMask_0033B5EC(frame, context, state, 0x0033B5ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042862CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042862C;
    }
block_0042862C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042862CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042862CU);
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00428720; }
        goto block_00428638;
    }
block_00428638:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428638U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428638U);
        }
        {
            const uint32_t updatedAddress = 0x00428640U + 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428638U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00428644U + 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042863CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00428648U + 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428640U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00428648U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428658U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428658U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428658;
    }
block_00428658:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428658U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428658U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428664U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_CloseToFileSelect_002F4794(frame, context, state, 0x002F4794U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428664U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428664;
    }
block_00428664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428664U);
        }
        {
            const uint32_t operand = 0x00000054U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00428668U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00428668U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00428668U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00428668U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0042866CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0042866CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0042866CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0042866CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0042866CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0042866CU,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0042866CU,
                                           firstAddress + 24U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
block_00428670:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428670U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428670U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428678U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateKeyboardPageGeometry_002F43F8(frame, context, state, 0x002F43F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428678U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428678;
    }
block_00428678:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428678U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428678U);
        }
        {
            r0 = 0x00000000U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428684U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateGlyphOverlayTransition_002F4700(frame, context, state, 0x002F4700U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428684U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428684;
    }
block_00428684:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428684U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428684U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428684U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00428690U + 664U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428688U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x00428694U - 0x52CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042868CU, address);
            }
            r4 = value;
        }
        {
            r3 = 0x0000002EU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r1 + operand;
        }
        {
            r1 = 0x00000049U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r1 + operand;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000034U;
            r1 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x004286B0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x004286B4U, address);
            }
        }
        {
            const uint32_t address = 0x004286C0U + 612U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004286B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x004286BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004286C0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t address = 0x004286D0U + 572U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004286C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x004286CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004286D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t updatedAddress = r6 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004286DCU, address);
            }
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t operand = 0x0000003CU;
            r0 = operand - r0;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x004286E8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x004286ECU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x004286F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004286F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) {
            r0 = 0x00000000U;
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r6 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00428700U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428704U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042870CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaValues_002FCDEC(frame, context, state, 0x002FCDECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042870CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042870C;
    }
block_0042870C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042870CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042870CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042870CU, address);
            }
            r0 = value;
        }
        {
            r3 = 0x0000002EU;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000038U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428720U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428720U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428720;
    }
block_00428720:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428720U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428720U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428728U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateCursorTransform_0043F10C(frame, context, state, 0x0043F10CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428728U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428728;
    }
block_00428728:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428728U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428728U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428728U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_00428740; }
        goto block_00428734;
    }
block_00428734:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428734U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428734U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428734U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x00428740U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_NameEntry_UpdateTouchHighlightGeometry_0043E9B4(frame, context, state, 0x0043E9B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428740U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428740;
    }
block_00428740:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428740U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428740U);
        }
        {
            const uint32_t updatedAddress = 0x00428748U + 0x1E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428740U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428744U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_004287D4; }
        goto block_00428750;
    }
block_00428750:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428750U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428750U);
        }
        {
            const uint32_t updatedAddress = 0x00428758U + 0x1D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428750U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428758U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428758U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428758;
    }
block_00428758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428758U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_004287D4; }
        goto block_00428764;
    }
block_00428764:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428764U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428764U);
        }
        {
            const uint32_t updatedAddress = 0x0042876CU + 0x1C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428764U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00428770U + 416U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428768U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00428774U + 416U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042876CU, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[12] = frame.Guest.vfp[5];
        }
        {
            frame.Guest.vfp[9] = frame.Guest.vfp[5];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[4] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[7] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[12])) {
                return Oot3dAotMemoryFault(context, 0x00428788U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0042878CU, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00428790U, address);
            }
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00428794U, address);
            }
        }
        {
            const uint32_t address = r0 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00428798U, address);
            }
        }
        {
            const uint32_t address = r0 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[9])) {
                return Oot3dAotMemoryFault(context, 0x0042879CU, address);
            }
        }
        {
            const uint32_t address = r0 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x004287A0U, address);
            }
        }
        {
            const uint32_t address = r0 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x004287A4U, address);
            }
        }
        {
            const uint32_t address = r0 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x004287A8U, address);
            }
        }
        {
            const uint32_t address = r0 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x004287ACU, address);
            }
        }
        {
            frame.Guest.vfp[10] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[8] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[11] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[6] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r0 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[5])) {
                return Oot3dAotMemoryFault(context, 0x004287C4U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x004287C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x004287D4U + 0x158U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004287CCU, address);
            }
            r0 = value;
        }
        {
            r0 = r0;
        }
        goto block_004287D4;
    }
block_004287D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004287D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004287D4U);
        }
        {
            const uint32_t updatedAddress = 0x004287DCU + 0x154U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004287D4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004287E0U;
            const Oot3dWholeAotFlow callFlow = Oot3dAotCallExternal(context, 0x00372224U, frame, state, commitState, reloadState);
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004287E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004287E0;
    }
block_004287E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004287E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004287E0U);
        }
        {
            const uint32_t address = 0x004287E8U + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004287E0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = 0x004287ECU - 0x684U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004287E4U, address);
            }
            r5 = value;
        }
        {
            r4 = 0x00000000U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[2];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        {
            const uint32_t operand = 0x00000010U;
            r7 = r5 - operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r8 = r7 + operand;
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x004287FCU, address);
            }
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00428800U, address);
            }
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00428804U, address);
            }
        }
        goto block_00428808;
    }
block_00428808:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428808U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428808U);
        }
        {
            const uint32_t updatedAddress = r5 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428808U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428810U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_ApplyPositionOffsets_002F9A1C(frame, context, state, 0x002F9A1CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428810U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428810;
    }
block_00428810:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428810U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428810U);
        }
        {
            const uint32_t updatedAddress = r5 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428810U, address);
            }
            r0 = value;
        }
        {
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428818U, address);
            }
            r0 = value;
        }
        {
            r9 = r0;
        }
        {
            const uint32_t updatedAddress = r5 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428820U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428828U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_first_word_mul_48_002F9A0C(frame, context, state, 0x002F9A0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428828U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428828;
    }
block_00428828:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428828U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428828U);
        }
        {
            const uint32_t updatedAddress = r7 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428828U, address);
            }
            r3 = value;
        }
        {
            r1 = r0;
        }
        {
            r2 = r9;
        }
        {
            r0 = r3;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042883CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererStreamBuffer_CopyPositions_0036759C(frame, context, state, 0x0036759CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042883CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042883C;
    }
block_0042883C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042883CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042883CU);
        }
        {
            const uint32_t updatedAddress = r5 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042883CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428848U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_14_stride_20_002FC3F0(frame, context, state, 0x002FC3F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428848U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428848;
    }
block_00428848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428848U);
        }
        {
            r9 = r0;
        }
        {
            const uint32_t updatedAddress = r5 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042884CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428854U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_first_word_lsl_5_002F9A00(frame, context, state, 0x002F9A00U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428854U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428854;
    }
block_00428854:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428854U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428854U);
        }
        {
            const uint32_t updatedAddress = r7 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428854U, address);
            }
            r3 = value;
        }
        {
            r1 = r0;
        }
        {
            r2 = r9;
        }
        {
            r0 = r3;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428868U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererStreamBuffer_CopyTexcoords_00317D1C(frame, context, state, 0x00317D1CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428868U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428868;
    }
block_00428868:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428868U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428868U);
        }
        {
            const uint32_t updatedAddress = r5 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428868U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428874U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_18_stride_40_002FC3E4(frame, context, state, 0x002FC3E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428874U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428874;
    }
block_00428874:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428874U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428874U);
        }
        {
            r9 = r0;
        }
        {
            const uint32_t updatedAddress = r5 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428878U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428880U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_first_word_lsl_6_002F99F4(frame, context, state, 0x002F99F4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428880U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428880;
    }
block_00428880:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428880U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428880U);
        }
        {
            const uint32_t updatedAddress = r7 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428880U, address);
            }
            r3 = value;
        }
        {
            r1 = r0;
        }
        {
            r2 = r9;
        }
        {
            r0 = r3;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00428894U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererStreamBuffer_CopyColors_002F9934(frame, context, state, 0x002F9934U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00428894U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00428894;
    }
block_00428894:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428894U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428894U);
        }
        {
            const uint32_t updatedAddress = r8 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428894U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r2 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004288A0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004288A4U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x004288B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r12, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004288B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004288B0;
    }
block_004288B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004288B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004288B0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00428808; }
        goto block_004288BC;
    }
block_004288BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004288BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004288BCU);
        }
        {
            const uint32_t updatedAddress = 0x004288C4U - 0x780U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004288BCU, address);
            }
            r5 = value;
        }
        {
            r4 = 0x00000000U;
        }
        goto block_004288C4;
    }
block_004288C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004288C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004288C4U);
        }
        {
            const uint32_t updatedAddress = r5 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004288C4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x004288D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderGroup_SubmitModels_002F7684(frame, context, state, 0x002F7684U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004288D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004288D0;
    }
block_004288D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004288D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004288D0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_004288C4; }
        goto block_004288DC;
    }
block_004288DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004288DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004288DCU);
        }
        {
            const uint32_t updatedAddress = 0x004288E4U - 0x7B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004288DCU, address);
            }
            r5 = value;
        }
        {
            r4 = 0x00000000U;
        }
        goto block_004288E4;
    }
block_004288E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004288E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004288E4U);
        }
        {
            const uint32_t updatedAddress = r5 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004288E4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x004288F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderGroup_SubmitModels_002F7684(frame, context, state, 0x002F7684U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004288F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004288F0;
    }
block_004288F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004288F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004288F0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_004288E4; }
        goto block_004288FC;
    }
block_004288FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004288FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004288FCU);
        }
        goto block_00428934;
    }
block_00428934:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00428934U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00428934U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00428934U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042893CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseQuadGroup_UpdateAndSubmit_002F94A8(frame, context, state, 0x002F94A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042893CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042893C;
    }
block_0042893C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042893CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042893CU);
        }
        {
            const uint32_t operand = 0x00000054U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00428940U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00428940U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00428940U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00428940U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00428944U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00428944U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00428944U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00428944U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00428944U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00428944U,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00428944U,
                                           firstAddress + 24U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_PauseTouchButtonPanel_Init_0046ACB8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0046ACB8U:
        goto block_0046ACB8;
    case 0x0046ACCCU:
        goto block_0046ACCC;
    case 0x0046ACD4U:
        goto block_0046ACD4;
    case 0x0046ACE4U:
        goto block_0046ACE4;
    case 0x0046AD04U:
        goto block_0046AD04;
    case 0x0046AD20U:
        goto block_0046AD20;
    case 0x0046AD34U:
        goto block_0046AD34;
    case 0x0046AD48U:
        goto block_0046AD48;
    case 0x0046AD58U:
        goto block_0046AD58;
    case 0x0046AD78U:
        goto block_0046AD78;
    case 0x0046ADB0U:
        goto block_0046ADB0;
    case 0x0046ADC4U:
        goto block_0046ADC4;
    case 0x0046ADD0U:
        goto block_0046ADD0;
    case 0x0046ADE0U:
        goto block_0046ADE0;
    case 0x0046ADF0U:
        goto block_0046ADF0;
    case 0x0046AE10U:
        goto block_0046AE10;
    case 0x0046AE1CU:
        goto block_0046AE1C;
    case 0x0046AE28U:
        goto block_0046AE28;
    case 0x0046AE50U:
        goto block_0046AE50;
    case 0x0046AE60U:
        goto block_0046AE60;
    case 0x0046AE68U:
        goto block_0046AE68;
    case 0x0046AE74U:
        goto block_0046AE74;
    case 0x0046AE7CU:
        goto block_0046AE7C;
    case 0x0046AE94U:
        goto block_0046AE94;
    case 0x0046AEACU:
        goto block_0046AEAC;
    case 0x0046AECCU:
        goto block_0046AECC;
    case 0x0046AED8U:
        goto block_0046AED8;
    case 0x0046AEE8U:
        goto block_0046AEE8;
    case 0x0046AEF8U:
        goto block_0046AEF8;
    case 0x0046AF08U:
        goto block_0046AF08;
    case 0x0046AF18U:
        goto block_0046AF18;
    case 0x0046AF64U:
        goto block_0046AF64;
    case 0x0046AF70U:
        goto block_0046AF70;
    case 0x0046AF80U:
        goto block_0046AF80;
    case 0x0046AF8CU:
        goto block_0046AF8C;
    case 0x0046AF98U:
        goto block_0046AF98;
    case 0x0046AFA8U:
        goto block_0046AFA8;
    case 0x0046AFB4U:
        goto block_0046AFB4;
    case 0x0046AFC0U:
        goto block_0046AFC0;
    case 0x0046AFD0U:
        goto block_0046AFD0;
    case 0x0046AFDCU:
        goto block_0046AFDC;
    case 0x0046AFECU:
        goto block_0046AFEC;
    case 0x0046AFF8U:
        goto block_0046AFF8;
    case 0x0046B008U:
        goto block_0046B008;
    case 0x0046B014U:
        goto block_0046B014;
    case 0x0046B024U:
        goto block_0046B024;
    case 0x0046B064U:
        goto block_0046B064;
    case 0x0046B0D4U:
        goto block_0046B0D4;
    case 0x0046B0DCU:
        goto block_0046B0DC;
    case 0x0046B0F8U:
        goto block_0046B0F8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0046ACB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ACB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ACB8U);
        }
        {
            const uint32_t firstAddress = r13 - 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0046ACB8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0046ACB8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0046ACB8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0046ACB8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0046ACB8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0046ACB8U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0046ACB8U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0046ACB8U,
                                           firstAddress + 28U);
            }
            r13 = r13 - 32U;
        }
        {
            const uint32_t operand = 0x00000700U;
            r13 = r13 - operand;
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x00000020U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046ACCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046ACCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046ACCC;
    }
block_0046ACCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ACCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ACCCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0046ACE4; }
        goto block_0046ACD4;
    }
block_0046ACD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ACD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ACD4U);
        }
        {
            r1 = 0x0000005CU;
        }
        {
            const uint32_t address = 0x0046ACE0U + 924U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ACD8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0046ACE4U + 924U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ACDCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046ACE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_Init_002FC694(frame, context, state, 0x002FC694U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046ACE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046ACE4;
    }
block_0046ACE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ACE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ACE4U);
        }
        {
            const uint32_t updatedAddress = 0x0046ACECU + 0x398U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ACE4U, address);
            }
            r5 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000364U;
            r2 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046ACF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046ACF4U, address);
            }
        }
        {
            r3 = 0x0000005CU;
        }
        {
            const uint32_t operand = 0x00000084U;
            r1 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AD04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadRects_002FC534(frame, context, state, 0x002FC534U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AD04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AD04;
    }
block_0046AD04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AD04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AD04U);
        }
        {
            const uint32_t updatedAddress = 0x0046AD0CU + 0x37CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AD04U, address);
            }
            r2 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046AD0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AD10U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x0000005CU;
        }
        {
            const uint32_t operand = 0x000002E0U;
            r1 = r2 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AD20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadTexcoords_002FC40C(frame, context, state, 0x002FC40CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AD20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AD20;
    }
block_0046AD20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AD20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AD20U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = 0x0046AD2CU + 864U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AD24U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000590U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000018CU;
            r0 = r0 + operand;
        }
        {
            r2 = 0x0000002EU;
        }
        goto block_0046AD34;
    }
block_0046AD34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AD34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AD34U);
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0046AD34U, address);
            }
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0046AD40U, address);
            }
        }
        if (!(flags.Z())) { goto block_0046AD34; }
        goto block_0046AD48;
    }
block_0046AD48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AD48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AD48U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AD48U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x0000005CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AD58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaValues_002FCDEC(frame, context, state, 0x002FCDECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AD58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AD58;
    }
block_0046AD58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AD58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AD58U);
        }
        {
            const uint32_t updatedAddress = 0x0046AD60U + 0x330U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AD58U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000140U;
            r8 = r13 + operand;
        }
        {
            r4 = r8;
        }
        {
            r0 = 0x00000000U;
        }
        {
            r3 = 0x0000005CU;
        }
        {
            r9 = 0x00000002U;
        }
        {
            r7 = 0x00000001U;
        }
        {
            r10 = 0x00000003U;
        }
        goto block_0046AD78;
    }
block_0046AD78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AD78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AD78U);
        }
        {
            r1 = r12 & Oot3dAotLsl(r0, 2U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046AD7CU, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r2 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046AD88U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046AD8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046AD90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046AD94U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r10 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046AD9CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r3, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r3 = r3 - operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) { goto block_0046AD78; }
        goto block_0046ADB0;
    }
block_0046ADB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ADB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ADB0U);
        }
        {
            const uint32_t operand = 0x00000028U;
            r4 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0046ADBCU + 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ADB4U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000118U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046ADC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_Memcpy_00371738(frame, context, state, 0x00371738U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046ADC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046ADC4;
    }
block_0046ADC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ADC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ADC4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ADC4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046ADD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_c_stride_30_002FC3FC(frame, context, state, 0x002FC3FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046ADD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046ADD0;
    }
block_0046ADD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ADD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ADD0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046ADD0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ADD4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046ADE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_14_stride_20_002FC3F0(frame, context, state, 0x002FC3F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046ADE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046ADE0;
    }
block_0046ADE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ADE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ADE0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046ADE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ADE4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046ADF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_18_stride_40_002FC3E4(frame, context, state, 0x002FC3E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046ADF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046ADF0;
    }
block_0046ADF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ADF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ADF0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046ADF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046ADFCU + 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ADF4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046ADF8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ADFCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE00U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE04U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x000001B8U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0046AE10U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AE10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AE10;
    }
block_0046AE10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AE10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AE10U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r1 = r4;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AE1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStageState_ConstructFromDescriptor_00348F34(frame, context, state, 0x00348F34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AE1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AE1C;
    }
block_0046AE1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AE1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AE1CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046AE1CU, address);
            }
        }
        {
            r0 = 0x00000002U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AE28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureDescriptor_GetBuiltin_002E11D0(frame, context, state, 0x002E11D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AE28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AE28;
    }
block_0046AE28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AE28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AE28U);
        }
        {
            const uint32_t updatedAddress = 0x0046AE30U + 0x26CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE28U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046AE34U + 0x26CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE2CU, address);
            }
            r12 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046AE34U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046AE38U, address);
            }
        }
        {
            r2 = r0;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046AE40U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE44U, address);
            }
            r0 = value;
        }
        {
            r3 = r12;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AE50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStage_ConfigureTextureUnit_00348A64(frame, context, state, 0x00348A64U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AE50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AE50;
    }
block_0046AE50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AE50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AE50U);
        }
        {
            const uint32_t updatedAddress = 0x0046AE58U + 0x24CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE50U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE54U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0046AE94; }
        goto block_0046AE60;
    }
block_0046AE60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AE60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AE60U);
        }
        {
            const uint32_t updatedAddress = 0x0046AE68U + 0x23CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE60U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AE68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AE68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AE68;
    }
block_0046AE68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AE68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AE68U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0046AE94; }
        goto block_0046AE74;
    }
block_0046AE74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AE74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AE74U);
        }
        {
            const uint32_t updatedAddress = 0x0046AE7CU + 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE74U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AE7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AE7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AE7C;
    }
block_0046AE7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AE7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AE7CU);
        }
        {
            const uint32_t updatedAddress = 0x0046AE84U + 0x228U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE7CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046AE88U + 0x228U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE80U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x0046AE90U + 0x214U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE88U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_0046AE94;
    }
block_0046AE94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AE94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AE94U);
        }
        {
            const uint32_t updatedAddress = 0x0046AE9CU + 0x218U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE94U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AE9CU, address);
            }
            r1 = value;
        }
        {
            r2 = r3;
        }
        {
            const uint32_t updatedAddress = r0 + 0x47CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AEA4U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AEACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererModelResource_Create_0034897C(frame, context, state, 0x0034897CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AEACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AEAC;
    }
block_0046AEAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AEACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AEACU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046AEACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AEB0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046AEBCU + 0x1FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AEB4U, address);
            }
            r8 = value;
        }
        {
            r1 = r1 | 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046AEBCU, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AECCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AECCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AECC;
    }
block_0046AECC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AECCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AECCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0046AEE8; }
        goto block_0046AED8;
    }
block_0046AED8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AED8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AED8U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AEE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_Init_002F8EE4(frame, context, state, 0x002F8EE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AEE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AEE8;
    }
block_0046AEE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AEE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AEE8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046AEE8U, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x00000038U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AEF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AEF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AEF8;
    }
block_0046AEF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AEF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AEF8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r2 = 0x00000004U;
        }
        if (!(flags.Z())) {
            r1 = 0x00000007U;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AF08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseQuadGroup_Construct_002F2448(frame, context, state, 0x002F2448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AF08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AF08;
    }
block_0046AF08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AF08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AF08U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046AF08U, address);
            }
        }
        {
            const uint32_t address = 0x0046AF14U + 424U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AF0CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AF18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseQuadGroup_SetPosition_002F7AF4(frame, context, state, 0x002F7AF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AF18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AF18;
    }
block_0046AF18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AF18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AF18U);
        }
        {
            r0 = 0x00000051U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046AF1CU, address);
            }
        }
        {
            r4 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046AF24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046AF28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046AF2CU, address);
            }
        }
        {
            r0 = ~(0x00000000U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046AF34U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046AF38U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046AF3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046AF40U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046AF44U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046AF48U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x74U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046AF4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x78U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0046AF50U, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x00000014U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046AF5CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AF64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AF64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AF64;
    }
block_0046AF64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AF64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AF64U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r1 = 0x00000004U;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AF70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseCounter_Construct_002DB6A0(frame, context, state, 0x002DB6A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AF70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AF70;
    }
block_0046AF70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AF70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AF70U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046AF70U, address);
            }
        }
        {
            const uint32_t address = 0x0046AF7CU + 324U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AF74U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0046AF80U + 324U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AF78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AF80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseCounter_UpdateDigitPositions_002FCC88(frame, context, state, 0x002FCC88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AF80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AF80;
    }
block_0046AF80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AF80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AF80U);
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x00000014U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AF8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AF8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AF8C;
    }
block_0046AF8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AF8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AF8CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r1 = 0x00000004U;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AF98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseCounter_Construct_002DB6A0(frame, context, state, 0x002DB6A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AF98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AF98;
    }
block_0046AF98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AF98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AF98U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046AF98U, address);
            }
        }
        {
            const uint32_t address = 0x0046AFA4U + 292U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AF9CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0046AFA8U + 292U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046AFA0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AFA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseCounter_UpdateDigitPositions_002FCC88(frame, context, state, 0x002FCC88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AFA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AFA8;
    }
block_0046AFA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AFA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AFA8U);
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x00000010U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AFB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AFB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AFB4;
    }
block_0046AFB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AFB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AFB4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r1 = 0x00000001U;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AFC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseUiSixteenQuadOverlay_Construct_002D2190(frame, context, state, 0x002D2190U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AFC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AFC0;
    }
block_0046AFC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AFC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AFC0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046AFC0U, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x00000050U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AFD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AFD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AFD0;
    }
block_0046AFD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AFD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AFD0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r1 = 0x00000001U;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AFDCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseUiTwentyFiveQuadOverlay_Construct_002D1E30(frame, context, state, 0x002D1E30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AFDCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AFDC;
    }
block_0046AFDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AFDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AFDCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046AFDCU, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x00000010U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AFECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AFECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AFEC;
    }
block_0046AFEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AFECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AFECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r1 = 0x00000001U;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046AFF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseUiEightQuadOverlay_Construct_002D1AF8(frame, context, state, 0x002D1AF8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046AFF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046AFF8;
    }
block_0046AFF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046AFF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046AFF8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046AFF8U, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B008U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B008U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B008;
    }
block_0046B008:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B008U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B008U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0046B024; }
        goto block_0046B014;
    }
block_0046B014:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B014U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B014U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000008U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B024U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_Init_002F8EE4(frame, context, state, 0x002F8EE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B024U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B024;
    }
block_0046B024:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B024U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B024U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B024U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046B030U + 0xA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B028U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000018U;
            r6 = r13 + operand;
        }
        {
            r3 = 0x00000053U;
        }
        {
            const uint32_t operand = 0x00000020U;
            r7 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0046B038U, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = r6;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0046B040U, faultAddress);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            r1 = r0;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0046B04CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046B04CU,
                                           firstAddress + 4U);
            }
        }
        {
            r1 = r7;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046B054U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B058U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B064U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadRects_002FC534(frame, context, state, 0x002FC534U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B064U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B064;
    }
block_0046B064:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B064U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B064U);
        }
        {
            r3 = 0x00000054U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046B068U, address);
            }
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = r6;
        }
        {
            r1 = r7;
        }
        goto block_0046B0D4;
    }
block_0046B0D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B0D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B0D4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B0D4U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B0DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadRects_002FC534(frame, context, state, 0x002FC534U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B0DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B0DC;
    }
block_0046B0DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B0DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B0DCU);
        }
        {
            r3 = 0x00000055U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046B0E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B0E4U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = r6;
        }
        {
            r1 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B0F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadRects_002FC534(frame, context, state, 0x002FC534U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B0F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B0F8;
    }
block_0046B0F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B0F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B0F8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046B0F8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000700U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0046B100U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0046B100U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0046B100U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0046B100U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0046B100U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0046B100U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0046B100U,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0046B100U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_PauseItemsPage_Init_0046B554(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0046B554U:
        goto block_0046B554;
    case 0x0046B56CU:
        goto block_0046B56C;
    case 0x0046B574U:
        goto block_0046B574;
    case 0x0046B584U:
        goto block_0046B584;
    case 0x0046B5A4U:
        goto block_0046B5A4;
    case 0x0046B5C0U:
        goto block_0046B5C0;
    case 0x0046B5D0U:
        goto block_0046B5D0;
    case 0x0046B5E4U:
        goto block_0046B5E4;
    case 0x0046B5F8U:
        goto block_0046B5F8;
    case 0x0046B614U:
        goto block_0046B614;
    case 0x0046B64CU:
        goto block_0046B64C;
    case 0x0046B65CU:
        goto block_0046B65C;
    case 0x0046B668U:
        goto block_0046B668;
    case 0x0046B678U:
        goto block_0046B678;
    case 0x0046B688U:
        goto block_0046B688;
    case 0x0046B6ACU:
        goto block_0046B6AC;
    case 0x0046B6B8U:
        goto block_0046B6B8;
    case 0x0046B6C4U:
        goto block_0046B6C4;
    case 0x0046B6E8U:
        goto block_0046B6E8;
    case 0x0046B6F8U:
        goto block_0046B6F8;
    case 0x0046B700U:
        goto block_0046B700;
    case 0x0046B70CU:
        goto block_0046B70C;
    case 0x0046B714U:
        goto block_0046B714;
    case 0x0046B72CU:
        goto block_0046B72C;
    case 0x0046B744U:
        goto block_0046B744;
    case 0x0046B764U:
        goto block_0046B764;
    case 0x0046B770U:
        goto block_0046B770;
    case 0x0046B780U:
        goto block_0046B780;
    case 0x0046B790U:
        goto block_0046B790;
    case 0x0046B79CU:
        goto block_0046B79C;
    case 0x0046B7ACU:
        goto block_0046B7AC;
    case 0x0046B7BCU:
        goto block_0046B7BC;
    case 0x0046B7C8U:
        goto block_0046B7C8;
    case 0x0046B7D8U:
        goto block_0046B7D8;
    case 0x0046B7E8U:
        goto block_0046B7E8;
    case 0x0046B7F4U:
        goto block_0046B7F4;
    case 0x0046B804U:
        goto block_0046B804;
    case 0x0046B81CU:
        goto block_0046B81C;
    case 0x0046B82CU:
        goto block_0046B82C;
    case 0x0046B838U:
        goto block_0046B838;
    case 0x0046B848U:
        goto block_0046B848;
    case 0x0046B85CU:
        goto block_0046B85C;
    case 0x0046B86CU:
        goto block_0046B86C;
    case 0x0046B878U:
        goto block_0046B878;
    case 0x0046B888U:
        goto block_0046B888;
    case 0x0046B894U:
        goto block_0046B894;
    case 0x0046B8A0U:
        goto block_0046B8A0;
    case 0x0046B8B0U:
        goto block_0046B8B0;
    case 0x0046B8C0U:
        goto block_0046B8C0;
    case 0x0046B8CCU:
        goto block_0046B8CC;
    case 0x0046B8DCU:
        goto block_0046B8DC;
    case 0x0046B8ECU:
        goto block_0046B8EC;
    case 0x0046B8F8U:
        goto block_0046B8F8;
    case 0x0046B908U:
        goto block_0046B908;
    case 0x0046B918U:
        goto block_0046B918;
    case 0x0046B968U:
        goto block_0046B968;
    case 0x0046B970U:
        goto block_0046B970;
    case 0x0046B97CU:
        goto block_0046B97C;
    case 0x0046B988U:
        goto block_0046B988;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0046B554:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B554U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B554U);
        }
        {
            const uint32_t firstAddress = r13 - 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0046B554U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0046B554U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0046B554U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0046B554U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0046B554U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0046B554U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0046B554U,
                                           firstAddress + 24U);
            }
            r13 = r13 - 28U;
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x00000020U;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0046B560U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0046B560U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000374U;
            r13 = r13 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B56CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B56CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B56C;
    }
block_0046B56C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B56CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B56CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0046B584; }
        goto block_0046B574;
    }
block_0046B574:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B574U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B574U);
        }
        {
            r1 = 0x00000025U;
        }
        {
            const uint32_t address = 0x0046B580U + 932U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B578U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B584U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_Init_002FC694(frame, context, state, 0x002FC694U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B584U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B584;
    }
block_0046B584:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B584U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B584U);
        }
        {
            const uint32_t updatedAddress = 0x0046B58CU + 0x39CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B584U, address);
            }
            r5 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000001E8U;
            r2 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B590U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046B594U, address);
            }
        }
        {
            r3 = 0x00000025U;
        }
        {
            const uint32_t operand = 0x000000C0U;
            r1 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B5A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadRects_002FC534(frame, context, state, 0x002FC534U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B5A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B5A4;
    }
block_0046B5A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B5A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B5A4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046B5A8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000310U;
            r2 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B5B0U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000025U;
        }
        {
            const uint32_t operand = 0x00000128U;
            r1 = r2 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B5C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadTexcoords_002FC40C(frame, context, state, 0x002FC40CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B5C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B5C0;
    }
block_0046B5C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B5C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B5C0U);
        }
        {
            const uint32_t address = 0x0046B5C8U + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B5C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000002E0U;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 736U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0046B5C8U, address);
            }
        }
        {
            r1 = 0x00000012U;
        }
        goto block_0046B5D0;
    }
block_0046B5D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B5D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B5D0U);
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0046B5D0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0046B5DCU, address);
            }
        }
        if (!(flags.Z())) { goto block_0046B5D0; }
        goto block_0046B5E4;
    }
block_0046B5E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B5E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B5E4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B5E4U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x00000025U;
        }
        {
            const uint32_t operand = 0x000002E0U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B5F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaValues_002FCDEC(frame, context, state, 0x002FCDECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B5F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B5F8;
    }
block_0046B5F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B5F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B5F8U);
        }
        {
            const uint32_t updatedAddress = 0x0046B600U + 0x330U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B5F8U, address);
            }
            r4 = value;
        }
        {
            const uint32_t operand = 0x00000124U;
            r0 = r13 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r2 = 0x00000025U;
        }
        {
            r7 = 0x00000002U;
        }
        {
            r8 = 0x00000001U;
        }
        {
            r9 = 0x00000003U;
        }
        goto block_0046B614;
    }
block_0046B614:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B614U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B614U);
        }
        {
            r3 = r4 & Oot3dAotLsl(r1, 2U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046B618U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r3 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r12 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046B624U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046B628U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046B62CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046B630U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r3 = r9 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046B638U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        if (!(flags.Z())) { goto block_0046B614; }
        goto block_0046B64C;
    }
block_0046B64C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B64CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B64CU);
        }
        {
            const uint32_t updatedAddress = 0x0046B654U + 0x2E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B64CU, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000118U;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B65CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_Memcpy_00371738(frame, context, state, 0x00371738U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B65CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B65C;
    }
block_0046B65C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B65CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B65CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B65CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B668U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_c_stride_30_002FC3FC(frame, context, state, 0x002FC3FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B668U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B668;
    }
block_0046B668:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B668U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B668U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B668U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B66CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B678U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_14_stride_20_002FC3F0(frame, context, state, 0x002FC3F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B678U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B678;
    }
block_0046B678:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B678U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B678U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B678U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B67CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B688U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_offset_from_field_18_stride_40_002FC3E4(frame, context, state, 0x002FC3E4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B688U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B688;
    }
block_0046B688:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B688U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B688U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B688U, address);
            }
        }
        {
            const uint32_t operand = 0x00000124U;
            r0 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B690U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046B69CU + 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B694U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B698U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B69CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B6A0U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x000001B8U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0046B6ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B6ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B6AC;
    }
block_0046B6AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B6ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B6ACU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x0000000CU;
            r1 = r13 + operand;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B6B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStageState_ConstructFromDescriptor_00348F34(frame, context, state, 0x00348F34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B6B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B6B8;
    }
block_0046B6B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B6B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B6B8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B6B8U, address);
            }
        }
        {
            r0 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B6C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureDescriptor_GetBuiltin_002E11D0(frame, context, state, 0x002E11D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B6C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B6C4;
    }
block_0046B6C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B6C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B6C4U);
        }
        {
            const uint32_t updatedAddress = 0x0046B6CCU + 0x274U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B6C4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046B6D0U + 0x26CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B6C8U, address);
            }
            r2 = value;
        }
        {
            r3 = r1;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046B6D0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0046B6D0U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046B6D4U, address);
            }
        }
        {
            r2 = r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B6DCU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B6E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererTextureStage_ConfigureTextureUnit_00348A64(frame, context, state, 0x00348A64U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B6E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B6E8;
    }
block_0046B6E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B6E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B6E8U);
        }
        {
            const uint32_t updatedAddress = 0x0046B6F0U + 0x254U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B6E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B6ECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0046B72C; }
        goto block_0046B6F8;
    }
block_0046B6F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B6F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B6F8U);
        }
        {
            const uint32_t updatedAddress = 0x0046B700U + 0x244U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B6F8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B700U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B700U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B700;
    }
block_0046B700:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B700U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B700U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0046B72C; }
        goto block_0046B70C;
    }
block_0046B70C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B70CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B70CU);
        }
        {
            const uint32_t updatedAddress = 0x0046B714U + 0x234U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B70CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B714U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B714U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B714;
    }
block_0046B714:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B714U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B714U);
        }
        {
            const uint32_t updatedAddress = 0x0046B71CU + 0x230U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B714U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046B720U + 0x230U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B718U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x0046B728U + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B720U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_0046B72C;
    }
block_0046B72C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B72CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B72CU);
        }
        {
            const uint32_t updatedAddress = 0x0046B734U + 0x220U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B72CU, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B734U, address);
            }
            r1 = value;
        }
        {
            r2 = r3;
        }
        {
            const uint32_t updatedAddress = r0 + 0x47CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B73CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B744U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererModelResource_Create_0034897C(frame, context, state, 0x0034897CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B744U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B744;
    }
block_0046B744:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B744U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B744U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B744U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B748U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046B754U + 0x204U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B74CU, address);
            }
            r4 = value;
        }
        {
            r1 = r1 | 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x178U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046B754U, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B764U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B764U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B764;
    }
block_0046B764:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B764U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B764U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0046B780; }
        goto block_0046B770;
    }
block_0046B770:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B770U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B770U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x00000018U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B780U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_Init_002F8EE4(frame, context, state, 0x002F8EE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B780U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B780;
    }
block_0046B780:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B780U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B780U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B780U, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B790U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B790U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B790;
    }
block_0046B790:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B790U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B790U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0046B7AC; }
        goto block_0046B79C;
    }
block_0046B79C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B79CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B79CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B7ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_Init_002F8EE4(frame, context, state, 0x002F8EE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B7ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B7AC;
    }
block_0046B7AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B7ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B7ACU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B7ACU, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B7BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B7BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B7BC;
    }
block_0046B7BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B7BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B7BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0046B7D8; }
        goto block_0046B7C8;
    }
block_0046B7C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B7C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B7C8U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r3;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B7D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_Init_002F8EE4(frame, context, state, 0x002F8EE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B7D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B7D8;
    }
block_0046B7D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B7D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B7D8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B7D8U, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B7E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B7E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B7E8;
    }
block_0046B7E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B7E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B7E8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0046B804; }
        goto block_0046B7F4;
    }
block_0046B7F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B7F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B7F4U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r3;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B804U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_Init_002F8EE4(frame, context, state, 0x002F8EE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B804U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B804;
    }
block_0046B804:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B804U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B804U);
        }
        {
            const uint32_t address = 0x0046B80CU + 336U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B804U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B808U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B80CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B81CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_SetSlotAlpha_002F8CE0(frame, context, state, 0x002F8CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B81CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B81C;
    }
block_0046B81C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B81CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B81CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r5 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B820U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B82CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_SetSlotAlpha_002F8CE0(frame, context, state, 0x002F8CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B82CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B82C;
    }
block_0046B82C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B82CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B82CU);
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x00000038U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B838U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B838U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B838;
    }
block_0046B838:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B838U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B838U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r2 = 0x00000001U;
        }
        if (!(flags.Z())) {
            r1 = 0x00000000U;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B848U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseQuadGroup_Construct_002F2448(frame, context, state, 0x002F2448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B848U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B848;
    }
block_0046B848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B848U);
        }
        {
            const uint32_t updatedAddress = 0x0046B850U + 0x110U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B848U, address);
            }
            r7 = value;
        }
        {
            r1 = r6;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B850U, address);
            }
        }
        {
            r0 = 0x00000038U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B85CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B85CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B85C;
    }
block_0046B85C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B85CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B85CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r2 = 0x00000001U;
        }
        if (!(flags.Z())) {
            r1 = r2;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B86CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseQuadGroup_Construct_002F2448(frame, context, state, 0x002F2448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B86CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B86C;
    }
block_0046B86C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B86CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B86CU);
        }
        {
            r4 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0046B878U + 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B870U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B874U, address);
            }
        }
        goto block_0046B878;
    }
block_0046B878:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B878U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B878U);
        }
        {
            const uint32_t updatedAddress = r7 + Oot3dAotLsl(r4, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046B878U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B888U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseQuadGroup_SetScale_002F79B4(frame, context, state, 0x002F79B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B888U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B888;
    }
block_0046B888:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B888U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B888U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046B878; }
        goto block_0046B894;
    }
block_0046B894:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B894U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B894U);
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x00000038U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B8A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B8A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B8A0;
    }
block_0046B8A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B8A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B8A0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r2 = 0x00000001U;
        }
        if (!(flags.Z())) {
            r1 = 0x00000000U;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B8B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseQuadGroup_Construct_002F2448(frame, context, state, 0x002F2448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B8B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B8B0;
    }
block_0046B8B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B8B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B8B0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B8B4U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B8C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseQuadGroup_SetScale_002F79B4(frame, context, state, 0x002F79B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B8C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B8C0;
    }
block_0046B8C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B8C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B8C0U);
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x00000038U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B8CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B8CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B8CC;
    }
block_0046B8CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B8CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B8CCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r2 = 0x00000001U;
        }
        if (!(flags.Z())) {
            r1 = 0x00000006U;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B8DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseQuadGroup_Construct_002F2448(frame, context, state, 0x002F2448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B8DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B8DC;
    }
block_0046B8DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B8DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B8DCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B8DCU, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x0000000CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B8ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B8ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B8EC;
    }
block_0046B8EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B8ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B8ECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B8F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseItemsPage_InitAuxiliaryQuadGroup_0048046C(frame, context, state, 0x0048046CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B8F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B8F8;
    }
block_0046B8F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B8F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B8F8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B8F8U, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = 0x00000038U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B908U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ResourceMemory_Allocate_00313CE0(frame, context, state, 0x00313CE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B908U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B908;
    }
block_0046B908:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B908U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B908U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r2 = 0x00000004U;
        }
        if (!(flags.Z())) {
            r1 = 0x00000008U;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B918U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseQuadGroup_Construct_002F2448(frame, context, state, 0x002F2448U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B918U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B918;
    }
block_0046B918:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B918U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B918U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        goto block_0046B968;
    }
block_0046B968:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B968U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B968U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046B968U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B970U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseQuadGroup_SetPosition_002F7AF4(frame, context, state, 0x002F7AF4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B970U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B970;
    }
block_0046B970:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B970U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B970U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B97CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseItemsPage_ResetState_002EB05C(frame, context, state, 0x002EB05CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B97CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B97C;
    }
block_0046B97C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B97CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B97CU);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046B988U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseItemsPage_ResetInteractionState_002EB628(frame, context, state, 0x002EB628U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046B988U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046B988;
    }
block_0046B988:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046B988U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046B988U);
        }
        {
            const uint32_t operand = 0x00000374U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0046B98CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0046B98CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0046B990U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0046B990U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0046B990U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0046B990U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0046B990U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0046B990U,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0046B990U,
                                           firstAddress + 24U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
