#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_FUN_002d1210_002D1210(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_002d1244_002D1244(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_002d134c_002D134C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00303b24_00303B24(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0046c204_0046C204(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00483a3c_00483A3C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_FUN_002d1210_002D1210(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r8 = state.R[8];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002D1210U:
        goto block_002D1210;
    case 0x002D1218U:
        goto block_002D1218;
    case 0x002D1230U:
        goto block_002D1230;
    case 0x002D1238U:
        goto block_002D1238;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002D1210:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D1210U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D1210U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000020U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_002D1238; }
        goto block_002D1218;
    }
block_002D1218:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D1218U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D1218U);
        }
        {
            const uint32_t updatedAddress = 0x002D1220U + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D1218U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D121CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x828U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D1224U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002D1238; }
        goto block_002D1230;
    }
block_002D1230:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D1230U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D1230U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D1230U, address);
            }
            r0 = value;
        }
        return Oot3dAotReturned(r14);
    }
block_002D1238:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D1238U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D1238U);
        }
        {
            r0 = 0x00000000U;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_002d1244_002D1244(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002D1244U:
        goto block_002D1244;
    case 0x002D1270U:
        goto block_002D1270;
    case 0x002D127CU:
        goto block_002D127C;
    case 0x002D1288U:
        goto block_002D1288;
    case 0x002D128CU:
        goto block_002D128C;
    case 0x002D12D0U:
        goto block_002D12D0;
    case 0x002D12F8U:
        goto block_002D12F8;
    case 0x002D12FCU:
        goto block_002D12FC;
    case 0x002D1308U:
        goto block_002D1308;
    case 0x002D1314U:
        goto block_002D1314;
    case 0x002D132CU:
        goto block_002D132C;
    case 0x002D1330U:
        goto block_002D1330;
    case 0x002D133CU:
        goto block_002D133C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002D1244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D1244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D1244U);
        }
        {
            const uint32_t firstAddress = r13 - 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002D1244U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x002D1244U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002D1244U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x002D1244U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002D1244U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002D1244U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002D1244U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002D1244U,
                                           firstAddress + 28U);
            }
            r13 = r13 - 32U;
        }
        {
            r4 = Oot3dAotLsr(r1, 7U);
        }
        {
            r12 = r1 & ~(0x00000001U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = 0x002D125CU + 0xECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D1254U, address);
            }
            r11 = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D1258U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 2U);
            r12 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r4 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D1264U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r12, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_002D127C; }
        goto block_002D1270;
    }
block_002D1270:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D1270U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D1270U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x002D1270U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002D1274U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002D1274U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002D1274U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002D1274U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002D1274U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002D1274U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002D1274U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002D1274U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 32U;
        }
        return Oot3dAotReturned(r14);
    }
block_002D127C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D127CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D127CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r8 = 0x00000000U;
        }
        if (!(flags.C()) || (flags.Z())) { goto block_002D133C; }
        goto block_002D1288;
    }
block_002D1288:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D1288U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D1288U);
        }
        {
            const uint32_t operand = 0x00100000U;
            r10 = r8 - operand;
        }
        goto block_002D128C;
    }
block_002D128C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D128CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D128CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 2U);
            r12 = r2 + operand;
        }
        {
            const uint32_t operand = r8;
            r4 = r1 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000080U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = r12;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D1298U, address);
            }
            r7 = value;
            r12 = updatedAddress;
        }
        if ((flags.C()) && !(flags.Z())) {
            r4 = 0x00000080U;
        }
        {
            const uint32_t operand = 0x00000004U;
            r5 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x002D12A4U, address);
            }
        }
        {
            const uint32_t operand = r8;
            r6 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 20U);
            r3 = r10 + operand;
        }
        {
            r3 = r3 | r6;
        }
        {
            r3 = r3 | 0x80000000U;
        }
        {
            r3 = r3 | 0x000F0000U;
        }
        {
            r9 = Oot3dAotLsr(r4, 1U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002D12C0U, address);
            }
        }
        {
            Oot3dAotSetAddFlags(flags, r9, 0x80000001U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r5 + operand;
        }
        if (!(flags.C()) || (flags.Z())) { goto block_002D12FC; }
        goto block_002D12D0;
    }
block_002D12D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D12D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D12D0U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D12D0U, address);
            }
            r5 = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r4 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r6 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002D12DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D12E0U, address);
            }
            r5 = value;
            r12 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r9, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r9 = r9 - operand;
        }
        {
            r3 = r6;
        }
        {
            const uint32_t operand = 0x00000004U;
            r12 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002D12F0U, address);
            }
        }
        if (!(flags.Z())) { goto block_002D12D0; }
        goto block_002D12F8;
    }
block_002D12F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D12F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D12F8U);
        }
        goto block_002D1330;
    }
block_002D12FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D12FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D12FCU);
        }
        {
            r5 = Oot3dAotLsl(r9, 1U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002D1330; }
        goto block_002D1308;
    }
block_002D1308:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D1308U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D1308U);
        }
        {
            const uint32_t operand = 0x00000004U;
            r12 = r12 - operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r4 = r3 - operand;
        }
        {
            r5 = Oot3dAotAsr(r5, 1U);
        }
        goto block_002D1314;
    }
block_002D1314:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D1314U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D1314U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D1314U, address);
            }
            r7 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r5, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r5 = r5 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x002D131CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r12 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D1320U, address);
            }
            r6 = value;
            r12 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002D1324U, address);
            }
            r4 = updatedAddress;
        }
        if (!(flags.Z())) { goto block_002D1314; }
        goto block_002D132C;
    }
block_002D132C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D132CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D132CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 3U);
            r3 = r3 + operand;
        }
        goto block_002D1330;
    }
block_002D1330:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D1330U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D1330U);
        }
        {
            const uint32_t operand = 0x00000080U;
            r8 = r8 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_002D128C; }
        goto block_002D133C;
    }
block_002D133C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D133CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D133CU);
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002D133CU, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002D1340U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002D1340U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002D1340U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002D1340U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002D1340U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002D1340U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002D1340U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002D1340U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 32U;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_002d134c_002D134C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002D134CU:
        goto block_002D134C;
    case 0x002D1368U:
        goto block_002D1368;
    case 0x002D136CU:
        goto block_002D136C;
    case 0x002D1374U:
        goto block_002D1374;
    case 0x002D137CU:
        goto block_002D137C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002D134C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D134CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D134CU);
        }
        {
            const uint32_t updatedAddress = 0x002D1354U + 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D134CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r13 - 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x002D1350U, address);
            }
            r13 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x002D1354U, faultAddress);
            }
            r2 = static_cast<uint32_t>(value);
            r3 = static_cast<uint32_t>(value >> 32U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r4 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r4 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_002D1374; }
        goto block_002D1368;
    }
block_002D1368:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D1368U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D1368U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002D1368U, address);
            }
        }
        goto block_002D136C;
    }
block_002D136C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D136CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D136CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = r13;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D136CU, address);
            }
            r4 = value;
            r13 = updatedAddress;
        }
        return Oot3dAotReturned(r14);
    }
block_002D1374:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D1374U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D1374U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002D136C; }
        goto block_002D137C;
    }
block_002D137C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D137CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D137CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r0 = r0 | Oot3dAotLsl(r1, 20U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = r2;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002D1388U, address);
            }
            r2 = updatedAddress;
        }
        {
            const uint32_t value = r1 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002D1390U, address);
            }
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r2 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002D139CU, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002D13A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = r13;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D13A8U, address);
            }
            r4 = value;
            r13 = updatedAddress;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_00303b24_00303B24(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00303B24U:
        goto block_00303B24;
    case 0x00303B5CU:
        goto block_00303B5C;
    case 0x00303B68U:
        goto block_00303B68;
    case 0x00303BB0U:
        goto block_00303BB0;
    case 0x00303BD8U:
        goto block_00303BD8;
    case 0x00303BE0U:
        goto block_00303BE0;
    case 0x00303BE4U:
        goto block_00303BE4;
    case 0x00303BFCU:
        goto block_00303BFC;
    case 0x00303C0CU:
        goto block_00303C0C;
    case 0x00303C18U:
        goto block_00303C18;
    case 0x00303C1CU:
        goto block_00303C1C;
    case 0x00303C48U:
        goto block_00303C48;
    case 0x00303C50U:
        goto block_00303C50;
    case 0x00303C54U:
        goto block_00303C54;
    case 0x00303C78U:
        goto block_00303C78;
    case 0x00303C8CU:
        goto block_00303C8C;
    case 0x00303CA4U:
        goto block_00303CA4;
    case 0x00303CACU:
        goto block_00303CAC;
    case 0x00303CB4U:
        goto block_00303CB4;
    case 0x00303CB8U:
        goto block_00303CB8;
    case 0x00303CC4U:
        goto block_00303CC4;
    case 0x00303CCCU:
        goto block_00303CCC;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00303B24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303B24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303B24U);
        }
        {
            const uint32_t firstAddress = r13 - 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00303B24U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00303B24U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00303B24U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00303B24U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00303B24U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00303B24U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00303B24U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00303B24U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00303B24U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00303B24U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00303B24U,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00303B24U,
                                           firstAddress + 44U);
            }
            r13 = r13 - 48U;
        }
        {
            r11 = r1;
        }
        {
            const uint32_t updatedAddress = 0x00303B34U + 0x1A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303B2CU, address);
            }
            r0 = value;
        }
        {
            r2 = Oot3dAotLsr(r11, 7U);
        }
        {
            r1 = r1 & ~(0x00000001U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303B3CU, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303B40U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) {
            const uint32_t updatedAddress = 0x00303B58U + 0x17CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303B50U, address);
            }
            r1 = value;
        }
        if (flags.C()) {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00303B54U, address);
            }
        }
        if (flags.C()) { goto block_00303CCC; }
        goto block_00303B5C;
    }
block_00303B5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303B5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303B5CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r11, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r6 = 0x00000000U;
        }
        if (!(flags.C()) || (flags.Z())) { goto block_00303CC4; }
        goto block_00303B68;
    }
block_00303B68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303B68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303B68U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303B68U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + Oot3dAotLsl(r6, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303B70U, address);
            }
            r2 = value;
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r5 = r0 + operand;
        }
        {
            const uint32_t operand = r6;
            r0 = r11 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000080U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00303B80U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00303B8CU + 0x14CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303B84U, address);
            }
            r2 = value;
        }
        if ((flags.C()) && !(flags.Z())) {
            r0 = 0x00000080U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303B8CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 20U);
            r2 = r2 + operand;
        }
        {
            r9 = r0 & ~(0x00000001U);
        }
        {
            r2 = r2 | r3;
        }
        {
            r2 = r2 | 0x000F0000U;
        }
        {
            const uint32_t value = r9 & 0x0000000EU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t operand = 0x00000004U;
            r4 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00303BA8U, address);
            }
        }
        if (flags.Z()) { goto block_00303BD8; }
        goto block_00303BB0;
    }
block_00303BB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303BB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303BB0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303BB0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8U;
            const uint32_t address = r4;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00303BBCU, address);
            }
            r4 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303BC0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000002U;
            r9 = r9 - operand;
        }
        {
            const uint32_t value = r9 & 0x0000000EU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t operand = 0x00000008U;
            r5 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00303BD0U, address);
            }
        }
        if (!(flags.Z())) { goto block_00303BB0; }
        goto block_00303BD8;
    }
block_00303BD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303BD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303BD8U);
        }
        {
            Oot3dAotSetAddFlags(flags, r9, 0x80000001U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_00303C54; }
        goto block_00303BE0;
    }
block_00303BE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303BE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303BE0U);
        }
        {
            r7 = 0x00000010U;
        }
        goto block_00303BE4;
    }
block_00303BE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303BE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303BE4U);
        }
        {
            const uint32_t operand = r5;
            r0 = r4 - operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r9 = r9 - operand;
        }
        {
            r1 = Oot3dAotAsr(r0, 2U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            Oot3dAotSetSubtractFlags(flags, r7, Oot3dAotAsr(r0, 2U), static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00303C18; }
        goto block_00303BFC;
    }
block_00303BFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303BFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303BFCU);
        }
        {
            r2 = 0x00000040U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00303C0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00483a3c_00483A3C(frame, context, state, 0x00483A3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00303C0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00303C0C;
    }
block_00303C0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303C0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303C0CU);
        }
        {
            const uint32_t operand = 0x00000040U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000040U;
            r4 = r4 + operand;
        }
        goto block_00303C48;
    }
block_00303C18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303C18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303C18U);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_00303C1C;
    }
block_00303C1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303C1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303C1CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303C1CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r12 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00303C28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303C2CU, address);
            }
            r3 = value;
            r5 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000002U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000010U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            r4 = r12;
        }
        {
            const uint32_t operand = 0x00000004U;
            r5 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00303C40U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00303C1C; }
        goto block_00303C48;
    }
block_00303C48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303C48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303C48U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00303BE4; }
        goto block_00303C50;
    }
block_00303C50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303C50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303C50U);
        }
        goto block_00303CB8;
    }
block_00303C54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303C54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303C54U);
        }
        {
            r0 = ~(0x0000000EU);
        }
        {
            const uint32_t operand = r9;
            r0 = r0 - operand;
        }
        {
            r7 = 0x00000000U;
        }
        {
            r1 = Oot3dAotAsr(r0, 31U);
        }
        {
            r8 = r7;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r1, 28U);
            r0 = r0 + operand;
        }
        {
            r10 = Oot3dAotAsr(r0, 4U);
        }
        {
            const uint32_t operand = 0x00000000U;
            r9 = operand - r10;
        }
        goto block_00303CAC;
    }
block_00303C78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303C78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303C78U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 2U);
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r1 - operand;
        }
        {
            r2 = 0x00000008U;
        }
        goto block_00303C8C;
    }
block_00303C8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303C8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303C8CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303C8CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r2 = r2 - operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x00303C94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303C98U, address);
            }
            r3 = value;
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00303C9CU, address);
            }
            r1 = updatedAddress;
        }
        if (!(flags.Z())) { goto block_00303C8C; }
        goto block_00303CA4;
    }
block_00303CA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303CA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303CA4U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r8 = r8 + operand;
        }
        goto block_00303CAC;
    }
block_00303CAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303CACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303CACU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, r8, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00303C78; }
        goto block_00303CB4;
    }
block_00303CB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303CB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303CB4U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 6U);
            r4 = r4 - operand;
        }
        goto block_00303CB8;
    }
block_00303CB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303CB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303CB8U);
        }
        {
            const uint32_t operand = 0x00000080U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, r11, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_00303B68; }
        goto block_00303CC4;
    }
block_00303CC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303CC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303CC4U);
        }
        {
            const uint32_t updatedAddress = 0x00303CCCU + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00303CC4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00303CC8U, address);
            }
        }
        goto block_00303CCC;
    }
block_00303CCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00303CCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00303CCCU);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00303CD0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00303CD0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00303CD0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00303CD0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00303CD0U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00303CD0U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00303CD0U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00303CD0U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00303CD0U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_0046c204_0046C204(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0046C204U:
        goto block_0046C204;
    case 0x0046C230U:
        goto block_0046C230;
    case 0x0046C240U:
        goto block_0046C240;
    case 0x0046C24CU:
        goto block_0046C24C;
    case 0x0046C26CU:
        goto block_0046C26C;
    case 0x0046C29CU:
        goto block_0046C29C;
    case 0x0046C2A4U:
        goto block_0046C2A4;
    case 0x0046C2B4U:
        goto block_0046C2B4;
    case 0x0046C2BCU:
        goto block_0046C2BC;
    case 0x0046C2C8U:
        goto block_0046C2C8;
    case 0x0046C2D0U:
        goto block_0046C2D0;
    case 0x0046C2DCU:
        goto block_0046C2DC;
    case 0x0046C2E4U:
        goto block_0046C2E4;
    case 0x0046C2E8U:
        goto block_0046C2E8;
    case 0x0046C300U:
        goto block_0046C300;
    case 0x0046C314U:
        goto block_0046C314;
    case 0x0046C324U:
        goto block_0046C324;
    case 0x0046C33CU:
        goto block_0046C33C;
    case 0x0046C348U:
        goto block_0046C348;
    case 0x0046C360U:
        goto block_0046C360;
    case 0x0046C374U:
        goto block_0046C374;
    case 0x0046C380U:
        goto block_0046C380;
    case 0x0046C3A4U:
        goto block_0046C3A4;
    case 0x0046C3B0U:
        goto block_0046C3B0;
    case 0x0046C3BCU:
        goto block_0046C3BC;
    case 0x0046C3D4U:
        goto block_0046C3D4;
    case 0x0046C3F0U:
        goto block_0046C3F0;
    case 0x0046C3FCU:
        goto block_0046C3FC;
    case 0x0046C414U:
        goto block_0046C414;
    case 0x0046C41CU:
        goto block_0046C41C;
    case 0x0046C430U:
        goto block_0046C430;
    case 0x0046C438U:
        goto block_0046C438;
    case 0x0046C448U:
        goto block_0046C448;
    case 0x0046C454U:
        goto block_0046C454;
    case 0x0046C464U:
        goto block_0046C464;
    case 0x0046C478U:
        goto block_0046C478;
    case 0x0046C490U:
        goto block_0046C490;
    case 0x0046C4A0U:
        goto block_0046C4A0;
    case 0x0046C4B4U:
        goto block_0046C4B4;
    case 0x0046C4C4U:
        goto block_0046C4C4;
    case 0x0046C4D0U:
        goto block_0046C4D0;
    case 0x0046C4DCU:
        goto block_0046C4DC;
    case 0x0046C4F4U:
        goto block_0046C4F4;
    case 0x0046C508U:
        goto block_0046C508;
    case 0x0046C514U:
        goto block_0046C514;
    case 0x0046C524U:
        goto block_0046C524;
    case 0x0046C53CU:
        goto block_0046C53C;
    case 0x0046C54CU:
        goto block_0046C54C;
    case 0x0046C568U:
        goto block_0046C568;
    case 0x0046C578U:
        goto block_0046C578;
    case 0x0046C584U:
        goto block_0046C584;
    case 0x0046C59CU:
        goto block_0046C59C;
    case 0x0046C5B4U:
        goto block_0046C5B4;
    case 0x0046C5D0U:
        goto block_0046C5D0;
    case 0x0046C5E0U:
        goto block_0046C5E0;
    case 0x0046C5F8U:
        goto block_0046C5F8;
    case 0x0046C604U:
        goto block_0046C604;
    case 0x0046C61CU:
        goto block_0046C61C;
    case 0x0046C630U:
        goto block_0046C630;
    case 0x0046C63CU:
        goto block_0046C63C;
    case 0x0046C648U:
        goto block_0046C648;
    case 0x0046C658U:
        goto block_0046C658;
    case 0x0046C664U:
        goto block_0046C664;
    case 0x0046C688U:
        goto block_0046C688;
    case 0x0046C698U:
        goto block_0046C698;
    case 0x0046C6A4U:
        goto block_0046C6A4;
    case 0x0046C6C8U:
        goto block_0046C6C8;
    case 0x0046C6D4U:
        goto block_0046C6D4;
    case 0x0046C6E4U:
        goto block_0046C6E4;
    case 0x0046C6F4U:
        goto block_0046C6F4;
    case 0x0046C71CU:
        goto block_0046C71C;
    case 0x0046C730U:
        goto block_0046C730;
    case 0x0046C740U:
        goto block_0046C740;
    case 0x0046C750U:
        goto block_0046C750;
    case 0x0046C778U:
        goto block_0046C778;
    case 0x0046C78CU:
        goto block_0046C78C;
    case 0x0046C79CU:
        goto block_0046C79C;
    case 0x0046C7A8U:
        goto block_0046C7A8;
    case 0x0046C7BCU:
        goto block_0046C7BC;
    case 0x0046C808U:
        goto block_0046C808;
    case 0x0046C81CU:
        goto block_0046C81C;
    case 0x0046C83CU:
        goto block_0046C83C;
    case 0x0046C84CU:
        goto block_0046C84C;
    case 0x0046C85CU:
        goto block_0046C85C;
    case 0x0046C86CU:
        goto block_0046C86C;
    case 0x0046C890U:
        goto block_0046C890;
    case 0x0046C8A0U:
        goto block_0046C8A0;
    case 0x0046C8B4U:
        goto block_0046C8B4;
    case 0x0046C8C4U:
        goto block_0046C8C4;
    case 0x0046C8C8U:
        goto block_0046C8C8;
    case 0x0046C8D8U:
        goto block_0046C8D8;
    case 0x0046C8E4U:
        goto block_0046C8E4;
    case 0x0046C8E8U:
        goto block_0046C8E8;
    case 0x0046C8F0U:
        goto block_0046C8F0;
    case 0x0046C908U:
        goto block_0046C908;
    case 0x0046C928U:
        goto block_0046C928;
    case 0x0046C934U:
        goto block_0046C934;
    case 0x0046C94CU:
        goto block_0046C94C;
    case 0x0046C958U:
        goto block_0046C958;
    case 0x0046C960U:
        goto block_0046C960;
    case 0x0046C984U:
        goto block_0046C984;
    case 0x0046C998U:
        goto block_0046C998;
    case 0x0046C9A8U:
        goto block_0046C9A8;
    case 0x0046C9D8U:
        goto block_0046C9D8;
    case 0x0046C9F0U:
        goto block_0046C9F0;
    case 0x0046C9FCU:
        goto block_0046C9FC;
    case 0x0046CA10U:
        goto block_0046CA10;
    case 0x0046CA1CU:
        goto block_0046CA1C;
    case 0x0046CA28U:
        goto block_0046CA28;
    case 0x0046CA50U:
        goto block_0046CA50;
    case 0x0046CA60U:
        goto block_0046CA60;
    case 0x0046CA6CU:
        goto block_0046CA6C;
    case 0x0046CA80U:
        goto block_0046CA80;
    case 0x0046CA8CU:
        goto block_0046CA8C;
    case 0x0046CA94U:
        goto block_0046CA94;
    case 0x0046CAA8U:
        goto block_0046CAA8;
    case 0x0046CAB4U:
        goto block_0046CAB4;
    case 0x0046CAC8U:
        goto block_0046CAC8;
    case 0x0046CADCU:
        goto block_0046CADC;
    case 0x0046CAECU:
        goto block_0046CAEC;
    case 0x0046CB00U:
        goto block_0046CB00;
    case 0x0046CB1CU:
        goto block_0046CB1C;
    case 0x0046CB3CU:
        goto block_0046CB3C;
    case 0x0046CB68U:
        goto block_0046CB68;
    case 0x0046CB80U:
        goto block_0046CB80;
    case 0x0046CB94U:
        goto block_0046CB94;
    case 0x0046CBACU:
        goto block_0046CBAC;
    case 0x0046CBC4U:
        goto block_0046CBC4;
    case 0x0046CBD0U:
        goto block_0046CBD0;
    case 0x0046CBE8U:
        goto block_0046CBE8;
    case 0x0046CBF4U:
        goto block_0046CBF4;
    case 0x0046CC04U:
        goto block_0046CC04;
    case 0x0046CC1CU:
        goto block_0046CC1C;
    case 0x0046CC34U:
        goto block_0046CC34;
    case 0x0046CC40U:
        goto block_0046CC40;
    case 0x0046CC58U:
        goto block_0046CC58;
    case 0x0046CC64U:
        goto block_0046CC64;
    case 0x0046CC74U:
        goto block_0046CC74;
    case 0x0046CC8CU:
        goto block_0046CC8C;
    case 0x0046CC98U:
        goto block_0046CC98;
    case 0x0046CCB0U:
        goto block_0046CCB0;
    case 0x0046CCCCU:
        goto block_0046CCCC;
    case 0x0046CCE8U:
        goto block_0046CCE8;
    case 0x0046CCF4U:
        goto block_0046CCF4;
    case 0x0046CCFCU:
        goto block_0046CCFC;
    case 0x0046CD18U:
        goto block_0046CD18;
    case 0x0046CD1CU:
        goto block_0046CD1C;
    case 0x0046CD2CU:
        goto block_0046CD2C;
    case 0x0046CD34U:
        goto block_0046CD34;
    case 0x0046CD8CU:
        goto block_0046CD8C;
    case 0x0046CD98U:
        goto block_0046CD98;
    case 0x0046CDA0U:
        goto block_0046CDA0;
    case 0x0046CDB8U:
        goto block_0046CDB8;
    case 0x0046CDD8U:
        goto block_0046CDD8;
    case 0x0046CDE4U:
        goto block_0046CDE4;
    case 0x0046CDE8U:
        goto block_0046CDE8;
    case 0x0046CDF0U:
        goto block_0046CDF0;
    case 0x0046CE08U:
        goto block_0046CE08;
    case 0x0046CE34U:
        goto block_0046CE34;
    case 0x0046CE40U:
        goto block_0046CE40;
    case 0x0046CE6CU:
        goto block_0046CE6C;
    case 0x0046CE84U:
        goto block_0046CE84;
    case 0x0046CE9CU:
        goto block_0046CE9C;
    case 0x0046CEE8U:
        goto block_0046CEE8;
    case 0x0046CEFCU:
        goto block_0046CEFC;
    case 0x0046CF0CU:
        goto block_0046CF0C;
    case 0x0046CF1CU:
        goto block_0046CF1C;
    case 0x0046CF38U:
        goto block_0046CF38;
    case 0x0046CF4CU:
        goto block_0046CF4C;
    case 0x0046CF64U:
        goto block_0046CF64;
    case 0x0046CF70U:
        goto block_0046CF70;
    case 0x0046CFB4U:
        goto block_0046CFB4;
    case 0x0046CFECU:
        goto block_0046CFEC;
    case 0x0046D018U:
        goto block_0046D018;
    case 0x0046D020U:
        goto block_0046D020;
    case 0x0046D034U:
        goto block_0046D034;
    case 0x0046D048U:
        goto block_0046D048;
    case 0x0046D058U:
        goto block_0046D058;
    case 0x0046D07CU:
        goto block_0046D07C;
    case 0x0046D098U:
        goto block_0046D098;
    case 0x0046D0A4U:
        goto block_0046D0A4;
    case 0x0046D0B0U:
        goto block_0046D0B0;
    case 0x0046D0B4U:
        goto block_0046D0B4;
    case 0x0046D0C8U:
        goto block_0046D0C8;
    case 0x0046D0E0U:
        goto block_0046D0E0;
    case 0x0046D10CU:
        goto block_0046D10C;
    case 0x0046D114U:
        goto block_0046D114;
    case 0x0046D128U:
        goto block_0046D128;
    case 0x0046D130U:
        goto block_0046D130;
    case 0x0046D1ACU:
        goto block_0046D1AC;
    case 0x0046D1CCU:
        goto block_0046D1CC;
    case 0x0046D1D8U:
        goto block_0046D1D8;
    case 0x0046D1DCU:
        goto block_0046D1DC;
    case 0x0046D1E4U:
        goto block_0046D1E4;
    case 0x0046D1F8U:
        goto block_0046D1F8;
    case 0x0046D20CU:
        goto block_0046D20C;
    case 0x0046D218U:
        goto block_0046D218;
    case 0x0046D220U:
        goto block_0046D220;
    case 0x0046D244U:
        goto block_0046D244;
    case 0x0046D250U:
        goto block_0046D250;
    case 0x0046D284U:
        goto block_0046D284;
    case 0x0046D298U:
        goto block_0046D298;
    case 0x0046D2A4U:
        goto block_0046D2A4;
    case 0x0046D2B0U:
        goto block_0046D2B0;
    case 0x0046D2B4U:
        goto block_0046D2B4;
    case 0x0046D2D0U:
        goto block_0046D2D0;
    case 0x0046D2D8U:
        goto block_0046D2D8;
    case 0x0046D2F0U:
        goto block_0046D2F0;
    case 0x0046D328U:
        goto block_0046D328;
    case 0x0046D32CU:
        goto block_0046D32C;
    case 0x0046D334U:
        goto block_0046D334;
    case 0x0046D35CU:
        goto block_0046D35C;
    case 0x0046D384U:
        goto block_0046D384;
    case 0x0046D3A0U:
        goto block_0046D3A0;
    case 0x0046D3ACU:
        goto block_0046D3AC;
    case 0x0046D3B4U:
        goto block_0046D3B4;
    case 0x0046D3BCU:
        goto block_0046D3BC;
    case 0x0046D3E4U:
        goto block_0046D3E4;
    case 0x0046D40CU:
        goto block_0046D40C;
    case 0x0046D428U:
        goto block_0046D428;
    case 0x0046D438U:
        goto block_0046D438;
    case 0x0046D450U:
        goto block_0046D450;
    case 0x0046D468U:
        goto block_0046D468;
    case 0x0046D474U:
        goto block_0046D474;
    case 0x0046D48CU:
        goto block_0046D48C;
    case 0x0046D498U:
        goto block_0046D498;
    case 0x0046D4A8U:
        goto block_0046D4A8;
    case 0x0046D4C0U:
        goto block_0046D4C0;
    case 0x0046D4CCU:
        goto block_0046D4CC;
    case 0x0046D4E4U:
        goto block_0046D4E4;
    case 0x0046D508U:
        goto block_0046D508;
    case 0x0046D520U:
        goto block_0046D520;
    case 0x0046D538U:
        goto block_0046D538;
    case 0x0046D540U:
        goto block_0046D540;
    case 0x0046D54CU:
        goto block_0046D54C;
    case 0x0046D564U:
        goto block_0046D564;
    case 0x0046D570U:
        goto block_0046D570;
    case 0x0046D588U:
        goto block_0046D588;
    case 0x0046D594U:
        goto block_0046D594;
    case 0x0046D5ACU:
        goto block_0046D5AC;
    case 0x0046D5BCU:
        goto block_0046D5BC;
    case 0x0046D5C8U:
        goto block_0046D5C8;
    case 0x0046D5D8U:
        goto block_0046D5D8;
    case 0x0046D5FCU:
        goto block_0046D5FC;
    case 0x0046D610U:
        goto block_0046D610;
    case 0x0046D620U:
        goto block_0046D620;
    case 0x0046D654U:
        goto block_0046D654;
    case 0x0046D664U:
        goto block_0046D664;
    case 0x0046D670U:
        goto block_0046D670;
    case 0x0046D690U:
        goto block_0046D690;
    case 0x0046D6A4U:
        goto block_0046D6A4;
    case 0x0046D6B4U:
        goto block_0046D6B4;
    case 0x0046D6E8U:
        goto block_0046D6E8;
    case 0x0046D6F8U:
        goto block_0046D6F8;
    case 0x0046D70CU:
        goto block_0046D70C;
    case 0x0046D720U:
        goto block_0046D720;
    case 0x0046D734U:
        goto block_0046D734;
    case 0x0046D744U:
        goto block_0046D744;
    case 0x0046D778U:
        goto block_0046D778;
    case 0x0046D788U:
        goto block_0046D788;
    case 0x0046D79CU:
        goto block_0046D79C;
    case 0x0046D7B0U:
        goto block_0046D7B0;
    case 0x0046D7C4U:
        goto block_0046D7C4;
    case 0x0046D7D4U:
        goto block_0046D7D4;
    case 0x0046D808U:
        goto block_0046D808;
    case 0x0046D818U:
        goto block_0046D818;
    case 0x0046D824U:
        goto block_0046D824;
    case 0x0046D848U:
        goto block_0046D848;
    case 0x0046D85CU:
        goto block_0046D85C;
    case 0x0046D868U:
        goto block_0046D868;
    case 0x0046D884U:
        goto block_0046D884;
    case 0x0046D8A0U:
        goto block_0046D8A0;
    case 0x0046D8D8U:
        goto block_0046D8D8;
    case 0x0046D8E4U:
        goto block_0046D8E4;
    case 0x0046D8E8U:
        goto block_0046D8E8;
    case 0x0046D900U:
        goto block_0046D900;
    case 0x0046D914U:
        goto block_0046D914;
    case 0x0046D92CU:
        goto block_0046D92C;
    case 0x0046D938U:
        goto block_0046D938;
    case 0x0046D944U:
        goto block_0046D944;
    case 0x0046D950U:
        goto block_0046D950;
    case 0x0046D95CU:
        goto block_0046D95C;
    case 0x0046D968U:
        goto block_0046D968;
    case 0x0046D978U:
        goto block_0046D978;
    case 0x0046D990U:
        goto block_0046D990;
    case 0x0046D998U:
        goto block_0046D998;
    case 0x0046D9A0U:
        goto block_0046D9A0;
    case 0x0046D9A8U:
        goto block_0046D9A8;
    case 0x0046D9BCU:
        goto block_0046D9BC;
    case 0x0046D9D4U:
        goto block_0046D9D4;
    case 0x0046D9E0U:
        goto block_0046D9E0;
    case 0x0046D9ECU:
        goto block_0046D9EC;
    case 0x0046DA08U:
        goto block_0046DA08;
    case 0x0046DA24U:
        goto block_0046DA24;
    case 0x0046DA5CU:
        goto block_0046DA5C;
    case 0x0046DA68U:
        goto block_0046DA68;
    case 0x0046DA6CU:
        goto block_0046DA6C;
    case 0x0046DA84U:
        goto block_0046DA84;
    case 0x0046DA98U:
        goto block_0046DA98;
    case 0x0046DAB0U:
        goto block_0046DAB0;
    case 0x0046DABCU:
        goto block_0046DABC;
    case 0x0046DAC8U:
        goto block_0046DAC8;
    case 0x0046DAD4U:
        goto block_0046DAD4;
    case 0x0046DAE0U:
        goto block_0046DAE0;
    case 0x0046DAECU:
        goto block_0046DAEC;
    case 0x0046DAFCU:
        goto block_0046DAFC;
    case 0x0046DB14U:
        goto block_0046DB14;
    case 0x0046DB1CU:
        goto block_0046DB1C;
    case 0x0046DB24U:
        goto block_0046DB24;
    case 0x0046DB2CU:
        goto block_0046DB2C;
    case 0x0046DB40U:
        goto block_0046DB40;
    case 0x0046DB58U:
        goto block_0046DB58;
    case 0x0046DB64U:
        goto block_0046DB64;
    case 0x0046DB80U:
        goto block_0046DB80;
    case 0x0046DB90U:
        goto block_0046DB90;
    case 0x0046DBA0U:
        goto block_0046DBA0;
    case 0x0046DBDCU:
        goto block_0046DBDC;
    case 0x0046DBF0U:
        goto block_0046DBF0;
    case 0x0046DC30U:
        goto block_0046DC30;
    case 0x0046DC60U:
        goto block_0046DC60;
    case 0x0046DC78U:
        goto block_0046DC78;
    case 0x0046DCB0U:
        goto block_0046DCB0;
    case 0x0046DCBCU:
        goto block_0046DCBC;
    case 0x0046DCD8U:
        goto block_0046DCD8;
    case 0x0046DCF0U:
        goto block_0046DCF0;
    case 0x0046DD28U:
        goto block_0046DD28;
    case 0x0046DD34U:
        goto block_0046DD34;
    case 0x0046DD50U:
        goto block_0046DD50;
    case 0x0046DD5CU:
        goto block_0046DD5C;
    case 0x0046DD6CU:
        goto block_0046DD6C;
    case 0x0046DD94U:
        goto block_0046DD94;
    case 0x0046DDA4U:
        goto block_0046DDA4;
    case 0x0046DDA8U:
        goto block_0046DDA8;
    case 0x0046DDB4U:
        goto block_0046DDB4;
    case 0x0046DDB8U:
        goto block_0046DDB8;
    case 0x0046DDCCU:
        goto block_0046DDCC;
    case 0x0046DDD8U:
        goto block_0046DDD8;
    case 0x0046DDE8U:
        goto block_0046DDE8;
    case 0x0046DDFCU:
        goto block_0046DDFC;
    case 0x0046DE20U:
        goto block_0046DE20;
    case 0x0046DE3CU:
        goto block_0046DE3C;
    case 0x0046DE74U:
        goto block_0046DE74;
    case 0x0046DE84U:
        goto block_0046DE84;
    case 0x0046DEA0U:
        goto block_0046DEA0;
    case 0x0046DEA8U:
        goto block_0046DEA8;
    case 0x0046DEC4U:
        goto block_0046DEC4;
    case 0x0046DED4U:
        goto block_0046DED4;
    case 0x0046DEE8U:
        goto block_0046DEE8;
    case 0x0046DF34U:
        goto block_0046DF34;
    case 0x0046DF50U:
        goto block_0046DF50;
    case 0x0046DF6CU:
        goto block_0046DF6C;
    case 0x0046DFA4U:
        goto block_0046DFA4;
    case 0x0046DFB4U:
        goto block_0046DFB4;
    case 0x0046DFD0U:
        goto block_0046DFD0;
    case 0x0046DFD8U:
        goto block_0046DFD8;
    case 0x0046DFF4U:
        goto block_0046DFF4;
    case 0x0046E004U:
        goto block_0046E004;
    case 0x0046E010U:
        goto block_0046E010;
    case 0x0046E024U:
        goto block_0046E024;
    case 0x0046E048U:
        goto block_0046E048;
    case 0x0046E064U:
        goto block_0046E064;
    case 0x0046E09CU:
        goto block_0046E09C;
    case 0x0046E0ACU:
        goto block_0046E0AC;
    case 0x0046E0C8U:
        goto block_0046E0C8;
    case 0x0046E0D0U:
        goto block_0046E0D0;
    case 0x0046E0ECU:
        goto block_0046E0EC;
    case 0x0046E0FCU:
        goto block_0046E0FC;
    case 0x0046E108U:
        goto block_0046E108;
    case 0x0046E11CU:
        goto block_0046E11C;
    case 0x0046E140U:
        goto block_0046E140;
    case 0x0046E15CU:
        goto block_0046E15C;
    case 0x0046E194U:
        goto block_0046E194;
    case 0x0046E1A4U:
        goto block_0046E1A4;
    case 0x0046E1C0U:
        goto block_0046E1C0;
    case 0x0046E1C8U:
        goto block_0046E1C8;
    case 0x0046E1E4U:
        goto block_0046E1E4;
    case 0x0046E1F4U:
        goto block_0046E1F4;
    case 0x0046E200U:
        goto block_0046E200;
    case 0x0046E214U:
        goto block_0046E214;
    case 0x0046E228U:
        goto block_0046E228;
    case 0x0046E244U:
        goto block_0046E244;
    case 0x0046E254U:
        goto block_0046E254;
    case 0x0046E26CU:
        goto block_0046E26C;
    case 0x0046E288U:
        goto block_0046E288;
    case 0x0046E28CU:
        goto block_0046E28C;
    case 0x0046E298U:
        goto block_0046E298;
    case 0x0046E2ACU:
        goto block_0046E2AC;
    case 0x0046E2B4U:
        goto block_0046E2B4;
    case 0x0046E2CCU:
        goto block_0046E2CC;
    case 0x0046E2F0U:
        goto block_0046E2F0;
    case 0x0046E308U:
        goto block_0046E308;
    case 0x0046E314U:
        goto block_0046E314;
    case 0x0046E330U:
        goto block_0046E330;
    case 0x0046E33CU:
        goto block_0046E33C;
    case 0x0046E350U:
        goto block_0046E350;
    case 0x0046E364U:
        goto block_0046E364;
    case 0x0046E368U:
        goto block_0046E368;
    case 0x0046E370U:
        goto block_0046E370;
    case 0x0046E388U:
        goto block_0046E388;
    case 0x0046E394U:
        goto block_0046E394;
    case 0x0046E39CU:
        goto block_0046E39C;
    case 0x0046E3B4U:
        goto block_0046E3B4;
    case 0x0046E3E0U:
        goto block_0046E3E0;
    case 0x0046E410U:
        goto block_0046E410;
    case 0x0046E428U:
        goto block_0046E428;
    case 0x0046E434U:
        goto block_0046E434;
    case 0x0046E44CU:
        goto block_0046E44C;
    case 0x0046E46CU:
        goto block_0046E46C;
    case 0x0046E47CU:
        goto block_0046E47C;
    case 0x0046E484U:
        goto block_0046E484;
    case 0x0046E490U:
        goto block_0046E490;
    case 0x0046E498U:
        goto block_0046E498;
    case 0x0046E4ACU:
        goto block_0046E4AC;
    case 0x0046E4B8U:
        goto block_0046E4B8;
    case 0x0046E4CCU:
        goto block_0046E4CC;
    case 0x0046E4DCU:
        goto block_0046E4DC;
    case 0x0046E4F4U:
        goto block_0046E4F4;
    case 0x0046E4FCU:
        goto block_0046E4FC;
    case 0x0046E510U:
        goto block_0046E510;
    case 0x0046E534U:
        goto block_0046E534;
    case 0x0046E54CU:
        goto block_0046E54C;
    case 0x0046E588U:
        goto block_0046E588;
    case 0x0046E5A4U:
        goto block_0046E5A4;
    case 0x0046E5B0U:
        goto block_0046E5B0;
    case 0x0046E5C4U:
        goto block_0046E5C4;
    case 0x0046E5D8U:
        goto block_0046E5D8;
    case 0x0046E5DCU:
        goto block_0046E5DC;
    case 0x0046E5ECU:
        goto block_0046E5EC;
    case 0x0046E604U:
        goto block_0046E604;
    case 0x0046E610U:
        goto block_0046E610;
    case 0x0046E618U:
        goto block_0046E618;
    case 0x0046E630U:
        goto block_0046E630;
    case 0x0046E65CU:
        goto block_0046E65C;
    case 0x0046E68CU:
        goto block_0046E68C;
    case 0x0046E6A4U:
        goto block_0046E6A4;
    case 0x0046E6B0U:
        goto block_0046E6B0;
    case 0x0046E6C4U:
        goto block_0046E6C4;
    case 0x0046E6E0U:
        goto block_0046E6E0;
    case 0x0046E6F0U:
        goto block_0046E6F0;
    case 0x0046E6F8U:
        goto block_0046E6F8;
    case 0x0046E70CU:
        goto block_0046E70C;
    case 0x0046E71CU:
        goto block_0046E71C;
    case 0x0046E734U:
        goto block_0046E734;
    case 0x0046E73CU:
        goto block_0046E73C;
    case 0x0046E750U:
        goto block_0046E750;
    case 0x0046E774U:
        goto block_0046E774;
    case 0x0046E78CU:
        goto block_0046E78C;
    case 0x0046E798U:
        goto block_0046E798;
    case 0x0046E7B4U:
        goto block_0046E7B4;
    case 0x0046E7C0U:
        goto block_0046E7C0;
    case 0x0046E7D4U:
        goto block_0046E7D4;
    case 0x0046E7E8U:
        goto block_0046E7E8;
    case 0x0046E7ECU:
        goto block_0046E7EC;
    case 0x0046E7FCU:
        goto block_0046E7FC;
    case 0x0046E814U:
        goto block_0046E814;
    case 0x0046E820U:
        goto block_0046E820;
    case 0x0046E828U:
        goto block_0046E828;
    case 0x0046E840U:
        goto block_0046E840;
    case 0x0046E86CU:
        goto block_0046E86C;
    case 0x0046E89CU:
        goto block_0046E89C;
    case 0x0046E8B4U:
        goto block_0046E8B4;
    case 0x0046E8C0U:
        goto block_0046E8C0;
    case 0x0046E8D4U:
        goto block_0046E8D4;
    case 0x0046E8F0U:
        goto block_0046E8F0;
    case 0x0046E900U:
        goto block_0046E900;
    case 0x0046E908U:
        goto block_0046E908;
    case 0x0046E914U:
        goto block_0046E914;
    case 0x0046E924U:
        goto block_0046E924;
    case 0x0046E938U:
        goto block_0046E938;
    case 0x0046E968U:
        goto block_0046E968;
    case 0x0046E978U:
        goto block_0046E978;
    case 0x0046E98CU:
        goto block_0046E98C;
    case 0x0046E9A4U:
        goto block_0046E9A4;
    case 0x0046E9ACU:
        goto block_0046E9AC;
    case 0x0046E9C4U:
        goto block_0046E9C4;
    case 0x0046E9ECU:
        goto block_0046E9EC;
    case 0x0046EA04U:
        goto block_0046EA04;
    case 0x0046EA10U:
        goto block_0046EA10;
    case 0x0046EA28U:
        goto block_0046EA28;
    case 0x0046EA34U:
        goto block_0046EA34;
    case 0x0046EA48U:
        goto block_0046EA48;
    case 0x0046EA5CU:
        goto block_0046EA5C;
    case 0x0046EA60U:
        goto block_0046EA60;
    case 0x0046EA6CU:
        goto block_0046EA6C;
    case 0x0046EA84U:
        goto block_0046EA84;
    case 0x0046EA90U:
        goto block_0046EA90;
    case 0x0046EA98U:
        goto block_0046EA98;
    case 0x0046EAB0U:
        goto block_0046EAB0;
    case 0x0046EAD8U:
        goto block_0046EAD8;
    case 0x0046EAF4U:
        goto block_0046EAF4;
    case 0x0046EB00U:
        goto block_0046EB00;
    case 0x0046EB18U:
        goto block_0046EB18;
    case 0x0046EB24U:
        goto block_0046EB24;
    case 0x0046EB3CU:
        goto block_0046EB3C;
    case 0x0046EB48U:
        goto block_0046EB48;
    case 0x0046EB60U:
        goto block_0046EB60;
    case 0x0046EB84U:
        goto block_0046EB84;
    case 0x0046EB94U:
        goto block_0046EB94;
    case 0x0046EB9CU:
        goto block_0046EB9C;
    case 0x0046EBA8U:
        goto block_0046EBA8;
    case 0x0046EBB4U:
        goto block_0046EBB4;
    case 0x0046EBC4U:
        goto block_0046EBC4;
    case 0x0046EBD8U:
        goto block_0046EBD8;
    case 0x0046EBE0U:
        goto block_0046EBE0;
    case 0x0046EBF8U:
        goto block_0046EBF8;
    case 0x0046EC10U:
        goto block_0046EC10;
    case 0x0046EC28U:
        goto block_0046EC28;
    case 0x0046EC4CU:
        goto block_0046EC4C;
    case 0x0046EC64U:
        goto block_0046EC64;
    case 0x0046EC70U:
        goto block_0046EC70;
    case 0x0046EC84U:
        goto block_0046EC84;
    case 0x0046EC98U:
        goto block_0046EC98;
    case 0x0046EC9CU:
        goto block_0046EC9C;
    case 0x0046ECA8U:
        goto block_0046ECA8;
    case 0x0046ECC0U:
        goto block_0046ECC0;
    case 0x0046ECCCU:
        goto block_0046ECCC;
    case 0x0046ECD4U:
        goto block_0046ECD4;
    case 0x0046ECECU:
        goto block_0046ECEC;
    case 0x0046ED14U:
        goto block_0046ED14;
    case 0x0046ED30U:
        goto block_0046ED30;
    case 0x0046ED3CU:
        goto block_0046ED3C;
    case 0x0046ED54U:
        goto block_0046ED54;
    case 0x0046ED60U:
        goto block_0046ED60;
    case 0x0046ED78U:
        goto block_0046ED78;
    case 0x0046ED84U:
        goto block_0046ED84;
    case 0x0046ED9CU:
        goto block_0046ED9C;
    case 0x0046EDB0U:
        goto block_0046EDB0;
    case 0x0046EDC0U:
        goto block_0046EDC0;
    case 0x0046EDC8U:
        goto block_0046EDC8;
    case 0x0046EDCCU:
        goto block_0046EDCC;
    case 0x0046EDECU:
        goto block_0046EDEC;
    case 0x0046EDF8U:
        goto block_0046EDF8;
    case 0x0046EE04U:
        goto block_0046EE04;
    case 0x0046EE28U:
        goto block_0046EE28;
    case 0x0046EE34U:
        goto block_0046EE34;
    case 0x0046EE44U:
        goto block_0046EE44;
    case 0x0046EE64U:
        goto block_0046EE64;
    case 0x0046EE70U:
        goto block_0046EE70;
    case 0x0046EE78U:
        goto block_0046EE78;
    case 0x0046EE84U:
        goto block_0046EE84;
    case 0x0046EE90U:
        goto block_0046EE90;
    case 0x0046EE98U:
        goto block_0046EE98;
    case 0x0046EEBCU:
        goto block_0046EEBC;
    case 0x0046EEC8U:
        goto block_0046EEC8;
    case 0x0046EED0U:
        goto block_0046EED0;
    case 0x0046EED8U:
        goto block_0046EED8;
    case 0x0046EEF0U:
        goto block_0046EEF0;
    case 0x0046EF08U:
        goto block_0046EF08;
    case 0x0046EF18U:
        goto block_0046EF18;
    case 0x0046EF28U:
        goto block_0046EF28;
    case 0x0046EF40U:
        goto block_0046EF40;
    case 0x0046EF50U:
        goto block_0046EF50;
    case 0x0046EF5CU:
        goto block_0046EF5C;
    case 0x0046EF74U:
        goto block_0046EF74;
    case 0x0046EF90U:
        goto block_0046EF90;
    case 0x0046EFA8U:
        goto block_0046EFA8;
    case 0x0046EFC4U:
        goto block_0046EFC4;
    case 0x0046EFD8U:
        goto block_0046EFD8;
    case 0x0046EFE4U:
        goto block_0046EFE4;
    case 0x0046EFFCU:
        goto block_0046EFFC;
    case 0x0046F008U:
        goto block_0046F008;
    case 0x0046F028U:
        goto block_0046F028;
    case 0x0046F034U:
        goto block_0046F034;
    case 0x0046F048U:
        goto block_0046F048;
    case 0x0046F05CU:
        goto block_0046F05C;
    case 0x0046F060U:
        goto block_0046F060;
    case 0x0046F068U:
        goto block_0046F068;
    case 0x0046F0A4U:
        goto block_0046F0A4;
    case 0x0046F0ACU:
        goto block_0046F0AC;
    case 0x0046F0B0U:
        goto block_0046F0B0;
    case 0x0046F0D8U:
        goto block_0046F0D8;
    case 0x0046F0F4U:
        goto block_0046F0F4;
    case 0x0046F100U:
        goto block_0046F100;
    case 0x0046F10CU:
        goto block_0046F10C;
    case 0x0046F124U:
        goto block_0046F124;
    case 0x0046F138U:
        goto block_0046F138;
    case 0x0046F144U:
        goto block_0046F144;
    case 0x0046F158U:
        goto block_0046F158;
    case 0x0046F164U:
        goto block_0046F164;
    case 0x0046F188U:
        goto block_0046F188;
    case 0x0046F194U:
        goto block_0046F194;
    case 0x0046F19CU:
        goto block_0046F19C;
    case 0x0046F1B4U:
        goto block_0046F1B4;
    case 0x0046F1CCU:
        goto block_0046F1CC;
    case 0x0046F1DCU:
        goto block_0046F1DC;
    case 0x0046F1ECU:
        goto block_0046F1EC;
    case 0x0046F204U:
        goto block_0046F204;
    case 0x0046F214U:
        goto block_0046F214;
    case 0x0046F220U:
        goto block_0046F220;
    case 0x0046F244U:
        goto block_0046F244;
    case 0x0046F250U:
        goto block_0046F250;
    case 0x0046F264U:
        goto block_0046F264;
    case 0x0046F274U:
        goto block_0046F274;
    case 0x0046F28CU:
        goto block_0046F28C;
    case 0x0046F294U:
        goto block_0046F294;
    case 0x0046F2ACU:
        goto block_0046F2AC;
    case 0x0046F2B8U:
        goto block_0046F2B8;
    case 0x0046F2D0U:
        goto block_0046F2D0;
    case 0x0046F2F4U:
        goto block_0046F2F4;
    case 0x0046F310U:
        goto block_0046F310;
    case 0x0046F31CU:
        goto block_0046F31C;
    case 0x0046F330U:
        goto block_0046F330;
    case 0x0046F344U:
        goto block_0046F344;
    case 0x0046F348U:
        goto block_0046F348;
    case 0x0046F370U:
        goto block_0046F370;
    case 0x0046F398U:
        goto block_0046F398;
    case 0x0046F3B0U:
        goto block_0046F3B0;
    case 0x0046F3BCU:
        goto block_0046F3BC;
    case 0x0046F3C8U:
        goto block_0046F3C8;
    case 0x0046F3E0U:
        goto block_0046F3E0;
    case 0x0046F3F4U:
        goto block_0046F3F4;
    case 0x0046F408U:
        goto block_0046F408;
    case 0x0046F414U:
        goto block_0046F414;
    case 0x0046F41CU:
        goto block_0046F41C;
    case 0x0046F434U:
        goto block_0046F434;
    case 0x0046F450U:
        goto block_0046F450;
    case 0x0046F45CU:
        goto block_0046F45C;
    case 0x0046F474U:
        goto block_0046F474;
    case 0x0046F480U:
        goto block_0046F480;
    case 0x0046F490U:
        goto block_0046F490;
    case 0x0046F498U:
        goto block_0046F498;
    case 0x0046F4A8U:
        goto block_0046F4A8;
    case 0x0046F4BCU:
        goto block_0046F4BC;
    case 0x0046F4C0U:
        goto block_0046F4C0;
    case 0x0046F4E0U:
        goto block_0046F4E0;
    case 0x0046F4ECU:
        goto block_0046F4EC;
    case 0x0046F4F4U:
        goto block_0046F4F4;
    case 0x0046F548U:
        goto block_0046F548;
    case 0x0046F554U:
        goto block_0046F554;
    case 0x0046F564U:
        goto block_0046F564;
    case 0x0046F570U:
        goto block_0046F570;
    case 0x0046F584U:
        goto block_0046F584;
    case 0x0046F598U:
        goto block_0046F598;
    case 0x0046F59CU:
        goto block_0046F59C;
    case 0x0046F5A0U:
        goto block_0046F5A0;
    case 0x0046F5BCU:
        goto block_0046F5BC;
    case 0x0046F5C8U:
        goto block_0046F5C8;
    case 0x0046F5D0U:
        goto block_0046F5D0;
    case 0x0046F5E4U:
        goto block_0046F5E4;
    case 0x0046F634U:
        goto block_0046F634;
    case 0x0046F640U:
        goto block_0046F640;
    case 0x0046F648U:
        goto block_0046F648;
    case 0x0046F684U:
        goto block_0046F684;
    case 0x0046F690U:
        goto block_0046F690;
    case 0x0046F698U:
        goto block_0046F698;
    case 0x0046F6ACU:
        goto block_0046F6AC;
    case 0x0046F6C4U:
        goto block_0046F6C4;
    case 0x0046F6DCU:
        goto block_0046F6DC;
    case 0x0046F6ECU:
        goto block_0046F6EC;
    case 0x0046F718U:
        goto block_0046F718;
    case 0x0046F728U:
        goto block_0046F728;
    case 0x0046F740U:
        goto block_0046F740;
    case 0x0046F744U:
        goto block_0046F744;
    case 0x0046F768U:
        goto block_0046F768;
    case 0x0046F774U:
        goto block_0046F774;
    case 0x0046F790U:
        goto block_0046F790;
    case 0x0046F7D0U:
        goto block_0046F7D0;
    case 0x0046F7E8U:
        goto block_0046F7E8;
    case 0x0046F7F4U:
        goto block_0046F7F4;
    case 0x0046F80CU:
        goto block_0046F80C;
    case 0x0046F82CU:
        goto block_0046F82C;
    case 0x0046F834U:
        goto block_0046F834;
    case 0x0046F83CU:
        goto block_0046F83C;
    case 0x0046F84CU:
        goto block_0046F84C;
    case 0x0046F858U:
        goto block_0046F858;
    case 0x0046F864U:
        goto block_0046F864;
    case 0x0046F870U:
        goto block_0046F870;
    case 0x0046F87CU:
        goto block_0046F87C;
    case 0x0046F888U:
        goto block_0046F888;
    case 0x0046F894U:
        goto block_0046F894;
    case 0x0046F898U:
        goto block_0046F898;
    case 0x0046F8A0U:
        goto block_0046F8A0;
    case 0x0046F8ACU:
        goto block_0046F8AC;
    case 0x0046F8C4U:
        goto block_0046F8C4;
    case 0x0046F8CCU:
        goto block_0046F8CC;
    case 0x0046F8D8U:
        goto block_0046F8D8;
    case 0x0046F8DCU:
        goto block_0046F8DC;
    case 0x0046F938U:
        goto block_0046F938;
    case 0x0046F948U:
        goto block_0046F948;
    case 0x0046F954U:
        goto block_0046F954;
    case 0x0046F964U:
        goto block_0046F964;
    case 0x0046F970U:
        goto block_0046F970;
    case 0x0046F99CU:
        goto block_0046F99C;
    case 0x0046F9A8U:
        goto block_0046F9A8;
    case 0x0046F9C4U:
        goto block_0046F9C4;
    case 0x0046F9D8U:
        goto block_0046F9D8;
    case 0x0046F9E8U:
        goto block_0046F9E8;
    case 0x0046F9F4U:
        goto block_0046F9F4;
    case 0x0046FA00U:
        goto block_0046FA00;
    case 0x0046FA0CU:
        goto block_0046FA0C;
    case 0x0046FA18U:
        goto block_0046FA18;
    case 0x0046FA24U:
        goto block_0046FA24;
    case 0x0046FA30U:
        goto block_0046FA30;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0046C204:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C204U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C204U);
        }
        {
            const uint32_t firstAddress = r13 - 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0046C204U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046C204U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0046C204U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0046C204U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0046C204U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0046C204U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0046C204U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0046C204U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0046C204U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0046C204U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0046C204U,
                                           firstAddress + 40U);
            }
            r13 = r13 - 44U;
        }
        {
            r0 = 0x00000000U;
        }
        {
            r13 -= 40U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0046C20CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0046C20CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0046C20CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0046C20CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0046C20CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0046C20CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0046C20CU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0046C20CU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x0046C20CU,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x0046C20CU,
                                           firstAddress + 36U);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r13 = r13 - operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C218U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046C224U + 0xF2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C21CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C220U, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C224U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00001000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00001000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C360; }
        goto block_0046C230;
    }
block_0046C230:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C230U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C230U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C230U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C234U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000200U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000200U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C360; }
        goto block_0046C240;
    }
block_0046C240:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C240U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C240U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x578U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C240U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046C26C; }
        goto block_0046C24C;
    }
block_0046C24C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C24CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C24CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C24CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C250U, address);
            }
            r12 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r2 - operand;
        }
        {
            r1 = r0;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r12 - operand;
        }
        goto block_0046C2E8;
    }
block_0046C26C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C26CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C26CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x514U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C26CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x51CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C270U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x518U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C274U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r12 = r0 - operand;
        }
        {
            const uint32_t operand = r12;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C280U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x520U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C284U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r1 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, r0, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t operand = r4;
            r3 = r3 + operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = 0x00000001U;
            r0 = r12 - operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046C2A4; }
        goto block_0046C29C;
    }
block_0046C29C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C29CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C29CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            r0 = 0x00000000U;
        }
        goto block_0046C2A4;
    }
block_0046C2A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C2A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C2A4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C2A4U, address);
            }
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = 0x00000001U;
            r1 = r4 - operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046C2BC; }
        goto block_0046C2B4;
    }
block_0046C2B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C2B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C2B4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            r1 = 0x00000000U;
        }
        goto block_0046C2BC;
    }
block_0046C2BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C2BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C2BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000001U;
            r2 = r12 - operand;
        }
        if ((flags.N()) != (flags.V())) { goto block_0046C2D0; }
        goto block_0046C2C8;
    }
block_0046C2C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C2C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C2C8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            r2 = 0x00000000U;
        }
        goto block_0046C2D0;
    }
block_0046C2D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C2D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C2D0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r3, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000001U;
            r3 = r4 - operand;
        }
        if ((flags.N()) != (flags.V())) { goto block_0046C2E4; }
        goto block_0046C2DC;
    }
block_0046C2DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C2DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C2DCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            r3 = 0x00000000U;
        }
        goto block_0046C2E4;
    }
block_0046C2E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C2E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C2E4U);
        }
        {
            r4 = 0x00000003U;
        }
        goto block_0046C2E8;
    }
block_0046C2E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C2E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C2E8U);
        }
        {
            const uint32_t updatedAddress = 0x0046C2F0U + 0xE64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C2E8U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046C2F4U + 0xE64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C2ECU, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C2F0U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C2F4U, address);
            }
            r8 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, r8, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046C314; }
        goto block_0046C300;
    }
block_0046C300:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C300U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C300U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046C300U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046C30CU + 0xE50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C304U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046C308U, address);
            }
            r12 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r12 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046C310U, address);
            }
        }
        goto block_0046C314;
    }
block_0046C314:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C314U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C314U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C314U, address);
            }
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, r4, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) {
            r0 = r12;
        }
        if (flags.C()) { goto block_0046C33C; }
        goto block_0046C324;
    }
block_0046C324:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C324U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C324U);
        }
        {
            r0 = r0 | Oot3dAotLsl(r1, 16U);
        }
        {
            const uint32_t updatedAddress = 0x0046C330U + 0xE30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C328U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C32CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C334U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C338U, address);
            }
        }
        goto block_0046C33C;
    }
block_0046C33C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C33CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C33CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C33CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046C360; }
        goto block_0046C348;
    }
block_0046C348:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C348U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C348U);
        }
        {
            r1 = r2 | Oot3dAotLsl(r3, 16U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C34CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046C358U + 0xE0CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C350U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C354U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C35CU, address);
            }
        }
        goto block_0046C360;
    }
block_0046C360:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C360U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C360U);
        }
        {
            const uint32_t updatedAddress = 0x0046C368U + 0xE00U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C360U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C364U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C368U, address);
            }
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0046F9C4; }
        goto block_0046C374;
    }
block_0046C374:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C374U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C374U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C374U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046C448; }
        goto block_0046C380;
    }
block_0046C380:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C380U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C380U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3F4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C380U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046C38CU + 0xDDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C384U, address);
            }
            r9 = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            Oot3dAotSetAddFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r6 = r0 + operand;
        }
        if (!(flags.Z())) {
            r6 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r9 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C390U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C398U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0046C448; }
        goto block_0046C3A4;
    }
block_0046C3A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C3A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C3A4U);
        }
        {
            const uint32_t updatedAddress = 0x0046C3ACU + 0xDC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C3A4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x0000000AU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046C3B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d134c_002D134C(frame, context, state, 0x002D134CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046C3B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046C3B0;
    }
block_0046C3B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C3B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C3B0U);
        }
        {
            r1 = 0x0000001EU;
        }
        {
            r0 = 0x00000200U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046C3BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d134c_002D134C(frame, context, state, 0x002D134CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046C3BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046C3BC;
    }
block_0046C3BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C3BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C3BCU);
        }
        {
            const uint32_t updatedAddress = 0x0046C3C4U + 0xD90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C3BCU, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046C3C8U + 0xD90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C3C0U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C3C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C3C8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046C3F0; }
        goto block_0046C3D4;
    }
block_0046C3D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C3D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C3D4U);
        }
        {
            const uint32_t operand = 0x00000000U;
            Oot3dAotSetAddFlags(flags, r6, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r6 + operand;
        }
        if (!(flags.Z())) {
            r1 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C3DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046C3E8U + 0xD88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C3E0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C3E4U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C3ECU, address);
            }
        }
        goto block_0046C3F0;
    }
block_0046C3F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C3F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C3F0U);
        }
        {
            r1 = 0x0000001EU;
        }
        {
            r0 = 0x00000200U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046C3FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d134c_002D134C(frame, context, state, 0x002D134CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046C3FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046C3FC;
    }
block_0046C3FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C3FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C3FCU);
        }
        {
            const uint32_t updatedAddress = r9 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0046C3FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046C408U + 0xD6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C400U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C404U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C408U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C430; }
        goto block_0046C414;
    }
block_0046C414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C414U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046C448; }
        goto block_0046C41C;
    }
block_0046C41C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C41CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C41CU);
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046C420U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C424U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C428U, address);
            }
        }
        goto block_0046C448;
    }
block_0046C430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C430U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046C448; }
        goto block_0046C438;
    }
block_0046C438:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C438U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C438U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046C43CU, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C440U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C444U, address);
            }
        }
        goto block_0046C448;
    }
block_0046C448:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C448U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C448U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C448U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046C630; }
        goto block_0046C454;
    }
block_0046C454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C454U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C454U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C458U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00100000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00100000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046C630; }
        goto block_0046C464;
    }
block_0046C464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C464U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3F4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C464U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046C470U + 0xD08U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C468U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x0000000CU;
            r7 = r1 - operand;
        }
        if (flags.Z()) { goto block_0046C514; }
        goto block_0046C478;
    }
block_0046C478:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C478U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C478U);
        }
        {
            const uint32_t updatedAddress = 0x0046C480U + 0xCD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C478U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046C484U + 0xCD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C47CU, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C480U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C484U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046C4A0; }
        goto block_0046C490;
    }
block_0046C490:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C490U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C490U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046C494U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C498U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C49CU, address);
            }
        }
        goto block_0046C4A0;
    }
block_0046C4A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C4A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C4A0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C4A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C4A4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C4A8U, address);
            }
            r2 = value;
        }
        {
            r0 = 0x0000029CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046C4B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046C4B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046C4B4;
    }
block_0046C4B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C4B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C4B4U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C4B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C4B8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046C4D0; }
        goto block_0046C4C4;
    }
block_0046C4C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C4C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C4C4U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046C4C8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0046C4C8U,
                                           firstAddress + 4U);
            }
            r0 = r0 + 8U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C4CCU, address);
            }
        }
        goto block_0046C4D0;
    }
block_0046C4D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C4D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C4D0U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C4D0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046C4F4; }
        goto block_0046C4DC;
    }
block_0046C4DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C4DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C4DCU);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C4E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046C4ECU + 0xC90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C4E4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C4E8U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C4F0U, address);
            }
        }
        goto block_0046C4F4;
    }
block_0046C4F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C4F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C4F4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C4F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C4F8U, address);
            }
            r2 = value;
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C4FCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046C508U + 0xC78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C500U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046C508U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046C508U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046C508;
    }
block_0046C508:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C508U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C508U);
        }
        {
        }
        {
        }
        goto block_0046C584;
    }
block_0046C514:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C514U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C514U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C514U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C518U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000200U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046C584; }
        goto block_0046C524;
    }
block_0046C524:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C524U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C524U);
        }
        {
            const uint32_t updatedAddress = 0x0046C52CU + 0xC28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C524U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046C530U + 0xC28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C528U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C52CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C530U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046C54C; }
        goto block_0046C53C;
    }
block_0046C53C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C53CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C53CU);
        }
        {
            r2 = 0x00000200U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046C540U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C544U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C548U, address);
            }
        }
        goto block_0046C54C;
    }
block_0046C54C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C54CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C54CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C54CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C550U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C554U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000200U;
            r1 = r0 - operand;
        }
        {
            r0 = 0x0000029CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046C568U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046C568U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046C568;
    }
block_0046C568:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C568U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C568U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C568U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C56CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046C584; }
        goto block_0046C578;
    }
block_0046C578:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C578U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C578U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046C57CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0046C57CU,
                                           firstAddress + 4U);
            }
            r0 = r0 + 8U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C580U, address);
            }
        }
        goto block_0046C584;
    }
block_0046C584:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C584U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C584U);
        }
        {
            const uint32_t updatedAddress = 0x0046C58CU + 0xBC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C584U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046C590U + 0xBC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C588U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C58CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C590U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046C5B4; }
        goto block_0046C59C;
    }
block_0046C59C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C59CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C59CU);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C5A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046C5ACU + 0xBD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C5A4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C5A8U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C5B0U, address);
            }
        }
        goto block_0046C5B4;
    }
block_0046C5B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C5B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C5B4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C5B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C5B8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C5BCU, address);
            }
            r2 = value;
        }
        {
            r0 = 0x000002CCU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000200U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) {
            r1 = 0x00000200U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046C5D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046C5D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046C5D0;
    }
block_0046C5D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C5D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C5D0U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C5D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C5D4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046C5F8; }
        goto block_0046C5E0;
    }
block_0046C5E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C5E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C5E0U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C5E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046C5F0U + 0xB98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C5E8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C5ECU, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C5F4U, address);
            }
        }
        goto block_0046C5F8;
    }
block_0046C5F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C5F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C5F8U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C5F8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046C61C; }
        goto block_0046C604;
    }
block_0046C604:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C604U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C604U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C608U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046C614U + 0xB78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C60CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C610U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C618U, address);
            }
        }
        goto block_0046C61C;
    }
block_0046C61C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C61CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C61CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C61CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C620U, address);
            }
            r2 = value;
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C624U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046C630U + 0xB60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C628U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046C630U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046C630U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046C630;
    }
block_0046C630:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C630U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C630U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C630U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046C6C8; }
        goto block_0046C63C;
    }
block_0046C63C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C63CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C63CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3F4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C63CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C688; }
        goto block_0046C648;
    }
block_0046C648:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C648U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C648U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C648U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C64CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00800000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00800000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C688; }
        goto block_0046C658;
    }
block_0046C658:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C658U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C658U);
        }
        {
            const uint32_t updatedAddress = 0x0046C660U + 0xB08U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C658U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C660U, address);
            }
            r1 = value;
        }
        goto block_0046C664;
    }
block_0046C664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C664U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C668U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r3 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            r2 = ~(r2);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t updatedAddress = r3 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046C680U, address);
            }
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046C664; }
        goto block_0046C688;
    }
block_0046C688:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C688U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C688U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C688U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C68CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x01000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x01000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046C6C8; }
        goto block_0046C698;
    }
block_0046C698:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C698U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C698U);
        }
        {
            const uint32_t updatedAddress = 0x0046C6A0U + 0xAC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C698U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000009U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C6A0U, address);
            }
            r1 = value;
        }
        goto block_0046C6A4;
    }
block_0046C6A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C6A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C6A4U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C6A8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r3 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            r2 = ~(r2);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000010U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t updatedAddress = r3 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046C6C0U, address);
            }
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046C6A4; }
        goto block_0046C6C8;
    }
block_0046C6C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C6C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C6C8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C6C8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000008U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C79C; }
        goto block_0046C6D4;
    }
block_0046C6D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C6D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C6D4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C6D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C6D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00600000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00600000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C79C; }
        goto block_0046C6E4;
    }
block_0046C6E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C6E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C6E4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3F4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C6E4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t value = r0 & 0x00400000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00400000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C740; }
        goto block_0046C6F4;
    }
block_0046C6F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C6F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C6F4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C6F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x3E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C6F8U, address);
            }
            r1 = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C704U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 5U);
            r0 = operand - r2;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r7 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C710U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046C740; }
        goto block_0046C71C;
    }
block_0046C71C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C71CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C71CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C71CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000004U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 4U);
            r2 = r0 + operand;
        }
        {
            r0 = 0x00000290U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046C730U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1244_002D1244(frame, context, state, 0x002D1244U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046C730U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046C730;
    }
block_0046C730:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C730U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C730U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C730U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0046C71C; }
        goto block_0046C740;
    }
block_0046C740:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C740U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C740U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C740U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C744U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00200000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00200000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C79C; }
        goto block_0046C750;
    }
block_0046C750:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C750U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C750U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C750U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x3E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C754U, address);
            }
            r1 = value;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C760U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 5U);
            r0 = operand - r2;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r7 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C76CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046C79C; }
        goto block_0046C778;
    }
block_0046C778:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C778U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C778U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C778U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000004U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 4U);
            r2 = r0 + operand;
        }
        {
            r0 = 0x000002C0U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046C78CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1244_002D1244(frame, context, state, 0x002D1244U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046C78CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046C78C;
    }
block_0046C78C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C78CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C78CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C78CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0046C778; }
        goto block_0046C79C;
    }
block_0046C79C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C79CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C79CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C79CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000200U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000200U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046D5BC; }
        goto block_0046C7A8;
    }
block_0046C7A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C7A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C7A8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C7A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046C7B4U + 0x9E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C7ACU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C7B0U, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D4E4; }
        goto block_0046C7BC;
    }
block_0046C7BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C7BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C7BCU);
        }
        {
            const uint32_t updatedAddress = 0x0046C7C4U + 0x9A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C7BCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000374U;
            r0 = r0 + operand;
        }
        {
            r12 = 0x0000000BU;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C7CCU, address);
            }
            r1 = value;
        }
        {
            r10 = r0;
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C7D4U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r4, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r2 = 0x00000000U;
        }
        if (flags.Z()) {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x808U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046C7E4U, address);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0046C7ECU, address);
            }
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x71CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C7F4U, address);
            }
        }
        {
            r6 = r2;
        }
        {
            r7 = r2;
        }
        {
            r9 = r2;
        }
        {
            const uint32_t updatedAddress = r13 + 0x778U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046C804U, address);
            }
        }
        goto block_0046C808;
    }
block_0046C808:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C808U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C808U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r1 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C810U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r2, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C8E8; }
        goto block_0046C81C;
    }
block_0046C81C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C81CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C81CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 3U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x3FDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C820U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00000400U;
            r1 = r13 + operand;
        }
        if (flags.Z()) {
            const uint32_t operand = 0x000003D4U;
            r1 = r1 + operand;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + Oot3dAotLsl(r7, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046C830U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00000001U;
            r7 = r7 + operand;
        }
        if (flags.Z()) { goto block_0046C8E8; }
        goto block_0046C83C;
    }
block_0046C83C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C83CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C83CU);
        }
        {
            const uint32_t updatedAddress = r1 + 0x3F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C83CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x71CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C844U, address);
            }
        }
        if (flags.Z()) { goto block_0046C85C; }
        goto block_0046C84C;
    }
block_0046C84C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C84CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C84CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x5D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C850U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r9, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) {
            r9 = r1;
        }
        goto block_0046C85C;
    }
block_0046C85C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C85CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C85CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 3U);
            r8 = r10 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046C864U, address);
            }
        }
        if (flags.Z()) { goto block_0046C8E4; }
        goto block_0046C86C;
    }
block_0046C86C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C86CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C86CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x5D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C870U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C874U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x5D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C87CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r8 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046C884U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = r8;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046C8E4; }
        goto block_0046C890;
    }
block_0046C890:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C890U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C890U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C890U, address);
            }
            r1 = value;
        }
        {
            r11 = r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C8D8; }
        goto block_0046C8A0;
    }
block_0046C8A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C8A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C8A0U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C8A0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r3 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x5D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C8A8U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r3, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0046C8C8; }
        goto block_0046C8B4;
    }
block_0046C8B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C8B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C8B4U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046C8B4U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r8 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C8BCU, address);
            }
        }
        if (!(flags.Z())) { goto block_0046C8E4; }
        goto block_0046C8C4;
    }
block_0046C8C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C8C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C8C4U);
        }
        goto block_0046C8D8;
    }
block_0046C8C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C8C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C8C8U);
        }
        {
            r11 = r1;
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C8CCU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046C8A0; }
        goto block_0046C8D8;
    }
block_0046C8D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C8D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C8D8U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046C8DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C8E0U, address);
            }
        }
        goto block_0046C8E4;
    }
block_0046C8E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C8E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C8E4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        goto block_0046C8E8;
    }
block_0046C8E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C8E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C8E8U);
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r12, operand, static_cast<Oot3dAotFlagMask>(0x8U));
            r12 = r12 - operand;
        }
        if (!(flags.N())) { goto block_0046C808; }
        goto block_0046C8F0;
    }
block_0046C8F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C8F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C8F0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x66CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C8F0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r1 = 0x00000000U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x71CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C8FCU, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C958; }
        goto block_0046C908;
    }
block_0046C908:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C908U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C908U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C908U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x5D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C910U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x0000000FU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x604U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C918U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x71CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C91CU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C960; }
        goto block_0046C928;
    }
block_0046C928:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C928U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C928U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x19U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C928U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046C94C; }
        goto block_0046C934;
    }
block_0046C934:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C934U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C934U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C934U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            r1 = r2;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r9, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) {
            r2 = r9;
        }
        {
            r9 = r2;
        }
        goto block_0046C94C;
    }
block_0046C94C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C94CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C94CU);
        }
        {
            const uint32_t operand = r1;
            r1 = r9 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x10000000U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) { goto block_0046C960; }
        goto block_0046C958;
    }
block_0046C958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C958U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x71CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C95CU, address);
            }
        }
        goto block_0046C960;
    }
block_0046C960:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C960U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C960U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x804U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C964U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x884U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C968U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r6, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x8B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C970U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r1, r7, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C978U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r1 & 0x00000200U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000200U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046CD1C; }
        goto block_0046C984;
    }
block_0046C984:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C984U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C984U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x820U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C984U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            r3 = r0;
        }
        {
            r1 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046CA80; }
        goto block_0046C998;
    }
block_0046C998:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C998U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C998U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C998U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C99CU, address);
            }
            r8 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r8, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046C9F0; }
        goto block_0046C9A8;
    }
block_0046C9A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C9A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C9A8U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C9A8U, address);
            }
            r10 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r8 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r9 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0x5D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C9B4U, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 2U);
            r10 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r9 + 0x824U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C9BCU, address);
            }
            r11 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0x5D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C9C0U, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x824U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C9C4U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = r10;
            r8 = r8 - operand;
        }
        {
            const uint32_t operand = r14;
            r10 = r11 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, r10, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046C9F0; }
        goto block_0046C9D8;
    }
block_0046C9D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C9D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C9D8U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r9 + 0x854U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C9DCU, address);
            }
            r9 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 3U);
            r8 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0x3F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C9E4U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r9, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046C9FC; }
        goto block_0046C9F0;
    }
block_0046C9F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C9F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C9F0U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x804U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046C9F4U, address);
            }
        }
        goto block_0046CA80;
    }
block_0046C9FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046C9FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046C9FCU);
        }
        {
            const uint32_t updatedAddress = r8 + 0x3F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046C9FCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00001400U;
            r2 = r2 - operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r2 = r2 - operand;
        }
        if (flags.Z()) {
            r2 = 0x00000001U;
        }
        if (flags.Z()) { goto block_0046CA28; }
        goto block_0046CA10;
    }
block_0046CA10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CA10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CA10U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r2 = 0x00000002U;
        }
        if (flags.Z()) { goto block_0046CA28; }
        goto block_0046CA1C;
    }
block_0046CA1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CA1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CA1CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r2 = 0x00000003U;
        }
        if (!(flags.Z())) {
            r2 = 0x00000000U;
        }
        goto block_0046CA28;
    }
block_0046CA28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CA28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CA28U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x3ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CA28U, address);
            }
            r8 = value;
        }
        {
            r9 = ~(0x00000003U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 2U);
            r8 = r9 + operand;
        }
        {
            r2 = r2 | r8;
        }
        {
            r8 = r2 & 0x000000FFU;
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r4 + 0x8C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CA40U, address);
            }
            r2 = value;
        }
        if ((flags.N()) != (flags.V())) {
            r9 = Oot3dAotLsl(r1, 2U);
        }
        if ((flags.N()) != (flags.V())) {
            r2 = Oot3dAotShiftRegister(r2, 1U, r9, false).Value;
        }
        if ((flags.N()) != (flags.V())) { goto block_0046CA60; }
        goto block_0046CA50;
    }
block_0046CA50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CA50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CA50U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CA50U, address);
            }
            r9 = value;
        }
        {
            r2 = Oot3dAotLsl(r1, 2U);
        }
        {
            const uint32_t operand = 0x00000020U;
            r2 = r2 - operand;
        }
        {
            r2 = Oot3dAotShiftRegister(r9, 1U, r2, false).Value;
        }
        goto block_0046CA60;
    }
block_0046CA60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CA60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CA60U);
        }
        {
            r2 = r2 & 0x0000000FU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, r2, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046C9F0; }
        goto block_0046CA6C;
    }
block_0046CA6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CA6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CA6CU);
        }
        {
            const uint32_t updatedAddress = r3 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CA6CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CA70U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r6, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046C998; }
        goto block_0046CA80;
    }
block_0046CA80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CA80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CA80U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            r1 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046CAB4; }
        goto block_0046CA8C;
    }
block_0046CA8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CA8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CA8CU);
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x000003D4U;
            r2 = r2 + operand;
        }
        goto block_0046CA94;
    }
block_0046CA94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CA94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CA94U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r12 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CA98U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x888U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CA9CU, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r12, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046CD1C; }
        goto block_0046CAA8;
    }
block_0046CAA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CAA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CAA8U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r7, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046CA94; }
        goto block_0046CAB4;
    }
block_0046CAB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CAB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CAB4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CAB4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x71CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CABCU, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046CD1C; }
        goto block_0046CAC8;
    }
block_0046CAC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CAC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CAC8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x19U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CAC8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x808U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CACCU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x604U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CAD4U, address);
            }
            r2 = value;
        }
        if (!(flags.Z())) { goto block_0046CAEC; }
        goto block_0046CADC;
    }
block_0046CADC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CADCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CADCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x604U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CADCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CAE0U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            r2 = r3 & ~(0x0000000FU);
        }
        goto block_0046CAEC;
    }
block_0046CAEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CAECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CAECU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x604U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CAECU, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r2, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x3F5U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CAF4U, address);
            }
            r3 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046CB1C; }
        goto block_0046CB00;
    }
block_0046CB00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CB00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CB00U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CB00U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CB04U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r3 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x5D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CB0CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = r2;
            r3 = r3 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r12, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046CB80; }
        goto block_0046CB1C;
    }
block_0046CB1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CB1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CB1CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CB1CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CB20U, address);
            }
            r3 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r5 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r1 + 0x5D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CB30U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r2;
            r3 = r1 - operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046CB68; }
        goto block_0046CB3C;
    }
block_0046CB3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CB3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CB3CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r1 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CB40U, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CB4CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r8;
            r12 = r12 - operand;
        }
        {
            const uint32_t operand = r3;
            r12 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8CCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046CB58U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x8BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CB5CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0046CB3C; }
        goto block_0046CB68;
    }
block_0046CB68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CB68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CB68U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8CCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046CB68U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x604U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CB6CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x3F5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CB7CU, address);
            }
        }
        goto block_0046CB80;
    }
block_0046CB80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CB80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CB80U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x604U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046CB80U, address);
            }
        }
        {
            r2 = Oot3dAotLsr(r2, 3U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r4 + 0x8C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046CB8CU, address);
            }
        }
        if (flags.Z()) { goto block_0046CBC4; }
        goto block_0046CB94;
    }
block_0046CB94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CB94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CB94U);
        }
        {
            const uint32_t updatedAddress = 0x0046CB9CU + 0x5B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CB94U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046CBA0U + 0x5B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CB98U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CB9CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CBA0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046D4E4; }
        goto block_0046CBAC;
    }
block_0046CBAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CBACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CBACU);
        }
        {
            const uint32_t updatedAddress = 0x0046CBB4U + 0x5E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CBACU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046CBB0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046CBB4U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CBBCU, address);
            }
        }
        goto block_0046D4E4;
    }
block_0046CBC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CBC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CBC4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x808U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CBC4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0046CBF4; }
        goto block_0046CBD0;
    }
block_0046CBD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CBD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CBD0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CBD0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x000008C0U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r0 + operand;
        }
        {
            r0 = 0x00000200U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046CBE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1244_002D1244(frame, context, state, 0x002D1244U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046CBE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046CBE8;
    }
block_0046CBE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CBE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CBE8U);
        }
        {
        }
        {
        }
        goto block_0046D4E4;
    }
block_0046CBF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CBF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CBF4U);
        }
        {
            const uint32_t operand = 0x000008C0U;
            r2 = r4 + operand;
        }
        {
            r1 = 0x00000027U;
        }
        {
            r0 = 0x00000200U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046CC04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1244_002D1244(frame, context, state, 0x002D1244U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046CC04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046CC04;
    }
block_0046CC04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CC04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CC04U);
        }
        {
            const uint32_t updatedAddress = 0x0046CC0CU + 0x548U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC04U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046CC10U + 0x548U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC08U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC10U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046CC34; }
        goto block_0046CC1C;
    }
block_0046CC1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CC1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CC1CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x95CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC1CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046CC20U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046CC2CU + 0x570U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC24U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046CC28U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CC30U, address);
            }
        }
        goto block_0046CC34;
    }
block_0046CC34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CC34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CC34U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC34U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046CC58; }
        goto block_0046CC40;
    }
block_0046CC40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CC40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CC40U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x960U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC40U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046CC44U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046CC50U + 0x550U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC48U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046CC4CU, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CC54U, address);
            }
        }
        goto block_0046CC58;
    }
block_0046CC58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CC58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CC58U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3F4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC58U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046CCB0; }
        goto block_0046CC64;
    }
block_0046CC64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CC64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CC64U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC64U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC68U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046CC8C; }
        goto block_0046CC74;
    }
block_0046CC74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CC74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CC74U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x964U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC74U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046CC78U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046CC84U + 0x520U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC7CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046CC80U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CC88U, address);
            }
        }
        goto block_0046CC8C;
    }
block_0046CC8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CC8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CC8CU);
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC8CU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046CCB0; }
        goto block_0046CC98;
    }
block_0046CC98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CC98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CC98U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x968U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CC98U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046CC9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046CCA8U + 0x500U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CCA0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046CCA4U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CCACU, address);
            }
        }
        goto block_0046CCB0;
    }
block_0046CCB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CCB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CCB0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x820U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CCB0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r7;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x720U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0046CCB8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x724U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CCBCU, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            r0 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046CCE8; }
        goto block_0046CCCC;
    }
block_0046CCCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CCCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CCCCU);
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CCCCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r3 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x728U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046CCD8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CCDCU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046CCCC; }
        goto block_0046CCE8;
    }
block_0046CCE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CCE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CCE8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            r1 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046D4E4; }
        goto block_0046CCF4;
    }
block_0046CCF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CCF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CCF4U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x000003D4U;
            r2 = r2 + operand;
        }
        goto block_0046CCFC;
    }
block_0046CCFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CCFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CCFCU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r12 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CD00U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r7, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x728U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046CD10U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0046CCFC; }
        goto block_0046CD18;
    }
block_0046CD18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CD18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CD18U);
        }
        goto block_0046D4E4;
    }
block_0046CD1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CD1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CD1CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            r2 = r0;
        }
        {
            r1 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046CD8C; }
        goto block_0046CD2C;
    }
block_0046CD2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CD2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CD2CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r9 = r6 - operand;
        }
        {
            r10 = 0x00000000U;
        }
        goto block_0046CD34;
    }
block_0046CD34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CD34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CD34U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CD34U, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 3U);
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r12 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x7C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046CD40U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CD44U, address);
            }
            r8 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r9, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 2U);
            r8 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0x5D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CD54U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x824U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046CD58U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CD5CU, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 1U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 3U);
            r8 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0x3F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CD68U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x854U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046CD6CU, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000400U;
            r12 = r3 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x000003C8U;
            r12 = r12 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r3 + 0x7C4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046CD78U, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CD7CU, address);
            }
            r2 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r3 + 0x7C4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0046CD80U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r6, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046CD34; }
        goto block_0046CD8C;
    }
block_0046CD8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CD8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CD8CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            r1 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046CDB8; }
        goto block_0046CD98;
    }
block_0046CD98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CD98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CD98U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x000003D4U;
            r2 = r2 + operand;
        }
        goto block_0046CDA0;
    }
block_0046CDA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CDA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CDA0U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r12 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CDA4U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r7, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t updatedAddress = r12 + 0x888U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046CDB0U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0046CDA0; }
        goto block_0046CDB8;
    }
block_0046CDB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CDB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CDB8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x884U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0046CDB8U, address);
            }
        }
        {
            const uint32_t operand = 0x000007C0U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8B8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0046CDC0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x820U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046CDC4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x508U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CDC8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r5 + 0x19U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CDD0U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) { goto block_0046CDE8; }
        goto block_0046CDD8;
    }
block_0046CDD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CDD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CDD8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x71CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046CDDCU, address);
            }
        }
        if (flags.Z()) { goto block_0046CE08; }
        goto block_0046CDE4;
    }
block_0046CDE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CDE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CDE4U);
        }
        goto block_0046CDF0;
    }
block_0046CDE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CDE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CDE8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046CE08; }
        goto block_0046CDF0;
    }
block_0046CDF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CDF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CDF0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x604U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CDF0U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r2 = Oot3dAotAsr(r2, 3U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046CDFCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x3F5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046CE00U, address);
            }
        }
        goto block_0046CE34;
    }
block_0046CE08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CE08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CE08U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CE08U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x604U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CE0CU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            r1 = r1 & ~(0x0000000FU);
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r5 + 0x604U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046CE18U, address);
            }
        }
        if ((flags.N()) == (flags.V())) {
            r1 = 0x00000000U;
        }
        if ((flags.N()) != (flags.V())) {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x3F5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046CE24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x604U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CE28U, address);
            }
            r1 = value;
        }
        {
            r1 = Oot3dAotAsr(r1, 3U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046CE30U, address);
            }
        }
        goto block_0046CE34;
    }
block_0046CE34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CE34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CE34U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x71CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CE34U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D2F0; }
        goto block_0046CE40;
    }
block_0046CE40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CE40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CE40U);
        }
        {
            const uint32_t operand = 0x000003E8U;
            r1 = r5 + operand;
        }
        {
            r12 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x75CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046CE48U, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046CE50U, address);
            }
        }
        {
            const uint32_t operand = 0x000005D0U;
            r10 = r5 + operand;
        }
        {
            r1 = r12;
        }
        {
            r11 = r12;
        }
        {
            const uint32_t operand = 0x000000CCU;
            r2 = r2 + operand;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x770U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046CE68U, address);
            }
        }
        goto block_0046CE6C;
    }
block_0046CE6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CE6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CE6CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r8 = r4 + operand;
        }
        {
            r12 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000027U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t updatedAddress = r8 + 0x8C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046CE7CU, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0046CE6C; }
        goto block_0046CE84;
    }
block_0046CE84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CE84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CE84U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            r9 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x768U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CE90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x76CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046CE94U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046D298; }
        goto block_0046CE9C;
    }
block_0046CE9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CE9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CE9CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x768U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CE9CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x768U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CEA0U, address);
            }
            r3 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x758U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CEA8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CEACU, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CEB0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r8 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x764U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046CEB8U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 3U);
            r3 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 2U);
            r12 = r10 + operand;
        }
        {
            const uint32_t operand = 0x000003E8U;
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CEC8U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CECCU, address);
            }
            r14 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CED0U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r14;
            r8 = r8 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00001400U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x750U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046CEE0U, address);
            }
        }
        if (flags.Z()) { goto block_0046CF1C; }
        goto block_0046CEE8;
    }
block_0046CEE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CEE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CEE8U);
        }
        {
            const uint32_t operand = 0x00001400U;
            r12 = r12 - operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r12, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r12 = r12 - operand;
        }
        if (flags.Z()) {
            r0 = 0x00000001U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r13 + 0x758U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CEF4U, address);
            }
        }
        if (flags.Z()) { goto block_0046CF1C; }
        goto block_0046CEFC;
    }
block_0046CEFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CEFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CEFCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x00000002U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r13 + 0x758U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CF04U, address);
            }
        }
        if (flags.Z()) { goto block_0046CF1C; }
        goto block_0046CF0C;
    }
block_0046CF0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CF0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CF0CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x00000003U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r13 + 0x758U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CF14U, address);
            }
        }
        if (flags.Z()) {
            r0 = 0x00000004U;
        }
        goto block_0046CF1C;
    }
block_0046CF1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CF1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CF1CU);
        }
        {
            const uint32_t updatedAddress = r3 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CF1CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x758U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CF20U, address);
            }
            r14 = value;
        }
        {
            r8 = ~(0x00000003U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 2U);
            r12 = r8 + operand;
        }
        {
            r12 = r12 | r14;
        }
        if ((flags.N()) == (flags.V())) { goto block_0046CF4C; }
        goto block_0046CF38;
    }
block_0046CF38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CF38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CF38U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CF38U, address);
            }
            r8 = value;
        }
        {
            r14 = Oot3dAotLsl(r9, 2U);
        }
        {
            r12 = r8 | Oot3dAotShiftRegister(r12, 0U, r14, false).Value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8C4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046CF44U, address);
            }
        }
        goto block_0046CF64;
    }
block_0046CF4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CF4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CF4CU);
        }
        {
            r8 = Oot3dAotLsl(r9, 2U);
        }
        {
            const uint32_t operand = 0x00000020U;
            r8 = r8 - operand;
        }
        {
            r12 = Oot3dAotShiftRegister(r12, 0U, r8, false).Value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CF58U, address);
            }
            r8 = value;
        }
        {
            r12 = r12 | r8;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8C8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046CF60U, address);
            }
        }
        goto block_0046CF64;
    }
block_0046CF64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CF64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CF64U);
        }
        {
            const uint32_t updatedAddress = r3 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CF64U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046CFB4; }
        goto block_0046CF70;
    }
block_0046CF70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CF70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CF70U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CF70U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x750U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CF74U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046CF78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CF7CU, address);
            }
            r3 = value;
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r12) * r0);
        }
        {
            r3 = r3 | r9;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046CF88U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CF8CU, address);
            }
            r3 = value;
        }
        {
            r12 = 0x10000000U;
        }
        {
            r0 = r12 | Oot3dAotLsl(r0, 16U);
        }
        {
            r0 = r0 | r3;
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CF9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x8BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CFA0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CFACU, address);
            }
        }
        goto block_0046D284;
    }
block_0046CFB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CFB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CFB4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x76CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CFB4U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r8 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, r0, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            r12 = r0;
        }
        {
            const uint32_t updatedAddress = r13 + 0x76CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046CFC4U, address);
            }
        }
        {
            const uint32_t operand = r0;
            r12 = r11 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r12 = r12 - operand;
        }
        {
            r12 = r12 & ~(r8);
        }
        {
            const uint32_t updatedAddress = r3 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CFD4U, address);
            }
            r8 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r8) * r0);
        }
        {
            const uint32_t operand = r0;
            r11 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x754U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CFE4U, address);
            }
        }
        if (!(flags.Z())) { goto block_0046D018; }
        goto block_0046CFEC;
    }
block_0046CFEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046CFECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046CFECU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x750U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CFECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046CFF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x768U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CFF4U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CFF8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046CFFCU, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x770U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D000U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 2U);
            r12 = r10 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D008U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r12;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x760U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D010U, address);
            }
        }
        goto block_0046D020;
    }
block_0046D018:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D018U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D018U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046D034; }
        goto block_0046D020;
    }
block_0046D020:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D020U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D020U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D020U, address);
            }
            r0 = value;
        }
        {
            r12 = Oot3dAotLsl(r1, 2U);
        }
        {
            r0 = r0 | Oot3dAotShiftRegister(r9, 0U, r12, false).Value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D02CU, address);
            }
        }
        goto block_0046D048;
    }
block_0046D034:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D034U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D034U);
        }
        {
            r0 = Oot3dAotLsl(r1, 2U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D038U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000020U;
            r0 = r0 - operand;
        }
        {
            r0 = r12 | Oot3dAotShiftRegister(r9, 0U, r0, false).Value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D044U, address);
            }
        }
        goto block_0046D048;
    }
block_0046D048:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D048U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D048U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r9 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        if (flags.Z()) { goto block_0046D0B0; }
        goto block_0046D058;
    }
block_0046D058:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D058U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D058U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x764U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D058U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D05CU, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x750U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D060U, address);
            }
            r14 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D064U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r12 = r10 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D06CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r8;
            r8 = r12 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, r14, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046D0B0; }
        goto block_0046D07C;
    }
block_0046D07C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D07CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D07CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x75CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D07CU, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D084U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D08CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r0, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046D0B0; }
        goto block_0046D098;
    }
block_0046D098:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D098U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D098U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x760U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D098U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, r0, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0046D0B0; }
        goto block_0046D0A4;
    }
block_0046D0A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D0A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D0A4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r14 = 0x00000000U;
        }
        if (!(flags.Z())) { goto block_0046D0B4; }
        goto block_0046D0B0;
    }
block_0046D0B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D0B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D0B0U);
        }
        {
            r14 = 0x00000001U;
        }
        goto block_0046D0B4;
    }
block_0046D0B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D0B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D0B4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r14, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D0B8U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x770U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D0BCU, address);
            }
            r3 = value;
        }
        if (!(flags.Z())) {
            const uint32_t operand = r3;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) { goto block_0046D0E0; }
        goto block_0046D0C8;
    }
block_0046D0C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D0C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D0C8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x764U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D0C8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D0CCU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D0D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r10 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D0D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r3;
            r0 = r0 - operand;
        }
        goto block_0046D0E0;
    }
block_0046D0E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D0E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D0E0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x750U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D0E0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r12 = operand - r1;
        }
        {
            const uint32_t operand = r3;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x754U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D0ECU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = r3;
            r0 = r0 - operand;
        }
        {
            r0 = Oot3dAotLsr(r0, 2U);
        }
        {
            r3 = r0 & 0x00000003U;
            Oot3dAotSetLogicalFlags(flags, r3, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r3 = 0x00000001U;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 2U);
            r3 = r3 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r12, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0046D244; }
        goto block_0046D10C;
    }
block_0046D10C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D10CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D10CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046D218; }
        goto block_0046D114;
    }
block_0046D114:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D114U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D114U);
        }
        {
            const uint32_t operand = 0x00000003U;
            r3 = r11 + operand;
        }
        {
            r3 = r3 & ~(0x00000003U);
        }
        {
            const uint32_t value = r0 & 0x00000003U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r11 = r3 + operand;
        }
        if (flags.Z()) { goto block_0046D1D8; }
        goto block_0046D128;
    }
block_0046D128:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D128U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D128U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046D1AC; }
        goto block_0046D130;
    }
block_0046D130:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D130U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D130U);
        }
        {
            r3 = r0 & 0x00000003U;
        }
        {
            r12 = Oot3dAotLsl(r1, 2U);
        }
        {
            const uint32_t operand = 0x0000000BU;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotShiftRegister(r3, 0U, r12, false).Value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D140U, address);
            }
            r12 = value;
        }
        {
            r3 = r3 | r12;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D148U, address);
            }
        }
        goto block_0046D1CC;
    }
block_0046D1AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D1ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D1ACU);
        }
        {
            r3 = Oot3dAotLsl(r1, 2U);
        }
        {
            const uint32_t operand = 0x00000020U;
            r3 = r3 - operand;
        }
        {
            r12 = r0 & 0x00000003U;
        }
        {
            const uint32_t operand = 0x0000000BU;
            r12 = r12 + operand;
        }
        {
            r3 = Oot3dAotShiftRegister(r12, 0U, r3, false).Value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D1C0U, address);
            }
            r12 = value;
        }
        {
            r3 = r3 | r12;
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D1C8U, address);
            }
        }
        goto block_0046D1CC;
    }
block_0046D1CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D1CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D1CCU);
        }
        {
            r0 = r0 & ~(0x00000003U);
            Oot3dAotSetLogicalFlags(flags, r0, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        if (flags.Z()) { goto block_0046D218; }
        goto block_0046D1D8;
    }
block_0046D1D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D1D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D1D8U);
        }
        {
            r12 = 0x0000000FU;
        }
        goto block_0046D1DC;
    }
block_0046D1DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D1DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D1DCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046D1F8; }
        goto block_0046D1E4;
    }
block_0046D1E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D1E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D1E4U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D1E4U, address);
            }
            r3 = value;
        }
        {
            r8 = Oot3dAotLsl(r1, 2U);
        }
        {
            r3 = r3 | Oot3dAotShiftRegister(r12, 0U, r8, false).Value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D1F0U, address);
            }
        }
        goto block_0046D20C;
    }
block_0046D1F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D1F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D1F8U);
        }
        {
            r3 = Oot3dAotLsl(r1, 2U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D1FCU, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = 0x00000020U;
            r3 = r3 - operand;
        }
        {
            r3 = r8 | Oot3dAotShiftRegister(r12, 0U, r3, false).Value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D208U, address);
            }
        }
        goto block_0046D20C;
    }
block_0046D20C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D20CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D20CU);
        }
        {
            const uint32_t operand = 0x00000004U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        if (!(flags.Z())) { goto block_0046D1DC; }
        goto block_0046D218;
    }
block_0046D218:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D218U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D218U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r14, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D284; }
        goto block_0046D220;
    }
block_0046D220:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D220U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D220U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x76CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D220U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x76CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D224U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = r11;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 - operand;
        }
        {
            r0 = r0 & ~(r3);
        }
        {
            const uint32_t updatedAddress = r13 + 0x770U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D238U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D250; }
        goto block_0046D244;
    }
block_0046D244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D244U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x71CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D248U, address);
            }
        }
        goto block_0046D2F0;
    }
block_0046D250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D250U);
        }
        {
            r0 = Oot3dAotLsl(r3, 16U);
        }
        {
            r0 = r0 | Oot3dAotLsl(r1, 28U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D258U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x76CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D260U, address);
            }
        }
        {
            r0 = r0 | r1;
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D268U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x8BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D26CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            r11 = r1;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D280U, address);
            }
        }
        goto block_0046D284;
    }
block_0046D284:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D284U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D284U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x764U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D284U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r9 = r9 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, r6, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t updatedAddress = r13 + 0x768U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D290U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0046CE9C; }
        goto block_0046D298;
    }
block_0046D298:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D298U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D298U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x71CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D298U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D2F0; }
        goto block_0046D2A4;
    }
block_0046D2A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D2A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D2A4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            r0 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046D2D0; }
        goto block_0046D2B0;
    }
block_0046D2B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D2B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D2B0U);
        }
        {
            r1 = 0x00010000U;
        }
        goto block_0046D2B4;
    }
block_0046D2B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D2B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D2B4U);
        }
        {
            const uint32_t operand = r6;
            r3 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D2B8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            r2 = r2 | Oot3dAotShiftRegister(r1, 0U, r3, false).Value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r7, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t updatedAddress = r4 + 0x8C8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D2C8U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0046D2B4; }
        goto block_0046D2D0;
    }
block_0046D2D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D2D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D2D0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D2F0; }
        goto block_0046D2D8;
    }
block_0046D2D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D2D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D2D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D2D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r7;
            r1 = r6 + operand;
        }
        {
            r2 = 0xF0000000U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 28U);
            r1 = r2 + operand;
        }
        {
            r0 = r0 | r1;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8C8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D2ECU, address);
            }
        }
        goto block_0046D2F0;
    }
block_0046D2F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D2F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D2F0U);
        }
        {
            const uint32_t operand = r7;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x720U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0046D2F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x724U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D2F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x820U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D2FCU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x95CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D304U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x960U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D308U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046D314U + 0xBE0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D30CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x964U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D314U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046D320U + 0xBD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D318U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x968U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D31CU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046D3A0; }
        goto block_0046D328;
    }
block_0046D328:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D328U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D328U);
        }
        goto block_0046D334;
    }
block_0046D32C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D32CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D32CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0046D35C; }
        goto block_0046D334;
    }
block_0046D334:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D334U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D334U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D334U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x95CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D338U, address);
            }
            r12 = value;
        }
        {
            r3 = Oot3dAotLsl(r0, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D348U, address);
            }
            r2 = value;
        }
        {
            r2 = r2 & 0x0000000FU;
        }
        {
            r2 = r12 | Oot3dAotShiftRegister(r2, 0U, r3, false).Value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x95CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D354U, address);
            }
        }
        goto block_0046D384;
    }
block_0046D35C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D35CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D35CU);
        }
        {
            r2 = Oot3dAotLsl(r0, 2U);
        }
        {
            const uint32_t operand = 0x00000020U;
            r3 = r2 - operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D364U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x960U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D368U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D374U, address);
            }
            r2 = value;
        }
        {
            r2 = r2 & 0x0000000FU;
        }
        {
            r2 = r12 | Oot3dAotShiftRegister(r2, 0U, r3, false).Value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x960U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D380U, address);
            }
        }
        goto block_0046D384;
    }
block_0046D384:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D384U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D384U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D384U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r3 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x728U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D390U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D394U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046D32C; }
        goto block_0046D3A0;
    }
block_0046D3A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D3A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D3A0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r1 = 0x00000000U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0046D428; }
        goto block_0046D3AC;
    }
block_0046D3AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D3ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D3ACU);
        }
        {
            const uint32_t operand = 0x00000400U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x000003D4U;
            r3 = r3 + operand;
        }
        goto block_0046D3B4;
    }
block_0046D3B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D3B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D3B4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0046D3E4; }
        goto block_0046D3BC;
    }
block_0046D3BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D3BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D3BCU);
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D3BCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x95CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D3C0U, address);
            }
            r6 = value;
        }
        {
            r12 = Oot3dAotLsl(r0, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D3D0U, address);
            }
            r2 = value;
        }
        {
            r2 = r2 & 0x0000000FU;
        }
        {
            r2 = r6 | Oot3dAotShiftRegister(r2, 0U, r12, false).Value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x95CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D3DCU, address);
            }
        }
        goto block_0046D40C;
    }
block_0046D3E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D3E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D3E4U);
        }
        {
            r2 = Oot3dAotLsl(r0, 2U);
        }
        {
            const uint32_t operand = 0x00000020U;
            r12 = r2 - operand;
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D3ECU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D3F8U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x960U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D3FCU, address);
            }
            r2 = value;
        }
        {
            r6 = r6 & 0x0000000FU;
        }
        {
            r2 = r2 | Oot3dAotShiftRegister(r6, 0U, r12, false).Value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x960U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D408U, address);
            }
        }
        goto block_0046D40C;
    }
block_0046D40C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D40CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D40CU);
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D40CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r12 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r7, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x728U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D420U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0046D3B4; }
        goto block_0046D428;
    }
block_0046D428:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D428U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D428U);
        }
        {
            const uint32_t operand = 0x000008C0U;
            r2 = r4 + operand;
        }
        {
            r1 = 0x00000027U;
        }
        {
            r0 = 0x00000200U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046D438U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1244_002D1244(frame, context, state, 0x002D1244U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046D438U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046D438;
    }
block_0046D438:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D438U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D438U);
        }
        {
            const uint32_t updatedAddress = 0x0046D440U - 0x2ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D438U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046D444U - 0x2ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D43CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D440U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D444U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046D468; }
        goto block_0046D450;
    }
block_0046D450:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D450U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D450U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x95CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D450U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D454U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046D460U - 0x2C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D458U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D45CU, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D464U, address);
            }
        }
        goto block_0046D468;
    }
block_0046D468:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D468U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D468U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D468U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046D48C; }
        goto block_0046D474;
    }
block_0046D474:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D474U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D474U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x960U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D474U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D478U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046D484U - 0x2E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D47CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D480U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D488U, address);
            }
        }
        goto block_0046D48C;
    }
block_0046D48C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D48CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D48CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3F4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D48CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D4E4; }
        goto block_0046D498;
    }
block_0046D498:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D498U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D498U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D498U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D49CU, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046D4C0; }
        goto block_0046D4A8;
    }
block_0046D4A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D4A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D4A8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x964U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D4A8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D4ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046D4B8U - 0x314U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D4B0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D4B4U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D4BCU, address);
            }
        }
        goto block_0046D4C0;
    }
block_0046D4C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D4C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D4C0U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D4C0U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046D4E4; }
        goto block_0046D4CC;
    }
block_0046D4CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D4CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D4CCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x968U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D4CCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D4D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046D4DCU - 0x334U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D4D4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D4D8U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D4E0U, address);
            }
        }
        goto block_0046D4E4;
    }
block_0046D4E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D4E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D4E4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D4E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046D4F0U + 0xA0CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D4E8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D4ECU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & r1;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x720U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D4F8U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x724U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D4FCU, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046D5BC; }
        goto block_0046D508;
    }
block_0046D508:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D508U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D508U);
        }
        {
            const uint32_t updatedAddress = 0x0046D510U + 0x9F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D508U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046D514U - 0x3BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D50CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046D518U - 0x3C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D510U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000002U;
            r8 = r6 + operand;
        }
        {
            r7 = r6 | Oot3dAotAsr(r6, 18U);
        }
        {
            const uint32_t operand = 0x00000003U;
            r10 = r6 + operand;
        }
        goto block_0046D520;
    }
block_0046D520:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D520U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D520U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D524U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D528U, address);
            }
            r9 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x728U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D52CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r9, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046D540; }
        goto block_0046D538;
    }
block_0046D538:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D538U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D538U);
        }
        {
            const uint32_t firstAddress = r2;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0046D538U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0046D538U,
                                           firstAddress + 4U);
            }
            r2 = r2 + 8U;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D53CU, address);
            }
        }
        goto block_0046D540;
    }
block_0046D540:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D540U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D540U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D540U, address);
            }
            r9 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r9, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046D564; }
        goto block_0046D54C;
    }
block_0046D54C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D54CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D54CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r9 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 2U);
            r9 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r9 + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D554U, address);
            }
            r9 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = r2;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0046D558U, address);
            }
            r2 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = r2;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0046D55CU, address);
            }
            r2 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D560U, address);
            }
        }
        goto block_0046D564;
    }
block_0046D564:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D564U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D564U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D564U, address);
            }
            r9 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r9, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046D588; }
        goto block_0046D570;
    }
block_0046D570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D570U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r9 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 2U);
            r9 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r9 + 0x35CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D578U, address);
            }
            r9 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = r2;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0046D57CU, address);
            }
            r2 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = r2;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046D580U, address);
            }
            r2 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D584U, address);
            }
        }
        goto block_0046D588;
    }
block_0046D588:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D588U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D588U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D588U, address);
            }
            r9 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r9, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046D5AC; }
        goto block_0046D594;
    }
block_0046D594:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D594U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D594U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x360U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D59CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r2;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046D5A0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0046D5A0U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046D5A8U, address);
            }
        }
        goto block_0046D5AC;
    }
block_0046D5AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D5ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D5ACU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x724U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D5ACU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0046D520; }
        goto block_0046D5BC;
    }
block_0046D5BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D5BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D5BCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D5BCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046D818; }
        goto block_0046D5C8;
    }
block_0046D5C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D5C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D5C8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D5C8U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & 0x00000010U;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046D6F8; }
        goto block_0046D5D8;
    }
block_0046D5D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D5D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D5D8U);
        }
        {
            const uint32_t updatedAddress = 0x0046D5E0U + 0x924U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D5D8U, address);
            }
            r3 = value;
        }
        {
            r8 = ~(0x00000000U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046D5E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1B8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046D5E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1B4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046D5E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D5ECU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D664; }
        goto block_0046D5FC;
    }
block_0046D5FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D5FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D5FCU);
        }
        {
            const uint32_t operand = 0x00000070U;
            r1 = r3 - operand;
        }
        {
            const uint32_t operand = 0x00000300U;
            r12 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D604U, address);
            }
            r6 = value;
        }
        {
            const uint32_t operand = 0x000000F6U;
            r12 = r12 + operand;
        }
        {
            r7 = 0x00000001U;
        }
        goto block_0046D610;
    }
block_0046D610:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D610U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D610U);
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D610U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r12;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D614U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D654; }
        goto block_0046D620;
    }
block_0046D620:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D620U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D620U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D628U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            r2 = ~(r2);
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D634U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D638U, address);
            }
            r1 = value;
        }
        {
            r2 = Oot3dAotAsr(r1, 5U);
        }
        {
            r1 = r1 & 0x0000001FU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D648U, address);
            }
            r9 = value;
        }
        {
            r1 = r9 | Oot3dAotShiftRegister(r7, 0U, r1, false).Value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046D650U, address);
            }
        }
        goto block_0046D654;
    }
block_0046D654:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D654U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D654U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D658U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046D610; }
        goto block_0046D664;
    }
block_0046D664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D664U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3F4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D664U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046D6F8; }
        goto block_0046D670;
    }
block_0046D670:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D670U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D670U);
        }
        {
            const uint32_t updatedAddress = 0x0046D678U + 0x890U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D670U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x350U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046D674U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x34CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046D678U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x348U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0046D67CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D680U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046D6F8; }
        goto block_0046D690;
    }
block_0046D690:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D690U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D690U);
        }
        {
            const uint32_t operand = 0x00000088U;
            r1 = r3 - operand;
        }
        {
            const uint32_t operand = 0x00000300U;
            r12 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D698U, address);
            }
            r6 = value;
        }
        {
            const uint32_t operand = 0x000000F6U;
            r12 = r12 + operand;
        }
        {
            r7 = 0x00000001U;
        }
        goto block_0046D6A4;
    }
block_0046D6A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D6A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D6A4U);
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D6A4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r12;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D6A8U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D6E8; }
        goto block_0046D6B4;
    }
block_0046D6B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D6B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D6B4U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D6BCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            r2 = ~(r2);
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D6C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D6CCU, address);
            }
            r2 = value;
        }
        {
            r1 = Oot3dAotAsr(r2, 5U);
        }
        {
            r2 = r2 & 0x0000001FU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D6DCU, address);
            }
            r8 = value;
        }
        {
            r2 = r8 | Oot3dAotShiftRegister(r7, 0U, r2, false).Value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x7A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D6E4U, address);
            }
        }
        goto block_0046D6E8;
    }
block_0046D6E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D6E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D6E8U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D6ECU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_0046D6A4; }
        goto block_0046D6F8;
    }
block_0046D6F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D6F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D6F8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D6F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D6FCU, address);
            }
            r1 = value;
        }
        {
            r0 = r0 & 0x00000020U;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046D788; }
        goto block_0046D70C;
    }
block_0046D70C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D70CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D70CU);
        }
        {
            const uint32_t updatedAddress = 0x0046D714U + 0x7F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D70CU, address);
            }
            r3 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D714U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046D788; }
        goto block_0046D720;
    }
block_0046D720:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D720U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D720U);
        }
        {
            const uint32_t operand = 0x000000A0U;
            r1 = r3 - operand;
        }
        {
            const uint32_t operand = 0x00000300U;
            r12 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D728U, address);
            }
            r6 = value;
        }
        {
            const uint32_t operand = 0x000000F6U;
            r12 = r12 + operand;
        }
        {
            r7 = 0x00000001U;
        }
        goto block_0046D734;
    }
block_0046D734:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D734U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D734U);
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D734U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r12;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D738U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D778; }
        goto block_0046D744;
    }
block_0046D744:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D744U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D744U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D74CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            r2 = ~(r2);
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D758U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D75CU, address);
            }
            r1 = value;
        }
        {
            r2 = Oot3dAotAsr(r1, 5U);
        }
        {
            r1 = r1 & 0x0000001FU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D76CU, address);
            }
            r8 = value;
        }
        {
            r1 = r8 | Oot3dAotShiftRegister(r7, 0U, r1, false).Value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046D774U, address);
            }
        }
        goto block_0046D778;
    }
block_0046D778:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D778U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D778U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D77CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_0046D734; }
        goto block_0046D788;
    }
block_0046D788:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D788U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D788U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D788U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D78CU, address);
            }
            r1 = value;
        }
        {
            r0 = r0 & 0x00000002U;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046D818; }
        goto block_0046D79C;
    }
block_0046D79C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D79CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D79CU);
        }
        {
            const uint32_t updatedAddress = 0x0046D7A4U + 0x76CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D79CU, address);
            }
            r3 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D7A4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046D818; }
        goto block_0046D7B0;
    }
block_0046D7B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D7B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D7B0U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r1 = r3 - operand;
        }
        {
            const uint32_t operand = 0x00000300U;
            r12 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D7B8U, address);
            }
            r6 = value;
        }
        {
            const uint32_t operand = 0x000000F6U;
            r12 = r12 + operand;
        }
        {
            r7 = 0x00000001U;
        }
        goto block_0046D7C4;
    }
block_0046D7C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D7C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D7C4U);
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D7C4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r12;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D7C8U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D808; }
        goto block_0046D7D4;
    }
block_0046D7D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D7D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D7D4U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x4B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D7DCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            r2 = ~(r2);
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046D7E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D7ECU, address);
            }
            r1 = value;
        }
        {
            r2 = Oot3dAotAsr(r1, 5U);
        }
        {
            r1 = r1 & 0x0000001FU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D7FCU, address);
            }
            r8 = value;
        }
        {
            r1 = r8 | Oot3dAotShiftRegister(r7, 0U, r1, false).Value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046D804U, address);
            }
        }
        goto block_0046D808;
    }
block_0046D808:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D808U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D808U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D80CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_0046D7C4; }
        goto block_0046D818;
    }
block_0046D818:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D818U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D818U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D818U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000010U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046DB80; }
        goto block_0046D824;
    }
block_0046D824:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D824U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D824U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D824U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x1B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D82CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D834U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x348U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D83CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046D85C; }
        goto block_0046D848;
    }
block_0046D848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D848U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x34CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D848U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x350U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D850U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (flags.Z()) { goto block_0046DB80; }
        goto block_0046D85C;
    }
block_0046D85C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D85CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D85CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D85CU, address);
            }
            r8 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D9E0; }
        goto block_0046D868;
    }
block_0046D868:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D868U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D868U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x348U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D868U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x34CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D870U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x350U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D878U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046D9E0; }
        goto block_0046D884;
    }
block_0046D884:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D884U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D884U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            r11 = r2;
        }
        {
            r12 = r2;
        }
        {
            r6 = r2;
        }
        {
            r10 = 0x00000001U;
        }
        if (!(flags.Z())) { goto block_0046D8D8; }
        goto block_0046D8A0;
    }
block_0046D8A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D8A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D8A0U);
        }
        {
            r0 = Oot3dAotLsr(r6, 5U);
        }
        {
            r1 = r6 & 0x0000001FU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x348U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D8ACU, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r0, 1U, r1, flags.C());
            r0 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        if (flags.Z()) {
            r0 = r6 & ~(0x0000001FU);
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00000020U;
            r6 = r0 + operand;
        }
        {
            r1 = r6 & 0x0000001FU;
        }
        {
            r0 = Oot3dAotLsr(r6, 5U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x348U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D8CCU, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r10, 0U, r1, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046D8A0; }
        goto block_0046D8D8;
    }
block_0046D8D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D8D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D8D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x344U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D8D8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046D9E0; }
        goto block_0046D8E4;
    }
block_0046D8E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D8E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D8E4U);
        }
        {
            const uint32_t updatedAddress = 0x0046D8ECU - 0x794U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D8E4U, address);
            }
            r9 = value;
        }
        goto block_0046D8E8;
    }
block_0046D8E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D8E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D8E8U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 2U);
            r0 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r0 + 0x1C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D8F0U, address);
            }
            r7 = value;
        }
        if (!(flags.Z())) {
            const uint32_t operand = r11;
            r0 = r7 - operand;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r12, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D944; }
        goto block_0046D900;
    }
block_0046D900:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D900U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D900U);
        }
        {
            const uint32_t updatedAddress = 0x0046D908U - 0x7B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D900U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D904U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D908U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046D92C; }
        goto block_0046D914;
    }
block_0046D914:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D914U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D914U);
        }
        {
            r3 = r11 | 0x80000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D918U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046D924U + 0x5F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D91CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D920U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D928U, address);
            }
        }
        goto block_0046D92C;
    }
block_0046D92C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D92CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D92CU);
        }
        {
            const uint32_t updatedAddress = 0x0046D934U + 0x5E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D92CU, address);
            }
            r0 = value;
        }
        {
            r1 = Oot3dAotLsl(r12, 2U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046D938U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046D938U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046D938;
    }
block_0046D938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D938U);
        }
        {
        }
        {
        }
        goto block_0046D950;
    }
block_0046D944:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D944U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D944U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t operand = 0x00000001U;
            r12 = r12 + operand;
        }
        if (!(flags.Z())) { goto block_0046D95C; }
        goto block_0046D950;
    }
block_0046D950:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D950U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D950U);
        }
        {
            r11 = r7;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 4U);
            r2 = r8 + operand;
        }
        {
            r12 = 0x00000001U;
        }
        goto block_0046D95C;
    }
block_0046D95C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D95CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D95CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x344U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D95CU, address);
            }
            r7 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        goto block_0046D978;
    }
block_0046D968:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D968U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D968U);
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r0, 1U, r1, flags.C());
            r0 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        if (flags.Z()) {
            r0 = r6 & ~(0x0000001FU);
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00000020U;
            r6 = r0 + operand;
        }
        goto block_0046D978;
    }
block_0046D978:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D978U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D978U);
        }
        {
            r1 = r6 & 0x0000001FU;
        }
        {
            r0 = Oot3dAotLsr(r6, 5U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x348U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D984U, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r10, 0U, r1, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046D998; }
        goto block_0046D990;
    }
block_0046D990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D990U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, r6, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0046D968; }
        goto block_0046D998;
    }
block_0046D998:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D998U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D998U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, r6, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0046D8E8; }
        goto block_0046D9A0;
    }
block_0046D9A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D9A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D9A0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046D9E0; }
        goto block_0046D9A8;
    }
block_0046D9A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D9A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D9A8U);
        }
        {
            const uint32_t updatedAddress = 0x0046D9B0U - 0x85CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D9A8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D9ACU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D9B0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046D9D4; }
        goto block_0046D9BC;
    }
block_0046D9BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D9BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D9BCU);
        }
        {
            r3 = r11 | 0x80000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D9C0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046D9CCU + 0x548U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D9C4U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046D9C8U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046D9D0U, address);
            }
        }
        goto block_0046D9D4;
    }
block_0046D9D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D9D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D9D4U);
        }
        {
            const uint32_t updatedAddress = 0x0046D9DCU + 0x53CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D9D4U, address);
            }
            r0 = value;
        }
        {
            r1 = Oot3dAotLsl(r12, 2U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046D9E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046D9E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046D9E0;
    }
block_0046D9E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D9E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D9E0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D9E0U, address);
            }
            r8 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (flags.Z()) { goto block_0046DB64; }
        goto block_0046D9EC;
    }
block_0046D9EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046D9ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046D9ECU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D9ECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x1B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D9F4U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046D9FCU, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046DB64; }
        goto block_0046DA08;
    }
block_0046DA08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DA08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DA08U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            r11 = r2;
        }
        {
            r12 = r2;
        }
        {
            r6 = r2;
        }
        {
            r10 = 0x00000001U;
        }
        if (!(flags.Z())) { goto block_0046DA5C; }
        goto block_0046DA24;
    }
block_0046DA24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DA24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DA24U);
        }
        {
            r0 = Oot3dAotLsr(r6, 5U);
        }
        {
            r1 = r6 & 0x0000001FU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DA30U, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r0, 1U, r1, flags.C());
            r0 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        if (flags.Z()) {
            r0 = r6 & ~(0x0000001FU);
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00000020U;
            r6 = r0 + operand;
        }
        {
            r1 = r6 & 0x0000001FU;
        }
        {
            r0 = Oot3dAotLsr(r6, 5U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DA50U, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r10, 0U, r1, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046DA24; }
        goto block_0046DA5C;
    }
block_0046DA5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DA5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DA5CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DA5CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046DB64; }
        goto block_0046DA68;
    }
block_0046DA68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DA68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DA68U);
        }
        {
            const uint32_t updatedAddress = 0x0046DA70U - 0x918U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DA68U, address);
            }
            r9 = value;
        }
        goto block_0046DA6C;
    }
block_0046DA6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DA6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DA6CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 2U);
            r0 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r0 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DA74U, address);
            }
            r7 = value;
        }
        if (!(flags.Z())) {
            const uint32_t operand = r11;
            r0 = r7 - operand;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r12, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046DAC8; }
        goto block_0046DA84;
    }
block_0046DA84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DA84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DA84U);
        }
        {
            const uint32_t updatedAddress = 0x0046DA8CU - 0x938U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DA84U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DA88U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DA8CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046DAB0; }
        goto block_0046DA98;
    }
block_0046DA98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DA98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DA98U);
        }
        {
            r3 = r11 | 0x80000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046DA9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046DAA8U + 0x474U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DAA0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046DAA4U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DAACU, address);
            }
        }
        goto block_0046DAB0;
    }
block_0046DAB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DAB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DAB0U);
        }
        {
            const uint32_t updatedAddress = 0x0046DAB8U + 0x468U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DAB0U, address);
            }
            r0 = value;
        }
        {
            r1 = Oot3dAotLsl(r12, 2U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046DABCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046DABCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046DABC;
    }
block_0046DABC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DABCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DABCU);
        }
        {
        }
        {
        }
        goto block_0046DAD4;
    }
block_0046DAC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DAC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DAC8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t operand = 0x00000001U;
            r12 = r12 + operand;
        }
        if (!(flags.Z())) { goto block_0046DAE0; }
        goto block_0046DAD4;
    }
block_0046DAD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DAD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DAD4U);
        }
        {
            r11 = r7;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 4U);
            r2 = r8 + operand;
        }
        {
            r12 = 0x00000001U;
        }
        goto block_0046DAE0;
    }
block_0046DAE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DAE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DAE0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DAE0U, address);
            }
            r7 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        goto block_0046DAFC;
    }
block_0046DAEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DAECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DAECU);
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r0, 1U, r1, flags.C());
            r0 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        if (flags.Z()) {
            r0 = r6 & ~(0x0000001FU);
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00000020U;
            r6 = r0 + operand;
        }
        goto block_0046DAFC;
    }
block_0046DAFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DAFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DAFCU);
        }
        {
            r1 = r6 & 0x0000001FU;
        }
        {
            r0 = Oot3dAotLsr(r6, 5U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DB08U, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r10, 0U, r1, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046DB1C; }
        goto block_0046DB14;
    }
block_0046DB14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DB14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DB14U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, r6, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0046DAEC; }
        goto block_0046DB1C;
    }
block_0046DB1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DB1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DB1CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, r6, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0046DA6C; }
        goto block_0046DB24;
    }
block_0046DB24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DB24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DB24U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (flags.Z()) { goto block_0046DB64; }
        goto block_0046DB2C;
    }
block_0046DB2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DB2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DB2CU);
        }
        {
            const uint32_t updatedAddress = 0x0046DB34U - 0x9E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DB2CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DB30U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DB34U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046DB58; }
        goto block_0046DB40;
    }
block_0046DB40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DB40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DB40U);
        }
        {
            r3 = r11 | 0x80000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046DB44U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046DB50U + 0x3CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DB48U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046DB4CU, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DB54U, address);
            }
        }
        goto block_0046DB58;
    }
block_0046DB58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DB58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DB58U);
        }
        {
            const uint32_t updatedAddress = 0x0046DB60U + 0x3C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DB58U, address);
            }
            r0 = value;
        }
        {
            r1 = Oot3dAotLsl(r12, 2U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046DB64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046DB64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046DB64;
    }
block_0046DB64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DB64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DB64U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1B4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DB68U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1B8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DB6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DB70U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x348U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DB74U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x34CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DB78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x350U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DB7CU, address);
            }
        }
        goto block_0046DB80;
    }
block_0046DB80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DB80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DB80U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DB80U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0046DB8CU + 920U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DB84U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t value = r0 & 0x00000400U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000400U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046DD50; }
        goto block_0046DB90;
    }
block_0046DB90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DB90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DB90U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DB90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DB94U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046DD50; }
        goto block_0046DBA0;
    }
block_0046DBA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DBA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DBA0U);
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r0 + 460U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DBA4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x54U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DBA8U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046DBACU, 0xEEB40A4AU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[20],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            const uint32_t address = r5 + 76U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DBB4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) {
            const uint32_t address = r5 + 80U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DBB8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (flags.Z()) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046DBBCU, 0x0E700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (!(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046DBC0U, 0x1EF10A40U};
            frame.Guest.vfp[1] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t address = r5 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DBCCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        if (!(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046DBD0U, 0x1EB41A4AU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[2], frame.Guest.vfp[20],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        if (!(flags.Z())) {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_0046DBF0; }
        goto block_0046DBDC;
    }
block_0046DBDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DBDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DBDCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DBDCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t address = 0x0046DBECU + 828U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DBE4U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x0046DBF0U + 828U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DBE8U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046DBECU, 0xEE010A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        goto block_0046DBF0;
    }
block_0046DBF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DBF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DBF0U);
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            r1 = r0 & ~(0x80000000U);
            Oot3dAotSetLogicalFlags(flags, r1, (0x80000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r1 = Oot3dAotLsl(r0, 1U);
        }
        {
            r2 = Oot3dAotLsl(r0, 9U);
        }
        if (!(flags.Z())) {
            r1 = Oot3dAotLsr(r1, 24U);
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000040U;
            r1 = r1 - operand;
        }
        {
            r2 = Oot3dAotLsr(r2, 16U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046DC0CU, 0xEEB40A4AU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[20],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            r0 = Oot3dAotLsr(r0, 31U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            r1 = r2 | Oot3dAotLsl(r1, 16U);
        }
        if ((flags.N()) != (flags.V())) {
            r1 = Oot3dAotLsl(r0, 23U);
        }
        if ((flags.N()) == (flags.V())) {
            r1 = r1 | Oot3dAotLsl(r0, 23U);
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046DC60; }
        goto block_0046DC30;
    }
block_0046DC30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DC30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DC30U);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            r2 = r0 & ~(0x80000000U);
            Oot3dAotSetLogicalFlags(flags, r2, (0x80000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r2 = Oot3dAotLsl(r0, 1U);
        }
        {
            r3 = Oot3dAotLsl(r0, 9U);
        }
        if (!(flags.Z())) {
            r2 = Oot3dAotLsr(r2, 24U);
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000040U;
            r2 = r2 - operand;
        }
        {
            r0 = Oot3dAotLsr(r0, 31U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            r3 = Oot3dAotLsr(r3, 16U);
        }
        if ((flags.N()) != (flags.V())) {
            r0 = Oot3dAotLsl(r0, 23U);
        }
        if ((flags.N()) == (flags.V())) {
            r2 = r3 | Oot3dAotLsl(r2, 16U);
        }
        if ((flags.N()) == (flags.V())) {
            r0 = r2 | Oot3dAotLsl(r0, 23U);
        }
        goto block_0046DC60;
    }
block_0046DC60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DC60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DC60U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x40DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DC60U, address);
            }
            r2 = value;
        }
        {
            r2 = r2 | 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x40DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046DC68U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DC6CU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046DCB0; }
        goto block_0046DC78;
    }
block_0046DC78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DC78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DC78U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x510U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DC78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DC7CU, address);
            }
            r1 = value;
        }
        {
            r1 = r1 | 0x00800000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x7A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DC84U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DC88U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 | 0x00080000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DC90U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046DC9CU - 0xB34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DC94U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x510U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DC98U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DC9CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r1 + operand;
        }
        {
            r1 = ~(r2);
        }
        {
            const uint32_t updatedAddress = r3 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DCA8U, address);
            }
        }
        goto block_0046DCD8;
    }
block_0046DCB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DCB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DCB0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x510U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DCB0U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046DCD8; }
        goto block_0046DCBC;
    }
block_0046DCBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DCBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DCBCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x510U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DCBCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DCC0U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 | 0x00800000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x7A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DCC8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DCCCU, address);
            }
            r1 = value;
        }
        {
            r1 = r1 | 0x00080000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DCD4U, address);
            }
        }
        goto block_0046DCD8;
    }
block_0046DCD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DCD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DCD8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x40EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DCD8U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 | 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x40EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DCE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DCE4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046DD28; }
        goto block_0046DCF0;
    }
block_0046DCF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DCF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DCF0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x514U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DCF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DCF4U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x01000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x7A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DCFCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD00U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00080000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DD08U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046DD14U - 0xBACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x514U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD10U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD14U, address);
            }
            r0 = value;
        }
        {
            r1 = ~(r1);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DD20U, address);
            }
        }
        goto block_0046DD50;
    }
block_0046DD28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DD28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DD28U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x514U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD28U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046DD50; }
        goto block_0046DD34;
    }
block_0046DD34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DD34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DD34U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x514U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DD34U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD38U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x01000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x7A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DD40U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD44U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00080000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DD4CU, address);
            }
        }
        goto block_0046DD50;
    }
block_0046DD50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DD50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DD50U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD50U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000020U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046DDD8; }
        goto block_0046DD5C;
    }
block_0046DD5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DD5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DD5CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x5F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD5CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000007U;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r0, 0U, 0U, flags.C());
            r0 = r1 & ~(shifted.Value);
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) { goto block_0046DDA8; }
        goto block_0046DD6C;
    }
block_0046DD6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DD6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DD6CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xDF4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD6CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x600U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD70U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        {
            const uint32_t updatedAddress = 0x0046DD80U - 0xC18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD78U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD7CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x158U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DD84U, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x7B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD88U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            r0 = r0 & ~(0x00080000U);
        }
        if (!(flags.Z())) { goto block_0046DDA4; }
        goto block_0046DD94;
    }
block_0046DD94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DD94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DD94U);
        }
        {
            r1 = ~(r1);
        }
        {
            const uint32_t updatedAddress = r0 + 0x158U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DD98U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DD9CU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00080000U;
        }
        goto block_0046DDA4;
    }
block_0046DDA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DDA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DDA4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7B0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046DDA4U, address);
            }
        }
        goto block_0046DDA8;
    }
block_0046DDA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DDA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DDA8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x560U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DDA8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046DDD8; }
        goto block_0046DDB4;
    }
block_0046DDB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DDB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DDB4U);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_0046DDB8;
    }
block_0046DDB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DDB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DDB8U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r1 = operand - r0;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9A0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DDC0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_0046DDD8; }
        goto block_0046DDCC;
    }
block_0046DDCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DDCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DDCCU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046DDB8; }
        goto block_0046DDD8;
    }
block_0046DDD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DDD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DDD8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DDD8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046DDE4U + 0x14CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DDDCU, address);
            }
            r14 = value;
        }
        {
            const uint32_t value = r0 & 0x00000010U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046E004; }
        goto block_0046DDE8;
    }
block_0046DDE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DDE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DDE8U);
        }
        {
            const uint32_t updatedAddress = 0x0046DDF0U + 0x118U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DDE8U, address);
            }
            r9 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DDF0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046DED4; }
        goto block_0046DDFC;
    }
block_0046DDFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DDFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DDFCU);
        }
        {
            const uint32_t operand = 0x00000088U;
            r1 = r9 - operand;
        }
        {
            const uint32_t updatedAddress = 0x0046DE08U - 0xCB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE00U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE04U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046DE10U - 0xCBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE08U, address);
            }
            r11 = value;
        }
        {
            r10 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x810U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DE10U, address);
            }
        }
        {
            const uint32_t operand = 0x00000300U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000F6U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x820U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DE1CU, address);
            }
        }
        goto block_0046DE20;
    }
block_0046DE20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DE20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DE20U);
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE20U, address);
            }
            r3 = value;
        }
        {
            r2 = r3 & 0x0000001FU;
        }
        {
            r1 = Oot3dAotAsr(r3, 5U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE30U, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r10, 0U, r2, flags.C());
            const uint32_t value = r1 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046DEC4; }
        goto block_0046DE3C;
    }
block_0046DE3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DE3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DE3CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x810U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE3CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x820U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE40U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + r12;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE50U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x000000B4U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r2 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE64U, address);
            }
            r6 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE68U, address);
            }
            r12 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r6, r12, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046DEA8; }
        goto block_0046DE74;
    }
block_0046DE74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DE74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DE74U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE74U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE78U, address);
            }
            r8 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, r8, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046DEA0; }
        goto block_0046DE84;
    }
block_0046DE84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DE84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DE84U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0046DE84U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE88U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r14 + Oot3dAotLsl(r6, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DE8CU, address);
            }
            r6 = value;
        }
        {
            r3 = r6 | Oot3dAotLsl(r3, 16U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046DE94U, address);
            }
            r12 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046DE9CU, address);
            }
        }
        goto block_0046DEA0;
    }
block_0046DEA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DEA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DEA0U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DEA0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DEA4U, address);
            }
        }
        goto block_0046DEA8;
    }
block_0046DEA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DEA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DEA8U);
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DEA8U, address);
            }
            r1 = value;
        }
        {
            r2 = Oot3dAotAsr(r1, 5U);
        }
        {
            r1 = r1 & 0x0000001FU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DEB8U, address);
            }
            r3 = value;
        }
        {
            r1 = r3 & ~(Oot3dAotShiftRegister(r10, 0U, r1, false).Value);
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DEC0U, address);
            }
        }
        goto block_0046DEC4;
    }
block_0046DEC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DEC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DEC4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DEC8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) { goto block_0046DE20; }
        goto block_0046DED4;
    }
block_0046DED4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DED4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DED4U);
        }
        {
            const uint32_t updatedAddress = 0x0046DEDCU + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DED4U, address);
            }
            r9 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DEDCU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046E004; }
        goto block_0046DEE8;
    }
block_0046DEE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DEE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DEE8U);
        }
        {
            const uint32_t operand = 0x00000070U;
            r1 = r9 - operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DEECU, address);
            }
            r1 = value;
        }
        goto block_0046DF34;
    }
block_0046DF34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DF34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DF34U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x810U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DF34U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046DF40U - 0xDE8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DF38U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046DF44U - 0xDF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DF3CU, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = 0x00000300U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000F6U;
            r1 = r1 + operand;
        }
        {
            r10 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x81CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DF4CU, address);
            }
        }
        goto block_0046DF50;
    }
block_0046DF50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DF50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DF50U);
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DF50U, address);
            }
            r3 = value;
        }
        {
            r2 = r3 & 0x0000001FU;
        }
        {
            r1 = Oot3dAotAsr(r3, 5U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DF60U, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r10, 0U, r2, flags.C());
            const uint32_t value = r1 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046DFF4; }
        goto block_0046DF6C;
    }
block_0046DF6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DF6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DF6CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x810U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DF6CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DF70U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + r12;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DF80U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x000000B4U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r2 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DF94U, address);
            }
            r6 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DF98U, address);
            }
            r12 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r6, r12, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046DFD8; }
        goto block_0046DFA4;
    }
block_0046DFA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DFA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DFA4U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DFA4U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DFA8U, address);
            }
            r8 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, r8, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046DFD0; }
        goto block_0046DFB4;
    }
block_0046DFB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DFB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DFB4U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0046DFB4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DFB8U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r14 + Oot3dAotLsl(r6, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DFBCU, address);
            }
            r6 = value;
        }
        {
            r3 = r6 | Oot3dAotLsl(r3, 16U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046DFC4U, address);
            }
            r12 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046DFCCU, address);
            }
        }
        goto block_0046DFD0;
    }
block_0046DFD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DFD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DFD0U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DFD0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DFD4U, address);
            }
        }
        goto block_0046DFD8;
    }
block_0046DFD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DFD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DFD8U);
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DFD8U, address);
            }
            r1 = value;
        }
        {
            r2 = Oot3dAotAsr(r1, 5U);
        }
        {
            r1 = r1 & 0x0000001FU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DFE8U, address);
            }
            r3 = value;
        }
        {
            r1 = r3 & ~(Oot3dAotShiftRegister(r10, 0U, r1, false).Value);
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046DFF0U, address);
            }
        }
        goto block_0046DFF4;
    }
block_0046DFF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046DFF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046DFF4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046DFF8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_0046DF50; }
        goto block_0046E004;
    }
block_0046E004:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E004U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E004U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E004U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046E0FC; }
        goto block_0046E010;
    }
block_0046E010:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E010U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E010U);
        }
        {
            const uint32_t updatedAddress = 0x0046E018U - 0x108U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E010U, address);
            }
            r9 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E018U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046E0FC; }
        goto block_0046E024;
    }
block_0046E024:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E024U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E024U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r1 = r9 - operand;
        }
        {
            const uint32_t updatedAddress = 0x0046E030U - 0xED8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E028U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E02CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046E038U - 0xEE4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E030U, address);
            }
            r11 = value;
        }
        {
            r10 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x810U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E038U, address);
            }
        }
        {
            const uint32_t operand = 0x00000300U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000F6U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x818U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E044U, address);
            }
        }
        goto block_0046E048;
    }
block_0046E048:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E048U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E048U);
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E048U, address);
            }
            r3 = value;
        }
        {
            r2 = r3 & 0x0000001FU;
        }
        {
            r1 = Oot3dAotAsr(r3, 5U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E058U, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r10, 0U, r2, flags.C());
            const uint32_t value = r1 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046E0EC; }
        goto block_0046E064;
    }
block_0046E064:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E064U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E064U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x810U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E064U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x818U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E068U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + r12;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E078U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x000000B4U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r2 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E08CU, address);
            }
            r6 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E090U, address);
            }
            r12 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r6, r12, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046E0D0; }
        goto block_0046E09C;
    }
block_0046E09C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E09CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E09CU);
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E09CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E0A0U, address);
            }
            r8 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, r8, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046E0C8; }
        goto block_0046E0AC;
    }
block_0046E0AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E0ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E0ACU);
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0046E0ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E0B0U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r14 + Oot3dAotLsl(r6, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E0B4U, address);
            }
            r6 = value;
        }
        {
            r3 = r6 | Oot3dAotLsl(r3, 16U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046E0BCU, address);
            }
            r12 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046E0C4U, address);
            }
        }
        goto block_0046E0C8;
    }
block_0046E0C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E0C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E0C8U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E0C8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E0CCU, address);
            }
        }
        goto block_0046E0D0;
    }
block_0046E0D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E0D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E0D0U);
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E0D0U, address);
            }
            r1 = value;
        }
        {
            r2 = Oot3dAotAsr(r1, 5U);
        }
        {
            r1 = r1 & 0x0000001FU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E0E0U, address);
            }
            r3 = value;
        }
        {
            r1 = r3 & ~(Oot3dAotShiftRegister(r10, 0U, r1, false).Value);
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E0E8U, address);
            }
        }
        goto block_0046E0EC;
    }
block_0046E0EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E0ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E0ECU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r9 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E0F0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_0046E048; }
        goto block_0046E0FC;
    }
block_0046E0FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E0FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E0FCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E0FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000020U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046E1F4; }
        goto block_0046E108;
    }
block_0046E108:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E108U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E108U);
        }
        {
            const uint32_t updatedAddress = 0x0046E110U - 0x204U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E108U, address);
            }
            r8 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r8 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E110U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046E1F4; }
        goto block_0046E11C;
    }
block_0046E11C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E11CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E11CU);
        }
        {
            const uint32_t operand = 0x000000A0U;
            r1 = r8 - operand;
        }
        {
            const uint32_t updatedAddress = 0x0046E128U - 0xFD0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E120U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E124U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046E130U - 0xFDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E128U, address);
            }
            r11 = value;
        }
        {
            r10 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x810U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E130U, address);
            }
        }
        {
            const uint32_t operand = 0x00000300U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000000F6U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x814U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E13CU, address);
            }
        }
        goto block_0046E140;
    }
block_0046E140:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E140U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E140U);
        }
        {
            const uint32_t updatedAddress = r8 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E140U, address);
            }
            r3 = value;
        }
        {
            r2 = r3 & 0x0000001FU;
        }
        {
            r1 = Oot3dAotAsr(r3, 5U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E150U, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftRegister(
                r10, 0U, r2, flags.C());
            const uint32_t value = r1 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046E1E4; }
        goto block_0046E15C;
    }
block_0046E15C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E15CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E15CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x810U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E15CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x814U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E160U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + r12;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E170U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x000000B4U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r2 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E184U, address);
            }
            r6 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E188U, address);
            }
            r12 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r6, r12, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046E1C8; }
        goto block_0046E194;
    }
block_0046E194:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E194U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E194U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E194U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E198U, address);
            }
            r9 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, r9, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046E1C0; }
        goto block_0046E1A4;
    }
block_0046E1A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E1A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E1A4U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0046E1A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E1A8U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r14 + Oot3dAotLsl(r6, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E1ACU, address);
            }
            r6 = value;
        }
        {
            r3 = r6 | Oot3dAotLsl(r3, 16U);
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046E1B4U, address);
            }
            r12 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046E1BCU, address);
            }
        }
        goto block_0046E1C0;
    }
block_0046E1C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E1C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E1C0U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E1C0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E1C4U, address);
            }
        }
        goto block_0046E1C8;
    }
block_0046E1C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E1C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E1C8U);
        }
        {
            const uint32_t updatedAddress = r8 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E1C8U, address);
            }
            r1 = value;
        }
        {
            r2 = Oot3dAotAsr(r1, 5U);
        }
        {
            r1 = r1 & 0x0000001FU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E1D8U, address);
            }
            r3 = value;
        }
        {
            r1 = r3 & ~(Oot3dAotShiftRegister(r10, 0U, r1, false).Value);
        }
        {
            const uint32_t updatedAddress = r2 + 0x7A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E1E0U, address);
            }
        }
        goto block_0046E1E4;
    }
block_0046E1E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E1E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E1E4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E1E8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000BDU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_0046E140; }
        goto block_0046E1F4;
    }
block_0046E1F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E1F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E1F4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E1F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000040U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046F768; }
        goto block_0046E200;
    }
block_0046E200:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E200U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E200U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x560U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E200U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0046E20CU + 844U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E204U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t address = 0x0046E210U + 844U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E208U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046E914; }
        goto block_0046E214;
    }
block_0046E214:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E214U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E214U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E214U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046E220U + 0x340U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E218U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E21CU, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046E914; }
        goto block_0046E228;
    }
block_0046E228:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E228U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E228U);
        }
        {
            frame.Guest.vfp[17] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[23];
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[20];
        }
        {
            const uint32_t updatedAddress = 0x0046E23CU + 0x32CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E234U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046E240U + 0x32CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E238U, address);
            }
            r9 = value;
        }
        {
            const uint32_t address = 0x0046E244U + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E23CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r7 = 0x00000000U;
        }
        goto block_0046E244;
    }
block_0046E244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E244U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x98CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E244U, address);
            }
            r0 = value;
        }
        {
            r0 = Oot3dAotShiftRegister(r0, 1U, r7, false).Value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046E484; }
        goto block_0046E254;
    }
block_0046E254:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E254U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E254U);
        }
        {
            const uint32_t updatedAddress = 0x0046E25CU + 0x314U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E254U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x790U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E258U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + Oot3dAotLsl(r7, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E25CU, address);
            }
            r1 = value;
        }
        {
            r0 = Oot3dAotShiftRegister(r0, 1U, r1, false).Value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046E484; }
        goto block_0046E26C;
    }
block_0046E26C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E26CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E26CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x974U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E270U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r5 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E27CU, address);
            }
            r11 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r11, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0046E490; }
        goto block_0046E288;
    }
block_0046E288:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E288U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E288U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046E28CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1210_002D1210(frame, context, state, 0x002D1210U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046E28CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046E28C;
    }
block_0046E28C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E28CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E28CU);
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r0, 0U, 0U, flags.C());
            r6 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r6, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_0046E490; }
        goto block_0046E298;
    }
block_0046E298:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E298U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E298U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 2U);
            r10 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E29CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r11, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r10 + 0x190U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E2A4U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_0046E314; }
        goto block_0046E2AC;
    }
block_0046E2AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E2ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E2ACU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046E484; }
        goto block_0046E2B4;
    }
block_0046E2B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E2B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E2B4U);
        }
        {
            const uint32_t updatedAddress = 0x0046E2BCU + 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E2B4U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046E2C0U + 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E2B8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E2BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E2C0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046E2F0; }
        goto block_0046E2CC;
    }
block_0046E2CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E2CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E2CCU);
        }
        {
            const uint32_t updatedAddress = 0x0046E2D4U + 0x2A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E2CCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0x214U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E2D0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + Oot3dAotLsl(r7, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E2D4U, address);
            }
            r2 = value;
        }
        {
            r1 = r1 | Oot3dAotLsl(r2, 8U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E2DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046E2E8U + 0x298U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E2E0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E2E4U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E2ECU, address);
            }
        }
        goto block_0046E2F0;
    }
block_0046E2F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E2F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E2F0U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x214U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E2F0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E2F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x190U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E2FCU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x000001C8U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046E308U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046E308U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046E308;
    }
block_0046E308:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E308U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E308U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r10 + 0x190U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E30CU, address);
            }
        }
        goto block_0046E484;
    }
block_0046E314:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E314U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E314U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000000U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r10 + 0x190U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E31CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x10CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0046E320U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E324U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046E434; }
        goto block_0046E330;
    }
block_0046E330:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E330U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E330U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E330U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046E368; }
        goto block_0046E33C;
    }
block_0046E33C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E33CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E33CU);
        }
        {
            const uint32_t updatedAddress = 0x0046E344U + 0x240U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E33CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E340U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046E364; }
        goto block_0046E350;
    }
block_0046E350:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E350U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E350U);
        }
        {
            r3 = 0x00000400U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000100U;
        }
        {
            r0 = 0x00010000U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0046E364U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r12, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046E364U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046E364;
    }
block_0046E364:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E364U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E364U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E364U, address);
            }
        }
        goto block_0046E368;
    }
block_0046E368:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E368U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E368U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            r3 = 0x000000FFU;
        }
        goto block_0046E370;
    }
block_0046E370:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E370U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E370U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r6 + operand;
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E374U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E37CU, 0xEEB40AE9U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046E394; }
        goto block_0046E388;
    }
block_0046E388:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E388U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E388U);
        }
        {
            r2 = Oot3dAotLsl(r2, 1U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, Oot3dAotLsr(r2, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046E39C; }
        goto block_0046E394;
    }
block_0046E394:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E394U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E394U);
        }
        {
            r2 = 0x00000000U;
        }
        goto block_0046E3B4;
    }
block_0046E39C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E39CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E39CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E39CU, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r9, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E3A8U, 0xBEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if ((flags.N()) == (flags.V())) {
            r2 = r8;
        }
        if ((flags.N()) != (flags.V())) {
            r2 = frame.Guest.vfp[0];
        }
        goto block_0046E3B4;
    }
block_0046E3B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E3B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E3B4U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E3B4U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046E3BCU, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E3C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E3C8U, 0xEEB40A69U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z())) {
            r1 = Oot3dAotLsl(r1, 1U);
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r3, Oot3dAotLsr(r1, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r1 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046E410; }
        goto block_0046E3E0;
    }
block_0046E3E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E3E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E3E0U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E3E0U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E3E4U, 0xEEB40AE9U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E3ECU, 0x3EB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        if (flags.C()) {
            r1 = 0x00000000U;
        }
        if (!(flags.C())) {
            r1 = 0x00000800U;
        }
        {
            r12 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x45000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E404U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r12 = frame.Guest.vfp[0];
        }
        {
            r1 = r1 | r12;
        }
        goto block_0046E410;
    }
block_0046E410:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E410U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E410U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E410U, address);
            }
            r12 = value;
        }
        {
            r1 = r2 | Oot3dAotLsl(r1, 12U);
        }
        {
            const uint32_t updatedAddress = r12 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E418U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000100U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046E370; }
        goto block_0046E428;
    }
block_0046E428:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E428U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E428U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E428U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E430U, address);
            }
        }
        goto block_0046E434;
    }
block_0046E434:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E434U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E434U);
        }
        {
            const uint32_t updatedAddress = 0x0046E43CU + 0x138U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E434U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046E440U + 0x138U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E438U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E43CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E440U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046E46C; }
        goto block_0046E44C;
    }
block_0046E44C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E44CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E44CU);
        }
        {
            const uint32_t updatedAddress = 0x0046E454U + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E44CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r2 + Oot3dAotLsl(r7, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E450U, address);
            }
            r2 = value;
        }
        {
            r2 = Oot3dAotLsl(r2, 8U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046E458U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046E464U + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E45CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046E460U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E468U, address);
            }
        }
        goto block_0046E46C;
    }
block_0046E46C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E46CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E46CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E46CU, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000100U;
        }
        {
            r0 = 0x000001C8U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046E47CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046E47CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046E47C;
    }
block_0046E47C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E47CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E47CU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E480U, address);
            }
        }
        goto block_0046E484;
    }
block_0046E484:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E484U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E484U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r7 = r7 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046E244; }
        goto block_0046E490;
    }
block_0046E490:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E490U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E490U);
        }
        {
            const uint32_t updatedAddress = 0x0046E498U + 0xDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E490U, address);
            }
            r11 = value;
        }
        {
            r7 = 0x00000000U;
        }
        goto block_0046E498;
    }
block_0046E498:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E498U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E498U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 3U);
            r0 = operand - r7;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 4U);
            r10 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x9A0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E4A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (flags.Z()) { goto block_0046E908; }
        goto block_0046E4AC;
    }
block_0046E4AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E4ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E4ACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x98CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E4ACU, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r0, 0U, 25U, flags.C());
            r0 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xAU));
        }
        if (!(flags.N())) { goto block_0046E6F8; }
        goto block_0046E4B8;
    }
block_0046E4B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E4B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E4B8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x790U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E4B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r7 + operand;
        }
        {
            r0 = Oot3dAotShiftRegister(r0, 1U, r1, false).Value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0046E6F8; }
        goto block_0046E4CC;
    }
block_0046E4CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E4CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E4CCU);
        }
        {
            const uint32_t updatedAddress = r10 + 0xA00U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E4CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E4D4U, address);
            }
            r9 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046E4DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1210_002D1210(frame, context, state, 0x002D1210U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046E4DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046E4DC;
    }
block_0046E4DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E4DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E4DCU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 2U);
            r8 = r5 + operand;
        }
        {
            r6 = r0;
        }
        {
            const uint32_t updatedAddress = r8 + 0x124U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E4E4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r9, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r8 + 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E4ECU, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_0046E588; }
        goto block_0046E4F4;
    }
block_0046E4F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E4F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E4F4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046E6F8; }
        goto block_0046E4FC;
    }
block_0046E4FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E4FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E4FCU);
        }
        {
            const uint32_t updatedAddress = 0x0046E504U + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E4FCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E500U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E504U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046E534; }
        goto block_0046E510;
    }
block_0046E510:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E510U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E510U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E510U, address);
            }
            r2 = value;
        }
        {
            r1 = Oot3dAotLsl(r7, 8U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r1 + operand;
        }
        {
            r1 = r1 | r2;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E520U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046E52CU + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E524U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E528U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E530U, address);
            }
        }
        goto block_0046E534;
    }
block_0046E534:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E534U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E534U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E534U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E538U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E540U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x000001C8U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046E54CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046E54CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046E54C;
    }
block_0046E54C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E54CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E54CU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r8 + 0x1A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E550U, address);
            }
        }
        goto block_0046E6F8;
    }
block_0046E588:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E588U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E588U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000000U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r8 + 0x1A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E590U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x124U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0046E594U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E598U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046E6B0; }
        goto block_0046E5A4;
    }
block_0046E5A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E5A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E5A4U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E5A4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046E5DC; }
        goto block_0046E5B0;
    }
block_0046E5B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E5B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E5B0U);
        }
        {
            const uint32_t updatedAddress = 0x0046E5B8U - 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E5B0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E5B4U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046E5D8; }
        goto block_0046E5C4;
    }
block_0046E5C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E5C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E5C4U);
        }
        {
            r3 = 0x00000400U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000100U;
        }
        {
            r0 = 0x00010000U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0046E5D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r12, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046E5D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046E5D8;
    }
block_0046E5D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E5D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E5D8U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E5D8U, address);
            }
        }
        goto block_0046E5DC;
    }
block_0046E5DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E5DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E5DCU);
        }
        {
            const uint32_t updatedAddress = 0x0046E5E4U - 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E5DCU, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046E5E8U - 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E5E0U, address);
            }
            r9 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r3 = 0x000000FFU;
        }
        goto block_0046E5EC;
    }
block_0046E5EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E5ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E5ECU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r6 + operand;
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E5F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E5F8U, 0xEEB40AE9U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046E610; }
        goto block_0046E604;
    }
block_0046E604:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E604U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E604U);
        }
        {
            r2 = Oot3dAotLsl(r2, 1U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, Oot3dAotLsr(r2, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046E618; }
        goto block_0046E610;
    }
block_0046E610:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E610U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E610U);
        }
        {
            r2 = 0x00000000U;
        }
        goto block_0046E630;
    }
block_0046E618:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E618U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E618U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E618U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r9, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E624U, 0xBEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if ((flags.N()) == (flags.V())) {
            r2 = r8;
        }
        if ((flags.N()) != (flags.V())) {
            r2 = frame.Guest.vfp[0];
        }
        goto block_0046E630;
    }
block_0046E630:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E630U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E630U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E630U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046E638U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E63CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E644U, 0xEEB40A69U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z())) {
            r0 = Oot3dAotLsl(r0, 1U);
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r3, Oot3dAotLsr(r0, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046E68C; }
        goto block_0046E65C;
    }
block_0046E65C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E65CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E65CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E65CU, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E660U, 0xEEB40AE9U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E668U, 0x3EB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        if (flags.C()) {
            r0 = 0x00000000U;
        }
        if (!(flags.C())) {
            r0 = 0x00000800U;
        }
        {
            r12 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x45000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E680U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r12 = frame.Guest.vfp[0];
        }
        {
            r0 = r0 | r12;
        }
        goto block_0046E68C;
    }
block_0046E68C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E68CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E68CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E68CU, address);
            }
            r12 = value;
        }
        {
            r0 = r2 | Oot3dAotLsl(r0, 12U);
        }
        {
            const uint32_t updatedAddress = r12 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E694U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000100U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046E5EC; }
        goto block_0046E6A4;
    }
block_0046E6A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E6A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E6A4U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E6A4U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E6ACU, address);
            }
        }
        goto block_0046E6B0;
    }
block_0046E6B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E6B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E6B0U);
        }
        {
            const uint32_t updatedAddress = 0x0046E6B8U - 0x140U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E6B0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E6B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E6B8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046E6E0; }
        goto block_0046E6C4;
    }
block_0046E6C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E6C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E6C4U);
        }
        {
            r1 = Oot3dAotLsl(r7, 8U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E6CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046E6D8U - 0x158U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E6D0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E6D4U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E6DCU, address);
            }
        }
        goto block_0046E6E0;
    }
block_0046E6E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E6E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E6E0U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E6E0U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000100U;
        }
        {
            r0 = 0x000001C8U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046E6F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046E6F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046E6F0;
    }
block_0046E6F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E6F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E6F0U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E6F4U, address);
            }
        }
        goto block_0046E6F8;
    }
block_0046E6F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E6F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E6F8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x790U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E6F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000018U;
            r1 = r7 + operand;
        }
        {
            r0 = Oot3dAotShiftRegister(r0, 1U, r1, false).Value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0046E908; }
        goto block_0046E70C;
    }
block_0046E70C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E70CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E70CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0xA0CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E70CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E714U, address);
            }
            r9 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046E71CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1210_002D1210(frame, context, state, 0x002D1210U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046E71CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046E71C;
    }
block_0046E71C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E71CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E71CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 2U);
            r8 = r5 + operand;
        }
        {
            r6 = r0;
        }
        {
            const uint32_t updatedAddress = r8 + 0x144U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E724U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r9, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r8 + 0x1C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E72CU, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_0046E798; }
        goto block_0046E734;
    }
block_0046E734:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E734U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E734U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046E908; }
        goto block_0046E73C;
    }
block_0046E73C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E73CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E73CU);
        }
        {
            const uint32_t updatedAddress = 0x0046E744U - 0x1CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E73CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E740U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E744U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046E774; }
        goto block_0046E750;
    }
block_0046E750:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E750U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E750U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x24CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E750U, address);
            }
            r2 = value;
        }
        {
            r1 = Oot3dAotLsl(r7, 8U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            r1 = r1 | r2;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E760U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046E76CU - 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E764U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E768U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E770U, address);
            }
        }
        goto block_0046E774;
    }
block_0046E774:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E774U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E774U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x24CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E774U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E778U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r8 + 0x1C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E780U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x000001C8U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046E78CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046E78CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046E78C;
    }
block_0046E78C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E78CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E78CU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r8 + 0x1C8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E790U, address);
            }
        }
        goto block_0046E908;
    }
block_0046E798:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E798U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E798U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000000U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r8 + 0x1C8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E7A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x144U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0046E7A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E7A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046E8C0; }
        goto block_0046E7B4;
    }
block_0046E7B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E7B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E7B4U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E7B4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046E7EC; }
        goto block_0046E7C0;
    }
block_0046E7C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E7C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E7C0U);
        }
        {
            const uint32_t updatedAddress = 0x0046E7C8U - 0x244U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E7C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E7C4U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046E7E8; }
        goto block_0046E7D4;
    }
block_0046E7D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E7D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E7D4U);
        }
        {
            r3 = 0x00000400U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000100U;
        }
        {
            r0 = 0x00010000U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0046E7E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r12, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046E7E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046E7E8;
    }
block_0046E7E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E7E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E7E8U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E7E8U, address);
            }
        }
        goto block_0046E7EC;
    }
block_0046E7EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E7ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E7ECU);
        }
        {
            const uint32_t updatedAddress = 0x0046E7F4U - 0x28CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E7ECU, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046E7F8U - 0x28CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E7F0U, address);
            }
            r9 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            r3 = 0x000000FFU;
        }
        goto block_0046E7FC;
    }
block_0046E7FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E7FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E7FCU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r6 + operand;
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E800U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E808U, 0xEEB40AE9U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046E820; }
        goto block_0046E814;
    }
block_0046E814:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E814U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E814U);
        }
        {
            r2 = Oot3dAotLsl(r2, 1U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, Oot3dAotLsr(r2, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046E828; }
        goto block_0046E820;
    }
block_0046E820:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E820U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E820U);
        }
        {
            r2 = 0x00000000U;
        }
        goto block_0046E840;
    }
block_0046E828:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E828U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E828U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E828U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r9, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E834U, 0xBEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if ((flags.N()) == (flags.V())) {
            r2 = r8;
        }
        if ((flags.N()) != (flags.V())) {
            r2 = frame.Guest.vfp[0];
        }
        goto block_0046E840;
    }
block_0046E840:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E840U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E840U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E840U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046E848U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E84CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E854U, 0xEEB40A69U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z())) {
            r1 = Oot3dAotLsl(r1, 1U);
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r3, Oot3dAotLsr(r1, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r1 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046E89C; }
        goto block_0046E86C;
    }
block_0046E86C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E86CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E86CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E86CU, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E870U, 0xEEB40AE9U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[19],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E878U, 0x3EB10A40U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        if (flags.C()) {
            r1 = 0x00000000U;
        }
        if (!(flags.C())) {
            r1 = 0x00000800U;
        }
        {
            r12 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x45000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046E890U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r12 = frame.Guest.vfp[0];
        }
        {
            r1 = r1 | r12;
        }
        goto block_0046E89C;
    }
block_0046E89C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E89CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E89CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E89CU, address);
            }
            r12 = value;
        }
        {
            r1 = r2 | Oot3dAotLsl(r1, 12U);
        }
        {
            const uint32_t updatedAddress = r12 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E8A4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000100U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046E7FC; }
        goto block_0046E8B4;
    }
block_0046E8B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E8B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E8B4U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E8B4U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E8BCU, address);
            }
        }
        goto block_0046E8C0;
    }
block_0046E8C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E8C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E8C0U);
        }
        {
            const uint32_t updatedAddress = 0x0046E8C8U - 0x350U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E8C0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E8C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E8C8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046E8F0; }
        goto block_0046E8D4;
    }
block_0046E8D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E8D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E8D4U);
        }
        {
            r1 = Oot3dAotLsl(r7, 8U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E8DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046E8E8U - 0x368U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E8E0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E8E4U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E8ECU, address);
            }
        }
        goto block_0046E8F0;
    }
block_0046E8F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E8F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E8F0U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x804U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E8F0U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000100U;
        }
        {
            r0 = 0x000001C8U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046E900U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046E900U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046E900;
    }
block_0046E900:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E900U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E900U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E904U, address);
            }
        }
        goto block_0046E908;
    }
block_0046E908:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E908U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E908U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r7 = r7 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046E498; }
        goto block_0046E914;
    }
block_0046E914:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E914U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E914U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xD8CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E914U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0046E920U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E918U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046F244; }
        goto block_0046E924;
    }
block_0046E924:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E924U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E924U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E924U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046E930U + 0x308U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E928U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E92CU, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046F244; }
        goto block_0046E938;
    }
block_0046E938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E938U);
        }
        {
            const uint32_t updatedAddress = 0x0046E940U + 0x2FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E938U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[23];
        }
        {
            const uint32_t updatedAddress = 0x0046E94CU - 0x3E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E944U, address);
            }
            r9 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E948U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E94CU, address);
            }
            r0 = value;
        }
        {
            r8 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0046E95CU + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E954U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0046E960U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E958U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r11 = r8;
        }
        {
            const uint32_t updatedAddress = r13 + 0x808U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E960U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x804U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E964U, address);
            }
        }
        goto block_0046E968;
    }
block_0046E968:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E968U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E968U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x564U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E96CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x00004000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00004000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0046EB9C; }
        goto block_0046E978;
    }
block_0046E978:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E978U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E978U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xD70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E97CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E984U, address);
            }
            r10 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046E98CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1210_002D1210(frame, context, state, 0x002D1210U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046E98CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046E98C;
    }
block_0046E98C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E98CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E98CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 2U);
            r7 = r5 + operand;
        }
        {
            r6 = r0;
        }
        {
            const uint32_t updatedAddress = r7 + 0x164U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E994U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r10, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r7 + 0x1E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E99CU, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_0046EA10; }
        goto block_0046E9A4;
    }
block_0046E9A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E9A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E9A4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046EB9C; }
        goto block_0046E9AC;
    }
block_0046E9AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E9ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E9ACU);
        }
        {
            const uint32_t updatedAddress = 0x0046E9B4U - 0x440U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E9ACU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046E9B8U - 0x440U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E9B0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E9B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E9B8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046E9EC; }
        goto block_0046E9C4;
    }
block_0046E9C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E9C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E9C4U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x26CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E9CCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + Oot3dAotLsl(r8, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E9D0U, address);
            }
            r2 = value;
        }
        {
            r1 = r1 | Oot3dAotLsl(r2, 8U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E9D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046E9E4U + 0x264U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E9DCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046E9E0U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046E9E8U, address);
            }
        }
        goto block_0046E9EC;
    }
block_0046E9EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046E9ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046E9ECU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x26CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E9ECU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x810U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E9F0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x1E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046E9F8U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x000000B0U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046EA04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046EA04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046EA04;
    }
block_0046EA04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EA04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EA04U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x1E8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0046EA04U, address);
            }
        }
        {
        }
        goto block_0046EB9C;
    }
block_0046EA10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EA10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EA10U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r7 + 0x1E8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0046EA14U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x164U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0046EA18U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EA1CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000008U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046EB48; }
        goto block_0046EA28;
    }
block_0046EA28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EA28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EA28U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x810U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EA28U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046EA60; }
        goto block_0046EA34;
    }
block_0046EA34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EA34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EA34U);
        }
        {
            const uint32_t updatedAddress = 0x0046EA3CU - 0x4B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EA34U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EA38U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046EA5C; }
        goto block_0046EA48;
    }
block_0046EA48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EA48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EA48U);
        }
        {
            r3 = 0x00000200U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000100U;
        }
        {
            r0 = 0x00010000U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0046EA5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r12, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046EA5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046EA5C;
    }
block_0046EA5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EA5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EA5CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x810U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046EA5CU, address);
            }
        }
        goto block_0046EA60;
    }
block_0046EA60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EA60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EA60U);
        }
        {
            const uint32_t updatedAddress = 0x0046EA68U - 0x4FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EA60U, address);
            }
            r3 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r10 = 0x000000FFU;
        }
        goto block_0046EA6C;
    }
block_0046EA6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EA6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EA6CU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r6 + operand;
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EA70U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046EA78U, 0xEEB40ACAU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[20],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046EA90; }
        goto block_0046EA84;
    }
block_0046EA84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EA84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EA84U);
        }
        {
            r2 = Oot3dAotLsl(r2, 1U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r10, Oot3dAotLsr(r2, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046EA98; }
        goto block_0046EA90;
    }
block_0046EA90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EA90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EA90U);
        }
        {
            r7 = 0x00000000U;
        }
        goto block_0046EAB0;
    }
block_0046EA98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EA98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EA98U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046EA98U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r3, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046EAA4U, 0xBEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if ((flags.N()) == (flags.V())) {
            r7 = r9;
        }
        if ((flags.N()) != (flags.V())) {
            r7 = frame.Guest.vfp[0];
        }
        goto block_0046EAB0;
    }
block_0046EAB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EAB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EAB0U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x810U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EAB0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r2 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0046EAB4U, address);
            }
        }
        {
            const uint32_t address = r0 + 516U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EAB8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046EAC0U, 0xEEB40A4AU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[20],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z())) {
            r0 = Oot3dAotLsl(r0, 1U);
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r10, Oot3dAotLsr(r0, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r2 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046EB24; }
        goto block_0046EAD8;
    }
block_0046EAD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EAD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EAD8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046EAD8U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046EAE0U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046EAE4U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        if (!(flags.C())) { goto block_0046EB00; }
        goto block_0046EAF4;
    }
block_0046EAF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EAF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EAF4U);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        goto block_0046EB00;
    }
block_0046EB00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EB00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EB00U);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x45000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046EB08U, 0xAE300A69U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        if ((flags.N()) == (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046EB0CU, 0xAEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if ((flags.N()) == (flags.V())) {
            r2 = frame.Guest.vfp[0];
        }
        if ((flags.N()) == (flags.V())) { goto block_0046EB24; }
        goto block_0046EB18;
    }
block_0046EB18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EB18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EB18U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046EB18U, 0xEE300A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046EB1CU, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        goto block_0046EB24;
    }
block_0046EB24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EB24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EB24U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x810U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EB24U, address);
            }
            r0 = value;
        }
        {
            r2 = r7 | Oot3dAotLsl(r2, 12U);
        }
        {
            const uint32_t updatedAddress = r0 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046EB2CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000080U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046EA6C; }
        goto block_0046EB3C;
    }
block_0046EB3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EB3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EB3CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EB3CU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000008U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046EB44U, address);
            }
        }
        goto block_0046EB48;
    }
block_0046EB48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EB48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EB48U);
        }
        {
            const uint32_t updatedAddress = 0x0046EB50U - 0x5DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EB48U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046EB54U - 0x5DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EB4CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EB50U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EB54U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046EB84; }
        goto block_0046EB60;
    }
block_0046EB60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EB60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EB60U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + Oot3dAotLsl(r8, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EB68U, address);
            }
            r1 = value;
        }
        {
            r1 = Oot3dAotLsl(r1, 8U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046EB70U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046EB7CU + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EB74U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046EB78U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046EB80U, address);
            }
        }
        goto block_0046EB84;
    }
block_0046EB84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EB84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EB84U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x810U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EB84U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000080U;
        }
        {
            r0 = 0x000000B0U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046EB94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046EB94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046EB94;
    }
block_0046EB94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EB94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EB94U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046EB98U, address);
            }
        }
        goto block_0046EB9C;
    }
block_0046EB9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EB9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EB9CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r8 = r8 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046E968; }
        goto block_0046EBA8;
    }
block_0046EBA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EBA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EBA8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x564U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EBA8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00008000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00008000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0046EDC8; }
        goto block_0046EBB4;
    }
block_0046EBB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EBB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EBB4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xD78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EBB4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EBBCU, address);
            }
            r7 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046EBC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1210_002D1210(frame, context, state, 0x002D1210U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046EBC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046EBC4;
    }
block_0046EBC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EBC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EBC4U);
        }
        {
            r6 = r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x16CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EBC8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r7, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r5 + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EBD0U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_0046EC4C; }
        goto block_0046EBD8;
    }
block_0046EBD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EBD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EBD8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046EDC8; }
        goto block_0046EBE0;
    }
block_0046EBE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EBE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EBE0U);
        }
        {
            const uint32_t updatedAddress = 0x0046EBE8U - 0x674U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EBE0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046EBECU - 0x674U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EBE4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EBE8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EBECU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046EC10; }
        goto block_0046EBF8;
    }
block_0046EBF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EBF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EBF8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x274U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EBF8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046EBFCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046EC08U + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EC00U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046EC04U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046EC0CU, address);
            }
        }
        goto block_0046EC10;
    }
block_0046EC10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EC10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EC10U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x274U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EC10U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x814U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EC14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EC1CU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x000000B0U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046EC28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046EC28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046EC28;
    }
block_0046EC28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EC28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EC28U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1F0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0046EC28U, address);
            }
        }
        {
        }
        goto block_0046EDC8;
    }
block_0046EC4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EC4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EC4CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x1F0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0046EC50U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x16CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0046EC54U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EC58U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000010U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046ED84; }
        goto block_0046EC64;
    }
block_0046EC64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EC64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EC64U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x814U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EC64U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046EC9C; }
        goto block_0046EC70;
    }
block_0046EC70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EC70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EC70U);
        }
        {
            const uint32_t updatedAddress = 0x0046EC78U - 0x6F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EC70U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EC74U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046EC98; }
        goto block_0046EC84;
    }
block_0046EC84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EC84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EC84U);
        }
        {
            r3 = 0x00000200U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000100U;
        }
        {
            r0 = 0x00010000U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0046EC98U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r12, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046EC98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046EC98;
    }
block_0046EC98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EC98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EC98U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x814U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046EC98U, address);
            }
        }
        goto block_0046EC9C;
    }
block_0046EC9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EC9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EC9CU);
        }
        {
            const uint32_t updatedAddress = 0x0046ECA4U - 0x738U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EC9CU, address);
            }
            r3 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            r7 = 0x000000FFU;
        }
        goto block_0046ECA8;
    }
block_0046ECA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ECA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ECA8U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r2 = r6 + operand;
        }
        {
            const uint32_t address = r2 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ECACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046ECB4U, 0xEEB40ACAU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[20],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046ECCC; }
        goto block_0046ECC0;
    }
block_0046ECC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ECC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ECC0U);
        }
        {
            r1 = Oot3dAotLsl(r1, 1U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, Oot3dAotLsr(r1, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046ECD4; }
        goto block_0046ECCC;
    }
block_0046ECCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ECCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ECCCU);
        }
        {
            r1 = 0x00000000U;
        }
        goto block_0046ECEC;
    }
block_0046ECD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ECD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ECD4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046ECD4U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r3, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046ECE0U, 0xBEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if ((flags.N()) == (flags.V())) {
            r1 = r9;
        }
        if ((flags.N()) != (flags.V())) {
            r1 = frame.Guest.vfp[0];
        }
        goto block_0046ECEC;
    }
block_0046ECEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ECECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ECECU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x814U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ECECU, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r12 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046ECF0U, address);
            }
        }
        {
            const uint32_t address = r2 + 516U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ECF4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046ECFCU, 0xEEB40A4AU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[20],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z())) {
            r2 = Oot3dAotLsl(r2, 1U);
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r7, Oot3dAotLsr(r2, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r2 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046ED60; }
        goto block_0046ED14;
    }
block_0046ED14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ED14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ED14U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046ED14U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046ED1CU, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046ED20U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        if (!(flags.C())) { goto block_0046ED3C; }
        goto block_0046ED30;
    }
block_0046ED30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ED30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ED30U);
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r3, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        goto block_0046ED3C;
    }
block_0046ED3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ED3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ED3CU);
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x45000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046ED44U, 0xAE300A69U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        if ((flags.N()) == (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046ED48U, 0xAEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if ((flags.N()) == (flags.V())) {
            r2 = frame.Guest.vfp[0];
        }
        if ((flags.N()) == (flags.V())) { goto block_0046ED60; }
        goto block_0046ED54;
    }
block_0046ED54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ED54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ED54U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046ED54U, 0xEE300A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046ED58U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        goto block_0046ED60;
    }
block_0046ED60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ED60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ED60U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x814U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ED60U, address);
            }
            r12 = value;
        }
        {
            r1 = r1 | Oot3dAotLsl(r2, 12U);
        }
        {
            const uint32_t updatedAddress = r12 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046ED68U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000080U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046ECA8; }
        goto block_0046ED78;
    }
block_0046ED78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ED78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ED78U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ED78U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000010U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046ED80U, address);
            }
        }
        goto block_0046ED84;
    }
block_0046ED84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ED84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ED84U);
        }
        {
            const uint32_t updatedAddress = 0x0046ED8CU - 0x818U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ED84U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046ED90U - 0x818U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ED88U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ED8CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ED90U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046EDB0; }
        goto block_0046ED9C;
    }
block_0046ED9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046ED9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046ED9CU);
        }
        {
            const uint32_t updatedAddress = 0x0046EDA4U - 0x15CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046ED9CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0046EDA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046EDA4U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046EDACU, address);
            }
        }
        goto block_0046EDB0;
    }
block_0046EDB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EDB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EDB0U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x814U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EDB0U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000080U;
        }
        {
            r0 = 0x000000B0U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046EDC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046EDC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046EDC0;
    }
block_0046EDC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EDC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EDC0U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046EDC4U, address);
            }
        }
        goto block_0046EDC8;
    }
block_0046EDC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EDC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EDC8U);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_0046EDCC;
    }
block_0046EDCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EDCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EDCCU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r2 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xD7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EDD4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x170U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EDD8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EDE0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046EDF8; }
        goto block_0046EDEC;
    }
block_0046EDEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EDECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EDECU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046EDCC; }
        goto block_0046EDF8;
    }
block_0046EDF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EDF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EDF8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000004U;
            r10 = r13 + operand;
        }
        if (!(flags.Z())) { goto block_0046EFE4; }
        goto block_0046EE04;
    }
block_0046EE04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EE04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EE04U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EE04U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x1F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EE0CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x1FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EE14U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x200U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EE1CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046F244; }
        goto block_0046EE28;
    }
block_0046EE28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EE28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EE28U);
        }
        {
            r7 = 0x00000000U;
        }
        {
            r8 = 0x00000200U;
        }
        {
            r0 = r7;
        }
        goto block_0046EE34;
    }
block_0046EE34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EE34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EE34U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r2 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x1F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EE38U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046EE64; }
        goto block_0046EE44;
    }
block_0046EE44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EE44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EE44U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x278U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EE44U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x1F4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0046EE48U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r8, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            r8 = r1;
        }
        {
            const uint32_t operand = r3;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r1 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r7, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r7 = r1 - operand;
        }
        goto block_0046EE64;
    }
block_0046EE64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EE64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EE64U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046EE34; }
        goto block_0046EE70;
    }
block_0046EE70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EE70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EE70U);
        }
        {
            r9 = 0x00000000U;
        }
        {
            r11 = 0x000000FFU;
        }
        goto block_0046EE78;
    }
block_0046EE78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EE78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EE78U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xD7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EE7CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046EE84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1210_002D1210(frame, context, state, 0x002D1210U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046EE84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046EE84;
    }
block_0046EE84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EE84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EE84U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, r7, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            r6 = r8;
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0046EEBC; }
        goto block_0046EE90;
    }
block_0046EE90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EE90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EE90U);
        }
        {
            r3 = Oot3dAotLsl(r9, 3U);
        }
        {
            r12 = Oot3dAotShiftRegister(r11, 0U, r3, false).Value;
        }
        goto block_0046EE98;
    }
block_0046EE98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EE98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EE98U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x818U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EE98U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r10 + Oot3dAotLsl(r6, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EE9CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + r6;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EEA0U, address);
            }
            r2 = value;
        }
        {
            r1 = r1 & ~(r12);
        }
        {
            r1 = r1 | Oot3dAotShiftRegister(r2, 0U, r3, false).Value;
        }
        {
            const uint32_t updatedAddress = r10 + Oot3dAotLsl(r6, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046EEACU, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, r7, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046EE98; }
        goto block_0046EEBC;
    }
block_0046EEBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EEBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EEBCU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r9 = r9 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046EE78; }
        goto block_0046EEC8;
    }
block_0046EEC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EEC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EEC8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000100U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046EF90; }
        goto block_0046EED0;
    }
block_0046EED0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EED0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EED0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000100U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) { goto block_0046EF5C; }
        goto block_0046EED8;
    }
block_0046EED8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EED8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EED8U);
        }
        {
            const uint32_t updatedAddress = 0x0046EEE0U - 0x96CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EED8U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046EEE4U - 0x96CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EEDCU, address);
            }
            r9 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EEE0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EEE4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046EF08; }
        goto block_0046EEF0;
    }
block_0046EEF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EEF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EEF0U);
        }
        {
            r1 = r8 | 0x00000400U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046EEF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046EF00U - 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EEF8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046EEFCU, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046EF04U, address);
            }
        }
        goto block_0046EF08;
    }
block_0046EF08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EF08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EF08U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 2U);
            r2 = r10 + operand;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = operand - r8;
        }
        {
            r0 = 0x000000B0U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046EF18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046EF18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046EF18;
    }
block_0046EF18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EF18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EF18U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EF18U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EF1CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046EF40; }
        goto block_0046EF28;
    }
block_0046EF28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EF28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EF28U);
        }
        {
            r1 = 0x00000500U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046EF2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046EF38U - 0x2F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EF30U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046EF34U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046EF3CU, address);
            }
        }
        goto block_0046EF40;
    }
block_0046EF40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EF40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EF40U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r10 + operand;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r1 = r7 - operand;
        }
        {
            r0 = 0x000000B0U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046EF50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046EF50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046EF50;
    }
block_0046EF50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EF50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EF50U);
        }
        {
        }
        {
        }
        goto block_0046F244;
    }
block_0046EF5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EF5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EF5CU);
        }
        {
            const uint32_t updatedAddress = 0x0046EF64U - 0x9F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EF5CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046EF68U - 0x9F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EF60U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EF64U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EF68U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046EFC4; }
        goto block_0046EF74;
    }
block_0046EF74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EF74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EF74U);
        }
        {
            r2 = r8 | 0x00000400U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046EF78U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046EF84U - 0x33CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EF7CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046EF80U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046EF88U, address);
            }
        }
        goto block_0046EFC4;
    }
block_0046EF90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EF90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EF90U);
        }
        {
            const uint32_t updatedAddress = 0x0046EF98U - 0xA24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EF90U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046EF9CU - 0xA24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EF94U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EF98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EF9CU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046EFC4; }
        goto block_0046EFA8;
    }
block_0046EFA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EFA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EFA8U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r2 = r8 - operand;
        }
        {
            r2 = r2 | 0x00000500U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046EFB0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046EFBCU - 0x374U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EFB4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046EFB8U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046EFC0U, address);
            }
        }
        goto block_0046EFC4;
    }
block_0046EFC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EFC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EFC4U);
        }
        {
            const uint32_t operand = r8;
            r0 = r7 - operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 2U);
            r2 = r10 + operand;
        }
        {
            r0 = 0x000000B0U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046EFD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046EFD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046EFD8;
    }
block_0046EFD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EFD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EFD8U);
        }
        {
        }
        {
        }
        goto block_0046F244;
    }
block_0046EFE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EFE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EFE4U);
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[21];
        }
        {
            const uint32_t updatedAddress = 0x0046EFF0U + 0x2F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EFE8U, address);
            }
            r8 = value;
        }
        {
            const uint32_t address = 0x0046EFF4U + 744U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EFECU, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x0046EFF8U + 744U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046EFF0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r7 = 0x00000000U;
        }
        {
            r9 = 0x000000FFU;
        }
        goto block_0046EFFC;
    }
block_0046EFFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046EFFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046EFFCU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xD7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F000U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046F008U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1210_002D1210(frame, context, state, 0x002D1210U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046F008U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046F008;
    }
block_0046F008:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F008U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F008U);
        }
        {
            r6 = r0;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 2U);
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F010U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x1F4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0046F018U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F01CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000020U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046F158; }
        goto block_0046F028;
    }
block_0046F028:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F028U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F028U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x818U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F028U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046F060; }
        goto block_0046F034;
    }
block_0046F034:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F034U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F034U);
        }
        {
            const uint32_t updatedAddress = 0x0046F03CU - 0xAB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F034U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F038U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046F05C; }
        goto block_0046F048;
    }
block_0046F048:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F048U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F048U);
        }
        {
            r3 = 0x00000200U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000100U;
        }
        {
            r0 = 0x00010000U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0046F05CU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r12, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046F05CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046F05C;
    }
block_0046F05C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F05CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F05CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x818U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F05CU, address);
            }
        }
        goto block_0046F060;
    }
block_0046F060:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F060U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F060U);
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[19];
        }
        {
            r0 = 0x00000000U;
        }
        goto block_0046F068;
    }
block_0046F068:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F068U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F068U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[22];
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x818U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F070U, address);
            }
            r3 = value;
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F074U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r1 = r0;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000100U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F090U, 0xEE400A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F094U, 0xEEBC0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r3 + r1;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046F09CU, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0046F068; }
        goto block_0046F0A4;
    }
block_0046F0A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F0A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F0A4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r8, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0046F144; }
        goto block_0046F0AC;
    }
block_0046F0AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F0ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F0ACU);
        }
        {
            const uint32_t updatedAddress = 0x0046F0B4U + 0x234U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F0ACU, address);
            }
            r2 = value;
        }
        goto block_0046F0B0;
    }
block_0046F0B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F0B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F0B0U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r6 + operand;
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F0B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F0BCU, 0xEEB40A4AU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[20],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z())) {
            r1 = Oot3dAotLsl(r1, 1U);
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r9, Oot3dAotLsr(r1, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r6 + 0x818U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F0CCU, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0046F0D0U, address);
            }
        }
        if (flags.Z()) { goto block_0046F138; }
        goto block_0046F0D8;
    }
block_0046F0D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F0D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F0D8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F0D8U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F0E0U, 0xEE200A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F0E4U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        if (!(flags.C())) { goto block_0046F100; }
        goto block_0046F0F4;
    }
block_0046F0F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F0F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F0F4U);
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        goto block_0046F100;
    }
block_0046F100:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F100U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F100U);
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x43000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046F124; }
        goto block_0046F10C;
    }
block_0046F10C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F10CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F10CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F10CU, 0xEE300A48U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r6 + 0x818U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F110U, address);
            }
            r3 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F114U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r3 + r0;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F11CU, address);
            }
        }
        goto block_0046F138;
    }
block_0046F124:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F124U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F124U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F124U, 0xEE300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r6 + 0x818U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F128U, address);
            }
            r3 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F12CU, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r3 + r0;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F134U, address);
            }
        }
        goto block_0046F138;
    }
block_0046F138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F138U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r8, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046F0B0; }
        goto block_0046F144;
    }
block_0046F144:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F144U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F144U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x818U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F144U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0046F148U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F14CU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000020U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F154U, address);
            }
        }
        goto block_0046F158;
    }
block_0046F158:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F158U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F158U);
        }
        {
            r3 = Oot3dAotLsl(r7, 3U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            r12 = Oot3dAotShiftRegister(r9, 0U, r3, false).Value;
        }
        goto block_0046F164;
    }
block_0046F164:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F164U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F164U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x818U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F164U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r10 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F168U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F16CU, address);
            }
            r2 = value;
        }
        {
            r1 = r1 & ~(r12);
        }
        {
            r1 = r1 | Oot3dAotShiftRegister(r2, 0U, r3, false).Value;
        }
        {
            const uint32_t updatedAddress = r10 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F178U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000200U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046F164; }
        goto block_0046F188;
    }
block_0046F188:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F188U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F188U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r7 = r7 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046EFFC; }
        goto block_0046F194;
    }
block_0046F194:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F194U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F194U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_0046F244; }
        goto block_0046F19C;
    }
block_0046F19C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F19CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F19CU);
        }
        {
            const uint32_t updatedAddress = 0x0046F1A4U - 0xC30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F19CU, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046F1A8U - 0xC30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F1A0U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F1A4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F1A8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046F1CC; }
        goto block_0046F1B4;
    }
block_0046F1B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F1B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F1B4U);
        }
        {
            r1 = 0x00000400U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F1B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046F1C4U - 0x57CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F1BCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F1C0U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F1C8U, address);
            }
        }
        goto block_0046F1CC;
    }
block_0046F1CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F1CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F1CCU);
        }
        {
            r2 = r10;
        }
        {
            r1 = 0x00000100U;
        }
        {
            r0 = 0x000000B0U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046F1DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046F1DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046F1DC;
    }
block_0046F1DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F1DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F1DCU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F1DCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F1E0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046F204; }
        goto block_0046F1EC;
    }
block_0046F1EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F1ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F1ECU);
        }
        {
            r1 = 0x00000500U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F1F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046F1FCU - 0x5B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F1F4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F1F8U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F200U, address);
            }
        }
        goto block_0046F204;
    }
block_0046F204:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F204U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F204U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r10 + operand;
        }
        {
            r1 = 0x00000100U;
        }
        {
            r0 = 0x000000B0U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046F214U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046F214U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046F214;
    }
block_0046F214:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F214U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F214U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F218U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        goto block_0046F220;
    }
block_0046F220:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F220U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F220U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r2 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xD7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F228U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F238U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x170U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F23CU, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0046F220; }
        goto block_0046F244;
    }
block_0046F244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F244U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x5F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F244U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000007U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0046F498; }
        goto block_0046F250;
    }
block_0046F250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F250U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F250U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046F25CU + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F254U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F258U, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0046F498; }
        goto block_0046F264;
    }
block_0046F264:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F264U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F264U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xDE4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F264U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F26CU, address);
            }
            r7 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046F274U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1210_002D1210(frame, context, state, 0x002D1210U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046F274U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046F274;
    }
block_0046F274:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F274U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F274U);
        }
        {
            r6 = r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x180U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F278U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046F284U + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F27CU, address);
            }
            r11 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r7, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r5 + 0x204U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F284U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_0046F2F4; }
        goto block_0046F28C;
    }
block_0046F28C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F28CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F28CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0046F498; }
        goto block_0046F294;
    }
block_0046F294:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F294U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F294U);
        }
        {
            const uint32_t updatedAddress = 0x0046F29CU - 0xD28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F294U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046F2A0U - 0xD28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F298U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F29CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F2A0U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046F2B8; }
        goto block_0046F2AC;
    }
block_0046F2AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F2ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F2ACU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x288U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F2ACU, address);
            }
            r2 = value;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0046F2B0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0046F2B0U,
                                           firstAddress + 4U);
            }
            r0 = r0 + 8U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F2B4U, address);
            }
        }
        goto block_0046F2B8;
    }
block_0046F2B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F2B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F2B8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x288U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F2B8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x808U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F2BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x204U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F2C4U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x000000E8U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046F2D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046F2D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046F2D0;
    }
block_0046F2D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F2D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F2D0U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x204U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F2D4U, address);
            }
        }
        goto block_0046F498;
    }
block_0046F2F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F2F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F2F4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000000U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x204U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F2FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x180U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0046F300U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F304U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046F45C; }
        goto block_0046F310;
    }
block_0046F310:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F310U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F310U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x808U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F310U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046F348; }
        goto block_0046F31C;
    }
block_0046F31C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F31CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F31CU);
        }
        {
            const uint32_t updatedAddress = 0x0046F324U - 0xDA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F31CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F320U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046F344; }
        goto block_0046F330;
    }
block_0046F330:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F330U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F330U);
        }
        {
            r3 = 0x00000200U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000100U;
        }
        {
            r0 = 0x00010000U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0046F344U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r12, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046F344U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046F344;
    }
block_0046F344:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F344U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F344U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x808U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F344U, address);
            }
        }
        goto block_0046F348;
    }
block_0046F348:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F348U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F348U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[23];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            const uint32_t updatedAddress = 0x0046F35CU - 0xDF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F354U, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046F360U + 0x3A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F358U, address);
            }
            r8 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0046F368U + 912U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F360U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            const uint32_t address = 0x0046F36CU + 912U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F364U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r7 = 0x000000FFU;
        }
        {
            r9 = r1;
        }
        goto block_0046F370;
    }
block_0046F370:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F370U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F370U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r3 = r6 + operand;
        }
        {
            const uint32_t address = r3 + 516U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F374U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            r0 = frame.Guest.vfp[5];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F37CU, 0xEEF42A61U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[5], frame.Guest.vfp[3],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z())) {
            r0 = Oot3dAotLsl(r0, 1U);
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r7, Oot3dAotLsr(r0, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r6 + 0x808U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F38CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0046F390U, address);
            }
        }
        if (flags.Z()) { goto block_0046F3F4; }
        goto block_0046F398;
    }
block_0046F398:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F398U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F398U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F398U, 0xEE722A82U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[5], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F39CU, 0xEE622AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[5], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F3A0U, 0xEEF42AE1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[5], frame.Guest.vfp[3],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            frame.Guest.vfp[5] = frame.Guest.vfp[3];
        }
        if (!(flags.C())) { goto block_0046F3BC; }
        goto block_0046F3B0;
    }
block_0046F3B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F3B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F3B0U);
        }
        {
            r0 = frame.Guest.vfp[5];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x46000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            frame.Guest.vfp[5] = frame.Guest.vfp[2];
        }
        goto block_0046F3BC;
    }
block_0046F3BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F3BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F3BCU);
        }
        {
            r0 = frame.Guest.vfp[5];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r10, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046F3E0; }
        goto block_0046F3C8;
    }
block_0046F3C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F3C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F3C8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F3C8U, 0xEE722AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r6 + 0x808U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F3CCU, address);
            }
            r2 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F3D0U, 0xEEFC2AE2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[5];
        }
        {
            const uint32_t updatedAddress = r2 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F3D8U, address);
            }
        }
        goto block_0046F3F4;
    }
block_0046F3E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F3E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F3E0U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F3E0U, 0xEE722A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r6 + 0x808U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F3E4U, address);
            }
            r2 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F3E8U, 0xEEFC2AE2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[5];
        }
        {
            const uint32_t updatedAddress = r2 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F3F0U, address);
            }
        }
        goto block_0046F3F4;
    }
block_0046F3F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F3F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F3F4U);
        }
        {
            const uint32_t address = r3 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F3F4U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            r0 = frame.Guest.vfp[5];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F3FCU, 0xEEF42AE1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[5], frame.Guest.vfp[3],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046F414; }
        goto block_0046F408;
    }
block_0046F408:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F408U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F408U);
        }
        {
            r0 = Oot3dAotLsl(r0, 1U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, Oot3dAotLsr(r0, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046F41C; }
        goto block_0046F414;
    }
block_0046F414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F414U);
        }
        {
            r2 = 0x00000000U;
        }
        goto block_0046F434;
    }
block_0046F41C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F41CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F41CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F41CU, 0xEE622AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[5], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[5];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x45000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F428U, 0xBEFC2AE2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        if ((flags.N()) == (flags.V())) {
            r2 = r8;
        }
        if ((flags.N()) != (flags.V())) {
            r2 = frame.Guest.vfp[5];
        }
        goto block_0046F434;
    }
block_0046F434:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F434U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F434U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x808U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F434U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F438U, address);
            }
            r3 = value;
        }
        {
            r2 = r3 | Oot3dAotLsl(r2, 13U);
        }
        {
            const uint32_t updatedAddress = r0 + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046F440U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000080U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046F370; }
        goto block_0046F450;
    }
block_0046F450:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F450U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F450U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F450U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F458U, address);
            }
        }
        goto block_0046F45C;
    }
block_0046F45C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F45CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F45CU);
        }
        {
            const uint32_t updatedAddress = 0x0046F464U - 0xEF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F45CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046F468U - 0xEF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F460U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F464U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F468U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046F480; }
        goto block_0046F474;
    }
block_0046F474:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F474U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F474U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0046F478U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0046F478U,
                                           firstAddress + 4U);
            }
            r0 = r0 + 8U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F47CU, address);
            }
        }
        goto block_0046F480;
    }
block_0046F480:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F480U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F480U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x808U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F480U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000080U;
        }
        {
            r0 = 0x000000E8U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046F490U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046F490U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046F490;
    }
block_0046F490:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F490U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F490U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x80CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F494U, address);
            }
        }
        goto block_0046F498;
    }
block_0046F498:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F498U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F498U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x5F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F498U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000007U;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r0, 0U, 0U, flags.C());
            r0 = r1 & ~(shifted.Value);
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) { goto block_0046F768; }
        goto block_0046F4A8;
    }
block_0046F4A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F4A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F4A8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F4A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046F4B4U + 0x250U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F4ACU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F4B0U, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046F768; }
        goto block_0046F4BC;
    }
block_0046F4BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F4BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F4BCU);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_0046F4C0;
    }
block_0046F4C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F4C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F4C0U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r2 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xDF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F4C8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x184U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F4CCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F4D4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046F4EC; }
        goto block_0046F4E0;
    }
block_0046F4E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F4E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F4E0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046F4C0; }
        goto block_0046F4EC;
    }
block_0046F4EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F4ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F4ECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0046F768; }
        goto block_0046F4F4;
    }
block_0046F4F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F4F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F4F4U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000400U;
            r11 = r13 + operand;
        }
        {
            const uint32_t operand = 0x000003CCU;
            r11 = r11 + operand;
        }
        {
            r1 = r0;
        }
        {
            r2 = r0;
        }
        {
            r3 = r0;
        }
        {
            r6 = r0;
        }
        {
            r7 = r0;
        }
        {
            r8 = r0;
        }
        {
            r9 = r0;
        }
        {
            r10 = r0;
        }
        {
            r12 = r0;
        }
        {
            r14 = r0;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0046F528U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046F528U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0046F528U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0046F528U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0046F528U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0046F528U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0046F528U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0046F528U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0046F528U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0046F528U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0046F528U,
                                           firstAddress + 40U);
            }
            r11 = r11 + 44U;
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[20];
        }
        {
            r8 = 0x000000FFU;
        }
        {
            r10 = 0x00000020U;
        }
        {
            const uint32_t updatedAddress = 0x0046F540U - 0x258U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F538U, address);
            }
            r9 = value;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0046F53CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046F53CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0046F53CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0046F53CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0046F53CU,
                                           firstAddress + 16U);
            }
        }
        {
            const uint32_t operand = 0x0000002CU;
            r11 = r11 - operand;
        }
        {
            const uint32_t address = 0x0046F54CU + 444U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F544U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        goto block_0046F548;
    }
block_0046F548:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F548U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F548U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 2U);
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xDF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F54CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046F554U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d1210_002D1210(frame, context, state, 0x002D1210U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046F554U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046F554;
    }
block_0046F554:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F554U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F554U);
        }
        {
            r6 = r0;
        }
        {
            const uint32_t updatedAddress = r0 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F558U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046F640; }
        goto block_0046F564;
    }
block_0046F564:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F564U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F564U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x80CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F564U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046F59C; }
        goto block_0046F570;
    }
block_0046F570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F570U);
        }
        {
            const uint32_t updatedAddress = 0x0046F578U - 0xFF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F570U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F574U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046F598; }
        goto block_0046F584;
    }
block_0046F584:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F584U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F584U);
        }
        {
            r3 = 0x00000040U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = 0x00000100U;
        }
        {
            r0 = 0x00010000U;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0046F598U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r12, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046F598U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046F598;
    }
block_0046F598:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F598U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F598U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x80CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F598U, address);
            }
        }
        goto block_0046F59C;
    }
block_0046F59C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F59CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F59CU);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_0046F5A0;
    }
block_0046F5A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F5A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F5A0U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r6 + operand;
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F5A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F5A8U, 0xEE200A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F5B0U, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0046F5C8; }
        goto block_0046F5BC;
    }
block_0046F5BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F5BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F5BCU);
        }
        {
            r2 = Oot3dAotLsl(r2, 1U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, Oot3dAotLsr(r2, 24U), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0046F5D0; }
        goto block_0046F5C8;
    }
block_0046F5C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F5C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F5C8U);
        }
        {
            r2 = 0x00000000U;
        }
        goto block_0046F5E4;
    }
block_0046F5D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F5D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F5D0U);
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r9, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F5D8U, 0xBEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if ((flags.N()) == (flags.V())) {
            r2 = 0x000000FFU;
        }
        if ((flags.N()) != (flags.V())) {
            r2 = frame.Guest.vfp[0];
        }
        goto block_0046F5E4;
    }
block_0046F5E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F5E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F5E4U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x80CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F5E4U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046F5E8U, address);
            }
        }
        {
            const uint32_t address = r1 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F5ECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x80CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F5F0U, address);
            }
            r12 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F5F4U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F5F8U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F5FCU, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            r3 = r2 & 0x0000007FU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r2 = r10 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + r2;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046F610U, address);
            }
        }
        {
            const uint32_t address = r1 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F614U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0046F618U, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = r6 + 0x80CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F620U, address);
            }
            r1 = value;
        }
        if (!(flags.C())) {
            r3 = r3 | 0x00000080U;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = r1 + r2;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046F628U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046F5A0; }
        goto block_0046F634;
    }
block_0046F634:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F634U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F634U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F634U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000004U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x81CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F63CU, address);
            }
        }
        goto block_0046F640;
    }
block_0046F640:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F640U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F640U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            r1 = Oot3dAotLsl(r7, 3U);
        }
        goto block_0046F648;
    }
block_0046F648:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F648U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F648U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x80CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F648U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r3 = r10 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + r3;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F650U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r11 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F654U, address);
            }
            r3 = value;
        }
        {
            r2 = r3 | Oot3dAotShiftRegister(r2, 0U, r1, false).Value;
        }
        {
            const uint32_t updatedAddress = r11 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0046F65CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x80CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F660U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r2 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F668U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r3 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F66CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            r3 = r12 | Oot3dAotShiftRegister(r3, 0U, r1, false).Value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0046F67CU, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0046F648; }
        goto block_0046F684;
    }
block_0046F684:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F684U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F684U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r7 = r7 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0046F548; }
        goto block_0046F690;
    }
block_0046F690:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F690U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F690U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (!(flags.Z())) { goto block_0046F768; }
        goto block_0046F698;
    }
block_0046F698:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F698U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F698U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x80CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F698U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r1 = 0x0000002DU;
        }
        if (flags.Z()) {
            r0 = 0x000000C0U;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0046F6ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d134c_002D134C(frame, context, state, 0x002D134CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046F6ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046F6AC;
    }
block_0046F6AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F6ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F6ACU);
        }
        {
            const uint32_t updatedAddress = 0x0046F6B4U + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F6ACU, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046F6B8U + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F6B0U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F6B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F6B8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046F6DC; }
        goto block_0046F6C4;
    }
block_0046F6C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F6C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F6C4U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F6C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046F6D4U + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F6CCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F6D0U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F6D8U, address);
            }
        }
        goto block_0046F6DC;
    }
block_0046F6DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F6DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F6DCU);
        }
        {
            r2 = r11;
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = 0x00000124U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0046F6ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00303b24_00303B24(frame, context, state, 0x00303B24U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0046F6ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0046F6EC;
    }
block_0046F6EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F6ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F6ECU);
        }
        {
        }
        {
        }
        goto block_0046F718;
    }
block_0046F718:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F718U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F718U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F718U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F71CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046F740; }
        goto block_0046F728;
    }
block_0046F728:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F728U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F728U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F72CU, address);
            }
        }
        {
            r1 = 0x00000100U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F734U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F73CU, address);
            }
        }
        goto block_0046F740;
    }
block_0046F740:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F740U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F740U);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_0046F744;
    }
block_0046F744:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F744U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F744U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r2 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xDF8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F74CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F75CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x184U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F760U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0046F744; }
        goto block_0046F768;
    }
block_0046F768:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F768U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F768U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x850U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F768U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000800U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000800U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0046F9C4; }
        goto block_0046F774;
    }
block_0046F774:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F774U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F774U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x84CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F774U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F778U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000100U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000100U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xDB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F780U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x574U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F784U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0046F9C4; }
        goto block_0046F790;
    }
block_0046F790:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F790U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F790U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x585U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F790U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x586U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F794U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x584U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F798U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x587U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F79CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xDB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F7A0U, address);
            }
            r12 = value;
        }
        {
            r1 = Oot3dAotLsl(r1, 2U);
        }
        {
            r3 = r2 | Oot3dAotLsl(r3, 1U);
        }
        {
            r0 = r1 | Oot3dAotLsl(r0, 3U);
        }
        {
            r0 = r0 | r3;
        }
        {
            const uint32_t updatedAddress = 0x0046F7BCU - 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F7B4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0046F7C0U - 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F7B8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x574U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046F7BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F7C0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F7C4U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r12, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046F7E8; }
        goto block_0046F7D0;
    }
block_0046F7D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F7D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F7D0U);
        }
        {
            r12 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046F7D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046F7E0U + 0x260U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F7D8U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046F7DCU, address);
            }
            r1 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F7E4U, address);
            }
        }
        goto block_0046F7E8;
    }
block_0046F7E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F7E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F7E8U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F7E8U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r12, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046F80C; }
        goto block_0046F7F4;
    }
block_0046F7F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F7F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F7F4U);
        }
        {
            r12 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046F7F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0046F804U + 0x240U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F7FCU, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0046F800U, address);
            }
            r1 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000004U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F808U, address);
            }
        }
        goto block_0046F80C;
    }
block_0046F80C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F80CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F80CU);
        }
        {
            const uint32_t updatedAddress = 0x0046F814U + 0x234U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F80CU, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x574U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F810U, address);
            }
            r1 = value;
        }
        {
            r6 = r7 | Oot3dAotAsr(r7, 18U);
        }
        {
            const uint32_t operand = 0x00006000U;
            r1 = r1 - operand;
        }
        {
            const uint32_t operand = 0x00000030U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r1 = r1 - operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r12 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r6 + operand;
        }
        if (flags.Z()) { goto block_0046F898; }
        goto block_0046F82C;
    }
block_0046F82C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F82CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F82CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000018U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046F9D8; }
        goto block_0046F834;
    }
block_0046F834:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F834U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F834U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000021U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0046F9C4; }
        goto block_0046F83C;
    }
block_0046F83C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F83CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F83CU);
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F83CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F840U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046F858; }
        goto block_0046F84C;
    }
block_0046F84C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F84CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F84CU);
        }
        {
            r1 = 0x0000000FU;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046F850U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0046F850U,
                                           firstAddress + 4U);
            }
            r0 = r0 + 8U;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F854U, address);
            }
        }
        goto block_0046F858;
    }
block_0046F858:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F858U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F858U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F858U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046F870; }
        goto block_0046F864;
    }
block_0046F864:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F864U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F864U);
        }
        {
            r1 = 0x0000000FU;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046F868U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0046F868U,
                                           firstAddress + 4U);
            }
            r0 = r0 + 8U;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F86CU, address);
            }
        }
        goto block_0046F870;
    }
block_0046F870:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F870U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F870U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F870U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046F888; }
        goto block_0046F87C;
    }
block_0046F87C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F87CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F87CU);
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046F880U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0046F880U,
                                           firstAddress + 4U);
            }
            r0 = r0 + 8U;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F884U, address);
            }
        }
        goto block_0046F888;
    }
block_0046F888:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F888U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F888U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F888U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046F9C4; }
        goto block_0046F894;
    }
block_0046F894:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F894U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F894U);
        }
        goto block_0046FA30;
    }
block_0046F898:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F898U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F898U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046F8CC; }
        goto block_0046F8A0;
    }
block_0046F8A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F8A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F8A0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F8A0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046F8C4; }
        goto block_0046F8AC;
    }
block_0046F8AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F8ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F8ACU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x57CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F8ACU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x57DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F8B8U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0046F8CC; }
        goto block_0046F8C4;
    }
block_0046F8C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F8C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F8C4U);
        }
        {
            r1 = 0x00000001U;
        }
        goto block_0046F8D8;
    }
block_0046F8CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F8CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F8CCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            r1 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0046F8DC; }
        goto block_0046F8D8;
    }
block_0046F8D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F8D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F8D8U);
        }
        {
            r0 = 0x00000002U;
        }
        goto block_0046F8DC;
    }
block_0046F8DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F8DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F8DCU);
        }
        {
            r1 = r1 | r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x57BU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F8E0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000004U;
        }
        {
            r1 = r1 | r0;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x588U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F8F0U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (!(flags.Z())) {
            r0 = 0x00000008U;
        }
        {
            r1 = r1 | r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0x57AU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F904U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000010U;
        }
        {
            r1 = r1 | r0;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x58CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F914U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F918U, address);
            }
            r5 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (!(flags.Z())) {
            r0 = 0x00000020U;
        }
        {
            r0 = r0 | r1;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F92CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r5, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046F948; }
        goto block_0046F938;
    }
block_0046F938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F938U);
        }
        {
            r5 = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, r5, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r5 = 0x0000000FU;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0046F940U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0046F940U,
                                           firstAddress + 4U);
            }
            r1 = r1 + 8U;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F944U, address);
            }
        }
        goto block_0046F948;
    }
block_0046F948:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F948U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F948U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F948U, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r5, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046F964; }
        goto block_0046F954;
    }
block_0046F954:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F954U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F954U);
        }
        {
            r5 = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, r5, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r5 = 0x0000000FU;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0046F95CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0046F95CU,
                                           firstAddress + 4U);
            }
            r1 = r1 + 8U;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F960U, address);
            }
        }
        goto block_0046F964;
    }
block_0046F964:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F964U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F964U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F964U, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r5, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046F99C; }
        goto block_0046F970;
    }
block_0046F970:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F970U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F970U);
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            const uint32_t value = r0 & 0x0000000AU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) {
            r5 = 0x00000000U;
        }
        if (!(flags.Z())) {
            r5 = 0x00000002U;
        }
        {
            const uint32_t value = r0 & 0x00000010U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            const uint32_t value = r0 & 0x00000022U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r6 = 0x00000000U;
        }
        if (!(flags.Z())) {
            r6 = 0x00000001U;
        }
        {
            r5 = r5 | r6;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0046F994U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0046F994U,
                                           firstAddress + 4U);
            }
            r1 = r1 + 8U;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0046F998U, address);
            }
        }
        goto block_0046F99C;
    }
block_0046F99C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F99CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F99CU);
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F99CU, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046F9C4; }
        goto block_0046F9A8;
    }
block_0046F9A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F9A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F9A8U);
        }
        {
            r3 = r0 & 0x00000008U;
            Oot3dAotSetLogicalFlags(flags, r3, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            r0 = r0 & 0x00000020U;
        }
        if (!(flags.Z())) {
            r3 = 0x00000002U;
        }
        {
            r0 = r3 | Oot3dAotLsr(r0, 5U);
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0046F9B8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0046F9B8U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F9C0U, address);
            }
        }
        goto block_0046F9C4;
    }
block_0046F9C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F9C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F9C4U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r13 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0046F9CCU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0046F9CCU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0046F9CCU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0046F9CCU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0046F9CCU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0046F9CCU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0046F9CCU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0046F9CCU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0046F9CCU,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0046F9CCU,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            r13 += 40U;
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0046F9D4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0046F9D4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0046F9D4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0046F9D4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0046F9D4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0046F9D4U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0046F9D4U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0046F9D4U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0046F9D4U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_0046F9D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F9D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F9D8U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F9D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F9DCU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046F9F4; }
        goto block_0046F9E8;
    }
block_0046F9E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F9E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F9E8U);
        }
        {
            r1 = 0x0000000FU;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046F9ECU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0046F9ECU,
                                           firstAddress + 4U);
            }
            r0 = r0 + 8U;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046F9F0U, address);
            }
        }
        goto block_0046F9F4;
    }
block_0046F9F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046F9F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046F9F4U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046F9F4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046FA0C; }
        goto block_0046FA00;
    }
block_0046FA00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046FA00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046FA00U);
        }
        {
            r1 = 0x0000000FU;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046FA04U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0046FA04U,
                                           firstAddress + 4U);
            }
            r0 = r0 + 8U;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046FA08U, address);
            }
        }
        goto block_0046FA0C;
    }
block_0046FA0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046FA0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046FA0CU);
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046FA0CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0046FA24; }
        goto block_0046FA18;
    }
block_0046FA18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046FA18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046FA18U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046FA1CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0046FA1CU,
                                           firstAddress + 4U);
            }
            r0 = r0 + 8U;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046FA20U, address);
            }
        }
        goto block_0046FA24;
    }
block_0046FA24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046FA24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046FA24U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0046FA24U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0046F9C4; }
        goto block_0046FA30;
    }
block_0046FA30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0046FA30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0046FA30U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0046FA34U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0046FA34U,
                                           firstAddress + 4U);
            }
            r0 = r0 + 8U;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0046FA38U, address);
            }
        }
        goto block_0046F9C4;
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
