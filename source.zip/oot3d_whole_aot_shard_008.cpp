#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_FUN_0019e118_0019E118(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_001c6138_001C6138(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00257108_00257108(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BossDodongo_Update_0027BE30(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0029e828_0029E828(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_002b6b9c_002B6B9C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_sin_idx8_002CFCA0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00315350_00315350(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ChangeCameraStatus_00320D7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003309e0_003309E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003373c8_003373C8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_cos_idx8_00338F60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00345590_00345590(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00345a08_00345A08(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_ChangeAnimation_00353020(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_TitleCard_InitBossName_00354248(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003542c4_003542C4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelOwner_ApplyTevConstantColor_00357A50(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetRuntimeFlag200_0035AF04(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035af20_0035AF20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b0a0_0035B0A0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b164_0035B164(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b1cc_0035B1CC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_SetBGM_003655D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsDust_SpawnUpdateRateScaled_00365D20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Camera_RequestQuake_0036627C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CutsceneContext_StartUnskippable_00367374(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CutsceneContext_StartSkippable_00367494(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererGlobalState_Init_0036788C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_StaticInitGuard_TryAcquire_003679B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_CameraSetAtEye_00367B14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_CreateSubCamera_00367D74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_FAtan2F_003696EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SpawnAsChild_0036AA20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_GetLastFrame_0036AE14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_GetCamera_0036C5BC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0036d260_0036D260(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToF_0036E168(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_IsFrameCrossed_0036E5E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_WorldYawTowardActor_0036E800(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetCsActionWithHaltedActors_0036E980(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Flags_SetClear_0036EC14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_QueueSeqCmd_0036EC40(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SpawnFloorDustRing_0036F00C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_UpdateNoPlayState_00370734_00370734(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0037100c_0037100C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroFloat_00371E50(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_CosF_Core_00372674(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SinF_003727F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_transform_mtx3x4_vec3_003735AC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_OnFrameImpl_003736FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsDust_SpawnRandomBrown_0037378C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_CenteredFloat_003738A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Spawn_003738D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_Atan2S_003758B0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroOne_003759D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToS_00375A18(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlayActorSound2_00375BCC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_Change_00375c08_00375C08(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_ChangeType_00375D3C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetAC_00376168(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetAT_003761F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetOC_003762A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_UpdateBgCheckInfo_00376340(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_MoveForward_00376864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003da7ac_003DA7AC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0040a084_0040A084(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_FUN_0019e118_0019E118(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0019E118U:
        goto block_0019E118;
    case 0x0019E13CU:
        goto block_0019E13C;
    case 0x0019E144U:
        goto block_0019E144;
    case 0x0019E14CU:
        goto block_0019E14C;
    case 0x0019E154U:
        goto block_0019E154;
    case 0x0019E168U:
        goto block_0019E168;
    case 0x0019E188U:
        goto block_0019E188;
    case 0x0019E24CU:
        goto block_0019E24C;
    case 0x0019E264U:
        goto block_0019E264;
    case 0x0019E278U:
        goto block_0019E278;
    case 0x0019E294U:
        goto block_0019E294;
    case 0x0019E2A8U:
        goto block_0019E2A8;
    case 0x0019E2B4U:
        goto block_0019E2B4;
    case 0x0019E2C0U:
        goto block_0019E2C0;
    case 0x0019E2D0U:
        goto block_0019E2D0;
    case 0x0019E2DCU:
        goto block_0019E2DC;
    case 0x0019E2E8U:
        goto block_0019E2E8;
    case 0x0019E2FCU:
        goto block_0019E2FC;
    case 0x0019E30CU:
        goto block_0019E30C;
    case 0x0019E34CU:
        goto block_0019E34C;
    case 0x0019E358U:
        goto block_0019E358;
    case 0x0019E370U:
        goto block_0019E370;
    case 0x0019E384U:
        goto block_0019E384;
    case 0x0019E398U:
        goto block_0019E398;
    case 0x0019E3ACU:
        goto block_0019E3AC;
    case 0x0019E3BCU:
        goto block_0019E3BC;
    case 0x0019E3C8U:
        goto block_0019E3C8;
    case 0x0019E3D8U:
        goto block_0019E3D8;
    case 0x0019E3E0U:
        goto block_0019E3E0;
    case 0x0019E3F4U:
        goto block_0019E3F4;
    case 0x0019E43CU:
        goto block_0019E43C;
    case 0x0019E448U:
        goto block_0019E448;
    case 0x0019E458U:
        goto block_0019E458;
    case 0x0019E464U:
        goto block_0019E464;
    case 0x0019E474U:
        goto block_0019E474;
    case 0x0019E4A0U:
        goto block_0019E4A0;
    case 0x0019E4B4U:
        goto block_0019E4B4;
    case 0x0019E4C0U:
        goto block_0019E4C0;
    case 0x0019E4D8U:
        goto block_0019E4D8;
    case 0x0019E4FCU:
        goto block_0019E4FC;
    case 0x0019E518U:
        goto block_0019E518;
    case 0x0019E538U:
        goto block_0019E538;
    case 0x0019E550U:
        goto block_0019E550;
    case 0x0019E5DCU:
        goto block_0019E5DC;
    case 0x0019E5F8U:
        goto block_0019E5F8;
    case 0x0019E604U:
        goto block_0019E604;
    case 0x0019E610U:
        goto block_0019E610;
    case 0x0019E65CU:
        goto block_0019E65C;
    case 0x0019E680U:
        goto block_0019E680;
    case 0x0019E68CU:
        goto block_0019E68C;
    case 0x0019E698U:
        goto block_0019E698;
    case 0x0019E6A4U:
        goto block_0019E6A4;
    case 0x0019E6BCU:
        goto block_0019E6BC;
    case 0x0019E6C8U:
        goto block_0019E6C8;
    case 0x0019E6DCU:
        goto block_0019E6DC;
    case 0x0019E6F8U:
        goto block_0019E6F8;
    case 0x0019E718U:
        goto block_0019E718;
    case 0x0019E73CU:
        goto block_0019E73C;
    case 0x0019E758U:
        goto block_0019E758;
    case 0x0019E778U:
        goto block_0019E778;
    case 0x0019E790U:
        goto block_0019E790;
    case 0x0019E7B0U:
        goto block_0019E7B0;
    case 0x0019E7DCU:
        goto block_0019E7DC;
    case 0x0019E800U:
        goto block_0019E800;
    case 0x0019E818U:
        goto block_0019E818;
    case 0x0019E820U:
        goto block_0019E820;
    case 0x0019E828U:
        goto block_0019E828;
    case 0x0019E834U:
        goto block_0019E834;
    case 0x0019E84CU:
        goto block_0019E84C;
    case 0x0019E864U:
        goto block_0019E864;
    case 0x0019E89CU:
        goto block_0019E89C;
    case 0x0019E8BCU:
        goto block_0019E8BC;
    case 0x0019E8E0U:
        goto block_0019E8E0;
    case 0x0019E904U:
        goto block_0019E904;
    case 0x0019E920U:
        goto block_0019E920;
    case 0x0019E940U:
        goto block_0019E940;
    case 0x0019E958U:
        goto block_0019E958;
    case 0x0019E968U:
        goto block_0019E968;
    case 0x0019E978U:
        goto block_0019E978;
    case 0x0019E9A4U:
        goto block_0019E9A4;
    case 0x0019E9B0U:
        goto block_0019E9B0;
    case 0x0019E9F0U:
        goto block_0019E9F0;
    case 0x0019EA00U:
        goto block_0019EA00;
    case 0x0019EA0CU:
        goto block_0019EA0C;
    case 0x0019EA3CU:
        goto block_0019EA3C;
    case 0x0019EA48U:
        goto block_0019EA48;
    case 0x0019EA54U:
        goto block_0019EA54;
    case 0x0019EA5CU:
        goto block_0019EA5C;
    case 0x0019EA78U:
        goto block_0019EA78;
    case 0x0019EA8CU:
        goto block_0019EA8C;
    case 0x0019EA98U:
        goto block_0019EA98;
    case 0x0019EAA4U:
        goto block_0019EAA4;
    case 0x0019EAD0U:
        goto block_0019EAD0;
    case 0x0019EAE0U:
        goto block_0019EAE0;
    case 0x0019EAECU:
        goto block_0019EAEC;
    case 0x0019EAF8U:
        goto block_0019EAF8;
    case 0x0019EAFCU:
        goto block_0019EAFC;
    case 0x0019EB08U:
        goto block_0019EB08;
    case 0x0019EB18U:
        goto block_0019EB18;
    case 0x0019EB20U:
        goto block_0019EB20;
    case 0x0019EB2CU:
        goto block_0019EB2C;
    case 0x0019EB34U:
        goto block_0019EB34;
    case 0x0019EB4CU:
        goto block_0019EB4C;
    case 0x0019EB5CU:
        goto block_0019EB5C;
    case 0x0019EB68U:
        goto block_0019EB68;
    case 0x0019EB80U:
        goto block_0019EB80;
    case 0x0019EBC0U:
        goto block_0019EBC0;
    case 0x0019EBD4U:
        goto block_0019EBD4;
    case 0x0019EBE4U:
        goto block_0019EBE4;
    case 0x0019EBF4U:
        goto block_0019EBF4;
    case 0x0019EC18U:
        goto block_0019EC18;
    case 0x0019EC54U:
        goto block_0019EC54;
    case 0x0019EC60U:
        goto block_0019EC60;
    case 0x0019EC9CU:
        goto block_0019EC9C;
    case 0x0019ECE8U:
        goto block_0019ECE8;
    case 0x0019ED3CU:
        goto block_0019ED3C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0019E118:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E118U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E118U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0019E118U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0019E118U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0019E118U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0019E118U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0019E118U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0019E118U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0019E118U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0019E118U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0019E118U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r5 = r0;
        }
        {
            r10 = r1;
        }
        {
            const uint32_t updatedAddress = 0x0019E12CU + 0x430U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E124U, address);
            }
            r0 = value;
        }
        {
            r13 -= 48U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019E128U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0019E128U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0019E128U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0019E128U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0019E128U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0019E128U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0019E128U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0019E128U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x0019E128U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x0019E128U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x0019E128U,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x0019E128U,
                                           firstAddress + 44U);
            }
        }
        {
            const uint32_t operand = 0x0000004CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E130U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0019E168; }
        goto block_0019E13C;
    }
block_0019E13C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E13CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E13CU);
        }
        {
            const uint32_t updatedAddress = 0x0019E144U + 0x418U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E13CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E144U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E144U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E144;
    }
block_0019E144:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E144U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E144U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0019E168; }
        goto block_0019E14C;
    }
block_0019E14C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E14CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E14CU);
        }
        {
            const uint32_t updatedAddress = 0x0019E154U + 0x40CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E14CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E154U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E154U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E154;
    }
block_0019E154:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E154U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E154U);
        }
        {
            const uint32_t updatedAddress = 0x0019E15CU + 0x408U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E154U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0019E160U + 0x408U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E158U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x0019E168U + 0x3F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E160U, address);
            }
            r0 = value;
        }
        {
            r0 = r0;
        }
        goto block_0019E168;
    }
block_0019E168:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E168U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E168U);
        }
        {
            const uint32_t updatedAddress = 0x0019E170U + 0x3FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E168U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E170U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E174U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0019E180U + 0x3F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E178U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r10;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E17CU, address);
            }
            r7 = value;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E188U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E188U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E188;
    }
block_0019E188:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E188U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E188U);
        }
        {
            const uint32_t operand = 0x00000700U;
            r4 = r5 + operand;
        }
        {
            r11 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E190U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r10 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E1A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E1A8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0019E1B4U + 0x3ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E1ACU, address);
            }
            r9 = value;
        }
        {
            const uint32_t address = 0x0019E1B8U + 956U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E1B0U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E1BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E1C0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0019E1CCU + 940U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E1C4U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x0019E1D0U + 940U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E1C8U, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x6AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E1D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E1D8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019E1DCU, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000001FCU;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019E1E8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000003D4U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019E1F4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000003DCU;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019E200U, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000208U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019E20CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r5 + operand;
        }
        {
            const uint32_t address = 0x0019E21CU + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E214U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x0019E220U + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E218U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x0019E224U + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E21CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0019E228U + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E220U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x0019E22CU + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E224U, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            const uint32_t address = 0x0019E230U + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E228U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t address = 0x0019E234U + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E22CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0019E238U + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E230U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t operand = 0x000001F8U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000400U;
            r8 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r6 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019E244U, address);
            }
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x0019E250U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E248U, address);
            }
            switch (value) {
            case 0x0019E118U:
                goto block_0019E118;
            case 0x0019E13CU:
                goto block_0019E13C;
            case 0x0019E144U:
                goto block_0019E144;
            case 0x0019E14CU:
                goto block_0019E14C;
            case 0x0019E154U:
                goto block_0019E154;
            case 0x0019E168U:
                goto block_0019E168;
            case 0x0019E188U:
                goto block_0019E188;
            case 0x0019E24CU:
                goto block_0019E24C;
            case 0x0019E264U:
                goto block_0019E264;
            case 0x0019E278U:
                goto block_0019E278;
            case 0x0019E294U:
                goto block_0019E294;
            case 0x0019E2A8U:
                goto block_0019E2A8;
            case 0x0019E2B4U:
                goto block_0019E2B4;
            case 0x0019E2C0U:
                goto block_0019E2C0;
            case 0x0019E2D0U:
                goto block_0019E2D0;
            case 0x0019E2DCU:
                goto block_0019E2DC;
            case 0x0019E2E8U:
                goto block_0019E2E8;
            case 0x0019E2FCU:
                goto block_0019E2FC;
            case 0x0019E30CU:
                goto block_0019E30C;
            case 0x0019E34CU:
                goto block_0019E34C;
            case 0x0019E358U:
                goto block_0019E358;
            case 0x0019E370U:
                goto block_0019E370;
            case 0x0019E384U:
                goto block_0019E384;
            case 0x0019E398U:
                goto block_0019E398;
            case 0x0019E3ACU:
                goto block_0019E3AC;
            case 0x0019E3BCU:
                goto block_0019E3BC;
            case 0x0019E3C8U:
                goto block_0019E3C8;
            case 0x0019E3D8U:
                goto block_0019E3D8;
            case 0x0019E3E0U:
                goto block_0019E3E0;
            case 0x0019E3F4U:
                goto block_0019E3F4;
            case 0x0019E43CU:
                goto block_0019E43C;
            case 0x0019E448U:
                goto block_0019E448;
            case 0x0019E458U:
                goto block_0019E458;
            case 0x0019E464U:
                goto block_0019E464;
            case 0x0019E474U:
                goto block_0019E474;
            case 0x0019E4A0U:
                goto block_0019E4A0;
            case 0x0019E4B4U:
                goto block_0019E4B4;
            case 0x0019E4C0U:
                goto block_0019E4C0;
            case 0x0019E4D8U:
                goto block_0019E4D8;
            case 0x0019E4FCU:
                goto block_0019E4FC;
            case 0x0019E518U:
                goto block_0019E518;
            case 0x0019E538U:
                goto block_0019E538;
            case 0x0019E550U:
                goto block_0019E550;
            case 0x0019E5DCU:
                goto block_0019E5DC;
            case 0x0019E5F8U:
                goto block_0019E5F8;
            case 0x0019E604U:
                goto block_0019E604;
            case 0x0019E610U:
                goto block_0019E610;
            case 0x0019E65CU:
                goto block_0019E65C;
            case 0x0019E680U:
                goto block_0019E680;
            case 0x0019E68CU:
                goto block_0019E68C;
            case 0x0019E698U:
                goto block_0019E698;
            case 0x0019E6A4U:
                goto block_0019E6A4;
            case 0x0019E6BCU:
                goto block_0019E6BC;
            case 0x0019E6C8U:
                goto block_0019E6C8;
            case 0x0019E6DCU:
                goto block_0019E6DC;
            case 0x0019E6F8U:
                goto block_0019E6F8;
            case 0x0019E718U:
                goto block_0019E718;
            case 0x0019E73CU:
                goto block_0019E73C;
            case 0x0019E758U:
                goto block_0019E758;
            case 0x0019E778U:
                goto block_0019E778;
            case 0x0019E790U:
                goto block_0019E790;
            case 0x0019E7B0U:
                goto block_0019E7B0;
            case 0x0019E7DCU:
                goto block_0019E7DC;
            case 0x0019E800U:
                goto block_0019E800;
            case 0x0019E818U:
                goto block_0019E818;
            case 0x0019E820U:
                goto block_0019E820;
            case 0x0019E828U:
                goto block_0019E828;
            case 0x0019E834U:
                goto block_0019E834;
            case 0x0019E84CU:
                goto block_0019E84C;
            case 0x0019E864U:
                goto block_0019E864;
            case 0x0019E89CU:
                goto block_0019E89C;
            case 0x0019E8BCU:
                goto block_0019E8BC;
            case 0x0019E8E0U:
                goto block_0019E8E0;
            case 0x0019E904U:
                goto block_0019E904;
            case 0x0019E920U:
                goto block_0019E920;
            case 0x0019E940U:
                goto block_0019E940;
            case 0x0019E958U:
                goto block_0019E958;
            case 0x0019E968U:
                goto block_0019E968;
            case 0x0019E978U:
                goto block_0019E978;
            case 0x0019E9A4U:
                goto block_0019E9A4;
            case 0x0019E9B0U:
                goto block_0019E9B0;
            case 0x0019E9F0U:
                goto block_0019E9F0;
            case 0x0019EA00U:
                goto block_0019EA00;
            case 0x0019EA0CU:
                goto block_0019EA0C;
            case 0x0019EA3CU:
                goto block_0019EA3C;
            case 0x0019EA48U:
                goto block_0019EA48;
            case 0x0019EA54U:
                goto block_0019EA54;
            case 0x0019EA5CU:
                goto block_0019EA5C;
            case 0x0019EA78U:
                goto block_0019EA78;
            case 0x0019EA8CU:
                goto block_0019EA8C;
            case 0x0019EA98U:
                goto block_0019EA98;
            case 0x0019EAA4U:
                goto block_0019EAA4;
            case 0x0019EAD0U:
                goto block_0019EAD0;
            case 0x0019EAE0U:
                goto block_0019EAE0;
            case 0x0019EAECU:
                goto block_0019EAEC;
            case 0x0019EAF8U:
                goto block_0019EAF8;
            case 0x0019EAFCU:
                goto block_0019EAFC;
            case 0x0019EB08U:
                goto block_0019EB08;
            case 0x0019EB18U:
                goto block_0019EB18;
            case 0x0019EB20U:
                goto block_0019EB20;
            case 0x0019EB2CU:
                goto block_0019EB2C;
            case 0x0019EB34U:
                goto block_0019EB34;
            case 0x0019EB4CU:
                goto block_0019EB4C;
            case 0x0019EB5CU:
                goto block_0019EB5C;
            case 0x0019EB68U:
                goto block_0019EB68;
            case 0x0019EB80U:
                goto block_0019EB80;
            case 0x0019EBC0U:
                goto block_0019EBC0;
            case 0x0019EBD4U:
                goto block_0019EBD4;
            case 0x0019EBE4U:
                goto block_0019EBE4;
            case 0x0019EBF4U:
                goto block_0019EBF4;
            case 0x0019EC18U:
                goto block_0019EC18;
            case 0x0019EC54U:
                goto block_0019EC54;
            case 0x0019EC60U:
                goto block_0019EC60;
            case 0x0019EC9CU:
                goto block_0019EC9C;
            case 0x0019ECE8U:
                goto block_0019ECE8;
            case 0x0019ED3CU:
                goto block_0019ED3C;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_0019E24C;
    }
block_0019E24C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E24CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E24CU);
        }
        goto block_0019EC54;
    }
block_0019E264:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E264U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E264U);
        }
        {
            const uint32_t address = r7 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E264U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0019E270U + 0x334U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E268U, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0019E294; }
        goto block_0019E278;
    }
block_0019E278:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E278U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E278U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t address = 0x0019E284U + 804U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E27CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E280U, address);
            }
        }
        {
            const uint32_t address = r5 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E284U, address);
            }
        }
        {
            const uint32_t address = 0x0019E290U + 796U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E288U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E28CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E290U, address);
            }
        }
        goto block_0019E294;
    }
block_0019E294:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E294U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E294U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E294U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E29CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            r1 = 0x00000000U;
        }
        if (flags.Z()) { goto block_0019E820; }
        goto block_0019E2A8;
    }
block_0019E2A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E2A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E2A8U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xADU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019E2ACU, address);
            }
        }
        goto block_0019EC54;
    }
block_0019E2B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E2B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E2B4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E2B4U, address);
            }
            r1 = value;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E2C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E2C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E2C0;
    }
block_0019E2C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E2C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E2C0U);
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E2D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E2D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E2D0;
    }
block_0019E2D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E2D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E2D0U);
        }
        {
            r0 = r10;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E2DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002b6b9c_002B6B9C(frame, context, state, 0x002B6B9CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E2DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E2DC;
    }
block_0019E2DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E2DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E2DCU);
        }
        {
            r0 = r10;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E2E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E2E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E2E8;
    }
block_0019E2E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E2E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E2E8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x84U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E2E8U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E2FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E2FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E2FC;
    }
block_0019E2FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E2FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E2FCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x84U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E2FCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E30CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E30CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E30C;
    }
block_0019E30C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E30CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E30CU);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E310U, address);
            }
        }
        {
            r0 = 0x0000005AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E318U, address);
            }
        }
        {
            r0 = 0x000000F0U;
        }
        {
            const uint32_t address = 0x0019E328U + 648U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E320U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E324U, address);
            }
        }
        {
            const uint32_t address = r7 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E328U, address);
            }
        }
        {
            const uint32_t address = 0x0019E334U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E32CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            const uint32_t address = r6 + 508U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E334U, address);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0019E344U + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E33CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E34CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00345a08_00345A08(frame, context, state, 0x00345A08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E34CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E34C;
    }
block_0019E34C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E34CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E34CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E34CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0019E370; }
        goto block_0019E358;
    }
block_0019E358:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E358U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E358U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            r2 = 0x0000000AU;
        }
        {
            const uint32_t address = 0x0019E368U + 596U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E360U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E370U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00345a08_00345A08(frame, context, state, 0x00345A08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E370U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E370;
    }
block_0019E370:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E370U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E370U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E370U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x3ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E374U, address);
            }
            r0 = value;
        }
        {
            r0 = Oot3dAotAsr(r0, 31U);
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetAddFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r0 = r0 + operand;
        }
        if (flags.Z()) { goto block_0019E398; }
        goto block_0019E384;
    }
block_0019E384:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E384U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E384U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E384U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x3E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E388U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E390U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E398U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0040a084_0040A084(frame, context, state, 0x0040A084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E398U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E398;
    }
block_0019E398:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E398U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E398U);
        }
        {
            const uint32_t address = r7 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E398U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0019E3A4U + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E39CU, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0019E3E0; }
        goto block_0019E3AC;
    }
block_0019E3AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E3ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E3ACU);
        }
        {
            const uint32_t operand = 0x00002000U;
            r11 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0x68U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E3B0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019E3E0; }
        goto block_0019E3BC;
    }
block_0019E3BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E3BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E3BCU);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E3C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetRuntimeFlag200_0035AF04(frame, context, state, 0x0035AF04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E3C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E3C8;
    }
block_0019E3C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E3C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E3C8U);
        }
        {
            r2 = 0x00000067U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E3D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E3D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E3D8;
    }
block_0019E3D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E3D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E3D8U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r11 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E3DCU, address);
            }
        }
        goto block_0019E3E0;
    }
block_0019E3E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E3E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E3E0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E3E0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0019E3ECU + 0x1DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E3E4U, address);
            }
            r11 = value;
        }
        {
            const uint32_t address = 0x0019E3F0U + 468U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E3E8U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000C3U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0019E43C; }
        goto block_0019E3F4;
    }
block_0019E3F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E3F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E3F4U);
        }
        {
            const uint32_t address = 0x0019E3FCU + 464U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E3F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019E400U + 464U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E3F8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r7 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E3FCU, address);
            }
        }
        {
            const uint32_t address = r7 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0019E400U, address);
            }
        }
        {
            const uint32_t address = r7 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019E404U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0019E408U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0019E40CU, address);
            }
        }
        {
            const uint32_t address = r6 + 504U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E410U, address);
            }
        }
        {
            const uint32_t address = r7 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E414U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E418U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 512U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E41CU, address);
            }
        }
        {
            const uint32_t address = r7 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E420U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 516U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E424U, address);
            }
        }
        {
            const uint32_t address = r7 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E428U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E42CU, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 520U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E430U, address);
            }
        }
        {
            const uint32_t address = r7 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E434U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 524U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E438U, address);
            }
        }
        goto block_0019E43C;
    }
block_0019E43C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E43CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E43CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E43CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000A5U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019E458; }
        goto block_0019E448;
    }
block_0019E448:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E448U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E448U);
        }
        {
            r2 = 0x00000009U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E458U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E458U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E458;
    }
block_0019E458:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E458U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E458U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E458U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019E474; }
        goto block_0019E464;
    }
block_0019E464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E464U);
        }
        {
            r2 = 0x0000000CU;
        }
        {
            r1 = r5;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E474U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E474U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E474;
    }
block_0019E474:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E474U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E474U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E474U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r1 = r10;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r7 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0019E480U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E484U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) {
            r0 = 0x00000002U;
        }
        if ((flags.N()) != (flags.V())) {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E494U, address);
            }
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E4A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00345590_00345590(frame, context, state, 0x00345590U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E4A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E4A0;
    }
block_0019E4A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E4A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E4A0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E4A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r1 = 0x00000001U;
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E4B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_SetBGM_003655D0(frame, context, state, 0x003655D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E4B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E4B4;
    }
block_0019E4B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E4B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E4B4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E4B4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019E5DC; }
        goto block_0019E4C0;
    }
block_0019E4C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E4C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E4C0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            r2 = 0x00000005U;
        }
        {
            const uint32_t address = 0x0019E4D0U + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E4C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E4D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00345a08_00345A08(frame, context, state, 0x00345A08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E4D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E4D8;
    }
block_0019E4D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E4D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E4D8U);
        }
        {
            const uint32_t address = r8 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E4D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019E4E4U + 244U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E4DCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E4E4U, 0xEE201A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 444U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E4E8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E4ECU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E4F0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E4FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E4FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E4FC;
    }
block_0019E4FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E4FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E4FCU);
        }
        {
            const uint32_t address = r8 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E4FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E508U, 0xEE201A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E50CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r6 + 448U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E510U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E518U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E518U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E518;
    }
block_0019E518:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E518U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E518U);
        }
        {
            const uint32_t address = r8 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E518U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E524U, 0xEE201A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 452U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E528U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000A00U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E530U, 0xEE300A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E538U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E538U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E538;
    }
block_0019E538:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E538U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E538U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E544U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E550U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E550U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E550;
    }
block_0019E550:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E550U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E550U);
        }
        {
        }
        {
        }
        goto block_0019E5F8;
    }
block_0019E5DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E5DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E5DCU);
        }
        {
            const uint32_t address = r7 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E5DCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 516U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E5E0U, address);
            }
        }
        {
            const uint32_t address = r7 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E5E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E5E8U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 520U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E5ECU, address);
            }
        }
        {
            const uint32_t address = r7 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E5F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 524U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E5F4U, address);
            }
        }
        goto block_0019E5F8;
    }
block_0019E5F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E5F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E5F8U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E5F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0019E698; }
        goto block_0019E604;
    }
block_0019E604:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E604U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E604U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E604U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000096U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019EC54; }
        goto block_0019E610;
    }
block_0019E610:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E610U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E610U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0019E61CU + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E614U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019E618U, address);
            }
        }
        {
            const uint32_t address = r5 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0019E61CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0019E620U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x72U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E624U, address);
            }
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E62CU, address);
            }
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E634U, address);
            }
        }
        {
            const uint32_t address = r8 + 980U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019E638U, address);
            }
        }
        {
            r0 = 0x0000002DU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E640U, address);
            }
        }
        {
            r0 = 0x000000E1U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E648U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0019E654U + 0x36CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E64CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E650U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E65CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E65CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E65C;
    }
block_0019E65C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E65CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E65CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x0019E670U + 0x354U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E668U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E674U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E680U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_ChangeAnimation_00353020(frame, context, state, 0x00353020U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E680U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E680;
    }
block_0019E680:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E680U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E680U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r5 + operand;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E68CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_00370734_00370734(frame, context, state, 0x00370734U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E68CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E68C;
    }
block_0019E68C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E68CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E68CU);
        }
        {
        }
        {
        }
        goto block_0019EC54;
    }
block_0019E698:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E698U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E698U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E698U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0019EC54; }
        goto block_0019E6A4;
    }
block_0019E6A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E6A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E6A4U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E6A8U, address);
            }
        }
        {
            const uint32_t address = r8 + 980U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019E6ACU, address);
            }
        }
        {
            r0 = 0x00000014U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E6B4U, address);
            }
        }
        goto block_0019EC54;
    }
block_0019E6BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E6BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E6BCU);
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E6C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00345590_00345590(frame, context, state, 0x00345590U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E6C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E6C8;
    }
block_0019E6C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E6C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E6C8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E6C8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E6D0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E6D4U, 0xEE200A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E6DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E6DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E6DC;
    }
block_0019E6DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E6DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E6DCU);
        }
        {
            const uint32_t address = 0x0019E6E4U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E6DCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[23];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E6E8U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E6F0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E6F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E6F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E6F8;
    }
block_0019E6F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E6F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E6F8U);
        }
        {
            const uint32_t address = r8 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E6F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E704U, 0xEE201A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 444U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E708U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E70CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E710U, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E718U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E718U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E718;
    }
block_0019E718:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E718U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E718U);
        }
        {
            const uint32_t address = r8 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E718U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019E724U + 680U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E71CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E724U, 0xEE201A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 448U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E728U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E72CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E730U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E73CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E73CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E73C;
    }
block_0019E73C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E73CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E73CU);
        }
        {
            const uint32_t address = r8 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E73CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E748U, 0xEE201A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 452U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E74CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000A00U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E758U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E758U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E758;
    }
block_0019E758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E758U);
        }
        {
            const uint32_t address = r8 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E758U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E764U, 0xEE201A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 448U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E768U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E76CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E770U, 0xEE300A4AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E778U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E778U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E778;
    }
block_0019E778:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E778U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E778U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E788U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E790U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E790U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E790;
    }
block_0019E790:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E790U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E790U);
        }
        {
            const uint32_t address = r7 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E790U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E794U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x0019E7A0U + 0x230U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E798U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E79CU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E7A0U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0019EC54; }
        goto block_0019E7B0;
    }
block_0019E7B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E7B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E7B0U);
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E7B4U, address);
            }
        }
        {
            const uint32_t address = r8 + 980U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019E7B8U, address);
            }
        }
        {
            r0 = 0x0000002DU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E7C0U, address);
            }
        }
        {
            r0 = 0x000000E1U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E7C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0019E7D4U + 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E7CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E7D0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E7DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E7DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E7DC;
    }
block_0019E7DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E7DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E7DCU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x0019E7ECU + 0x1D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E7E4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x0019E7F0U + 484U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E7E8U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E7F4U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E800U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_ChangeAnimation_00353020(frame, context, state, 0x00353020U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E800U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E800;
    }
block_0019E800:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E800U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E800U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E818U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00345a08_00345A08(frame, context, state, 0x00345A08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E818U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E818;
    }
block_0019E818:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E818U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E818U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E818U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000001U;
        }
        goto block_0019E820;
    }
block_0019E820:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E820U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E820U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xADU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0019E820U, address);
            }
        }
        goto block_0019EC54;
    }
block_0019E828:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E828U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E828U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E828U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0019E84C; }
        goto block_0019E834;
    }
block_0019E834:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E834U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E834U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E84CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00345a08_00345A08(frame, context, state, 0x00345A08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E84CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E84C;
    }
block_0019E84C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E84CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E84CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[23];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E858U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E864U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E864U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E864;
    }
block_0019E864:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E864U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E864U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E864U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0019E870U + 364U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E868U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r7 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E86CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x0019E880U + 344U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E878U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E880U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E884U, 0xEE300A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E888U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r8 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E88CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E890U, 0xEE201AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E89CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E89CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E89C;
    }
block_0019E89C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E89CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E89CU);
        }
        {
            const uint32_t address = r8 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E89CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E8A8U, 0xEE201A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E8ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E8B0U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E8B4U, 0xEE300A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E8BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E8BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E8BC;
    }
block_0019E8BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E8BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E8BCU);
        }
        {
            const uint32_t address = r8 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E8BCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0019E8C8U - 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E8C0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E8C8U, 0xEE201A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E8CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000A00U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E8D4U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E8E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E8E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E8E0;
    }
block_0019E8E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E8E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E8E0U);
        }
        {
            const uint32_t address = r8 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E8E0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E8ECU, 0xEE201A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r6 + 444U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E8F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000204U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019E8FCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E904U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E904U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E904;
    }
block_0019E904:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E904U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E904U);
        }
        {
            const uint32_t address = r8 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E904U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E910U, 0xEE201A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E914U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r6 + 448U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E918U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E920U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E920U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E920;
    }
block_0019E920:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E920U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E920U);
        }
        {
            const uint32_t address = r8 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E920U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019E92CU, 0xEE201A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r6 + 452U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E934U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000020CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E940U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E940U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E940;
    }
block_0019E940:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E940U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E940U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E950U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E958U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E958U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E958;
    }
block_0019E958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E958U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = 0x0019E964U + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E95CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E968U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E968U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E968;
    }
block_0019E968:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E968U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E968U);
        }
        {
            const uint32_t address = 0x0019E970U + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E968U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0019E974U + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E96CU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0019E9F0; }
        goto block_0019E978;
    }
block_0019E978:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E978U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E978U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            r1 = 0x000001F4U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0019E984U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019E984U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019E984U,
                                           firstAddress + 8U);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            r3 = r2;
        }
        {
            const uint32_t operand = 0x000009E0U;
            r2 = r5 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E9A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnFloorDustRing_0036F00C(frame, context, state, 0x0036F00CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E9A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E9A4;
    }
block_0019E9A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E9A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E9A4U);
        }
        {
            const uint32_t updatedAddress = 0x0019E9ACU + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E9A4U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019E9B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019E9B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019E9B0;
    }
block_0019E9B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E9B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E9B0U);
        }
        {
        }
        {
        }
        goto block_0019EA48;
    }
block_0019E9F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019E9F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019E9F0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = 0x0019E9FCU + 844U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019E9F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EA00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EA00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EA00;
    }
block_0019EA00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EA00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EA00U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0019EA48; }
        goto block_0019EA0C;
    }
block_0019EA0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EA0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EA0CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            r1 = 0x000001F4U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0019EA18U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019EA18U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019EA18U,
                                           firstAddress + 8U);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            r3 = r2;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000001D4U;
            r2 = r2 + operand;
        }
        {
            r1 = r5;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EA3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnFloorDustRing_0036F00C(frame, context, state, 0x0036F00CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EA3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EA3C;
    }
block_0019EA3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EA3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EA3CU);
        }
        {
            const uint32_t updatedAddress = 0x0019EA44U - 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EA3CU, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EA48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EA48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EA48;
    }
block_0019EA48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EA48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EA48U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EA48U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019EA78; }
        goto block_0019EA54;
    }
block_0019EA54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EA54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EA54U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EA5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_00370734_00370734(frame, context, state, 0x00370734U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EA5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EA5C;
    }
block_0019EA5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EA5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EA5CU);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = 0x0019EA74U + 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EA6CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x000003D8U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EA78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EA78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EA78;
    }
block_0019EA78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EA78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EA78U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EA78U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000096U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0019EA88U + 0x2C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EA80U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EA8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EA8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EA8C;
    }
block_0019EA8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EA8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EA8CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EA8CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000087U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_0019EB5C; }
        goto block_0019EA98;
    }
block_0019EA98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EA98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EA98U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EA98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0019EAD0; }
        goto block_0019EAA4;
    }
block_0019EAA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EAA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EAA4U);
        }
        {
            r3 = 0x00000040U;
        }
        {
            r2 = 0x00000100U;
        }
        {
            r1 = 0x000000B4U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0019EAB0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019EAB0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019EAB0U,
                                           firstAddress + 8U);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r10 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x368U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EABCU, address);
            }
            r2 = value;
        }
        {
            r3 = 0x000000C8U;
        }
        {
            const uint32_t operand = 0x0000024CU;
            r1 = r1 + operand;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EAD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TitleCard_InitBossName_00354248(frame, context, state, 0x00354248U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EAD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EAD0;
    }
block_0019EAD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EAD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EAD0U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x0019EADCU + 0x278U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EAD4U, address);
            }
            r1 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EAE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_QueueSeqCmd_0036EC40(frame, context, state, 0x0036EC40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EAE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EAE0;
    }
block_0019EAE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EAE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EAE0U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EAECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b164_0035B164(frame, context, state, 0x0035B164U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EAECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EAEC;
    }
block_0019EAEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EAECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EAECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0019EB5C; }
        goto block_0019EAF8;
    }
block_0019EAF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EAF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EAF8U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EAFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b0a0_0035B0A0(frame, context, state, 0x0035B0A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EAFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EAFC;
    }
block_0019EAFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EAFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EAFCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0019EB5C; }
        goto block_0019EB08;
    }
block_0019EB08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EB08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EB08U);
        }
        {
            const uint32_t updatedAddress = 0x0019EB10U - 0x5B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EB08U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EB0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0019EB4C; }
        goto block_0019EB18;
    }
block_0019EB18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EB18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EB18U);
        }
        {
            const uint32_t updatedAddress = 0x0019EB20U - 0x5C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EB18U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EB20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EB20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EB20;
    }
block_0019EB20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EB20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EB20U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0019EB4C; }
        goto block_0019EB2C;
    }
block_0019EB2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EB2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EB2CU);
        }
        {
            const uint32_t updatedAddress = 0x0019EB34U - 0x5D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EB2CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EB34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EB34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EB34;
    }
block_0019EB34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EB34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EB34U);
        }
        {
            const uint32_t updatedAddress = 0x0019EB3CU - 0x5D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EB34U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0019EB40U - 0x5D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EB38U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x0019EB48U - 0x5ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EB40U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_0019EB4C;
    }
block_0019EB4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EB4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EB4CU);
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EB50U, address);
            }
            r0 = value;
        }
        {
            r1 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EB5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003542c4_003542C4(frame, context, state, 0x003542C4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EB5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EB5C;
    }
block_0019EB5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EB5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EB5CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EB5CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019EC54; }
        goto block_0019EB68;
    }
block_0019EB68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EB68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EB68U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            r2 = ~(0x00000000U);
        }
        {
            r1 = r10;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EB80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00345a08_00345A08(frame, context, state, 0x00345A08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EB80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EB80;
    }
block_0019EB80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EB80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EB80U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EB80U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r11 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019EB88U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019EB88U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0019EB88U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019EB8CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019EB8CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0019EB8CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r0 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EB94U, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019EB98U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019EB98U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0019EB98U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019EB9CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019EB9CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0019EB9CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EBA4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019EBA8U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019EBA8U,
                                           firstAddress + 4U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0019EBA8U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r11 = value11;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019EBACU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019EBACU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0019EBACU,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x84U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EBB4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EBC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EBC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EBC0;
    }
block_0019EBC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EBC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EBC0U);
        }
        {
            r11 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x84U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0019EBC4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EBC8U, address);
            }
            r1 = value;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EBD4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EBD4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EBD4;
    }
block_0019EBD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EBD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EBD4U);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EBE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EBE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EBE4;
    }
block_0019EBE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EBE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EBE4U);
        }
        {
            const uint32_t updatedAddress = 0x0019EBECU - 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EBE4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EBE8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EBF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EBF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EBF4;
    }
block_0019EBF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EBF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EBF4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x0019EC04U + 0x158U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EBFCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x0019EC08U + 336U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EC00U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019EC0CU, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EC18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_ChangeAnimation_00353020(frame, context, state, 0x00353020U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EC18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EC18;
    }
block_0019EC18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EC18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EC18U);
        }
        {
            const uint32_t updatedAddress = 0x0019EC20U + 0x140U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EC18U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x7AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0019EC1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x760U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019EC20U, address);
            }
        }
        {
            const uint32_t address = r8 + 948U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019EC24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EC28U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019EC30U, address);
            }
        }
        {
            r0 = 0x0000004BU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019EC38U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0019EC44U + 0x120U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EC3CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0019EC40U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019EC44U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EC48U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r9 + 0xFAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019EC50U, address);
            }
        }
        goto block_0019EC54;
    }
block_0019EC54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EC54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EC54U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x84U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EC54U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0019ED3C; }
        goto block_0019EC60;
    }
block_0019EC60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EC60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EC60U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x86U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EC60U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0019EC6CU + 252U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EC64U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0019EC70U + 252U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EC68U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x86U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019EC74U, address);
            }
        }
        {
            const uint32_t address = r6 + 504U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EC78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019EC7CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x86U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EC80U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019EC88U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019EC8CU, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019EC90U, 0xEE200A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019EC94U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019EC9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019EC9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019EC9C;
    }
block_0019EC9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019EC9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019EC9CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x86U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019EC9CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0019ECA8U + 200U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019ECA0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019ECA8U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019ECACU, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 508U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019ECB0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019ECB4U, 0xEE000A88U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019ECB8U, address);
            }
        }
        {
            const uint32_t address = r6 + 512U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019ECBCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019ECC0U, address);
            }
        }
        {
            const uint32_t address = r6 + 516U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019ECC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019ECC8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x86U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019ECCCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019ECD4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019ECD8U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019ECDCU, 0xEE200A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019ECE0U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019ECE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019ECE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019ECE8;
    }
block_0019ECE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019ECE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019ECE8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x86U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019ECE8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r2 = r13 + operand;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            r0 = r10;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019ECFCU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019ED00U, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 520U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019ED04U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019ED08U, 0xEE000A88U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019ED0CU, address);
            }
        }
        {
            const uint32_t address = r6 + 524U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019ED10U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019ED14U, address);
            }
        }
        {
            const uint32_t address = r8 + 988U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019ED18U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019ED1CU, address);
            }
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0019ED20U, address);
            }
        }
        {
            const uint32_t address = r8 + 988U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019ED24U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019ED28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0019ED2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x84U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019ED30U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x0000001CU;
            r3 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019ED3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b1cc_0035B1CC(frame, context, state, 0x0035B1CCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019ED3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019ED3C;
    }
block_0019ED3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019ED3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019ED3CU);
        }
        {
            const uint32_t operand = 0x0000004CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0019ED40U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0019ED40U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019ED40U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019ED40U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0019ED40U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0019ED40U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0019ED40U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0019ED40U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0019ED40U,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0019ED40U,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0019ED40U,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0019ED40U,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            r13 += 48U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0019ED44U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0019ED44U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0019ED44U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0019ED44U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0019ED44U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0019ED44U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0019ED44U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0019ED44U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0019ED44U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_001c6138_001C6138(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001C6138U:
        goto block_001C6138;
    case 0x001C6160U:
        goto block_001C6160;
    case 0x001C6170U:
        goto block_001C6170;
    case 0x001C6178U:
        goto block_001C6178;
    case 0x001C6184U:
        goto block_001C6184;
    case 0x001C6188U:
        goto block_001C6188;
    case 0x001C6198U:
        goto block_001C6198;
    case 0x001C61A4U:
        goto block_001C61A4;
    case 0x001C61B0U:
        goto block_001C61B0;
    case 0x001C61BCU:
        goto block_001C61BC;
    case 0x001C61CCU:
        goto block_001C61CC;
    case 0x001C61DCU:
        goto block_001C61DC;
    case 0x001C623CU:
        goto block_001C623C;
    case 0x001C6258U:
        goto block_001C6258;
    case 0x001C6264U:
        goto block_001C6264;
    case 0x001C6288U:
        goto block_001C6288;
    case 0x001C6294U:
        goto block_001C6294;
    case 0x001C62C0U:
        goto block_001C62C0;
    case 0x001C62D4U:
        goto block_001C62D4;
    case 0x001C62E8U:
        goto block_001C62E8;
    case 0x001C62F8U:
        goto block_001C62F8;
    case 0x001C6344U:
        goto block_001C6344;
    case 0x001C6350U:
        goto block_001C6350;
    case 0x001C635CU:
        goto block_001C635C;
    case 0x001C6374U:
        goto block_001C6374;
    case 0x001C638CU:
        goto block_001C638C;
    case 0x001C63A4U:
        goto block_001C63A4;
    case 0x001C63BCU:
        goto block_001C63BC;
    case 0x001C63D4U:
        goto block_001C63D4;
    case 0x001C63ECU:
        goto block_001C63EC;
    case 0x001C6404U:
        goto block_001C6404;
    case 0x001C6414U:
        goto block_001C6414;
    case 0x001C6420U:
        goto block_001C6420;
    case 0x001C64A8U:
        goto block_001C64A8;
    case 0x001C64B0U:
        goto block_001C64B0;
    case 0x001C64BCU:
        goto block_001C64BC;
    case 0x001C64C8U:
        goto block_001C64C8;
    case 0x001C64E0U:
        goto block_001C64E0;
    case 0x001C64F8U:
        goto block_001C64F8;
    case 0x001C6510U:
        goto block_001C6510;
    case 0x001C6528U:
        goto block_001C6528;
    case 0x001C6540U:
        goto block_001C6540;
    case 0x001C6558U:
        goto block_001C6558;
    case 0x001C6570U:
        goto block_001C6570;
    case 0x001C658CU:
        goto block_001C658C;
    case 0x001C6590U:
        goto block_001C6590;
    case 0x001C6598U:
        goto block_001C6598;
    case 0x001C65B8U:
        goto block_001C65B8;
    case 0x001C65D0U:
        goto block_001C65D0;
    case 0x001C65E8U:
        goto block_001C65E8;
    case 0x001C6600U:
        goto block_001C6600;
    case 0x001C6618U:
        goto block_001C6618;
    case 0x001C6630U:
        goto block_001C6630;
    case 0x001C6640U:
        goto block_001C6640;
    case 0x001C664CU:
        goto block_001C664C;
    case 0x001C6684U:
        goto block_001C6684;
    case 0x001C66A4U:
        goto block_001C66A4;
    case 0x001C66B4U:
        goto block_001C66B4;
    case 0x001C66C0U:
        goto block_001C66C0;
    case 0x001C66C8U:
        goto block_001C66C8;
    case 0x001C66D4U:
        goto block_001C66D4;
    case 0x001C66D8U:
        goto block_001C66D8;
    case 0x001C66DCU:
        goto block_001C66DC;
    case 0x001C66E8U:
        goto block_001C66E8;
    case 0x001C66F4U:
        goto block_001C66F4;
    case 0x001C6720U:
        goto block_001C6720;
    case 0x001C6748U:
        goto block_001C6748;
    case 0x001C6754U:
        goto block_001C6754;
    case 0x001C675CU:
        goto block_001C675C;
    case 0x001C6768U:
        goto block_001C6768;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001C6138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6138U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001C6138U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001C6138U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001C6138U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001C6138U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001C6138U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001C6138U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001C6138U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001C6138U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001C6138U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r11 = r1;
        }
        {
            r13 -= 24U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001C6144U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C6144U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001C6144U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001C6144U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x001C6144U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x001C6144U,
                                           firstAddress + 20U);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xAE4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C614CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001C6158U + 776U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6150U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x001C615CU + 776U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6154U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001C61DC; }
        goto block_001C6160;
    }
block_001C6160:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6160U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6160U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[21];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x000001E4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6170U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6170U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6170;
    }
block_001C6170:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6170U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6170U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001C6188; }
        goto block_001C6178;
    }
block_001C6178:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6178U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6178U);
        }
        {
            const uint32_t updatedAddress = 0x001C6180U + 0x2E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6178U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6184U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6184U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6184;
    }
block_001C6184:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6184U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6184U);
        }
        goto block_001C61DC;
    }
block_001C6188:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6188U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6188U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[21];
        }
        {
            const uint32_t address = 0x001C6194U + 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C618CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001E4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6198U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6198U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6198;
    }
block_001C6198:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6198U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6198U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001C61BC; }
        goto block_001C61A4;
    }
block_001C61A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C61A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C61A4U);
        }
        {
            const uint32_t updatedAddress = 0x001C61ACU + 0x2C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C61A4U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C61B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C61B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C61B0;
    }
block_001C61B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C61B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C61B0U);
        }
        {
        }
        {
        }
        goto block_001C61DC;
    }
block_001C61BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C61BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C61BCU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[21];
        }
        {
            const uint32_t address = 0x001C61C8U + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C61C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001E4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C61CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C61CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C61CC;
    }
block_001C61CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C61CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C61CCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x001C61D8U + 0x2A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C61D0U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            r0 = r4;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x001C61DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C61DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C61DC;
    }
block_001C61DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C61DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C61DCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAE4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C61DCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000030CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001C61E8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000318U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001C61F4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t address = 0x001C6204U + 632U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C61FCU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t operand = 0x0000031CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t address = 0x001C620CU + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6204U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x001C6210U + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6208U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x001C6214U + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C620CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r7 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r6 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r8 = 0x00000003U;
        }
        {
            r9 = 0x00000002U;
        }
        {
            r10 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000314U;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000308U;
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r5 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001C6234U, address);
            }
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x001C6240U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6238U, address);
            }
            switch (value) {
            case 0x001C6138U:
                goto block_001C6138;
            case 0x001C6160U:
                goto block_001C6160;
            case 0x001C6170U:
                goto block_001C6170;
            case 0x001C6178U:
                goto block_001C6178;
            case 0x001C6184U:
                goto block_001C6184;
            case 0x001C6188U:
                goto block_001C6188;
            case 0x001C6198U:
                goto block_001C6198;
            case 0x001C61A4U:
                goto block_001C61A4;
            case 0x001C61B0U:
                goto block_001C61B0;
            case 0x001C61BCU:
                goto block_001C61BC;
            case 0x001C61CCU:
                goto block_001C61CC;
            case 0x001C61DCU:
                goto block_001C61DC;
            case 0x001C623CU:
                goto block_001C623C;
            case 0x001C6258U:
                goto block_001C6258;
            case 0x001C6264U:
                goto block_001C6264;
            case 0x001C6288U:
                goto block_001C6288;
            case 0x001C6294U:
                goto block_001C6294;
            case 0x001C62C0U:
                goto block_001C62C0;
            case 0x001C62D4U:
                goto block_001C62D4;
            case 0x001C62E8U:
                goto block_001C62E8;
            case 0x001C62F8U:
                goto block_001C62F8;
            case 0x001C6344U:
                goto block_001C6344;
            case 0x001C6350U:
                goto block_001C6350;
            case 0x001C635CU:
                goto block_001C635C;
            case 0x001C6374U:
                goto block_001C6374;
            case 0x001C638CU:
                goto block_001C638C;
            case 0x001C63A4U:
                goto block_001C63A4;
            case 0x001C63BCU:
                goto block_001C63BC;
            case 0x001C63D4U:
                goto block_001C63D4;
            case 0x001C63ECU:
                goto block_001C63EC;
            case 0x001C6404U:
                goto block_001C6404;
            case 0x001C6414U:
                goto block_001C6414;
            case 0x001C6420U:
                goto block_001C6420;
            case 0x001C64A8U:
                goto block_001C64A8;
            case 0x001C64B0U:
                goto block_001C64B0;
            case 0x001C64BCU:
                goto block_001C64BC;
            case 0x001C64C8U:
                goto block_001C64C8;
            case 0x001C64E0U:
                goto block_001C64E0;
            case 0x001C64F8U:
                goto block_001C64F8;
            case 0x001C6510U:
                goto block_001C6510;
            case 0x001C6528U:
                goto block_001C6528;
            case 0x001C6540U:
                goto block_001C6540;
            case 0x001C6558U:
                goto block_001C6558;
            case 0x001C6570U:
                goto block_001C6570;
            case 0x001C658CU:
                goto block_001C658C;
            case 0x001C6590U:
                goto block_001C6590;
            case 0x001C6598U:
                goto block_001C6598;
            case 0x001C65B8U:
                goto block_001C65B8;
            case 0x001C65D0U:
                goto block_001C65D0;
            case 0x001C65E8U:
                goto block_001C65E8;
            case 0x001C6600U:
                goto block_001C6600;
            case 0x001C6618U:
                goto block_001C6618;
            case 0x001C6630U:
                goto block_001C6630;
            case 0x001C6640U:
                goto block_001C6640;
            case 0x001C664CU:
                goto block_001C664C;
            case 0x001C6684U:
                goto block_001C6684;
            case 0x001C66A4U:
                goto block_001C66A4;
            case 0x001C66B4U:
                goto block_001C66B4;
            case 0x001C66C0U:
                goto block_001C66C0;
            case 0x001C66C8U:
                goto block_001C66C8;
            case 0x001C66D4U:
                goto block_001C66D4;
            case 0x001C66D8U:
                goto block_001C66D8;
            case 0x001C66DCU:
                goto block_001C66DC;
            case 0x001C66E8U:
                goto block_001C66E8;
            case 0x001C66F4U:
                goto block_001C66F4;
            case 0x001C6720U:
                goto block_001C6720;
            case 0x001C6748U:
                goto block_001C6748;
            case 0x001C6754U:
                goto block_001C6754;
            case 0x001C675CU:
                goto block_001C675C;
            case 0x001C6768U:
                goto block_001C6768;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_001C623C;
    }
block_001C623C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C623CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C623CU);
        }
        goto block_001C675C;
    }
block_001C6258:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6258U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6258U);
        }
        {
            r1 = 0x00000019U;
        }
        {
            const uint32_t operand = 0x000001E4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6264U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6264U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6264;
    }
block_001C6264:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6264U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6264U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = 0x00000019U;
        }
        {
            const uint32_t operand = 0x000001E4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C6278U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6288U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6288U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6288;
    }
block_001C6288:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6288U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6288U);
        }
        {
            r1 = ~(0x00000000U);
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6294U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6294U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6294;
    }
block_001C6294:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6294U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6294U);
        }
        {
            const uint32_t operand = 0x0000008CU;
            r8 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C629CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C629CU,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001C629CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r9 = value9;
        }
        {
            const uint32_t operand = 0x00000324U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C62A4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C62A4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001C62A4U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000080U;
            r9 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000B30U;
            r0 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r9;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C62B0U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C62B0U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C62B0U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C62B4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C62B4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C62B4U,
                                           firstAddress + 8U);
            }
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C62C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C62C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C62C0;
    }
block_001C62C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C62C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C62C0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C62C0U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C62D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C62D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C62D4;
    }
block_001C62D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C62D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C62D4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C62D4U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000007U;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C62E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C62E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C62E8;
    }
block_001C62E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C62E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C62E8U);
        }
        {
            r2 = 0x00000005U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C62F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C62F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C62F8;
    }
block_001C62F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C62F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C62F8U);
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001C62F8U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C62F8U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C62F8U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t address = 0x001C6304U + 392U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C62FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001C6300U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C6300U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C6300U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r9;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001C6304U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C6304U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C6304U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r7;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001C6308U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C6308U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C6308U,
                                           firstAddress + 8U);
            }
        }
        {
            r0 = 0x00000014U;
        }
        {
            const uint32_t address = r5 + 764U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001C6310U, address);
            }
        }
        {
            const uint32_t address = r5 + 768U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C6314U, address);
            }
        }
        {
            const uint32_t address = 0x001C6320U + 368U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6318U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 772U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C631CU, address);
            }
        }
        {
            const uint32_t address = 0x001C6328U + 364U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6320U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 752U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C6324U, address);
            }
        }
        {
            const uint32_t address = 0x001C6330U + 360U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6328U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 756U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C632CU, address);
            }
        }
        {
            const uint32_t address = 0x001C6338U + 356U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6330U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001C6334U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xAE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C6338U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xAE4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001C633CU, address);
            }
        }
        goto block_001C6768;
    }
block_001C6344:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6344U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6344U);
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6350U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0036d260_0036D260(frame, context, state, 0x0036D260U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6350U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6350;
    }
block_001C6350:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6350U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6350U);
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C635CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0036d260_0036D260(frame, context, state, 0x0036D260U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C635CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C635C;
    }
block_001C635C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C635CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C635CU);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r5 + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6364U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 752U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6368U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6374U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6374U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6374;
    }
block_001C6374:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6374U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6374U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C637CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6380U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6384U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C638CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C638CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C638C;
    }
block_001C638C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C638CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C638CU);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r5 + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6394U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6398U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000B10U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C63A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C63A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C63A4;
    }
block_001C63A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C63A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C63A4U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r5 + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C63ACU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 764U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C63B0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C63BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C63BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C63BC;
    }
block_001C63BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C63BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C63BCU);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C63C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C63C8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 768U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C63CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C63D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C63D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C63D4;
    }
block_001C63D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C63D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C63D4U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C63DCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C63E0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C63E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C63ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C63ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C63EC;
    }
block_001C63EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C63ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C63ECU);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00000B20U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6404U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6404U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6404;
    }
block_001C6404:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6404U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6404U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAE8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6404U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C640CU, address);
            }
        }
        if (!(flags.Z())) { goto block_001C675C; }
        goto block_001C6414;
    }
block_001C6414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6414U);
        }
        {
            r1 = 0x00000019U;
        }
        {
            const uint32_t operand = 0x000001E4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6420U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6420U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6420;
    }
block_001C6420:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6420U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6420U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x001C642CU + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6424U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x001C6430U + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6428U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C642CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C6430U, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C6438U, 0xEE200A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C6440U, 0xDE101A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C6444U, 0xCE001A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C6448U, 0xEEBD0AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C6454U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xAE4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x001C6458U, address);
            }
        }
        goto block_001C6768;
    }
block_001C64A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C64A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C64A8U);
        }
        {
            const uint32_t operand = 0x000001E4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C64B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C64B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C64B0;
    }
block_001C64B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C64B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C64B0U);
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C64BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0036d260_0036D260(frame, context, state, 0x0036D260U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C64BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C64BC;
    }
block_001C64BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C64BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C64BCU);
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C64C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0036d260_0036D260(frame, context, state, 0x0036D260U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C64C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C64C8;
    }
block_001C64C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C64C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C64C8U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r5 + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C64D0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 752U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C64D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C64E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C64E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C64E0;
    }
block_001C64E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C64E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C64E0U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C64E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C64ECU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C64F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C64F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C64F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C64F8;
    }
block_001C64F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C64F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C64F8U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r5 + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6500U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6504U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000B10U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6510U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6510U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6510;
    }
block_001C6510:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6510U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6510U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r5 + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6518U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 764U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C651CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6528U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6528U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6528;
    }
block_001C6528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6528U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6530U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6534U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 768U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6538U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6540U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6540U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6540;
    }
block_001C6540:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6540U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6540U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6548U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C654CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6550U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6558U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6558U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6558;
    }
block_001C6558:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6558U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6558U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00000B20U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6570U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6570U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6570;
    }
block_001C6570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6570U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAE8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6570U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C6578U, address);
            }
        }
        if (flags.Z()) {
            r0 = 0x0000001EU;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xAE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C6580U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xAE4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C6584U, address);
            }
        }
        if (flags.Z()) { goto block_001C6768; }
        goto block_001C658C;
    }
block_001C658C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C658CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C658CU);
        }
        goto block_001C675C;
    }
block_001C6590:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6590U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6590U);
        }
        {
            const uint32_t operand = 0x000001E4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6598U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6598U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6598;
    }
block_001C6598:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6598U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6598U);
        }
        {
            const uint32_t address = 0x001C65A0U + 492U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6598U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x001C65A4U + 492U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C659CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r5 + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C65ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C65B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C65B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C65B8;
    }
block_001C65B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C65B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C65B8U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C65C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 820U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C65C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C65D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C65D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C65D0;
    }
block_001C65D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C65D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C65D0U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C65DCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 824U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C65E0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C65E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C65E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C65E8;
    }
block_001C65E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C65E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C65E8U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r5 + 804U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C65F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6600U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6600U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6600;
    }
block_001C6600:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6600U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6600U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C660CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 808U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6610U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6618U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6618U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6618;
    }
block_001C6618:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6618U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6618U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r5 + 812U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6624U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000B10U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6630U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6630U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6630;
    }
block_001C6630:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6630U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6630U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAE8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6630U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C6638U, address);
            }
        }
        if (!(flags.Z())) { goto block_001C675C; }
        goto block_001C6640;
    }
block_001C6640:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6640U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6640U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C664CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C664CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C664C;
    }
block_001C664C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C664CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C664CU);
        }
        {
            const uint32_t firstAddress = r6;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C664CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C664CU,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C664CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C6654U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C6654U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001C6654U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r6;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C665CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C665CU,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C665CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C6664U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C6664U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001C6664U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C6668U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C6668U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C6668U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001C666CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001C666CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001C666CU,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6674U, address);
            }
            r0 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6684U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6684U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6684;
    }
block_001C6684:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6684U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6684U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C668CU, address);
            }
        }
        {
            r3 = 0x00000005U;
        }
        {
            r2 = r4;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r1 + operand;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C66A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ChangeType_00375D3C(frame, context, state, 0x00375D3CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C66A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C66A4;
    }
block_001C66A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C66A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C66A4U);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C66B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C66B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C66B4;
    }
block_001C66B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C66B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C66B4U);
        }
        {
            r0 = 0x00000004U;
        }
        {
        }
        goto block_001C66D8;
    }
block_001C66C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C66C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C66C0U);
        }
        {
            const uint32_t operand = 0x000001E4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C66C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C66C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C66C8;
    }
block_001C66C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C66C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C66C8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001C675C; }
        goto block_001C66D4;
    }
block_001C66D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C66D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C66D4U);
        }
        {
            r0 = 0x00000005U;
        }
        goto block_001C66D8;
    }
block_001C66D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C66D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C66D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAE4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C66D8U, address);
            }
        }
        goto block_001C66DC;
    }
block_001C66DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C66DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C66DCU);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001C66E0U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C66E0U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C66E0U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C66E0U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C66E0U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C66E0U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            r13 += 24U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C66E4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C66E4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C66E4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C66E4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001C66E4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001C66E4U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001C66E4U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001C66E4U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001C66E4U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_001C66E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C66E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C66E8U);
        }
        {
            r1 = 0x0000000FU;
        }
        {
            const uint32_t operand = 0x000001E4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C66F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C66F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C66F4;
    }
block_001C66F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C66F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C66F4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8ECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C6700U, address);
            }
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = 0x0000000FU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001C670CU, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            const uint32_t address = 0x001C671CU + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6714U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001E4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001C6720U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001C6720U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001C6720;
    }
block_001C6720:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6720U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6720U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xFAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001C6720U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6724U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6728U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000258U;
            r2 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000900U;
            r0 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x000004B0U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x001C6740U, address);
            }
        }
        if (!(flags.C()) || (flags.Z())) { goto block_001C6754; }
        goto block_001C6748;
    }
block_001C6748:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6748U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6748U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001C674CU, address);
            }
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001C6750U, address);
            }
        }
        goto block_001C6754;
    }
block_001C6754:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6754U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6754U);
        }
        {
            const uint32_t updatedAddress = 0x001C675CU + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6754U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x8F0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001C6758U, address);
            }
        }
        goto block_001C675C;
    }
block_001C675C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C675CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C675CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAE4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C675CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001C66DC; }
        goto block_001C6768;
    }
block_001C6768:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001C6768U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001C6768U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xAECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001C6768U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r13 = r13 + operand;
        }
        {
            r3 = r6;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001C6774U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001C6774U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001C6774U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001C6774U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C6774U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C6774U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            r13 += 24U;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            r2 = r7;
        }
        {
            r0 = r11;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001C6784U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001C6784U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001C6784U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001C6784U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001C6784U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001C6784U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001C6784U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001C6784U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001C6784U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r14 = value14;
            r13 = r13 + 36U;
        }
        return Oot3dAotBranch(0x00367B14U);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_BossDodongo_Update_0027BE30(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0027BE30U:
        goto block_0027BE30;
    case 0x0027BF00U:
        goto block_0027BF00;
    case 0x0027BF14U:
        goto block_0027BF14;
    case 0x0027BF28U:
        goto block_0027BF28;
    case 0x0027BF3CU:
        goto block_0027BF3C;
    case 0x0027BF60U:
        goto block_0027BF60;
    case 0x0027BF6CU:
        goto block_0027BF6C;
    case 0x0027BF78U:
        goto block_0027BF78;
    case 0x0027BF7CU:
        goto block_0027BF7C;
    case 0x0027BFC8U:
        goto block_0027BFC8;
    case 0x0027BFE0U:
        goto block_0027BFE0;
    case 0x0027BFF8U:
        goto block_0027BFF8;
    case 0x0027C010U:
        goto block_0027C010;
    case 0x0027C024U:
        goto block_0027C024;
    case 0x0027C030U:
        goto block_0027C030;
    case 0x0027C03CU:
        goto block_0027C03C;
    case 0x0027C040U:
        goto block_0027C040;
    case 0x0027C068U:
        goto block_0027C068;
    case 0x0027C0A4U:
        goto block_0027C0A4;
    case 0x0027C0C4U:
        goto block_0027C0C4;
    case 0x0027C0E8U:
        goto block_0027C0E8;
    case 0x0027C0F8U:
        goto block_0027C0F8;
    case 0x0027C108U:
        goto block_0027C108;
    case 0x0027C130U:
        goto block_0027C130;
    case 0x0027C13CU:
        goto block_0027C13C;
    case 0x0027C148U:
        goto block_0027C148;
    case 0x0027C16CU:
        goto block_0027C16C;
    case 0x0027C18CU:
        goto block_0027C18C;
    case 0x0027C1A8U:
        goto block_0027C1A8;
    case 0x0027C1B8U:
        goto block_0027C1B8;
    case 0x0027C1C0U:
        goto block_0027C1C0;
    case 0x0027C1C8U:
        goto block_0027C1C8;
    case 0x0027C1F0U:
        goto block_0027C1F0;
    case 0x0027C204U:
        goto block_0027C204;
    case 0x0027C264U:
        goto block_0027C264;
    case 0x0027C278U:
        goto block_0027C278;
    case 0x0027C28CU:
        goto block_0027C28C;
    case 0x0027C2BCU:
        goto block_0027C2BC;
    case 0x0027C2DCU:
        goto block_0027C2DC;
    case 0x0027C2E8U:
        goto block_0027C2E8;
    case 0x0027C300U:
        goto block_0027C300;
    case 0x0027C318U:
        goto block_0027C318;
    case 0x0027C37CU:
        goto block_0027C37C;
    case 0x0027C388U:
        goto block_0027C388;
    case 0x0027C390U:
        goto block_0027C390;
    case 0x0027C3A8U:
        goto block_0027C3A8;
    case 0x0027C3C4U:
        goto block_0027C3C4;
    case 0x0027C3D0U:
        goto block_0027C3D0;
    case 0x0027C3F0U:
        goto block_0027C3F0;
    case 0x0027C40CU:
        goto block_0027C40C;
    case 0x0027C428U:
        goto block_0027C428;
    case 0x0027C444U:
        goto block_0027C444;
    case 0x0027C45CU:
        goto block_0027C45C;
    case 0x0027C468U:
        goto block_0027C468;
    case 0x0027C4A0U:
        goto block_0027C4A0;
    case 0x0027C4B8U:
        goto block_0027C4B8;
    case 0x0027C4D4U:
        goto block_0027C4D4;
    case 0x0027C4F4U:
        goto block_0027C4F4;
    case 0x0027C504U:
        goto block_0027C504;
    case 0x0027C50CU:
        goto block_0027C50C;
    case 0x0027C514U:
        goto block_0027C514;
    case 0x0027C528U:
        goto block_0027C528;
    case 0x0027C534U:
        goto block_0027C534;
    case 0x0027C548U:
        goto block_0027C548;
    case 0x0027C558U:
        goto block_0027C558;
    case 0x0027C564U:
        goto block_0027C564;
    case 0x0027C5C8U:
        goto block_0027C5C8;
    case 0x0027C5D8U:
        goto block_0027C5D8;
    case 0x0027C5F0U:
        goto block_0027C5F0;
    case 0x0027C624U:
        goto block_0027C624;
    case 0x0027C628U:
        goto block_0027C628;
    case 0x0027C634U:
        goto block_0027C634;
    case 0x0027C640U:
        goto block_0027C640;
    case 0x0027C658U:
        goto block_0027C658;
    case 0x0027C6A4U:
        goto block_0027C6A4;
    case 0x0027C6B0U:
        goto block_0027C6B0;
    case 0x0027C6D8U:
        goto block_0027C6D8;
    case 0x0027C6E4U:
        goto block_0027C6E4;
    case 0x0027C6F0U:
        goto block_0027C6F0;
    case 0x0027C708U:
        goto block_0027C708;
    case 0x0027C720U:
        goto block_0027C720;
    case 0x0027C734U:
        goto block_0027C734;
    case 0x0027C740U:
        goto block_0027C740;
    case 0x0027C74CU:
        goto block_0027C74C;
    case 0x0027C758U:
        goto block_0027C758;
    case 0x0027C764U:
        goto block_0027C764;
    case 0x0027C770U:
        goto block_0027C770;
    case 0x0027C788U:
        goto block_0027C788;
    case 0x0027C79CU:
        goto block_0027C79C;
    case 0x0027C7BCU:
        goto block_0027C7BC;
    case 0x0027C7C8U:
        goto block_0027C7C8;
    case 0x0027C80CU:
        goto block_0027C80C;
    case 0x0027C81CU:
        goto block_0027C81C;
    case 0x0027C830U:
        goto block_0027C830;
    case 0x0027C840U:
        goto block_0027C840;
    case 0x0027C84CU:
        goto block_0027C84C;
    case 0x0027C85CU:
        goto block_0027C85C;
    case 0x0027C860U:
        goto block_0027C860;
    case 0x0027C87CU:
        goto block_0027C87C;
    case 0x0027C898U:
        goto block_0027C898;
    case 0x0027C8A8U:
        goto block_0027C8A8;
    case 0x0027C8CCU:
        goto block_0027C8CC;
    case 0x0027C8DCU:
        goto block_0027C8DC;
    case 0x0027C8E8U:
        goto block_0027C8E8;
    case 0x0027C8F8U:
        goto block_0027C8F8;
    case 0x0027C958U:
        goto block_0027C958;
    case 0x0027C960U:
        goto block_0027C960;
    case 0x0027C970U:
        goto block_0027C970;
    case 0x0027C988U:
        goto block_0027C988;
    case 0x0027C99CU:
        goto block_0027C99C;
    case 0x0027C9E0U:
        goto block_0027C9E0;
    case 0x0027C9F4U:
        goto block_0027C9F4;
    case 0x0027CA08U:
        goto block_0027CA08;
    case 0x0027CA30U:
        goto block_0027CA30;
    case 0x0027CA3CU:
        goto block_0027CA3C;
    case 0x0027CB18U:
        goto block_0027CB18;
    case 0x0027CB78U:
        goto block_0027CB78;
    case 0x0027CB8CU:
        goto block_0027CB8C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0027BE30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027BE30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027BE30U);
        }
        {
            const uint32_t firstAddress = r13 - 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0027BE30U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0027BE30U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0027BE30U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0027BE30U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0027BE30U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0027BE30U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0027BE30U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0027BE30U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0027BE30U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0027BE30U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0027BE30U,
                                           firstAddress + 40U);
            }
            r13 = r13 - 44U;
        }
        {
            r4 = 0x00000000U;
        }
        {
            r13 -= 64U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 44U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 48U, frame.Guest.vfp[28])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 48U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 52U, frame.Guest.vfp[29])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 52U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 56U, frame.Guest.vfp[30])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 56U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 60U, frame.Guest.vfp[31])) {
                return Oot3dAotMemoryFault(context, 0x0027BE38U,
                                           firstAddress + 60U);
            }
        }
        {
            const uint32_t operand = 0x00000024U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BE40U, address);
            }
            r5 = value;
        }
        {
            const uint32_t address = 0x0027BE4CU + 988U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BE44U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x0027BE50U + 988U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BE48U, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BE4CU, address);
            }
            r9 = value;
        }
        {
            const uint32_t address = r5 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BE50U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BE54U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000700U;
            r6 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00002000U;
            r10 = r9 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BE60U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0027BE6CU + 964U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BE64U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BE68U, 0xEE200A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BE6CU, 0xEE400A4DU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[26], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0027BE70U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x7B2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0027BE74U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BE78U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x6EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027BE80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BE84U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0xAAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027BE90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xACU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BE94U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0xACU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027BEA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xAEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BEA4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0xAEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027BEB0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x90U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BEB4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027BEC0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x98U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BEC4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027BED0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BED4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BED8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BEDCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BEE0U, 0xEE708A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BEE4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BEE8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BEECU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BEF0U, 0xEE308A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027BF00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027BF00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027BF00;
    }
block_0027BF00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027BF00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027BF00U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BF00U, 0xEE209A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BF04U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027BF14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027BF14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027BF14;
    }
block_0027BF14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027BF14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027BF14U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BF14U, 0xEE009A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BF18U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027BF28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027BF28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027BF28;
    }
block_0027BF28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027BF28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027BF28U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BF28U, 0xEE208A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BF2CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027BF3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027BF3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027BF3C;
    }
block_0027BF3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027BF3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027BF3CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BF3CU, 0xEE008A68U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BF40U, 0xEEB00AC9U};
            frame.Guest.vfp[0] = frame.Guest.vfp[18] & 0x7FFFFFFFU;
        }
        {
            const uint32_t updatedAddress = 0x0027BF4CU + 0x2E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BF44U, address);
            }
            r7 = value;
        }
        {
            const uint32_t address = 0x0027BF50U + 744U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BF48U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t operand = 0x004E0000U;
            r8 = r7 - operand;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x01E40000U;
            r11 = r7 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r7, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0027BF78; }
        goto block_0027BF60;
    }
block_0027BF60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027BF60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027BF60U);
        }
        {
            r0 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r8, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0027BF78; }
        goto block_0027BF6C;
    }
block_0027BF6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027BF6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027BF6CU);
        }
        {
            r0 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r11, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0027BF7C; }
        goto block_0027BF78;
    }
block_0027BF78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027BF78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027BF78U);
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[21];
        }
        goto block_0027BF7C;
    }
block_0027BF7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027BF7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027BF7CU);
        }
        {
            const uint32_t address = 0x0027BF84U + 696U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BF7CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BF80U, 0xEEB48ACAU};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[16], frame.Guest.vfp[20],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BF88U, 0xCEBD0AC8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r6 + 0x74U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0027BF8CU, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = frame.Guest.vfp[0];
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r6 + 0x74U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027BF94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BF98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BF9CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BFA0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BFA4U, 0xEE308A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BFA8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BFACU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BFB0U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BFB4U, 0xEE708A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00008000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027BFC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027BFC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027BFC8;
    }
block_0027BFC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027BFC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027BFC8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BFC8U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BFCCU, 0xEE209A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00008000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027BFE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027BFE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027BFE0;
    }
block_0027BFE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027BFE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027BFE0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BFE0U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BFE4U, 0xEE009A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00008000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027BFF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027BFF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027BFF8;
    }
block_0027BFF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027BFF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027BFF8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027BFF8U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027BFFCU, 0xEE609A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00008000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C010U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C010U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C010;
    }
block_0027C010:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C010U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C010U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C010U, 0xEE409A48U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C014U, 0xEEB00AC9U};
            frame.Guest.vfp[0] = frame.Guest.vfp[18] & 0x7FFFFFFFU;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r7, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0027C03C; }
        goto block_0027C024;
    }
block_0027C024:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C024U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C024U);
        }
        {
            r0 = frame.Guest.vfp[19];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r8, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0027C03C; }
        goto block_0027C030;
    }
block_0027C030:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C030U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C030U);
        }
        {
            r0 = frame.Guest.vfp[19];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r11, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0027C040; }
        goto block_0027C03C;
    }
block_0027C03C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C03CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C03CU);
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[21];
        }
        goto block_0027C040;
    }
block_0027C040:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C040U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C040U);
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C044U, 0xEEF49AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[19], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C04CU, 0xCEBD0AE9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r6 + 0x76U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0027C050U, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = frame.Guest.vfp[0];
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r6 + 0x76U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027C058U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C05CU, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C068U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_WorldYawTowardActor_0036E800(frame, context, state, 0x0036E800U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C068U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C068;
    }
block_0027C068:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C068U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C068U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C068U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0027C074U + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C06CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0027C078U + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C070U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = 0x0027C080U + 0x1C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C078U, address);
            }
            r1 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t operand = 0x00003800U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000000E2U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            r0 = 0x00000001U;
        }
        if (flags.C()) {
            const uint32_t updatedAddress = r6 + 0x88U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0027C090U, address);
            }
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = r6 + 0x88U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027C094U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r6 + 0x8AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027C09CU, address);
            }
        }
        {
            const uint32_t address = r5 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C0A0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        goto block_0027C0A4;
    }
block_0027C0A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C0A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C0A4U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r2 + operand;
        }
        {
            const uint32_t address = r1 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C0ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C0B0U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C0B4U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r12 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, r3, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0027C0E8; }
        goto block_0027C0C4;
    }
block_0027C0C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C0C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C0C4U);
        }
        {
            const uint32_t address = r5 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C0C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r1 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C0C8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C0CCU, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C0D0U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            r0 = 0x00000001U;
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r6 + 0x8AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027C0E0U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0027C0F8; }
        goto block_0027C0E8;
    }
block_0027C0E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C0E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C0E8U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0027C0A4; }
        goto block_0027C0F8;
    }
block_0027C0F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C0F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C0F8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x760U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C0F8U, address);
            }
            r2 = value;
        }
        {
            r1 = r9;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0027C108U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C108U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C108;
    }
block_0027C108:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C108U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C108U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C108U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0027C114U + 312U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C10CU, address);
            }
            frame.Guest.vfp[27] = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r4 = r5 + operand;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            const uint32_t updatedAddress = r5 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027C120U, address);
            }
        }
        {
            const uint32_t address = r4 + 1016U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C124U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000000C4U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C130U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C130U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C130;
    }
block_0027C130:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C130U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C130U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C130U, address);
            }
            r0 = value;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C13CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_MoveForward_00376864(frame, context, state, 0x00376864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C13CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C13C;
    }
block_0027C13C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C13CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C13CU);
        }
        {
            r1 = r9;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C148U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0029e828_0029E828(frame, context, state, 0x0029E828U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C148U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C148;
    }
block_0027C148:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C148U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C148U);
        }
        {
            const uint32_t address = 0x0027C150U + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C148U, address);
            }
            frame.Guest.vfp[28] = value;
        }
        {
            const uint32_t address = 0x0027C154U + 252U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C14CU, address);
            }
            frame.Guest.vfp[29] = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[28];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[29];
        }
        {
            r1 = r5;
        }
        {
            r0 = r9;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C16CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdateBgCheckInfo_00376340(frame, context, state, 0x00376340U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C16CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C16C;
    }
block_0027C16C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C16CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C16CU);
        }
        {
            const uint32_t address = 0x0027C174U + 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C16CU, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000003D8U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C18CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C18CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C18C;
    }
block_0027C18C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C18CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C18CU);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000003DCU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C1A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C1A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C1A8;
    }
block_0027C1A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C1A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C1A8U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C1A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0027C1B4U + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C1ACU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t value = r0 & 0x0000007FU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0027C1F0; }
        goto block_0027C1B8;
    }
block_0027C1B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C1B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C1B8U);
        }
        {
            r7 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0027C1C4U + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C1BCU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        goto block_0027C1C0;
    }
block_0027C1C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C1C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C1C0U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C1C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C1C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C1C8;
    }
block_0027C1C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C1C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C1C8U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 2U);
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C1D8U, 0xEE000AA8U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 244U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0027C1DCU, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r7 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r7 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000032U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0027C1C0; }
        goto block_0027C1F0;
    }
block_0027C1F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C1F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C1F0U);
        }
        {
            const uint32_t operand = 0x000008F0U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C1F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r0 + operand;
        }
        {
            r2 = 0x00000019U;
        }
        goto block_0027C204;
    }
block_0027C204:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C204U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C204U);
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C204U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r1 + operand;
        }
        {
            r3 = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C210U, 0xEE310A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C214U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0027C218U, address);
            }
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C21CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 + operand;
        }
        goto block_0027C264;
    }
block_0027C264:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C264U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C264U);
        }
        {
            const uint32_t address = r3 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C264U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r2 = r2 - operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C26CU, 0xEE710A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r3 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0027C270U, address);
            }
        }
        if (!(flags.Z())) { goto block_0027C204; }
        goto block_0027C278;
    }
block_0027C278:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C278U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C278U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x98U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C278U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0027C284U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C27CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0027C288U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C280U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0027C37C; }
        goto block_0027C28C;
    }
block_0027C28C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C28CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C28CU);
        }
        {
            const uint32_t updatedAddress = 0x0027C294U + 0x2ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C28CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C290U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C298U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C2A0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C2A4U, 0xEE880A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[17], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C2A8U, 0xEE300A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C2ACU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0027C2E8; }
        goto block_0027C2BC;
    }
block_0027C2BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C2BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C2BCU);
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        if (flags.Z()) {
            const uint32_t address = 0x0027C2D4U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C2CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x0027C2D8U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C2D0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000810U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C2DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C2DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C2DC;
    }
block_0027C2DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C2DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C2DCU);
        }
        {
        }
        {
        }
        goto block_0027C300;
    }
block_0027C2E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C2E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C2E8U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[28];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            const uint32_t operand = 0x00000810U;
            r0 = r5 + operand;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C300U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C300U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C300;
    }
block_0027C300:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C300U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C300U);
        }
        {
            const uint32_t operand = 0x00003200U;
            r1 = r9 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C304U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C30CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0027C37C; }
        goto block_0027C318;
    }
block_0027C318:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C318U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C318U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C31CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C320U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x0027C330U + 604U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C328U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = r2 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r1 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0027C330U, address);
            }
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C334U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C338U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C33CU, 0xEEFC0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r2 = frame.Guest.vfp[1];
        }
        {
            r2 = r2 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0027C348U, address);
            }
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C34CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C350U, 0xEEFC0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[1];
        }
        {
            r2 = r1 & 0x000000FFU;
        }
        {
            const uint32_t operand = 0x00003100U;
            r1 = r9 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0027C360U, address);
            }
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C364U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C368U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C36CU, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r1 + 0xFEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027C378U, address);
            }
        }
        goto block_0027C37C;
    }
block_0027C37C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C37CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C37CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x8EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C37CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0027C468; }
        goto block_0027C388;
    }
block_0027C388:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C388U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C388U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000003E8U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0027C3D0; }
        goto block_0027C390;
    }
block_0027C390:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C390U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C390U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[29];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x000007E0U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C3A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C3A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C3A8;
    }
block_0027C3A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C3A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C3A8U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[29];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[28];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000003E4U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C3C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C3C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C3C4;
    }
block_0027C3C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C3C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C3C4U);
        }
        {
        }
        {
        }
        goto block_0027C40C;
    }
block_0027C3D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C3D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C3D0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[29];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            const uint32_t updatedAddress = r6 + 0x8EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027C3E0U, address);
            }
        }
        {
            const uint32_t address = 0x0027C3ECU + 420U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C3E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000007E0U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C3F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C3F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C3F0;
    }
block_0027C3F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C3F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C3F0U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[29];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000003E4U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C40CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C40CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C40C;
    }
block_0027C40C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C40CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C40CU);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[29];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000003E8U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C428U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C428U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C428;
    }
block_0027C428:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C428U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C428U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[28];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = 0x0027C440U + 340U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C438U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000003ECU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C444U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C444U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C444;
    }
block_0027C444:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C444U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C444U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[28];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            const uint32_t address = 0x0027C458U + 320U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C450U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000007F0U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C45CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C45CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C45C;
    }
block_0027C45C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C45CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C45CU);
        }
        {
        }
        {
        }
        goto block_0027C4B8;
    }
block_0027C468:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C468U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C468U);
        }
        {
            const uint32_t updatedAddress = 0x0027C470U + 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C468U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 992U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0027C46CU, address);
            }
        }
        {
            const uint32_t address = r4 + 996U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0027C470U, address);
            }
        }
        {
            const uint32_t address = r4 + 1000U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0027C474U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + r9;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C478U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0027C484U + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C47CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000003ECU;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C498U, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C4A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C4A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C4A0;
    }
block_0027C4A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C4A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C4A0U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            const uint32_t address = 0x0027C4B4U + 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C4ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000007F0U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C4B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C4B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C4B8;
    }
block_0027C4B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C4B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C4B8U);
        }
        {
            const uint32_t updatedAddress = r10 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C4B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0027C4C4U + 0xE4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C4BCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x0027C4C8U + 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C4C0U, address);
            }
            frame.Guest.vfp[30] = value;
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C4C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0027C840; }
        goto block_0027C4D4;
    }
block_0027C4D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C4D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C4D4U);
        }
        {
            const uint32_t address = r4 + 1012U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C4D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0027C4E0U + 0xD0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C4D8U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            r11 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r7 = 0x00000001U;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r8 = 0x00000000U;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0027C50C; }
        goto block_0027C4F4;
    }
block_0027C4F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C4F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C4F4U);
        }
        {
            const uint32_t updatedAddress = 0x0027C4FCU + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C4F4U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0027C514; }
        goto block_0027C504;
    }
block_0027C504:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C504U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C504U);
        }
        {
            r7 = 0x00000003U;
        }
        {
            r8 = 0x00000001U;
        }
        goto block_0027C50C;
    }
block_0027C50C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C50CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C50CU);
        }
        {
            r4 = 0x00000000U;
        }
        goto block_0027C5F0;
    }
block_0027C514:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C514U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C514U);
        }
        {
            const uint32_t updatedAddress = 0x0027C51CU + 0x9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C514U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x0027C524U + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C51CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0027C548; }
        goto block_0027C528;
    }
block_0027C528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C528U);
        }
        {
            r7 = 0x00000007U;
        }
        {
            r8 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C534U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C534U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C534;
    }
block_0027C534:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C534U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C534U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C534U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C538U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        goto block_0027C5F0;
    }
block_0027C548:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C548U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C548U);
        }
        {
            const uint32_t updatedAddress = 0x0027C550U + 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C548U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0027C5C8; }
        goto block_0027C558;
    }
block_0027C558:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C558U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C558U);
        }
        {
            const uint32_t updatedAddress = 0x0027C560U + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C558U, address);
            }
            r8 = value;
        }
        {
            r7 = 0x00000007U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C564U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C564U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C564;
    }
block_0027C564:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C564U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C564U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C564U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C568U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r4 = value;
        }
        goto block_0027C5F0;
    }
block_0027C5C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C5C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C5C8U);
        }
        {
            r7 = 0x00000001U;
        }
        {
            r8 = ~(0x00000000U);
        }
        {
            r4 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C5D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C5D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C5D8;
    }
block_0027C5D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C5D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C5D8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C5D8U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            r1 = ~(0x00000031U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C5E0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r11 = value;
        }
        goto block_0027C5F0;
    }
block_0027C5F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C5F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C5F0U);
        }
        {
            const uint32_t updatedAddress = r10 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C5F0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0027C5FCU + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C5F4U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x0027C600U + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C5F8U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = 0x0027C608U + 812U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C600U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2BCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C604U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0027C610U + 808U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C608U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x0027C614U + 808U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C60CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x3U));
        }
        {
            const uint32_t updatedAddress = r6 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C614U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (flags.C()) {
            r7 = ~(0x00000000U);
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r7, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0027C6A4; }
        goto block_0027C624;
    }
block_0027C624:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C624U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C624U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C628U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C628U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C628;
    }
block_0027C628:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C628U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C628U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C628U, 0xEE20BA2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[22], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C634U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C634U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C634;
    }
block_0027C634:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C634U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C634U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C634U, 0xEE20CA28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[24], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C640U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C640U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C640;
    }
block_0027C640:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C640U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C640U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C644U, 0xEE400A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0027C64CU, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0027C650U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C658U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C658U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C658;
    }
block_0027C658:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C658U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C658U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00000064U;
            r0 = r11 + operand;
        }
        {
            const uint32_t operand = 0x00000018U;
            r1 = r13 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C66CU, 0xEE400A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x0000000AU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0027C67CU, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0027C680U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0027C680U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = 0x0027C68CU + 0x2B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C684U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0027C688U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0027C68CU, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r3 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 2U);
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C69CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C6A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003373c8_003373C8(frame, context, state, 0x003373C8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C6A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C6A4;
    }
block_0027C6A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C6A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C6A4U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C6A4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r8, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0027C840; }
        goto block_0027C6B0;
    }
block_0027C6B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C6B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C6B0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0027C6BCU, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0027C6C0U, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0027C6C4U, address);
            }
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0027C6C8U, address);
            }
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0027C6CCU, address);
            }
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0027C6D0U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C6D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C6D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C6D8;
    }
block_0027C6D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C6D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C6D8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C6D8U, 0xEE20BA2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[22], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C6E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C6E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C6E4;
    }
block_0027C6E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C6E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C6E4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C6E4U, 0xEE20CA28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[24], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C6F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C6F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C6F0;
    }
block_0027C6F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C6F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C6F0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C6F4U, 0xEE400A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            const uint32_t address = r13 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0027C6FCU, address);
            }
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0027C700U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C708U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C708U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C708;
    }
block_0027C708:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C708U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C708U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            r1 = r13;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C710U, 0xEE400A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0027C714U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C718U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C720U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0037100c_0037100C(frame, context, state, 0x0037100CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C720U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C720;
    }
block_0027C720:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C720U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C720U);
        }
        {
            const uint32_t address = 0x0027C728U + 540U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C720U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            r7 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00005000U;
            r8 = r9 + operand;
        }
        {
            r10 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000018U;
            r11 = r13 + operand;
        }
        goto block_0027C734;
    }
block_0027C734:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C734U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C734U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x0027C738U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C740U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C740U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C740;
    }
block_0027C740:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C740U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C740U);
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0027C740U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C74CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C74CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C74C;
    }
block_0027C74C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C74CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C74CU);
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0027C74CU, address);
            }
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C758U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C758U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C758;
    }
block_0027C758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C758U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C758U, 0xEE60BA2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[23], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C764U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C764U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C764;
    }
block_0027C764:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C764U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C764U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C764U, 0xEE20CA28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[24], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C770U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C770U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C770;
    }
block_0027C770:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C770U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C770U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C774U, 0xEE400A2BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[24];
        }
        {
            const uint32_t address = r13 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0027C77CU, address);
            }
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0027C780U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C788U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C788U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C788;
    }
block_0027C788:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C788U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C788U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C78CU, 0xEE400A2BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[30];
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0027C794U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C79CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C79CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C79C;
    }
block_0027C79C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C79CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C79CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C79CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r8 + 0xC28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C7A4U, address);
            }
            r4 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C7B8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        goto block_0027C7BC;
    }
block_0027C7BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C7BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C7BCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C7BCU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0027C81C; }
        goto block_0027C7C8;
    }
block_0027C7C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C7C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C7C8U);
        }
        {
            r0 = r13;
        }
        {
            const uint32_t updatedAddress = r4 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0027C7CCU, address);
            }
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0027C7D0U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0027C7D0U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0027C7D0U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C7D8U, 0xEE200A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            const uint32_t firstAddress = r4;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0027C7DCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0027C7DCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0027C7DCU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r11;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0027C7E0U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0027C7E0U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0027C7E0U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0027C7E4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0027C7E4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0027C7E4U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0027C7F0U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0027C7F0U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0027C7F0U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0027C7F4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0027C7F4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0027C7F4U,
                                           firstAddress + 8U);
            }
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0027C7FCU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[28];
        }
        {
            const uint32_t updatedAddress = r4 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027C804U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C80CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C80CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C80C;
    }
block_0027C80C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C80CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C80CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C80CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0x25U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027C814U, address);
            }
        }
        goto block_0027C830;
    }
block_0027C81C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C81CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C81CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000034U;
            r4 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000050U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0027C7BC; }
        goto block_0027C830;
    }
block_0027C830:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C830U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C830U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r7 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r7 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0027C734; }
        goto block_0027C840;
    }
block_0027C840:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C840U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C840U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x96U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C840U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0027C898; }
        goto block_0027C84C;
    }
block_0027C84C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C84CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C84CU);
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r9;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C85CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003309e0_003309E0(frame, context, state, 0x003309E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C85CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C85C;
    }
block_0027C85C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C85CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C85CU);
        }
        {
            r0 = 0x00000000U;
        }
        goto block_0027C860;
    }
block_0027C860:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C860U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C860U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C860U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000002U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000004AU;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r6 + 0x92U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0027C874U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0027C860; }
        goto block_0027C87C;
    }
block_0027C87C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C87CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C87CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = 0x0027C890U + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C888U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x000003F4U;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C898U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C898U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C898;
    }
block_0027C898:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C898U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C898U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C898U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0027C8A4U + 0xA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C89CU, address);
            }
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0027C8F8; }
        goto block_0027C8A8;
    }
block_0027C8A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C8A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C8A8U);
        }
        {
            const uint32_t updatedAddress = 0x0027C8B0U + 0xA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C8A8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x760U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C8ACU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C8B0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00005C00U;
            r6 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r6 = r6 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000A10U;
            r2 = r5 + operand;
        }
        if (!(flags.Z())) {
            r1 = r6;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C8CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAC_00376168(frame, context, state, 0x00376168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C8CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C8CC;
    }
block_0027C8CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C8CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C8CCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C8CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000A10U;
            r2 = r5 + operand;
        }
        {
            r1 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C8DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C8DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C8DC;
    }
block_0027C8DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C8DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C8DCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x760U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C8DCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r4, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0027C8F8; }
        goto block_0027C8E8;
    }
block_0027C8E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C8E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C8E8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C8E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000A10U;
            r2 = r5 + operand;
        }
        {
            r1 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027C8F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAT_003761F0(frame, context, state, 0x003761F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027C8F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027C8F8;
    }
block_0027C8F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C8F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C8F8U);
        }
        {
            const uint32_t updatedAddress = 0x0027C900U + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C8F8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x760U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C8FCU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r5 + 0xA2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C90CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x0000000DU;
        }
        if (!(flags.Z())) {
            const uint32_t address = r0 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x0027C914U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = r0 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0027C918U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C91CU, address);
            }
            r2 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000228U;
            r2 = r2 + operand;
        }
        goto block_0027C960;
    }
block_0027C958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C958U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0027C970; }
        goto block_0027C960;
    }
block_0027C960:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C960U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C960U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x760U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C960U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r4, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t address = r2 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0027C968U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = r2 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0027C96CU, address);
            }
        }
        goto block_0027C970;
    }
block_0027C970:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C970U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C970U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        {
            const uint32_t operand = 0x00000050U;
            r2 = r2 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) { goto block_0027C958; }
        goto block_0027C988;
    }
block_0027C988:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C988U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C988U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r5 + operand;
        }
        {
            const uint32_t address = r1 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C98CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C990U, 0xEEB41A40U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[2], frame.Guest.vfp[0],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_0027C9E0; }
        goto block_0027C99C;
    }
block_0027C99C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C99CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C99CU);
        }
        {
            const uint32_t updatedAddress = 0x0027C9A4U - 0x424U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C99CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r3 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C9A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0027C9B0U, address);
            }
        }
        {
            r2 = 0x00000050U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x56U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0027C9B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0027C9BCU, address);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x5AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0027C9C4U, address);
            }
        }
        {
            const uint32_t address = r1 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C9C8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027C9CCU, 0xEEBC1AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[2];
        }
        {
            r1 = r1 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0027C9D8U, address);
            }
        }
        goto block_0027C9F4;
    }
block_0027C9E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C9E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C9E0U);
        }
        {
            const uint32_t updatedAddress = 0x0027C9E8U - 0x468U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C9E0U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027C9E8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027C9F0U, address);
            }
        }
        goto block_0027C9F4;
    }
block_0027C9F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027C9F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027C9F4U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[30];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027CA08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027CA08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027CA08;
    }
block_0027CA08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027CA08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027CA08U);
        }
        {
            const uint32_t updatedAddress = 0x0027CA10U + 0x190U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA08U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0027CA14U + 0x188U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000018U;
            r4 = r13 + operand;
        }
        {
            const uint32_t address = 0x0027CA1CU + 392U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA14U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0027CA18U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0027CA18U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0027CA18U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t updatedAddress = r0 + r9;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA1CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r4;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0027CA20U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0027CA20U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0027CA20U,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x0027CA30U - 0x4B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA28U, address);
            }
            r5 = value;
        }
        {
            r6 = r2;
        }
        goto block_0027CA30;
    }
block_0027CA30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027CA30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027CA30U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x24U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA30U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0027CB78; }
        goto block_0027CA3C;
    }
block_0027CA3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027CA3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027CA3CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x25U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA3CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            r12 = r1 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x25U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0027CA4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA50U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA54U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r0 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA58U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA60U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[3] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CA68U, 0xEEF81AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CA6CU, 0xEE611A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CA70U, 0xEE001AA1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0027CA74U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA78U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA7CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA80U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CA88U, address);
            }
            r7 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[4] = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CA90U, 0xEEB82AC2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CA94U, 0xEE222A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[4], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CA98U, 0xEE411A02U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0027CA9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CAA0U, address);
            }
            r7 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CAA4U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            const uint32_t address = r0 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CAA8U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            frame.Guest.vfp[5] = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CAB0U, 0xEEF82AE2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CAB4U, 0xEE622A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CAB8U, 0xEE012AA2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[4], frame.Guest.vfp[3], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[4])) {
                return Oot3dAotMemoryFault(context, 0x0027CABCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CAC0U, address);
            }
            r7 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CAC4U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            frame.Guest.vfp[5] = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CACCU, 0xEEF82AE2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CAD0U, 0xEE622A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CAD4U, 0xEE420A22U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[4], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0027CAD8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CADCU, address);
            }
            r7 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CAE0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[4] = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CAE8U, 0xEEB82AC2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CAECU, 0xEE222A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[4], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CAF0U, 0xEE001A82U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0027CAF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CAF8U, address);
            }
            r7 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CAFCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[2] = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CB04U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CB08U, 0xEE211A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CB0CU, 0xEE401A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0027CB10U, address);
            }
        }
        if (!(flags.Z())) { goto block_0027CB78; }
        goto block_0027CB18;
    }
block_0027CB18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027CB18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027CB18U);
        }
        {
            r3 = r12 & 0x00000003U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + r3;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CB20U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r4;
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0027CB28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CB2CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x27U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0027CB30U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CB34U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0027CB38U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CB3CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0x2AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027CB40U, address);
            }
            r3 = value;
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CB48U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CB4CU, 0xEE201AAEU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[29], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CB54U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0027CB58U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[1];
        }
        {
            const uint32_t operand = r1;
            r1 = r3 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r0 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0027CB6CU, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r0 + 0x2AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0027CB70U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r0 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0027CB74U, address);
            }
        }
        goto block_0027CB78;
    }
block_0027CB78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027CB78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027CB78U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000034U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000050U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0027CA30; }
        goto block_0027CB8C;
    }
block_0027CB8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027CB8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027CB8CU);
        }
        {
            const uint32_t operand = 0x00000024U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 48U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 48U);
            }
            frame.Guest.vfp[28] = value12;
            uint32_t value13 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 52U, &value13)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 52U);
            }
            frame.Guest.vfp[29] = value13;
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 56U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 56U);
            }
            frame.Guest.vfp[30] = value14;
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 60U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0027CB90U,
                                           firstAddress + 60U);
            }
            frame.Guest.vfp[31] = value15;
            r13 += 64U;
        }
        {
            const uint32_t operand = 0x00000008U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0027CB98U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0027CB98U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0027CB98U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0027CB98U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0027CB98U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0027CB98U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0027CB98U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0027CB98U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0027CB98U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Math_SmoothStepToF_0036E168(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0036E168U:
        goto block_0036E168;
    case 0x0036E178U:
        goto block_0036E178;
    case 0x0036E1E4U:
        goto block_0036E1E4;
    case 0x0036E1F4U:
        goto block_0036E1F4;
    case 0x0036E21CU:
        goto block_0036E21C;
    case 0x0036E228U:
        goto block_0036E228;
    case 0x0036E244U:
        goto block_0036E244;
    case 0x0036E250U:
        goto block_0036E250;
    case 0x0036E26CU:
        goto block_0036E26C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0036E168:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E168U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E168U);
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036E168U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E16CU, 0xEEB42A40U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[4], frame.Guest.vfp[0],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) { goto block_0036E26C; }
        goto block_0036E178;
    }
block_0036E178:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E178U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E178U);
        }
        {
            const uint32_t updatedAddress = 0x0036E180U + 0xFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036E178U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0036E184U + 0x100U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036E17CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036E180U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036E188U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[6] = r1;
        }
        {
            frame.Guest.vfp[5] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E194U, 0xEEB83AC3U};
            Oot3dAotCommitVfp(frame.Guest.vfp[6], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[6], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E198U, 0xEEF82AE2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E19CU, 0xEE631A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[6], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[6] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E1A4U, 0xEE620AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[5], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0036E1B0U + 208U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036E1A8U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E1ACU, 0xEEB83AC3U};
            Oot3dAotCommitVfp(frame.Guest.vfp[6], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[6], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E1B0U, 0xEE611AA2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E1B4U, 0xEE600AA2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E1B8U, 0xEE231A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[6], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E1BCU, 0xEE211A22U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E1C0U, 0xEE702A42U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E1C4U, 0xEEB03AE2U};
            frame.Guest.vfp[6] = frame.Guest.vfp[5] & 0x7FFFFFFFU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E1C8U, 0xEE620AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[5], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[6];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            frame.Guest.vfp[1] = frame.Guest.vfp[5];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E1D8U, 0xEEF40AE1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[3],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.N()) == (flags.V())) { goto block_0036E1F4; }
        goto block_0036E1E4;
    }
block_0036E1E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E1E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E1E4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E1E4U, 0xEEF12A61U};
            frame.Guest.vfp[5] = frame.Guest.vfp[3] ^ 0x80000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E1E8U, 0xEEF40AE2U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[5],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0036E21C; }
        goto block_0036E1F4;
    }
block_0036E1F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E1F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E1F4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E1F4U, 0xEEF40AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E200U, 0xEEB11A41U};
            frame.Guest.vfp[2] = frame.Guest.vfp[2] ^ 0x80000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E204U, 0xEEF40AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E210U, 0xEE720A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[4], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0036E214U, address);
            }
        }
        goto block_0036E26C;
    }
block_0036E21C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E21CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E21CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E21CU, 0xEEF40AE1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[3],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_0036E244; }
        goto block_0036E228;
    }
block_0036E228:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E228U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E228U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[3];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E22CU, 0xEE321A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[4], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0036E230U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E234U, 0xEEB41AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[2], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0036E240U, address);
            }
        }
        goto block_0036E244;
    }
block_0036E244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E244U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E244U, 0xEEF40AE2U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[5],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0036E26C; }
        goto block_0036E250;
    }
block_0036E250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E250U);
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036E250U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E254U, 0xEE700AA2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0036E258U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E25CU, 0xEEF40AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0036E268U, address);
            }
        }
        goto block_0036E26C;
    }
block_0036E26C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E26CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E26CU);
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036E26CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E270U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036E274U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_003da7ac_003DA7AC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003DA7ACU:
        goto block_003DA7AC;
    case 0x003DA7D4U:
        goto block_003DA7D4;
    case 0x003DA7DCU:
        goto block_003DA7DC;
    case 0x003DA7E4U:
        goto block_003DA7E4;
    case 0x003DA808U:
        goto block_003DA808;
    case 0x003DA818U:
        goto block_003DA818;
    case 0x003DA820U:
        goto block_003DA820;
    case 0x003DA82CU:
        goto block_003DA82C;
    case 0x003DA850U:
        goto block_003DA850;
    case 0x003DA860U:
        goto block_003DA860;
    case 0x003DA86CU:
        goto block_003DA86C;
    case 0x003DA888U:
        goto block_003DA888;
    case 0x003DA938U:
        goto block_003DA938;
    case 0x003DA940U:
        goto block_003DA940;
    case 0x003DA948U:
        goto block_003DA948;
    case 0x003DA950U:
        goto block_003DA950;
    case 0x003DA958U:
        goto block_003DA958;
    case 0x003DA970U:
        goto block_003DA970;
    case 0x003DA98CU:
        goto block_003DA98C;
    case 0x003DA9B0U:
        goto block_003DA9B0;
    case 0x003DA9C8U:
        goto block_003DA9C8;
    case 0x003DA9E8U:
        goto block_003DA9E8;
    case 0x003DAA10U:
        goto block_003DAA10;
    case 0x003DAA24U:
        goto block_003DAA24;
    case 0x003DAA30U:
        goto block_003DAA30;
    case 0x003DAA50U:
        goto block_003DAA50;
    case 0x003DAA78U:
        goto block_003DAA78;
    case 0x003DAA88U:
        goto block_003DAA88;
    case 0x003DAA90U:
        goto block_003DAA90;
    case 0x003DAA94U:
        goto block_003DAA94;
    case 0x003DAAA8U:
        goto block_003DAAA8;
    case 0x003DAAB8U:
        goto block_003DAAB8;
    case 0x003DAAC4U:
        goto block_003DAAC4;
    case 0x003DAAD8U:
        goto block_003DAAD8;
    case 0x003DAAE8U:
        goto block_003DAAE8;
    case 0x003DAAF4U:
        goto block_003DAAF4;
    case 0x003DABC4U:
        goto block_003DABC4;
    case 0x003DABD8U:
        goto block_003DABD8;
    case 0x003DABF8U:
        goto block_003DABF8;
    case 0x003DAC20U:
        goto block_003DAC20;
    case 0x003DAC2CU:
        goto block_003DAC2C;
    case 0x003DAC3CU:
        goto block_003DAC3C;
    case 0x003DAC60U:
        goto block_003DAC60;
    case 0x003DAC7CU:
        goto block_003DAC7C;
    case 0x003DAC98U:
        goto block_003DAC98;
    case 0x003DACB0U:
        goto block_003DACB0;
    case 0x003DACD0U:
        goto block_003DACD0;
    case 0x003DACE8U:
        goto block_003DACE8;
    case 0x003DACF4U:
        goto block_003DACF4;
    case 0x003DAD0CU:
        goto block_003DAD0C;
    case 0x003DAD1CU:
        goto block_003DAD1C;
    case 0x003DAD28U:
        goto block_003DAD28;
    case 0x003DAD48U:
        goto block_003DAD48;
    case 0x003DAD84U:
        goto block_003DAD84;
    case 0x003DAD90U:
        goto block_003DAD90;
    case 0x003DADA8U:
        goto block_003DADA8;
    case 0x003DADCCU:
        goto block_003DADCC;
    case 0x003DADF0U:
        goto block_003DADF0;
    case 0x003DAE08U:
        goto block_003DAE08;
    case 0x003DAE28U:
        goto block_003DAE28;
    case 0x003DAE44U:
        goto block_003DAE44;
    case 0x003DAE60U:
        goto block_003DAE60;
    case 0x003DAE6CU:
        goto block_003DAE6C;
    case 0x003DAEDCU:
        goto block_003DAEDC;
    case 0x003DAF14U:
        goto block_003DAF14;
    case 0x003DAF98U:
        goto block_003DAF98;
    case 0x003DAFD0U:
        goto block_003DAFD0;
    case 0x003DB018U:
        goto block_003DB018;
    case 0x003DB020U:
        goto block_003DB020;
    case 0x003DB02CU:
        goto block_003DB02C;
    case 0x003DB070U:
        goto block_003DB070;
    case 0x003DB090U:
        goto block_003DB090;
    case 0x003DB0B0U:
        goto block_003DB0B0;
    case 0x003DB0BCU:
        goto block_003DB0BC;
    case 0x003DB0C8U:
        goto block_003DB0C8;
    case 0x003DB0DCU:
        goto block_003DB0DC;
    case 0x003DB0E8U:
        goto block_003DB0E8;
    case 0x003DB114U:
        goto block_003DB114;
    case 0x003DB14CU:
        goto block_003DB14C;
    case 0x003DB158U:
        goto block_003DB158;
    case 0x003DB198U:
        goto block_003DB198;
    case 0x003DB1B8U:
        goto block_003DB1B8;
    case 0x003DB1C8U:
        goto block_003DB1C8;
    case 0x003DB1D8U:
        goto block_003DB1D8;
    case 0x003DB234U:
        goto block_003DB234;
    case 0x003DB24CU:
        goto block_003DB24C;
    case 0x003DB294U:
        goto block_003DB294;
    case 0x003DB2A0U:
        goto block_003DB2A0;
    case 0x003DB2B4U:
        goto block_003DB2B4;
    case 0x003DB2CCU:
        goto block_003DB2CC;
    case 0x003DB2DCU:
        goto block_003DB2DC;
    case 0x003DB2ECU:
        goto block_003DB2EC;
    case 0x003DB310U:
        goto block_003DB310;
    case 0x003DB33CU:
        goto block_003DB33C;
    case 0x003DB350U:
        goto block_003DB350;
    case 0x003DB360U:
        goto block_003DB360;
    case 0x003DB3C0U:
        goto block_003DB3C0;
    case 0x003DB3DCU:
        goto block_003DB3DC;
    case 0x003DB3F8U:
        goto block_003DB3F8;
    case 0x003DB40CU:
        goto block_003DB40C;
    case 0x003DB418U:
        goto block_003DB418;
    case 0x003DB430U:
        goto block_003DB430;
    case 0x003DB440U:
        goto block_003DB440;
    case 0x003DB448U:
        goto block_003DB448;
    case 0x003DB4C4U:
        goto block_003DB4C4;
    case 0x003DB4E8U:
        goto block_003DB4E8;
    case 0x003DB50CU:
        goto block_003DB50C;
    case 0x003DB520U:
        goto block_003DB520;
    case 0x003DB534U:
        goto block_003DB534;
    case 0x003DB570U:
        goto block_003DB570;
    case 0x003DB57CU:
        goto block_003DB57C;
    case 0x003DB594U:
        goto block_003DB594;
    case 0x003DB5A4U:
        goto block_003DB5A4;
    case 0x003DB5BCU:
        goto block_003DB5BC;
    case 0x003DB60CU:
        goto block_003DB60C;
    case 0x003DB65CU:
        goto block_003DB65C;
    case 0x003DB668U:
        goto block_003DB668;
    case 0x003DB674U:
        goto block_003DB674;
    case 0x003DB6A0U:
        goto block_003DB6A0;
    case 0x003DB6BCU:
        goto block_003DB6BC;
    case 0x003DB6E4U:
        goto block_003DB6E4;
    case 0x003DB708U:
        goto block_003DB708;
    case 0x003DB734U:
        goto block_003DB734;
    case 0x003DB74CU:
        goto block_003DB74C;
    case 0x003DB758U:
        goto block_003DB758;
    case 0x003DB760U:
        goto block_003DB760;
    case 0x003DB76CU:
        goto block_003DB76C;
    case 0x003DB770U:
        goto block_003DB770;
    case 0x003DB778U:
        goto block_003DB778;
    case 0x003DB794U:
        goto block_003DB794;
    case 0x003DB7B0U:
        goto block_003DB7B0;
    case 0x003DB7C8U:
        goto block_003DB7C8;
    case 0x003DB7ECU:
        goto block_003DB7EC;
    case 0x003DB804U:
        goto block_003DB804;
    case 0x003DB818U:
        goto block_003DB818;
    case 0x003DB828U:
        goto block_003DB828;
    case 0x003DB89CU:
        goto block_003DB89C;
    case 0x003DB8BCU:
        goto block_003DB8BC;
    case 0x003DB8D8U:
        goto block_003DB8D8;
    case 0x003DB8F0U:
        goto block_003DB8F0;
    case 0x003DB924U:
        goto block_003DB924;
    case 0x003DB92CU:
        goto block_003DB92C;
    case 0x003DB93CU:
        goto block_003DB93C;
    case 0x003DB960U:
        goto block_003DB960;
    case 0x003DB980U:
        goto block_003DB980;
    case 0x003DB99CU:
        goto block_003DB99C;
    case 0x003DB9B0U:
        goto block_003DB9B0;
    case 0x003DB9B4U:
        goto block_003DB9B4;
    case 0x003DB9F8U:
        goto block_003DB9F8;
    case 0x003DBA10U:
        goto block_003DBA10;
    case 0x003DBA1CU:
        goto block_003DBA1C;
    case 0x003DBA28U:
        goto block_003DBA28;
    case 0x003DBA34U:
        goto block_003DBA34;
    case 0x003DBA50U:
        goto block_003DBA50;
    case 0x003DBA6CU:
        goto block_003DBA6C;
    case 0x003DBA84U:
        goto block_003DBA84;
    case 0x003DBA94U:
        goto block_003DBA94;
    case 0x003DBAA4U:
        goto block_003DBAA4;
    case 0x003DBAB0U:
        goto block_003DBAB0;
    case 0x003DBABCU:
        goto block_003DBABC;
    case 0x003DBAC4U:
        goto block_003DBAC4;
    case 0x003DBAD8U:
        goto block_003DBAD8;
    case 0x003DBB14U:
        goto block_003DBB14;
    case 0x003DBB20U:
        goto block_003DBB20;
    case 0x003DBB28U:
        goto block_003DBB28;
    case 0x003DBB34U:
        goto block_003DBB34;
    case 0x003DBB48U:
        goto block_003DBB48;
    case 0x003DBB5CU:
        goto block_003DBB5C;
    case 0x003DBB70U:
        goto block_003DBB70;
    case 0x003DBB88U:
        goto block_003DBB88;
    case 0x003DBB98U:
        goto block_003DBB98;
    case 0x003DBBCCU:
        goto block_003DBBCC;
    case 0x003DBBD8U:
        goto block_003DBBD8;
    case 0x003DBBE4U:
        goto block_003DBBE4;
    case 0x003DBC1CU:
        goto block_003DBC1C;
    case 0x003DBC40U:
        goto block_003DBC40;
    case 0x003DBC4CU:
        goto block_003DBC4C;
    case 0x003DBC58U:
        goto block_003DBC58;
    case 0x003DBC68U:
        goto block_003DBC68;
    case 0x003DBC9CU:
        goto block_003DBC9C;
    case 0x003DBCB0U:
        goto block_003DBCB0;
    case 0x003DBCC0U:
        goto block_003DBCC0;
    case 0x003DBCC4U:
        goto block_003DBCC4;
    case 0x003DBCD0U:
        goto block_003DBCD0;
    case 0x003DBCECU:
        goto block_003DBCEC;
    case 0x003DBCFCU:
        goto block_003DBCFC;
    case 0x003DBD0CU:
        goto block_003DBD0C;
    case 0x003DBD1CU:
        goto block_003DBD1C;
    case 0x003DBD5CU:
        goto block_003DBD5C;
    case 0x003DBD68U:
        goto block_003DBD68;
    case 0x003DBD78U:
        goto block_003DBD78;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003DA7AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA7ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA7ACU);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x003DA7ACU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003DA7ACU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003DA7ACU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x003DA7ACU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x003DA7ACU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x003DA7ACU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x003DA7ACU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x003DA7ACU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003DA7ACU,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r8 = r1;
        }
        {
            const uint32_t updatedAddress = 0x003DA7C0U + 0x390U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA7B8U, address);
            }
            r9 = value;
        }
        {
            r13 -= 64U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 44U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 48U, frame.Guest.vfp[28])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 48U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 52U, frame.Guest.vfp[29])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 52U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 56U, frame.Guest.vfp[30])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 56U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 60U, frame.Guest.vfp[31])) {
                return Oot3dAotMemoryFault(context, 0x003DA7BCU,
                                           firstAddress + 60U);
            }
        }
        {
            const uint32_t operand = 0x000000D4U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r9 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA7C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003DA7D0U + 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA7C8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003DA808; }
        goto block_003DA7D4;
    }
block_003DA7D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA7D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA7D4U);
        }
        {
            const uint32_t operand = 0x00000064U;
            r0 = r9 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DA7DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DA7DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DA7DC;
    }
block_003DA7DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA7DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA7DCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_003DA808; }
        goto block_003DA7E4;
    }
block_003DA7E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA7E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA7E4U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x003DA7F0U + 0x368U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA7E8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[2];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DA7F4U, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003DA7F8U, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x003DA7FCU, address);
            }
        }
        {
            const uint32_t operand = 0x00000064U;
            r0 = r9 + operand;
        }
        {
            r0 = r0;
        }
        goto block_003DA808;
    }
block_003DA808:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA808U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA808U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA808U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003DA814U + 840U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA80CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003DA850; }
        goto block_003DA818;
    }
block_003DA818:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA818U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA818U);
        }
        {
            const uint32_t updatedAddress = 0x003DA820U + 0x340U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA818U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DA820U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DA820U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DA820;
    }
block_003DA820:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA820U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA820U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_003DA850; }
        goto block_003DA82C;
    }
block_003DA82C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA82CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA82CU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = 0x003DA838U + 0x32CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA830U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003DA83CU, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DA840U, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x003DA844U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003DA850U + 0x310U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA848U, address);
            }
            r0 = value;
        }
        {
            r0 = r0;
        }
        goto block_003DA850;
    }
block_003DA850:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA850U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA850U);
        }
        {
            const uint32_t updatedAddress = 0x003DA858U + 0x310U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA850U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA854U, address);
            }
            r10 = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DA860U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_00370734_00370734(frame, context, state, 0x00370734U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DA860U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DA860;
    }
block_003DA860:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA860U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA860U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA860U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DA86CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DA86CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DA86C;
    }
block_003DA86C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA86CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA86CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = 0x003DA878U + 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA870U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DA874U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 144U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DA878U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA87CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DA888U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DA888U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DA888;
    }
block_003DA888:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA888U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA888U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000700U;
            r5 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA894U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xD0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003DA89CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000001FCU;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003DA8A8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000208U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xC8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003DA8B4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000020CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xC4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003DA8C0U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DA8C4U, 0xEEB8AAC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000003D4U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xC0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003DA8D0U, address);
            }
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r8 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003DA8DCU, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t address = 0x003DA8ECU + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA8E4U, address);
            }
            frame.Guest.vfp[27] = value;
        }
        {
            const uint32_t address = 0x003DA8F0U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA8E8U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x003DA8F4U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA8ECU, address);
            }
            frame.Guest.vfp[28] = value;
        }
        {
            const uint32_t address = 0x003DA8F8U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA8F0U, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            const uint32_t address = 0x003DA8FCU + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA8F4U, address);
            }
            frame.Guest.vfp[31] = value;
        }
        {
            const uint32_t address = 0x003DA900U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA8F8U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t address = 0x003DA904U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA8FCU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x003DA908U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA900U, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            const uint32_t address = 0x003DA90CU + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA904U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x003DA910U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA908U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x003DA914U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA90CU, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x003DA918U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA910U, address);
            }
            frame.Guest.vfp[30] = value;
        }
        {
            const uint32_t address = 0x003DA91CU + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA914U, address);
            }
            frame.Guest.vfp[29] = value;
        }
        {
            const uint32_t operand = 0x00000204U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r11 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x000001F8U;
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = 0x00000400U;
            r7 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000800U;
            r6 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xB8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003DA930U, address);
            }
        }
        if (flags.Z()) { goto block_003DAD90; }
        goto block_003DA938;
    }
block_003DA938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA938U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003DAA78; }
        goto block_003DA940;
    }
block_003DA940:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA940U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA940U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003DAA94; }
        goto block_003DA948;
    }
block_003DA948:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA948U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA948U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003DABC4; }
        goto block_003DA950;
    }
block_003DA950:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA950U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA950U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003DBD5C; }
        goto block_003DA958;
    }
block_003DA958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA958U);
        }
        {
            const uint32_t address = r6 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA958U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r6 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA95CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x0000003CU;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DA970U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00315350_00315350(frame, context, state, 0x00315350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DA970U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DA970;
    }
block_003DA970:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA970U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA970U);
        }
        {
            const uint32_t address = 0x003DA978U + 552U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA970U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[22];
        }
        {
            const uint32_t updatedAddress = r13 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA980U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA984U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DA98CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DA98CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DA98C;
    }
block_003DA98C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA98CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA98CU);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA98CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003DA998U + 524U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA990U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[26];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DA99CU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0xC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA9A4U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DA9A8U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DA9B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DA9B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DA9B0;
    }
block_003DA9B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA9B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA9B0U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA9BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA9C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DA9C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DA9C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DA9C8;
    }
block_003DA9C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA9C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA9C8U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DA9D4U, 0xEE7A0A6FU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[20], frame.Guest.vfp[31], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA9D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DA9DCU, 0xEEF40AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_003DAA10; }
        goto block_003DA9E8;
    }
block_003DA9E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DA9E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DA9E8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DA9E8U, 0xEE7A0A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x94U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA9ECU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DA9F4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DA9F8U, 0xEE3F1AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[31], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x003DAA04U + 420U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DA9FCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAA00U, 0xEE010A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAA04U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DAA0CU, address);
            }
        }
        goto block_003DAA10;
    }
block_003DAA10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAA10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAA10U);
        }
        {
            const uint32_t address = 0x003DAA18U + 404U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAA10U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAA1CU, 0xEE3A0A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAA24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_IsFrameCrossed_0036E5E0(frame, context, state, 0x0036E5E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAA24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAA24;
    }
block_003DAA24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAA24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAA24U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_003DBD5C; }
        goto block_003DAA30;
    }
block_003DAA30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAA30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAA30U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = 0x003DAA44U + 0x170U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAA3CU, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t address = 0x003DAA4CU + 356U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAA44U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAA50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_ChangeAnimation_00353020(frame, context, state, 0x00353020U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAA50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAA50;
    }
block_003DAA50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAA50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAA50U);
        }
        {
            r0 = 0x00000007U;
        }
        {
            const uint32_t address = 0x003DAA5CU + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAA54U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DAA58U, address);
            }
        }
        {
            const uint32_t address = r7 + 1016U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAA5CU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x78U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DAA64U, address);
            }
        }
        {
            const uint32_t address = r7 + 980U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003DAA68U, address);
            }
        }
        {
            const uint32_t address = r7 + 948U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003DAA6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DAA70U, address);
            }
        }
        goto block_003DBD5C;
    }
block_003DAA78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAA78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAA78U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t address = 0x003DAA84U + 312U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAA7CU, address);
            }
            frame.Guest.vfp[27] = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003DB2A0; }
        goto block_003DAA88;
    }
block_003DAA88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAA88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAA88U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000064U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003DBD5C; }
        goto block_003DAA90;
    }
block_003DAA90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAA90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAA90U);
        }
        goto block_003DBCB0;
    }
block_003DAA94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAA94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAA94U);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DAA98U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xD0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAA9CU, address);
            }
            r1 = value;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAAA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAAA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAAA8;
    }
block_003DAAA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAAA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAAA8U);
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAAB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAAB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAAB8;
    }
block_003DAAB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAAB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAAB8U);
        }
        {
            r0 = r8;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAAC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAAC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAAC4;
    }
block_003DAAC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAAC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAAC4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x84U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DAAC4U, address);
            }
        }
        {
            r2 = 0x00000003U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAAD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAAD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAAD8;
    }
block_003DAAD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAAD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAAD8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x84U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAAD8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAAE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAAE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAAE8;
    }
block_003DAAE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAAE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAAE8U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAAF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAAF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAAF4;
    }
block_003DAAF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAAF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAAF4U);
        }
        {
            const uint32_t address = r0 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAAF4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x003DAB00U + 0xC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAAF8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = r6 + 504U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAAFCU, address);
            }
        }
        {
            const uint32_t address = r0 + 144U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAB00U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 508U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAB04U, address);
            }
        }
        {
            const uint32_t address = r0 + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAB08U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 512U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAB0CU, address);
            }
        }
        {
            const uint32_t address = r0 + 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAB10U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 516U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAB14U, address);
            }
        }
        {
            const uint32_t address = r0 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAB18U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 520U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAB1CU, address);
            }
        }
        {
            const uint32_t address = r0 + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAB20U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t address = r6 + 524U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAB28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DAB2CU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DAB34U, address);
            }
        }
        {
            const uint32_t address = r4 + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAB38U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DAB48U, address);
            }
        }
        goto block_003DBD5C;
    }
block_003DABC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DABC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DABC4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DABC4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000388U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DABD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DABD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DABD8;
    }
block_003DABD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DABD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DABD8U);
        }
        {
            const uint32_t address = 0x003DABE0U + 720U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DABD8U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DABDCU, 0xEE200A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DABE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DABE4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000388U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DABF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DABF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DABF8;
    }
block_003DABF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DABF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DABF8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DABF8U, 0xEE200A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[21] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x003DAC10U + 676U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAC08U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x000003D8U;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[21];
        }
        {
            const uint32_t address = r6 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAC14U, address);
            }
        }
        {
            const uint32_t address = 0x003DAC20U + 664U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAC18U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAC20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAC20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAC20;
    }
block_003DAC20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAC20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAC20U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAC20U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAC2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAC2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAC2C;
    }
block_003DAC2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAC2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAC2CU);
        }
        {
            const uint32_t address = 0x003DAC34U + 648U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAC2CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAC30U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAC34U, 0xEE608A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAC3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAC3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAC3C;
    }
block_003DAC3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAC3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAC3CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAC3CU, 0xEE20AA0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAC40U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAC4CU, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x003DAC58U - 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAC50U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r0 = r11;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAC60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAC60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAC60;
    }
block_003DAC60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAC60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAC60U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAC60U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAC6CU, 0xEE300A0DU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[26], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAC74U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAC7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAC7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAC7C;
    }
block_003DAC7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAC7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAC7CU);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAC7CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAC88U, 0xEE300A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000A00U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAC98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAC98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAC98;
    }
block_003DAC98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAC98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAC98U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DACA4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DACA8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DACB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DACB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DACB0;
    }
block_003DACB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DACB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DACB0U);
        }
        {
            const uint32_t address = r4 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DACB0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003DACBCU - 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DACB4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DACC0U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0xC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DACC8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DACD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DACD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DACD0;
    }
block_003DACD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DACD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DACD0U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DACDCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DACE0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DACE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DACE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DACE8;
    }
block_003DACE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DACE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DACE8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DACE8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003DAD0C; }
        goto block_003DACF4;
    }
block_003DACF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DACF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DACF4U);
        }
        {
            const uint32_t address = r6 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DACF4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r6 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DACF8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x0000003CU;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAD0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00315350_00315350(frame, context, state, 0x00315350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAD0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAD0C;
    }
block_003DAD0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAD0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAD0CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[27];
        }
        {
            const uint32_t address = r13 + 144U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAD10U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAD1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_IsFrameCrossed_0036E5E0(frame, context, state, 0x0036E5E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAD1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAD1C;
    }
block_003DAD1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAD1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAD1CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_003DBD5C; }
        goto block_003DAD28;
    }
block_003DAD28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAD28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAD28U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            const uint32_t updatedAddress = 0x003DAD38U + 0x18CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAD30U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x003DAD3CU + 388U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAD34U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t address = r13 + 144U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAD3CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAD48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_ChangeAnimation_00353020(frame, context, state, 0x00353020U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAD48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAD48;
    }
block_003DAD48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAD48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAD48U);
        }
        {
            r0 = 0x00000006U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DAD50U, address);
            }
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = 0x00006000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003DAD5CU, address);
            }
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DAD60U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DAD60U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DAD60U,
                                           firstAddress + 8U);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[30];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[29];
        }
        {
            r3 = r1;
        }
        {
            const uint32_t updatedAddress = r13 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAD70U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003DAD7CU + 332U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAD74U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = 0x00000059U;
        }
        {
            r1 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAD84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Spawn_003738D0(frame, context, state, 0x003738D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAD84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAD84;
    }
block_003DAD84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAD84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAD84U);
        }
        {
        }
        {
        }
        goto block_003DBD5C;
    }
block_003DAD90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAD90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAD90U);
        }
        {
            const uint32_t address = r6 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAD90U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r6 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAD94U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x0000003CU;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DADA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00315350_00315350(frame, context, state, 0x00315350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DADA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DADA8;
    }
block_003DADA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DADA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DADA8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x94U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DADA8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x000007D0U;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r5 + 0x94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DADBCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DADC0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DADC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DADCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DADCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DADCC;
    }
block_003DADCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DADCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DADCCU);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DADCCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003DADD8U - 564U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DADD0U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[26];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DADDCU, 0xEE300A4BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0xC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DADE4U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DADE8U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DADF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DADF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DADF0;
    }
block_003DADF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DADF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DADF0U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DADFCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAE00U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAE08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAE08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAE08;
    }
block_003DAE08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAE08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAE08U);
        }
        {
            const uint32_t address = r7 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAE08U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003DAE14U - 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAE0CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            r0 = r11;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAE14U, 0xEE201A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[29];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAE28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAE28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAE28;
    }
block_003DAE28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAE28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAE28U);
        }
        {
            const uint32_t address = r7 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAE28U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAE34U, 0xEE201A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[30];
        }
        {
            const uint32_t operand = 0x00000A00U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAE44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAE44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAE44;
    }
block_003DAE44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAE44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAE44U);
        }
        {
            frame.Guest.vfp[25] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAE50U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAE60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAE60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAE60;
    }
block_003DAE60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAE60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAE60U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAE60U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003DAEDC; }
        goto block_003DAE6C;
    }
block_003DAE6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAE6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAE6CU);
        }
        {
            const uint32_t address = r7 + 948U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAE6CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = 0x00000008U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAE74U, 0xEE200A2DU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[27], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAE78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DAE7CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x72U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAE80U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x003DAE90U + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAE88U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) {
            const uint32_t address = 0x003DAE94U + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAE8CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x003DAE98U + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAE90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r6 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAE94U, address);
            }
        }
        {
            const uint32_t address = 0x003DAEA0U + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAE98U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAE9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DAEA0U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DAEA8U, address);
            }
        }
        goto block_003DBD5C;
    }
block_003DAEDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAEDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAEDCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x70U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAEDCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x003DAEE8U + 0x308U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAEE0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x003DAEECU - 832U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAEE4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003DAEF0U + 776U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAEE8U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r7 + 956U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAEF0U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r9 = r1 + operand;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[25];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x003DAF10U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAF08U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x000003B4U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAF14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAF14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAF14;
    }
block_003DAF14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAF14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAF14U);
        }
        {
            const uint32_t address = r9 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAF14U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAF18U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAF1CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = 0x003DAF28U + 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAF20U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAF24U, 0xEE700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r9 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAF28U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAF2CU, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAF30U, 0xEE600AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAF34U, 0xEE400A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAF38U, 0xEEB10AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x003DAF44U + 696U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAF3CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAF40U, 0xEE30AA60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAF44U, 0xEEB4AAC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[20], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        {
            const uint32_t address = 0x003DAF54U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAF4CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x003DAF58U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAF50U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        if (flags.C()) {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAF54U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003DAF60U + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAF58U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        if (flags.C()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[20] = frame.Guest.vfp[16];
        }
        {
            r0 = frame.Guest.vfp[20];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAF6CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[20] = frame.Guest.vfp[22];
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAF78U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAF7CU, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAF80U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAF84U, 0xEE200A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAF88U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAF98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAF98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAF98;
    }
block_003DAF98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAF98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAF98U);
        }
        {
            const uint32_t address = 0x003DAFA0U + 624U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAF98U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAF9CU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAFA0U, 0xEE200A2BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAFA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAFA8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAFB0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAFB4U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAFB8U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAFBCU, 0xEE200A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAFC0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DAFD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DAFD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DAFD0;
    }
block_003DAFD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DAFD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DAFD0U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAFD0U, 0xEE200A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x003DAFDCU + 568U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAFD4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[25];
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t address = r13 + 172U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAFE4U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r13 + 180U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAFECU, address);
            }
        }
        {
            const uint32_t address = r13 + 176U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DAFF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DAFF4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DAFFCU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB000U, 0xEE20AA20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB004U, 0xEEB4AA49U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[20], frame.Guest.vfp[18],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.Z()) {
            frame.Guest.vfp[16] = frame.Guest.vfp[18];
        }
        if (flags.Z()) {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        if (flags.Z()) { goto block_003DB02C; }
        goto block_003DB018;
    }
block_003DB018:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB018U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB018U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB020U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB020U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB020;
    }
block_003DB020:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB020U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB020U);
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB02CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB02CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB02C;
    }
block_003DB02C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB02CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB02CU);
        }
        {
            const uint32_t address = r13 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB02CU, address);
            }
        }
        {
            const uint32_t address = r13 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x003DB030U, address);
            }
        }
        {
            const uint32_t address = r13 + 104U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003DB034U, address);
            }
        }
        {
            const uint32_t address = r13 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x003DB038U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB03CU, 0xEEF10A48U};
            frame.Guest.vfp[1] = frame.Guest.vfp[16] ^ 0x80000000U;
        }
        {
            const uint32_t address = r13 + 116U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x003DB040U, address);
            }
        }
        {
            const uint32_t address = r13 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x003DB044U, address);
            }
        }
        {
            const uint32_t address = r13 + 120U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x003DB048U, address);
            }
        }
        {
            const uint32_t address = r13 + 124U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x003DB04CU, address);
            }
        }
        {
            const uint32_t address = r13 + 128U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003DB050U, address);
            }
        }
        {
            const uint32_t address = r13 + 132U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x003DB054U, address);
            }
        }
        {
            const uint32_t address = r13 + 136U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB058U, address);
            }
        }
        {
            const uint32_t address = r13 + 140U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x003DB05CU, address);
            }
        }
        {
            const uint32_t operand = 0x000000ACU;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000060U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x000000A0U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB070U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_transform_mtx3x4_vec3_003735AC(frame, context, state, 0x003735ACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB070U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB070;
    }
block_003DB070:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB070U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB070U);
        }
        {
            const uint32_t address = r9 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB070U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 160U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB074U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r7 + 948U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB07CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB080U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB090U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB090U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB090;
    }
block_003DB090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB090U);
        }
        {
            const uint32_t address = r9 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB090U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB094U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r7 + 948U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB09CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB0A0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x00000030U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB0B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB0B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB0B0;
    }
block_003DB0B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB0B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB0B0U);
        }
        {
            const uint32_t updatedAddress = 0x003DB0B8U + 0x160U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB0B0U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB0BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB0BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB0BC;
    }
block_003DB0BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB0BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB0BCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB0BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000007U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003DB0DC; }
        goto block_003DB0C8;
    }
block_003DB0C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB0C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB0C8U);
        }
        {
            r3 = 0x00000008U;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x00000364U;
            r0 = r8 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB0DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Camera_RequestQuake_0036627C(frame, context, state, 0x0036627CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB0DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB0DC;
    }
block_003DB0DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB0DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB0DCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB0DCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003DB114; }
        goto block_003DB0E8;
    }
block_003DB0E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB0E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB0E8U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            r1 = 0x000001F4U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB0F4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB0F4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DB0F4U,
                                           firstAddress + 8U);
            }
        }
        {
            r3 = 0x00000003U;
        }
        {
            const uint32_t address = 0x003DB104U + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB0FCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x003DB108U + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB100U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r2 = r4 + operand;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB114U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnFloorDustRing_0036F00C(frame, context, state, 0x0036F00CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB114U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB114;
    }
block_003DB114:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB114U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB114U);
        }
        {
            const uint32_t address = r9 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB114U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB118U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB124U, 0xEE308A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r9 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB128U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB12CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x000003B8U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB134U, 0xEE30AA60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 956U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB138U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB140U, 0xEE201A0CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[24], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x003DB14CU + 216U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB144U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB14CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB14CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB14C;
    }
block_003DB14C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB14CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB14CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB158U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_FAtan2F_003696EC(frame, context, state, 0x003696ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB158U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB158;
    }
block_003DB158:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB158U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB158U);
        }
        {
            const uint32_t address = 0x003DB160U + 200U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB158U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003DB160U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB164U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 956U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB168U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = 0x00000005U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB170U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r7 + 952U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB178U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB17CU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB184U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000036U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB198U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToS_00375A18(frame, context, state, 0x00375A18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB198U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB198;
    }
block_003DB198:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB198U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB198U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB198U, 0xEEB00AC8U};
            frame.Guest.vfp[0] = frame.Guest.vfp[16] & 0x7FFFFFFFU;
        }
        {
            const uint32_t updatedAddress = 0x003DB1A4U + 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB19CU, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB1A8U, 0xDEB00ACAU};
            frame.Guest.vfp[0] = frame.Guest.vfp[20] & 0x7FFFFFFFU;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r1 = frame.Guest.vfp[0];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003DBD5C; }
        goto block_003DB1B8;
    }
block_003DB1B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB1B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB1B8U);
        }
        {
            const uint32_t updatedAddress = 0x003DB1C0U + 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB1B8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x003DB1BCU, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB1C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB1C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB1C8;
    }
block_003DB1C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB1C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB1C8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x72U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB1C8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r5 + 0x70U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB1D0U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_003DB234; }
        goto block_003DB1D8;
    }
block_003DB1D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB1D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB1D8U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DB1E4U, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r5 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x003DB1E8U, address);
            }
        }
        goto block_003DB24C;
    }
block_003DB234:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB234U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB234U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DB240U, address);
            }
        }
        if ((flags.N()) != (flags.V())) {
            r0 = 0x00000003U;
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r5 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DB248U, address);
            }
        }
        goto block_003DB24C;
    }
block_003DB24C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB24CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB24CU);
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DB250U, address);
            }
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB254U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t address = r13 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB25CU, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB260U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            const uint32_t operand = 0x00000054U;
            r1 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB26CU, 0xEE300A0EU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[28], frame.Guest.fpscr));
        }
        {
            r0 = r8;
        }
        {
            const uint32_t address = r13 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB274U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB278U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB27CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003DB280U, faultAddress);
            }
        }
        {
            r3 = 0x00000320U;
        }
        {
            r2 = 0x00000028U;
        }
        {
            const uint32_t address = 0x003DB294U + 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB28CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB294U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsDust_SpawnRandomBrown_0037378C(frame, context, state, 0x0037378CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB294U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB294;
    }
block_003DB294:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB294U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB294U);
        }
        {
        }
        {
        }
        goto block_003DBD5C;
    }
block_003DB2A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB2A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB2A0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB2A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000005A0U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x003DB2B0U + 0x36CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB2A8U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB2B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB2B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB2B4;
    }
block_003DB2B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB2B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB2B4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB2B4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x0000014CU;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x003DB2C8U + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB2C0U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB2CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB2CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB2CC;
    }
block_003DB2CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB2CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB2CCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB2CCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000500U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000065U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (!(flags.Z())) { goto block_003DB350; }
        goto block_003DB2DC;
    }
block_003DB2DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB2DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB2DCU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB2DCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003DB2E4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB2ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB2ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB2EC;
    }
block_003DB2EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB2ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB2ECU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[31];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x0000005CU;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB304U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB310U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_ChangeAnimation_00353020(frame, context, state, 0x00353020U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB310U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB310;
    }
block_003DB310:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB310U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB310U);
        }
        {
            const uint32_t address = r6 + 504U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB310U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB314U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB318U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB31CU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 512U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB320U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB324U, 0xEE700AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB328U, 0xEE201A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB32CU, 0xEE001AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB330U, 0xEEB11AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 1020U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x003DB334U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB33CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_FAtan2F_003696EC(frame, context, state, 0x003696ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB33CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB33C;
    }
block_003DB33C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB33CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB33CU);
        }
        {
            const uint32_t updatedAddress = 0x003DB344U + 0x2E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB33CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r6 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB340U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xACU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DB344U, address);
            }
        }
        {
            r0 = 0x00000009U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DB34CU, address);
            }
        }
        goto block_003DB350;
    }
block_003DB350:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB350U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB350U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB350U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x003DB35CU + 0x2CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB354U, address);
            }
            r9 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r9, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_003DB3F8; }
        goto block_003DB360;
    }
block_003DB360:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB360U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB360U);
        }
        {
            const uint32_t updatedAddress = 0x003DB368U + 0x2C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB360U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000050U;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = 0x003DB370U + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB368U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DB36CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DB36CU,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003DB36CU,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x003DB36CU,
                                           firstAddress + 12U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
            r14 = value14;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB374U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DB374U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x003DB374U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003DB374U,
                                           firstAddress + 12U);
            }
        }
        {
            r3 = 0x00000002U;
        }
        {
            r2 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB380U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r0;
            r0 = r9 - operand;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB390U, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB398U, 0xEE000AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r13 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB3A0U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB3A4U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        {
            const uint32_t address = r13 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB3B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003DB3B4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000050U;
            r3 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB3C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelOwner_ApplyTevConstantColor_00357A50(frame, context, state, 0x00357A50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB3C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB3C0;
    }
block_003DB3C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB3C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB3C0U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003DB3C4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000050U;
            r3 = r13 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB3DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelOwner_ApplyTevConstantColor_00357A50(frame, context, state, 0x00357A50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB3DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB3DC;
    }
block_003DB3DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB3DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB3DCU);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003DB3E0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000050U;
            r3 = r13 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB3F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelOwner_ApplyTevConstantColor_00357A50(frame, context, state, 0x00357A50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB3F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB3F8;
    }
block_003DB3F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB3F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB3F8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB3F8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000500U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = 0x003DB408U + 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB400U, address);
            }
            r1 = value;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = r4;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB40CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB40CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB40C;
    }
block_003DB40C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB40CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB40CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB40CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000005A0U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003DB65C; }
        goto block_003DB418;
    }
block_003DB418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB418U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[31];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x000000CCU;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB430U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB430U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB430;
    }
block_003DB430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB430U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB430U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x003DB43CU + 0x1FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB434U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_003DB6A0; }
        goto block_003DB440;
    }
block_003DB440:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB440U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB440U);
        }
        {
        }
        if (!(flags.Z())) { goto block_003DB4C4; }
        goto block_003DB448;
    }
block_003DB448:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB448U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB448U);
        }
        {
            const uint32_t updatedAddress = 0x003DB450U + 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB448U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r14 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003DB450U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DB450U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DB450U,
                                           firstAddress + 8U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003DB450U,
                                           firstAddress + 12U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003DB450U,
                                           firstAddress + 16U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r9 = value9;
            r12 = value12;
            r0 = r0 + 20U;
        }
        {
            const uint32_t firstAddress = r14;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB454U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB454U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DB454U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r9)) {
                return Oot3dAotMemoryFault(context, 0x003DB454U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r12)) {
                return Oot3dAotMemoryFault(context, 0x003DB454U,
                                           firstAddress + 16U);
            }
            r14 = r14 + 20U;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003DB458U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DB458U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DB458U,
                                           firstAddress + 8U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003DB458U,
                                           firstAddress + 12U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003DB458U,
                                           firstAddress + 16U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r9 = value9;
            r12 = value12;
            r0 = r0 + 20U;
        }
        {
            const uint32_t firstAddress = r14;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB45CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB45CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DB45CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r9)) {
                return Oot3dAotMemoryFault(context, 0x003DB45CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r12)) {
                return Oot3dAotMemoryFault(context, 0x003DB45CU,
                                           firstAddress + 16U);
            }
            r14 = r14 + 20U;
        }
        {
            r9 = r13;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003DB464U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DB464U,
                                           firstAddress + 4U);
            }
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t updatedAddress = 0x003DB470U + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB468U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r14;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB46CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB46CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000028U;
            r14 = r14 - operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003DB474U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DB474U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DB474U,
                                           firstAddress + 8U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003DB474U,
                                           firstAddress + 12U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
            r0 = r0 + 16U;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB478U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB478U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DB478U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r12)) {
                return Oot3dAotMemoryFault(context, 0x003DB478U,
                                           firstAddress + 12U);
            }
            r9 = r9 + 16U;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003DB47CU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DB47CU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DB47CU,
                                           firstAddress + 8U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003DB47CU,
                                           firstAddress + 12U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
            r0 = r0 + 16U;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB480U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB480U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DB480U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r12)) {
                return Oot3dAotMemoryFault(context, 0x003DB480U,
                                           firstAddress + 12U);
            }
            r9 = r9 + 16U;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003DB484U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DB484U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DB484U,
                                           firstAddress + 8U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003DB484U,
                                           firstAddress + 12U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB48CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB48CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DB48CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r12)) {
                return Oot3dAotMemoryFault(context, 0x003DB48CU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000020U;
            r9 = r9 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x96U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DB494U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x72U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB498U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0x70U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB4A0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r9 + operand;
        }
        if (flags.Z()) {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r14 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB4B0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r10 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB4B4U, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB4B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r10 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB4BCU, address);
            }
        }
        {
            const uint32_t address = r7 + 980U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003DB4C0U, address);
            }
        }
        goto block_003DB4C4;
    }
block_003DB4C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB4C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB4C4U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB4D4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x003DB4E0U + 0x164U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB4D8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = 0x003DB4E4U + 356U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB4DCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000003F8U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB4E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB4E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB4E8;
    }
block_003DB4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB4E8U);
        }
        {
            const uint32_t updatedAddress = 0x003DB4F0U + 0x15CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB4E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003DB4F4U + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB4ECU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t firstAddress = r0 + 4U;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003DB4F0U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DB4F0U,
                                           firstAddress + 4U);
            }
            r1 = value1;
            r2 = value2;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t updatedAddress = r13 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003DB4F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003DB4FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003DB500U, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x50U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r1) << 32U |
                                   r0;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003DB504U, faultAddress);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB50CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB50CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB50C;
    }
block_003DB50C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB50CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB50CU);
        }
        {
            const uint32_t address = r4 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB50CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB510U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 148U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB514U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB520U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB520U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB520;
    }
block_003DB520:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB520U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB520U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB520U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB524U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 152U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB528U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB534U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB534U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB534;
    }
block_003DB534:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB534U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB534U);
        }
        {
            const uint32_t address = r4 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB534U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x003DB540U + 0x114U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB538U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x0000000AU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB540U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = 0x000001F4U;
        }
        {
            const uint32_t address = r13 + 156U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB548U, address);
            }
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x003DB54CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB54CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DB54CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000094U;
            r1 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003DB554U, address);
            }
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003DB55CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003DB568U - 0xA04U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB560U, address);
            }
            r3 = value;
        }
        {
            r0 = r8;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r3 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB570U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsDust_SpawnUpdateRateScaled_00365D20(frame, context, state, 0x00365D20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB570U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB570;
    }
block_003DB570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB570U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB57CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB57CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB57C;
    }
block_003DB57C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB57CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB57CU);
        }
        {
            const uint32_t address = r4 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB57CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB580U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 148U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB584U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r13 + 152U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x003DB58CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB594U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB594U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB594;
    }
block_003DB594:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB594U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB594U);
        }
        {
            const uint32_t address = r4 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB594U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB598U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 156U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB59CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB5A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB5A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB5A4;
    }
block_003DB5A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB5A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB5A4U);
        }
        {
            const uint32_t address = 0x003DB5ACU + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB5A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB5A8U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB5ACU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r9 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB5BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB5BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB5BC;
    }
block_003DB5BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB5BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB5BCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB5BCU, 0xEE200A0CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[24], frame.Guest.fpscr));
        }
        {
            r1 = 0x00000064U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB5C4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000094U;
            r1 = r13 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r9;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x0000000AU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x003DB5E8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r9)) {
                return Oot3dAotMemoryFault(context, 0x003DB5E8U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000050U;
            r0 = r13 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 2U);
            r3 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000058U;
            r0 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003DB5F8U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 2U);
            r2 = r0 + operand;
        }
        {
            r0 = r8;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x003DB604U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB60CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003373c8_003373C8(frame, context, state, 0x003373C8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB60CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB60C;
    }
block_003DB60C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB60CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB60CU);
        }
        {
        }
        {
        }
        goto block_003DB6A0;
    }
block_003DB65C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB65CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB65CU);
        }
        {
            const uint32_t updatedAddress = 0x003DB664U - 0x44CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB65CU, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB668U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB668U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB668;
    }
block_003DB668:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB668U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB668U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB668U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003DB6A0; }
        goto block_003DB674;
    }
block_003DB674:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB674U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB674U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            r1 = 0x000001F4U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB680U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB680U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DB680U,
                                           firstAddress + 8U);
            }
        }
        {
            r3 = 0x00000003U;
        }
        {
            const uint32_t address = 0x003DB690U + 808U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB688U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x003DB694U + 808U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB68CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r2 = r4 + operand;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB6A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnFloorDustRing_0036F00C(frame, context, state, 0x0036F00CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB6A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB6A0;
    }
block_003DB6A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB6A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB6A0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x003DB6ACU + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB6A4U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x0000006CU;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB6BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB6BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB6BC;
    }
block_003DB6BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB6BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB6BCU);
        }
        {
            const uint32_t address = r6 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB6BCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB6C0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB6C4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r0;
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DB6D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB6D4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x003DB6E0U + 0x2E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB6D8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003DB708; }
        goto block_003DB6E4;
    }
block_003DB6E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB6E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB6E4U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003DB6ECU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r4 + operand;
        }
        {
            r3 = 0x000003E8U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000394U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB708U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00257108_00257108(frame, context, state, 0x00257108U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB708U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB708;
    }
block_003DB708:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB708U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB708U);
        }
        {
            const uint32_t address = r6 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB708U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x94U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB70CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x003DB718U + 692U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB710U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB714U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r0;
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DB720U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB724U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x003DB730U + 0x298U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB728U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003DB778; }
        goto block_003DB734;
    }
block_003DB734:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB734U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB734U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x72U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB734U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r6 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB738U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003DB744U + 652U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB73CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        if (!(flags.Z())) { goto block_003DB760; }
        goto block_003DB74C;
    }
block_003DB74C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB74CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB74CU);
        }
        {
            const uint32_t updatedAddress = 0x003DB754U + 0x280U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB74CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003DB794; }
        goto block_003DB758;
    }
block_003DB758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB758U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB758U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        goto block_003DB770;
    }
block_003DB760:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB760U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB760U);
        }
        {
            const uint32_t updatedAddress = 0x003DB768U + 0x270U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB760U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_003DB794; }
        goto block_003DB76C;
    }
block_003DB76C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB76CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB76CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB76CU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        goto block_003DB770;
    }
block_003DB770:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB770U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB770U);
        }
        {
            const uint32_t address = r6 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB770U, address);
            }
        }
        goto block_003DB794;
    }
block_003DB778:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB778U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB778U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[24];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x003DB78CU + 592U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB784U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB794U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB794U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB794;
    }
block_003DB794:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB794U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB794U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x003DB7ACU + 564U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB7A4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB7B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB7B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB7B0;
    }
block_003DB7B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB7B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB7B0U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB7BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB7C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB7C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB7C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB7C8;
    }
block_003DB7C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB7C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB7C8U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB7C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003DB7D4U + 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB7CCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[26];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB7D8U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0xC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB7E0U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB7E4U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB7ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB7ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB7EC;
    }
block_003DB7EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB7ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB7ECU);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB7F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB7FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB804U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB804U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB804;
    }
block_003DB804:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB804U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB804U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB804U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r9 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r9 = r9 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_003DB9F8; }
        goto block_003DB818;
    }
block_003DB818:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB818U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB818U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB818U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x003DB824U - 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB81CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_003DB8F0; }
        goto block_003DB828;
    }
block_003DB828:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB828U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB828U);
        }
        {
            const uint32_t updatedAddress = 0x003DB830U + 0x1B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB828U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r6 = r13 + operand;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003DB838U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DB838U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DB838U,
                                           firstAddress + 8U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003DB838U,
                                           firstAddress + 12U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003DB838U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x003DB838U,
                                           firstAddress + 20U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r9 = value9;
            r12 = value12;
            r14 = value14;
            r0 = r0 + 24U;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB83CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB83CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DB83CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r9)) {
                return Oot3dAotMemoryFault(context, 0x003DB83CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r12)) {
                return Oot3dAotMemoryFault(context, 0x003DB83CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003DB83CU,
                                           firstAddress + 20U);
            }
            r6 = r6 + 24U;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003DB840U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DB840U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DB840U,
                                           firstAddress + 8U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003DB840U,
                                           firstAddress + 12U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003DB840U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x003DB840U,
                                           firstAddress + 20U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r9 = value9;
            r12 = value12;
            r14 = value14;
        }
        {
            const uint32_t updatedAddress = 0x003DB84CU + 0x1A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB844U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB848U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB848U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DB848U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r9)) {
                return Oot3dAotMemoryFault(context, 0x003DB848U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r12)) {
                return Oot3dAotMemoryFault(context, 0x003DB848U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003DB848U,
                                           firstAddress + 20U);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r6 = r6 - operand;
        }
        {
            r9 = r13;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003DB854U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DB854U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DB854U,
                                           firstAddress + 8U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003DB854U,
                                           firstAddress + 12U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x003DB854U,
                                           firstAddress + 16U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
            r14 = value14;
            r0 = r0 + 20U;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB858U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB858U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DB858U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r12)) {
                return Oot3dAotMemoryFault(context, 0x003DB858U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003DB858U,
                                           firstAddress + 16U);
            }
            r9 = r9 + 20U;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003DB85CU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DB85CU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DB85CU,
                                           firstAddress + 8U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003DB85CU,
                                           firstAddress + 12U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x003DB85CU,
                                           firstAddress + 16U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r12 = value12;
            r14 = value14;
            r0 = r0 + 20U;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB860U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB860U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DB860U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r12)) {
                return Oot3dAotMemoryFault(context, 0x003DB860U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003DB860U,
                                           firstAddress + 16U);
            }
            r9 = r9 + 20U;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003DB864U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DB864U,
                                           firstAddress + 4U);
            }
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x003DB868U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DB868U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000028U;
            r9 = r9 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x72U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB870U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r7 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB874U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0x70U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB87CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB880U, 0xEE201A0DU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[26], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r0 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r6 = r9 + operand;
        }
        if (flags.Z()) {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r6 = r6 + operand;
        }
        {
            r0 = r11;
        }
        {
            const uint32_t address = r6 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB894U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB89CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB89CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB89C;
    }
block_003DB89C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB89CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB89CU);
        }
        {
            const uint32_t address = r7 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB89CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB8A8U, 0xEE201A0DU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[26], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r10 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB8ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB8B0U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB8B4U, 0xEE300A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB8BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB8BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB8BC;
    }
block_003DB8BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB8BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB8BCU);
        }
        {
            const uint32_t address = r7 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB8BCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB8C8U, 0xEE201A0DU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[26], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB8CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000A00U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB8D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB8D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB8D8;
    }
block_003DB8D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB8D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB8D8U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r13 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB8E0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003DB8ECU + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB8E4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        goto block_003DB9B0;
    }
block_003DB8F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB8F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB8F0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x72U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB8F0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r6 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB8F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB900U, 0x1E300A6BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000003FCU;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        if (flags.Z()) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB914U, 0x0E300A2BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DB918U, address);
            }
        }
        {
            const uint32_t address = 0x003DB924U + 208U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB91CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB924U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB924U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB924;
    }
block_003DB924:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB924U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB924U);
        }
        {
            const uint32_t address = r6 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB924U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB92CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB92CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB92C;
    }
block_003DB92C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB92CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB92CU);
        }
        {
            const uint32_t address = r7 + 1020U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB92CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB930U, 0xEE608A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB934U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB93CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB93CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB93C;
    }
block_003DB93C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB93CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB93CU);
        }
        {
            const uint32_t address = r7 + 1020U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB93CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB948U, 0xEE609A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB94CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            r0 = r11;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB958U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB960U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB960U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB960;
    }
block_003DB960:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB960U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB960U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB960U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x003DB96CU + 80U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB964U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB970U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r13 + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB978U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB980U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB980U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB980;
    }
block_003DB980:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB980U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB980U);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DB980U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[22];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DB98CU, 0xEE300A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000A00U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB99CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB99CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB99C;
    }
block_003DB99C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB99CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB99CU);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[23];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r0 = r9;
        }
        goto block_003DB9B0;
    }
block_003DB9B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB9B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB9B0U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DB9B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DB9B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DB9B4;
    }
block_003DB9B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB9B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB9B4U);
        }
        goto block_003DBA84;
    }
block_003DB9F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DB9F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DB9F8U);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[24];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r5 + 0x72U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBA04U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003DBA28; }
        goto block_003DBA10;
    }
block_003DBA10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBA10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBA10U);
        }
        {
            r0 = r9;
        }
        {
            const uint32_t address = 0x003DBA1CU + 872U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBA14U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBA1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBA1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBA1C;
    }
block_003DBA1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBA1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBA1CU);
        }
        {
        }
        {
        }
        goto block_003DBA34;
    }
block_003DBA28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBA28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBA28U);
        }
        {
            const uint32_t address = 0x003DBA30U + 856U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBA28U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBA34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBA34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBA34;
    }
block_003DBA34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBA34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBA34U);
        }
        {
            const uint32_t address = r7 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBA34U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBA40U, 0xEE201A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[29];
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBA50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBA50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBA50;
    }
block_003DBA50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBA50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBA50U);
        }
        {
            const uint32_t address = r7 + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBA50U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBA5CU, 0xEE201A2CU};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[25], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[30];
        }
        {
            const uint32_t operand = 0x00000A00U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBA6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBA6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBA6C;
    }
block_003DBA6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBA6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBA6CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[24];
        }
        {
            const uint32_t updatedAddress = r13 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBA78U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBA84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToF_0036E168(frame, context, state, 0x0036E168U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBA84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBA84;
    }
block_003DBA84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBA84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBA84U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBA84U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x000000CEU;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (!(flags.Z())) { goto block_003DBBCC; }
        goto block_003DBA94;
    }
block_003DBA94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBA94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBA94U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x003DBAA0U + 0x2ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBA98U, address);
            }
            r1 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBAA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_QueueSeqCmd_0036EC40(frame, context, state, 0x0036EC40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBAA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBAA4;
    }
block_003DBAA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBAA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBAA4U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBAB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b164_0035B164(frame, context, state, 0x0035B164U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBAB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBAB0;
    }
block_003DBAB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBAB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBAB0U);
        }
        {
            const uint32_t value = r0 ^ 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
        }
        if (flags.Z()) { goto block_003DBB20; }
        goto block_003DBABC;
    }
block_003DBABC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBABCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBABCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBABCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBAC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBAC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBAC4;
    }
block_003DBAC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBAC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBAC4U);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBAC4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x003DBAD0U + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBAC8U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBACCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBAD0U, 0xEE408A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[17], frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBAD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBAD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBAD8;
    }
block_003DBAD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBAD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBAD8U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBADCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x003DBAE8U, faultAddress);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBAF0U, 0xEE000A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003DBAF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003DBAF8U, address);
            }
        }
        {
            r3 = r2;
        }
        {
            const uint32_t updatedAddress = r13 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBB00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBB04U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = 0x0000005FU;
        }
        {
            r1 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBB14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Spawn_003738D0(frame, context, state, 0x003738D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBB14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBB14;
    }
block_003DBB14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBB14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBB14U);
        }
        {
        }
        {
        }
        goto block_003DBBCC;
    }
block_003DBB20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBB20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBB20U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBB28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b0a0_0035B0A0(frame, context, state, 0x0035B0A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBB28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBB28;
    }
block_003DBB28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBB28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBB28U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_003DBBCC; }
        goto block_003DBB34;
    }
block_003DBB34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBB34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBB34U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBB34U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBB38U, 0xEE700A6EU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[29], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBB3CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBB40U, 0xEE300A4FU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[30], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBB48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Atan2S_003758B0(frame, context, state, 0x003758B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBB48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBB48;
    }
block_003DBB48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBB48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBB48U);
        }
        {
            r6 = r0;
        }
        {
            const uint32_t operand = 0x00008C00U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            r7 = r0;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBB5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBB5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBB5C;
    }
block_003DBB5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBB5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBB5CU);
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[29];
        }
        {
            const uint32_t address = 0x003DBB68U + 556U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBB60U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r0 = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBB68U, 0xEE00AA28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBB70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBB70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBB70;
    }
block_003DBB70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBB70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBB70U);
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[30];
        }
        {
            const uint32_t operand = 0x00007400U;
            r0 = r6 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            r7 = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBB80U, 0xEE409A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBB88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBB88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBB88;
    }
block_003DBB88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBB88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBB88U);
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[29];
        }
        {
            r0 = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBB90U, 0xEE009A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBB98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBB98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBB98;
    }
block_003DBB98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBB98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBB98U);
        }
        {
            frame.Guest.vfp[5] = frame.Guest.vfp[30];
        }
        {
            const uint32_t address = 0x003DBBA4U + 500U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBB9CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00008000U;
            r0 = r6 + operand;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[4] = frame.Guest.vfp[1];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBBB0U, 0xEE402A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r3 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r2 = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBBCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035af20_0035AF20(frame, context, state, 0x0035AF20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBBCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBBCC;
    }
block_003DBBCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBBCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBBCCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBBCCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000384U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003DBCB0; }
        goto block_003DBBD8;
    }
block_003DBBD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBBD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBBD8U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBBE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBBE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBBE4;
    }
block_003DBBE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBBE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBBE4U);
        }
        {
            const uint32_t firstAddress = r11;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DBBE4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DBBE4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003DBBE4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DBBECU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DBBECU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003DBBECU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r1 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DBBF4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DBBF4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003DBBF4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DBBFCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DBBFCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003DBBFCU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBC00U, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DBC04U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DBC04U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003DBC04U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x003DBC08U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DBC08U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003DBC08U,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x84U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBC10U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBC1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBC1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBC1C;
    }
block_003DBC1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBC1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBC1CU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x8CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DBC20U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x84U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DBC24U, address);
            }
        }
        {
            r0 = 0x00000064U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DBC2CU, address);
            }
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBC40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBC40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBC40;
    }
block_003DBC40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBC40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBC40U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBC4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetRuntimeFlag200_0035AF04(frame, context, state, 0x0035AF04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBC4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBC4C;
    }
block_003DBC4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBC4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBC4CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0xD0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBC4CU, address);
            }
            r1 = value;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBC58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBC58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBC58;
    }
block_003DBC58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBC58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBC58U);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBC68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBC68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBC68;
    }
block_003DBC68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBC68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBC68U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[30];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[29];
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003DBC74U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003DBC78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003DBC7CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003DBC80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBC84U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x003DBC90U + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBC88U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = 0x0000005DU;
        }
        {
            r2 = r8;
        }
        {
            r1 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBC9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBC9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBC9C;
    }
block_003DBC9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBC9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBC9CU);
        }
        {
            const uint32_t updatedAddress = 0x003DBCA4U + 0xFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBC9CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 484U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x003DBCA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBCA4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBCB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_SetClear_0036EC14(frame, context, state, 0x0036EC14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBCB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBCB0;
    }
block_003DBCB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBCB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBCB0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xAAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBCB0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x003DBCBCU - 0x684U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBCB4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003DBD5C; }
        goto block_003DBCC0;
    }
block_003DBCC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBCC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBCC0U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBCC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBCC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBCC4;
    }
block_003DBCC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBCC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBCC4U);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_003DBD5C; }
        goto block_003DBCD0;
    }
block_003DBCD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBCD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBCD0U);
        }
        {
            const uint32_t updatedAddress = 0x003DBCD8U - 0x68CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBCD0U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[28];
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBCD8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DBCDCU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003DBCE4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBCECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBCECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBCEC;
    }
block_003DBCEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBCECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBCECU);
        }
        {
            const uint32_t address = r4 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBCECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBCF0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DBCF4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBCFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBCFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBCFC;
    }
block_003DBCFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBCFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBCFCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBCFCU, 0xEE40DA0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[27], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[27], frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[28];
        }
        {
            const uint32_t address = r13 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x003DBD04U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBD0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBD0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBD0C;
    }
block_003DBD0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBD0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBD0CU);
        }
        {
            const uint32_t address = r4 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBD0CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBD10U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003DBD14U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBD1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBD1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBD1C;
    }
block_003DBD1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBD1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBD1CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBD1CU, 0xEE200A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            r1 = 0x00000032U;
        }
        {
            r3 = 0x00000001U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003DBD28U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000054U;
            r1 = r13 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x003DBD40U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x003DBD40U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003DBD44U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003DBD48U, address);
            }
        }
        {
            const uint32_t operand = 0x0000004CU;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000050U;
            r2 = r13 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBD5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003373c8_003373C8(frame, context, state, 0x003373C8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBD5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBD5C;
    }
block_003DBD5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBD5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBD5CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x84U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBD5CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_003DBD78; }
        goto block_003DBD68;
    }
block_003DBD68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBD68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBD68U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003DBD68U, address);
            }
            r2 = value;
        }
        {
            r3 = r11;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003DBD78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CameraSetAtEye_00367B14(frame, context, state, 0x00367B14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003DBD78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003DBD78;
    }
block_003DBD78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003DBD78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003DBD78U);
        }
        {
            const uint32_t operand = 0x000000D4U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 48U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 48U);
            }
            frame.Guest.vfp[28] = value12;
            uint32_t value13 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 52U, &value13)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 52U);
            }
            frame.Guest.vfp[29] = value13;
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 56U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 56U);
            }
            frame.Guest.vfp[30] = value14;
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 60U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003DBD7CU,
                                           firstAddress + 60U);
            }
            frame.Guest.vfp[31] = value15;
            r13 += 64U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003DBD80U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003DBD80U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003DBD80U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x003DBD80U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x003DBD80U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x003DBD80U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x003DBD80U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x003DBD80U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003DBD80U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
