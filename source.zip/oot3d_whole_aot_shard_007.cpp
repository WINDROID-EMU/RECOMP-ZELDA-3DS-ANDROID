#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_FUN_00123adc_00123ADC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnHorse_Update_0014A5A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00159184_00159184(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0019c82c_0019C82C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_IsMounted_001A60C0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnHorse_UpdateBgCheckInfo_001B3DB4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetRideActor_001EBF34(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_NotMounted_0021FD50(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_sin_idx8_002CFCA0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_cos_idx8_00338F60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnHorse_StartBraking_00341EA4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnHorse_ResolveCollision_00341F6C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnHorse_BgCheckBridgeJumpPoint_00342068(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00357a84_00357A84(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math3D_DistPlaneToPos_00357B30(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SurfaceType_IsHorseBlocked_00357B88(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnHorse_ObstructMovement_00357B9C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00357d54_00357D54(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnHorse_StartMountedIdle_00357D6C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00357ea0_00357EA0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_WorldDistXZToActor_00357EAC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BgCheck_EntityRaycastFloor3_00358410(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DynaPoly_GetActor_00359690(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_WaterBox_GetSurfaceImpl_0035E8A0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SurfaceType_GetFloorType_0035EA34(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_AnimationResource_GetLengthByIndex_003603C0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00363e8c_00363E8C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsDust_SpawnBrownLight_00363EC4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00366044_00366044(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_FAtan2F_003696EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BgCheck_EntityLineTest1_00369F9C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_GetLastFrame_0036AE14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_copy_u32x3_0036DF4C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_WorldYawTowardActor_0036E800(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsHahen_SpawnBurst_0036F9D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SmoothStepToSUpdateRate_00370084(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_MorphToLoop_00370350(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_ScaledStepToS_00370378(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SinF_003727F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_SetPlaySpeed_003731E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlaySoundGeneral_0037547C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SetScale_0037572C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_set_field_229c_clear_22ac_0037573C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_get_indexed_field_60_entry_00375750(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_Atan2S_003758B0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroOne_003759D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlayActorSound2_00375BCC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_Change_00375c08_00375C08(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetAT_003761F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CollisionCheck_SetOC_003762A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_UpdateBgCheckInfo_00376340(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_MoveForward_00376864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00408828_00408828(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_FUN_00123adc_00123ADC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00123ADCU:
        goto block_00123ADC;
    case 0x00123AF8U:
        goto block_00123AF8;
    case 0x00123B1CU:
        goto block_00123B1C;
    case 0x00123B28U:
        goto block_00123B28;
    case 0x00123B3CU:
        goto block_00123B3C;
    case 0x00123B4CU:
        goto block_00123B4C;
    case 0x00123B5CU:
        goto block_00123B5C;
    case 0x00123B64U:
        goto block_00123B64;
    case 0x00123B6CU:
        goto block_00123B6C;
    case 0x00123B84U:
        goto block_00123B84;
    case 0x00123BACU:
        goto block_00123BAC;
    case 0x00123BE8U:
        goto block_00123BE8;
    case 0x00123C0CU:
        goto block_00123C0C;
    case 0x00123C14U:
        goto block_00123C14;
    case 0x00123C20U:
        goto block_00123C20;
    case 0x00123C2CU:
        goto block_00123C2C;
    case 0x00123C3CU:
        goto block_00123C3C;
    case 0x00123C4CU:
        goto block_00123C4C;
    case 0x00123C5CU:
        goto block_00123C5C;
    case 0x00123C68U:
        goto block_00123C68;
    case 0x00123C6CU:
        goto block_00123C6C;
    case 0x00123C74U:
        goto block_00123C74;
    case 0x00123C84U:
        goto block_00123C84;
    case 0x00123C94U:
        goto block_00123C94;
    case 0x00123CA4U:
        goto block_00123CA4;
    case 0x00123CC0U:
        goto block_00123CC0;
    case 0x00123CD0U:
        goto block_00123CD0;
    case 0x00123CDCU:
        goto block_00123CDC;
    case 0x00123CE8U:
        goto block_00123CE8;
    case 0x00123CF4U:
        goto block_00123CF4;
    case 0x00123D04U:
        goto block_00123D04;
    case 0x00123D20U:
        goto block_00123D20;
    case 0x00123D30U:
        goto block_00123D30;
    case 0x00123D3CU:
        goto block_00123D3C;
    case 0x00123D44U:
        goto block_00123D44;
    case 0x00123D54U:
        goto block_00123D54;
    case 0x00123D64U:
        goto block_00123D64;
    case 0x00123D80U:
        goto block_00123D80;
    case 0x00123D90U:
        goto block_00123D90;
    case 0x00123D9CU:
        goto block_00123D9C;
    case 0x00123DB0U:
        goto block_00123DB0;
    case 0x00123DB8U:
        goto block_00123DB8;
    case 0x00123DD4U:
        goto block_00123DD4;
    case 0x00123DDCU:
        goto block_00123DDC;
    case 0x00123DE8U:
        goto block_00123DE8;
    case 0x00123DF4U:
        goto block_00123DF4;
    case 0x00123E38U:
        goto block_00123E38;
    case 0x00123EB0U:
        goto block_00123EB0;
    case 0x00123EC0U:
        goto block_00123EC0;
    case 0x00123ECCU:
        goto block_00123ECC;
    case 0x00123EDCU:
        goto block_00123EDC;
    case 0x00123EE4U:
        goto block_00123EE4;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00123ADC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123ADCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123ADCU);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00123ADCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00123ADCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00123ADCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00123ADCU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00123ADCU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00123ADCU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00123ADCU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00123ADCU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00123ADCU,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            r7 = r1;
        }
        {
            const uint32_t operand = 0x000001D4U;
            r0 = r0 + operand;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00123AECU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00123AECU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00123AECU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00123AECU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123AF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123AF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123AF8;
    }
block_00123AF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123AF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123AF8U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r6 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00123B04U + 0x340U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123AFCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123B00U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000200U;
            r5 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000200U;
            r8 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000062U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000066U;
            r8 = r8 + operand;
        }
        if (!(flags.Z())) { goto block_00123C14; }
        goto block_00123B1C;
    }
block_00123B1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123B1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123B1CU);
        }
        {
            const uint32_t updatedAddress = 0x00123B24U + 0x324U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123B1CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123B28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123B28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123B28;
    }
block_00123B28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123B28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123B28U);
        }
        {
            const uint32_t updatedAddress = 0x00123B30U + 0x31CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123B28U, address);
            }
            r9 = value;
        }
        {
            r2 = 0x0000016CU;
        }
        {
            r0 = r5;
        }
        {
            r1 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123B3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123B3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123B3C;
    }
block_00123B3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123B3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123B3CU);
        }
        {
            r2 = 0x0000016CU;
        }
        {
            r1 = r9;
        }
        {
            const uint32_t operand = 0x00000264U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123B4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123B4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123B4C;
    }
block_00123B4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123B4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123B4CU);
        }
        {
            r2 = 0x0000016CU;
        }
        {
            r1 = r9;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123B5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123B5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123B5C;
    }
block_00123B5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123B5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123B5CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00123EDC; }
        goto block_00123B64;
    }
block_00123B64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123B64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123B64U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123B64U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123B6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123B6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123B6C;
    }
block_00123B6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123B6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123B6CU);
        }
        {
            const uint32_t address = 0x00123B74U + 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123B6CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123B70U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123B74U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123B78U, 0xEE200A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123B7CU, 0xEE608A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123B84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123B84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123B84;
    }
block_00123B84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123B84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123B84U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123B84U, 0xEE200A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123B88U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00123B94U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00123B94U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00123B94U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r5 = value5;
        }
        {
            const uint32_t address = 0x00123BA0U + 692U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123B98U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x00123BA4U + 692U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123B9CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00123BA0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00123BA0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00123BA0U,
                                           firstAddress + 8U);
            }
        }
        {
            r5 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123BA8U, 0xEE609A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        goto block_00123BAC;
    }
block_00123BAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123BACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123BACU);
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123BACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123BB4U, 0xEE600A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123BB8U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123BBCU, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123BC0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[1];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00123BD4U, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = 0x00123BE0U + 0x27CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123BD8U, address);
            }
            r3 = value;
        }
        {
            r0 = r7;
        }
        {
            const uint32_t operand = 0x00000000U;
            r2 = r3 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123BE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsDust_SpawnBrownLight_00363EC4(frame, context, state, 0x00363EC4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123BE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123BE8;
    }
block_00123BE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123BE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123BE8U);
        }
        {
            const uint32_t address = r13 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123BE8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123BF4U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00123BF8U, address);
            }
        }
        {
            const uint32_t address = r13 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123BFCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123C00U, 0xEE300A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00123C04U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00123BAC; }
        goto block_00123C0C;
    }
block_00123C0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123C0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123C0CU);
        }
        {
            r0 = 0x00000001U;
        }
        goto block_00123C6C;
    }
block_00123C14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123C14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123C14U);
        }
        {
            const uint32_t updatedAddress = 0x00123C1CU + 0x244U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123C14U, address);
            }
            r9 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000011U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00123C74; }
        goto block_00123C20;
    }
block_00123C20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123C20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123C20U);
        }
        {
            r2 = 0x00000200U;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123C2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123C2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123C2C;
    }
block_00123C2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123C2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123C2CU);
        }
        {
            const uint32_t updatedAddress = 0x00123C34U + 0x230U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123C2CU, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000200U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123C3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123C3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123C3C;
    }
block_00123C3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123C3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123C3CU);
        }
        {
            r2 = 0x00000200U;
        }
        {
            r1 = r9;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123C4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123C4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123C4C;
    }
block_00123C4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123C4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123C4CU);
        }
        {
            const uint32_t updatedAddress = 0x00123C54U + 0x214U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123C4CU, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000200U;
        }
        {
            const uint32_t operand = 0x00000264U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123C5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123C5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123C5C;
    }
block_00123C5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123C5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123C5CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00123EDC; }
        goto block_00123C68;
    }
block_00123C68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123C68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123C68U);
        }
        {
            r0 = 0x00000012U;
        }
        goto block_00123C6C;
    }
block_00123C6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123C6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123C6CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00123C6CU, address);
            }
        }
        goto block_00123EDC;
    }
block_00123C74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123C74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123C74U);
        }
        {
            const uint32_t updatedAddress = 0x00123C7CU + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123C74U, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = 0x00123C80U + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123C78U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00123CDC; }
        goto block_00123C84;
    }
block_00123C84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123C84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123C84U);
        }
        {
            r7 = r2;
        }
        {
            r1 = Oot3dAotLsl(r2, 2U);
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123C94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123C94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123C94;
    }
block_00123C94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123C94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123C94U);
        }
        {
            const uint32_t updatedAddress = 0x00123C9CU + 0x1D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123C94U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x000005B0U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123CA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123CA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123CA4;
    }
block_00123CA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123CA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123CA4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = 0x00000026U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00123CACU, address);
            }
        }
        {
            r2 = r7;
        }
        {
            r1 = r10;
        }
        {
            const uint32_t operand = 0x00000264U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123CC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123CC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123CC0;
    }
block_00123CC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123CC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123CC0U);
        }
        {
            r2 = 0x000002D8U;
        }
        {
            r1 = r9;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123CD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123CD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123CD0;
    }
block_00123CD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123CD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123CD0U);
        }
        {
        }
        {
        }
        goto block_00123EDC;
    }
block_00123CDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123CDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123CDCU);
        }
        {
            const uint32_t updatedAddress = 0x00123CE4U + 0x194U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123CDCU, address);
            }
            r11 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000026U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00123D3C; }
        goto block_00123CE8;
    }
block_00123CE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123CE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123CE8U);
        }
        {
            const uint32_t updatedAddress = 0x00123CF0U + 0x18CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123CE8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123CF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123CF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123CF4;
    }
block_00123CF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123CF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123CF4U);
        }
        {
            const uint32_t updatedAddress = 0x00123CFCU + 0x184U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123CF4U, address);
            }
            r1 = value;
        }
        {
            r2 = r11;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123D04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123D04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123D04;
    }
block_00123D04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123D04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123D04U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = 0x00000027U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00123D0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00123D18U + 0x16CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123D10U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00123D1CU + 0x16CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123D14U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000264U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123D20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123D20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123D20;
    }
block_00123D20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123D20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123D20U);
        }
        {
            const uint32_t updatedAddress = 0x00123D28U + 0x164U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123D20U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00123D2CU + 0x164U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123D24U, address);
            }
            r1 = value;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123D30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123D30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123D30;
    }
block_00123D30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123D30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123D30U);
        }
        {
        }
        {
        }
        goto block_00123EDC;
    }
block_00123D3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123D3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123D3CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000027U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00123D9C; }
        goto block_00123D44;
    }
block_00123D44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123D44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123D44U);
        }
        {
            r2 = r11;
        }
        {
            r1 = 0x00001800U;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123D54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123D54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123D54;
    }
block_00123D54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123D54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123D54U);
        }
        {
            const uint32_t updatedAddress = 0x00123D5CU + 0x138U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123D54U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00123D60U + 0x138U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123D58U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123D64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123D64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123D64;
    }
block_00123D64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123D64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123D64U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = 0x00000028U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r6 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00123D6CU, address);
            }
        }
        {
            r2 = 0x000002D8U;
        }
        {
            r1 = r10;
        }
        {
            const uint32_t operand = 0x00000264U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123D80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123D80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123D80;
    }
block_00123D80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123D80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123D80U);
        }
        {
            r2 = 0x000005B0U;
        }
        {
            r1 = r9;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123D90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123D90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123D90;
    }
block_00123D90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123D90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123D90U);
        }
        {
        }
        {
        }
        goto block_00123EDC;
    }
block_00123D9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123D9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123D9CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000028U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00123DA8U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00123EB0; }
        goto block_00123DB0;
    }
block_00123DB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123DB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123DB0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00123EDC; }
        goto block_00123DB8;
    }
block_00123DB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123DB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123DB8U);
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123DB8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00123DC4U + 216U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123DBCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r4 + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123DC0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123DC4U, 0xEE600A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123DC8U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_00123DE8; }
        goto block_00123DD4;
    }
block_00123DD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123DD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123DD4U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123DDCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00363e8c_00363E8C(frame, context, state, 0x00363E8CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123DDCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123DDC;
    }
block_00123DDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123DDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123DDCU);
        }
        {
        }
        {
        }
        goto block_00123EDC;
    }
block_00123DE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123DE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123DE8U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000001D4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123DF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123DF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123DF4;
    }
block_00123DF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123DF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123DF4U);
        }
        {
            r0 = Oot3dAotLsl(r0, 1U);
        }
        {
            frame.Guest.vfp[3] = r0;
        }
        {
            const uint32_t address = 0x00123E04U + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123DFCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x00123E08U + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123E00U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r1 = 0x00000000U;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123E10U, 0xEEF81AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123E14U, 0xEE211A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123E18U, 0xDE510A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123E1CU, 0xCE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00123E20U, 0xEEBD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x00123E30U + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123E28U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00123E2CU, address);
            }
        }
        {
            const uint32_t operand = 0x000001D4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123E38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123E38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123E38;
    }
block_00123E38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123E38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123E38U);
        }
        {
            const uint32_t updatedAddress = 0x00123E40U + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123E38U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x258U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00123E3CU, address);
            }
        }
        goto block_00123EDC;
    }
block_00123EB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123EB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123EB0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x00123EBCU + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123EB4U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x00123EC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123EC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123EC0;
    }
block_00123EC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123EC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123EC0U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00123EC0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000012U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00123EDC; }
        goto block_00123ECC;
    }
block_00123ECC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123ECCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123ECCU);
        }
        {
            r2 = 0x00000088U;
        }
        {
            r1 = r9;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123EDCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123EDCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123EDC;
    }
block_00123EDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123EDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123EDCU);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00123EE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00366044_00366044(frame, context, state, 0x00366044U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00123EE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00123EE4;
    }
block_00123EE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00123EE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00123EE4U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00123EE8U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00123EE8U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00123EE8U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00123EE8U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00123EECU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00123EECU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00123EECU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00123EECU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00123EECU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00123EECU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00123EECU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00123EECU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00123EECU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_EnHorse_Update_0014A5A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0014A5A8U:
        goto block_0014A5A8;
    case 0x0014A66CU:
        goto block_0014A66C;
    case 0x0014A67CU:
        goto block_0014A67C;
    case 0x0014A690U:
        goto block_0014A690;
    case 0x0014A6A0U:
        goto block_0014A6A0;
    case 0x0014A6B4U:
        goto block_0014A6B4;
    case 0x0014A6C8U:
        goto block_0014A6C8;
    case 0x0014A6D4U:
        goto block_0014A6D4;
    case 0x0014A6F0U:
        goto block_0014A6F0;
    case 0x0014A708U:
        goto block_0014A708;
    case 0x0014A714U:
        goto block_0014A714;
    case 0x0014A730U:
        goto block_0014A730;
    case 0x0014A744U:
        goto block_0014A744;
    case 0x0014A74CU:
        goto block_0014A74C;
    case 0x0014A758U:
        goto block_0014A758;
    case 0x0014A76CU:
        goto block_0014A76C;
    case 0x0014A77CU:
        goto block_0014A77C;
    case 0x0014A78CU:
        goto block_0014A78C;
    case 0x0014A7A4U:
        goto block_0014A7A4;
    case 0x0014A7C4U:
        goto block_0014A7C4;
    case 0x0014A7D0U:
        goto block_0014A7D0;
    case 0x0014A7E0U:
        goto block_0014A7E0;
    case 0x0014A7F0U:
        goto block_0014A7F0;
    case 0x0014A7F8U:
        goto block_0014A7F8;
    case 0x0014A80CU:
        goto block_0014A80C;
    case 0x0014A818U:
        goto block_0014A818;
    case 0x0014A820U:
        goto block_0014A820;
    case 0x0014A828U:
        goto block_0014A828;
    case 0x0014A82CU:
        goto block_0014A82C;
    case 0x0014A834U:
        goto block_0014A834;
    case 0x0014A84CU:
        goto block_0014A84C;
    case 0x0014A858U:
        goto block_0014A858;
    case 0x0014A86CU:
        goto block_0014A86C;
    case 0x0014A878U:
        goto block_0014A878;
    case 0x0014A884U:
        goto block_0014A884;
    case 0x0014A890U:
        goto block_0014A890;
    case 0x0014A8E4U:
        goto block_0014A8E4;
    case 0x0014A8F8U:
        goto block_0014A8F8;
    case 0x0014A960U:
        goto block_0014A960;
    case 0x0014A96CU:
        goto block_0014A96C;
    case 0x0014A978U:
        goto block_0014A978;
    case 0x0014A984U:
        goto block_0014A984;
    case 0x0014A990U:
        goto block_0014A990;
    case 0x0014A9ECU:
        goto block_0014A9EC;
    case 0x0014AA00U:
        goto block_0014AA00;
    case 0x0014AA0CU:
        goto block_0014AA0C;
    case 0x0014AA2CU:
        goto block_0014AA2C;
    case 0x0014AA40U:
        goto block_0014AA40;
    case 0x0014AA50U:
        goto block_0014AA50;
    case 0x0014AA80U:
        goto block_0014AA80;
    case 0x0014AAA0U:
        goto block_0014AAA0;
    case 0x0014AAACU:
        goto block_0014AAAC;
    case 0x0014AABCU:
        goto block_0014AABC;
    case 0x0014AACCU:
        goto block_0014AACC;
    case 0x0014AAFCU:
        goto block_0014AAFC;
    case 0x0014AB14U:
        goto block_0014AB14;
    case 0x0014AB44U:
        goto block_0014AB44;
    case 0x0014AB70U:
        goto block_0014AB70;
    case 0x0014AB7CU:
        goto block_0014AB7C;
    case 0x0014AB8CU:
        goto block_0014AB8C;
    case 0x0014AB94U:
        goto block_0014AB94;
    case 0x0014ABA4U:
        goto block_0014ABA4;
    case 0x0014ABB0U:
        goto block_0014ABB0;
    case 0x0014ABB8U:
        goto block_0014ABB8;
    case 0x0014ABC8U:
        goto block_0014ABC8;
    case 0x0014ABD4U:
        goto block_0014ABD4;
    case 0x0014ABF8U:
        goto block_0014ABF8;
    case 0x0014AC10U:
        goto block_0014AC10;
    case 0x0014AC20U:
        goto block_0014AC20;
    case 0x0014AC38U:
        goto block_0014AC38;
    case 0x0014AC48U:
        goto block_0014AC48;
    case 0x0014AC60U:
        goto block_0014AC60;
    case 0x0014AC7CU:
        goto block_0014AC7C;
    case 0x0014AC84U:
        goto block_0014AC84;
    case 0x0014AC9CU:
        goto block_0014AC9C;
    case 0x0014ACDCU:
        goto block_0014ACDC;
    case 0x0014ACF0U:
        goto block_0014ACF0;
    case 0x0014AD08U:
        goto block_0014AD08;
    case 0x0014AD14U:
        goto block_0014AD14;
    case 0x0014AD30U:
        goto block_0014AD30;
    case 0x0014AD3CU:
        goto block_0014AD3C;
    case 0x0014AD68U:
        goto block_0014AD68;
    case 0x0014AD7CU:
        goto block_0014AD7C;
    case 0x0014AD88U:
        goto block_0014AD88;
    case 0x0014ADC4U:
        goto block_0014ADC4;
    case 0x0014ADC8U:
        goto block_0014ADC8;
    case 0x0014ADD0U:
        goto block_0014ADD0;
    case 0x0014ADE4U:
        goto block_0014ADE4;
    case 0x0014ADE8U:
        goto block_0014ADE8;
    case 0x0014ADF8U:
        goto block_0014ADF8;
    case 0x0014AE18U:
        goto block_0014AE18;
    case 0x0014AE24U:
        goto block_0014AE24;
    case 0x0014AE3CU:
        goto block_0014AE3C;
    case 0x0014AE60U:
        goto block_0014AE60;
    case 0x0014AE80U:
        goto block_0014AE80;
    case 0x0014AE90U:
        goto block_0014AE90;
    case 0x0014AEACU:
        goto block_0014AEAC;
    case 0x0014AEC0U:
        goto block_0014AEC0;
    case 0x0014AEC8U:
        goto block_0014AEC8;
    case 0x0014AEECU:
        goto block_0014AEEC;
    case 0x0014AF0CU:
        goto block_0014AF0C;
    case 0x0014AF1CU:
        goto block_0014AF1C;
    case 0x0014AF38U:
        goto block_0014AF38;
    case 0x0014AF74U:
        goto block_0014AF74;
    case 0x0014AF78U:
        goto block_0014AF78;
    case 0x0014AF84U:
        goto block_0014AF84;
    case 0x0014AF98U:
        goto block_0014AF98;
    case 0x0014AFB8U:
        goto block_0014AFB8;
    case 0x0014AFC0U:
        goto block_0014AFC0;
    case 0x0014AFC8U:
        goto block_0014AFC8;
    case 0x0014AFD8U:
        goto block_0014AFD8;
    case 0x0014AFF0U:
        goto block_0014AFF0;
    case 0x0014AFFCU:
        goto block_0014AFFC;
    case 0x0014B010U:
        goto block_0014B010;
    case 0x0014B030U:
        goto block_0014B030;
    case 0x0014B040U:
        goto block_0014B040;
    case 0x0014B0C8U:
        goto block_0014B0C8;
    case 0x0014B0D8U:
        goto block_0014B0D8;
    case 0x0014B0E4U:
        goto block_0014B0E4;
    case 0x0014B0F8U:
        goto block_0014B0F8;
    case 0x0014B10CU:
        goto block_0014B10C;
    case 0x0014B120U:
        goto block_0014B120;
    case 0x0014B130U:
        goto block_0014B130;
    case 0x0014B138U:
        goto block_0014B138;
    case 0x0014B160U:
        goto block_0014B160;
    case 0x0014B170U:
        goto block_0014B170;
    case 0x0014B184U:
        goto block_0014B184;
    case 0x0014B190U:
        goto block_0014B190;
    case 0x0014B1A0U:
        goto block_0014B1A0;
    case 0x0014B228U:
        goto block_0014B228;
    case 0x0014B23CU:
        goto block_0014B23C;
    case 0x0014B250U:
        goto block_0014B250;
    case 0x0014B25CU:
        goto block_0014B25C;
    case 0x0014B274U:
        goto block_0014B274;
    case 0x0014B288U:
        goto block_0014B288;
    case 0x0014B2A0U:
        goto block_0014B2A0;
    case 0x0014B2C4U:
        goto block_0014B2C4;
    case 0x0014B2D4U:
        goto block_0014B2D4;
    case 0x0014B2E4U:
        goto block_0014B2E4;
    case 0x0014B324U:
        goto block_0014B324;
    case 0x0014B348U:
        goto block_0014B348;
    case 0x0014B358U:
        goto block_0014B358;
    case 0x0014B36CU:
        goto block_0014B36C;
    case 0x0014B37CU:
        goto block_0014B37C;
    case 0x0014B38CU:
        goto block_0014B38C;
    case 0x0014B398U:
        goto block_0014B398;
    case 0x0014B3B8U:
        goto block_0014B3B8;
    case 0x0014B3D4U:
        goto block_0014B3D4;
    case 0x0014B3E8U:
        goto block_0014B3E8;
    case 0x0014B400U:
        goto block_0014B400;
    case 0x0014B408U:
        goto block_0014B408;
    case 0x0014B420U:
        goto block_0014B420;
    case 0x0014B42CU:
        goto block_0014B42C;
    case 0x0014B464U:
        goto block_0014B464;
    case 0x0014B470U:
        goto block_0014B470;
    case 0x0014B484U:
        goto block_0014B484;
    case 0x0014B498U:
        goto block_0014B498;
    case 0x0014B4A4U:
        goto block_0014B4A4;
    case 0x0014B4BCU:
        goto block_0014B4BC;
    case 0x0014B4DCU:
        goto block_0014B4DC;
    case 0x0014B508U:
        goto block_0014B508;
    case 0x0014B528U:
        goto block_0014B528;
    case 0x0014B544U:
        goto block_0014B544;
    case 0x0014B550U:
        goto block_0014B550;
    case 0x0014B568U:
        goto block_0014B568;
    case 0x0014B588U:
        goto block_0014B588;
    case 0x0014B594U:
        goto block_0014B594;
    case 0x0014B5A0U:
        goto block_0014B5A0;
    case 0x0014B5B0U:
        goto block_0014B5B0;
    case 0x0014B5BCU:
        goto block_0014B5BC;
    case 0x0014B5C0U:
        goto block_0014B5C0;
    case 0x0014B5CCU:
        goto block_0014B5CC;
    case 0x0014B5D8U:
        goto block_0014B5D8;
    case 0x0014B5ECU:
        goto block_0014B5EC;
    case 0x0014B60CU:
        goto block_0014B60C;
    case 0x0014B634U:
        goto block_0014B634;
    case 0x0014B648U:
        goto block_0014B648;
    case 0x0014B664U:
        goto block_0014B664;
    case 0x0014B670U:
        goto block_0014B670;
    case 0x0014B688U:
        goto block_0014B688;
    case 0x0014B6A8U:
        goto block_0014B6A8;
    case 0x0014B6B4U:
        goto block_0014B6B4;
    case 0x0014B6C0U:
        goto block_0014B6C0;
    case 0x0014B6D0U:
        goto block_0014B6D0;
    case 0x0014B6DCU:
        goto block_0014B6DC;
    case 0x0014B6E0U:
        goto block_0014B6E0;
    case 0x0014B6ECU:
        goto block_0014B6EC;
    case 0x0014B6F8U:
        goto block_0014B6F8;
    case 0x0014B70CU:
        goto block_0014B70C;
    case 0x0014B72CU:
        goto block_0014B72C;
    case 0x0014B7A8U:
        goto block_0014B7A8;
    case 0x0014B7C4U:
        goto block_0014B7C4;
    case 0x0014B7D8U:
        goto block_0014B7D8;
    case 0x0014B7E8U:
        goto block_0014B7E8;
    case 0x0014B7F8U:
        goto block_0014B7F8;
    case 0x0014B800U:
        goto block_0014B800;
    case 0x0014B804U:
        goto block_0014B804;
    case 0x0014B810U:
        goto block_0014B810;
    case 0x0014B840U:
        goto block_0014B840;
    case 0x0014B850U:
        goto block_0014B850;
    case 0x0014B860U:
        goto block_0014B860;
    case 0x0014B86CU:
        goto block_0014B86C;
    case 0x0014B878U:
        goto block_0014B878;
    case 0x0014B87CU:
        goto block_0014B87C;
    case 0x0014B888U:
        goto block_0014B888;
    case 0x0014B898U:
        goto block_0014B898;
    case 0x0014B8A4U:
        goto block_0014B8A4;
    case 0x0014B8B0U:
        goto block_0014B8B0;
    case 0x0014B8BCU:
        goto block_0014B8BC;
    case 0x0014B8CCU:
        goto block_0014B8CC;
    case 0x0014B8D8U:
        goto block_0014B8D8;
    case 0x0014B8E8U:
        goto block_0014B8E8;
    case 0x0014B8FCU:
        goto block_0014B8FC;
    case 0x0014B908U:
        goto block_0014B908;
    case 0x0014B91CU:
        goto block_0014B91C;
    case 0x0014B928U:
        goto block_0014B928;
    case 0x0014B934U:
        goto block_0014B934;
    case 0x0014B950U:
        goto block_0014B950;
    case 0x0014B958U:
        goto block_0014B958;
    case 0x0014B974U:
        goto block_0014B974;
    case 0x0014B99CU:
        goto block_0014B99C;
    case 0x0014B9BCU:
        goto block_0014B9BC;
    case 0x0014B9D0U:
        goto block_0014B9D0;
    case 0x0014B9E4U:
        goto block_0014B9E4;
    case 0x0014B9F8U:
        goto block_0014B9F8;
    case 0x0014BA0CU:
        goto block_0014BA0C;
    case 0x0014BA18U:
        goto block_0014BA18;
    case 0x0014BA68U:
        goto block_0014BA68;
    case 0x0014BA80U:
        goto block_0014BA80;
    case 0x0014BA90U:
        goto block_0014BA90;
    case 0x0014BA9CU:
        goto block_0014BA9C;
    case 0x0014BAB4U:
        goto block_0014BAB4;
    case 0x0014BAC0U:
        goto block_0014BAC0;
    case 0x0014BADCU:
        goto block_0014BADC;
    case 0x0014BAE4U:
        goto block_0014BAE4;
    case 0x0014BAF0U:
        goto block_0014BAF0;
    case 0x0014BAFCU:
        goto block_0014BAFC;
    case 0x0014BB04U:
        goto block_0014BB04;
    case 0x0014BB10U:
        goto block_0014BB10;
    case 0x0014BB1CU:
        goto block_0014BB1C;
    case 0x0014BB28U:
        goto block_0014BB28;
    case 0x0014BB4CU:
        goto block_0014BB4C;
    case 0x0014BB60U:
        goto block_0014BB60;
    case 0x0014BB74U:
        goto block_0014BB74;
    case 0x0014BB78U:
        goto block_0014BB78;
    case 0x0014BB84U:
        goto block_0014BB84;
    case 0x0014BBA0U:
        goto block_0014BBA0;
    case 0x0014BBB0U:
        goto block_0014BBB0;
    case 0x0014BBC4U:
        goto block_0014BBC4;
    case 0x0014BBCCU:
        goto block_0014BBCC;
    case 0x0014BC08U:
        goto block_0014BC08;
    case 0x0014BC1CU:
        goto block_0014BC1C;
    case 0x0014BC28U:
        goto block_0014BC28;
    case 0x0014BC40U:
        goto block_0014BC40;
    case 0x0014BC58U:
        goto block_0014BC58;
    case 0x0014BC8CU:
        goto block_0014BC8C;
    case 0x0014BCD0U:
        goto block_0014BCD0;
    case 0x0014BCD8U:
        goto block_0014BCD8;
    case 0x0014BCE4U:
        goto block_0014BCE4;
    case 0x0014BCFCU:
        goto block_0014BCFC;
    case 0x0014BD14U:
        goto block_0014BD14;
    case 0x0014BD48U:
        goto block_0014BD48;
    case 0x0014BD54U:
        goto block_0014BD54;
    case 0x0014BD5CU:
        goto block_0014BD5C;
    case 0x0014BD68U:
        goto block_0014BD68;
    case 0x0014BD80U:
        goto block_0014BD80;
    case 0x0014BD98U:
        goto block_0014BD98;
    case 0x0014BDCCU:
        goto block_0014BDCC;
    case 0x0014BDD8U:
        goto block_0014BDD8;
    case 0x0014BDE0U:
        goto block_0014BDE0;
    case 0x0014BDECU:
        goto block_0014BDEC;
    case 0x0014BE04U:
        goto block_0014BE04;
    case 0x0014BE1CU:
        goto block_0014BE1C;
    case 0x0014BE50U:
        goto block_0014BE50;
    case 0x0014BE5CU:
        goto block_0014BE5C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0014A5A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A5A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A5A8U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0014A5A8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0014A5A8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0014A5A8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0014A5A8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0014A5A8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0014A5A8U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0014A5A8U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0014A5A8U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0014A5A8U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00002000U;
            r7 = r1 + operand;
        }
        {
            r6 = r1;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r5 = r4 + operand;
        }
        {
            r13 -= 32U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0014A5BCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0014A5BCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0014A5BCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0014A5BCU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0014A5BCU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0014A5BCU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0014A5BCU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0014A5BCU,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t operand = 0x0000007CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t address = 0x0014A5CCU + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A5C4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0014A5D0U + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A5C8U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014A5CCU, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r13 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014A5E0U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r13 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014A5E8U, address);
            }
        }
        {
            const uint32_t address = r13 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0014A5ECU, address);
            }
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014A5F0U, address);
            }
        }
        {
            const uint32_t address = r13 + 80U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014A5F4U, address);
            }
        }
        {
            const uint32_t address = r13 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0014A5F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A5FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014A600U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A604U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000E00U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x78U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014A60CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014A610U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xEC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A614U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xECCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A618U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xED0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014A61CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xED4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0014A620U, address);
            }
        }
        {
            const uint32_t address = r6 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A624U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A628U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A634U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 712U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014A638U, address);
            }
        }
        {
            const uint32_t address = r6 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A63CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A640U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = 0x0014A654U + 0x2E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A64CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A650U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 716U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014A654U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A658U, address);
            }
            r9 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A65CU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A660U, address);
            }
            r8 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A66CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A66CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A66C;
    }
block_0014A66C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A66CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A66CU);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A66CU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            r0 = r9;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A674U, 0xEE09AA80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[20], frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A67CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A67CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A67C;
    }
block_0014A67C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A67CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A67CU);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A67CU, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A680U, address);
            }
            r9 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A684U, 0xEE49AA80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[21], frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A690U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A690U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A690;
    }
block_0014A690:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A690U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A690U);
        }
        {
            const uint32_t address = r8 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A690U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            r0 = r9;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A698U, 0xEE499A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[19], frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A6A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A6A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A6A0;
    }
block_0014A6A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A6A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A6A0U);
        }
        {
            const uint32_t address = r8 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A6A0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A6A4U, 0xEE790ACAU};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[19], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A6A8U, 0xEE091A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A6ACU, 0xEE310A6AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A6B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Atan2S_003758B0(frame, context, state, 0x003758B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A6B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A6B4;
    }
block_0014A6B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A6B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A6B4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A6B4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r8 = value;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A6C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A6C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A6C8;
    }
block_0014A6C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A6C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A6C8U);
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[0];
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A6D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A6D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A6D4;
    }
block_0014A6D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A6D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A6D4U);
        }
        {
            const uint32_t updatedAddress = 0x0014A6DCU + 0x260U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A6D4U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[18];
        }
        {
            r10 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r1 = 0x00000005U;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014A6E8U, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0014A74C; }
        goto block_0014A6F0;
    }
block_0014A6F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A6F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A6F0U);
        }
        {
            const uint32_t updatedAddress = 0x0014A6F8U + 0x248U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A6F0U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[18];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) {
            r1 = 0x00000004U;
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014A700U, address);
            }
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0014A74C; }
        goto block_0014A708;
    }
block_0014A708:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A708U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A708U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A708U, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0014A730; }
        goto block_0014A714;
    }
block_0014A714:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A714U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A714U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A714U, 0xEEB49AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[18], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            r0 = r4;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r1 = 0x00000001U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r0 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014A724U, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r0 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014A728U, address);
            }
        }
        goto block_0014A74C;
    }
block_0014A730:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A730U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A730U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A730U, 0xEEB49AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[18], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000003U;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014A73CU, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0014A74C; }
        goto block_0014A744;
    }
block_0014A744:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A744U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A744U);
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014A748U, address);
            }
        }
        goto block_0014A74C;
    }
block_0014A74C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A74CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A74CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A74CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00002000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00002000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014AA0C; }
        goto block_0014A758;
    }
block_0014A758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A758U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A758U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A75CU, address);
            }
            r8 = value;
        }
        {
            r11 = r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014A7F0; }
        goto block_0014A76C;
    }
block_0014A76C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A76CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A76CU);
        }
        {
            const uint32_t updatedAddress = r11 + 0xE74U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A76CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014A7F0; }
        goto block_0014A77C;
    }
block_0014A77C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A77CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A77CU);
        }
        {
            r9 = r8;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A78CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_WorldDistXZToActor_00357EAC(frame, context, state, 0x00357EACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A78CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A78C;
    }
block_0014A78C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A78CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A78CU);
        }
        {
            const uint32_t address = r9 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A78CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0014A798U + 428U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A790U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A794U, 0xEE700A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A798U, 0xEEF40AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) { goto block_0014A7F0; }
        goto block_0014A7A4;
    }
block_0014A7A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A7A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A7A4U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A7A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r9 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A7A8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x0014A7B4U + 0x194U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A7ACU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A7B0U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A7B4U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0014A7F0; }
        goto block_0014A7C4;
    }
block_0014A7C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A7C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A7C4U);
        }
        {
            r1 = r4;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A7D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_WorldYawTowardActor_0036E800(frame, context, state, 0x0036E800U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A7D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A7D0;
    }
block_0014A7D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A7D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A7D0U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A7D0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A7E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A7E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A7E0;
    }
block_0014A7E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A7E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A7E0U);
        }
        {
            const uint32_t updatedAddress = 0x0014A7E8U + 0x164U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A7E0U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0014A7F8; }
        goto block_0014A7F0;
    }
block_0014A7F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A7F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A7F0U);
        }
        {
            r2 = r10;
        }
        goto block_0014A82C;
    }
block_0014A7F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A7F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A7F8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A7F8U, address);
            }
            r0 = value;
        }
        {
            r2 = ~(0x00000000U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = r2;
        }
        if (flags.Z()) { goto block_0014A818; }
        goto block_0014A80C;
    }
block_0014A80C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A80CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A80CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = r10;
        }
        if (flags.Z()) {
            r0 = 0x00000001U;
        }
        goto block_0014A818;
    }
block_0014A818:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A818U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A818U);
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014A82C; }
        goto block_0014A820;
    }
block_0014A820:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A820U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A820U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014A7F0; }
        goto block_0014A828;
    }
block_0014A828:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A828U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A828U);
        }
        {
            r2 = 0x00000001U;
        }
        goto block_0014A82C;
    }
block_0014A82C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A82CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A82CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (flags.Z()) { goto block_0014A858; }
        goto block_0014A834;
    }
block_0014A834:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A834U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A834U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A834U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00010000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00010000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0014A844U + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A83CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A840U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014A858; }
        goto block_0014A84C;
    }
block_0014A84C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A84CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A84CU);
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A858U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetRideActor_001EBF34(frame, context, state, 0x001EBF34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A858U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A858;
    }
block_0014A858:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A858U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A858U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xE70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A858U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014A864U + 0xF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A85CU, address);
            }
            r9 = value;
        }
        {
            const uint32_t address = 0x0014A868U + 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A860U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014A960; }
        goto block_0014A86C;
    }
block_0014A86C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A86CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A86CU);
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A878U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_IsMounted_001A60C0(frame, context, state, 0x001A60C0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A878U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A878;
    }
block_0014A878:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A878U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A878U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0014A960; }
        goto block_0014A884;
    }
block_0014A884:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A884U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A884U);
        }
        {
            r1 = 0x00000023U;
        }
        {
            const uint32_t operand = 0x00000254U;
            r0 = r8 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A890U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AnimationResource_GetLengthByIndex_003603C0(frame, context, state, 0x003603C0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A890U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A890;
    }
block_0014A890:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A890U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A890U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = 0x0014A89CU + 0xC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A894U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A898U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A89CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A8A4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A8ACU, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A8B0U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A8B4U, 0xEE800A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A8B8U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A8BCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r11 + 0x1A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014A8C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x1ACU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014A8C8U, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r11 + 0xE70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014A8D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A8D4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000011U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000012U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014AA0C; }
        goto block_0014A8E4;
    }
block_0014A8E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A8E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A8E4U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A8E4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r9 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A8E8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014AA00; }
        goto block_0014A8F8;
    }
block_0014A8F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A8F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A8F8U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A8F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0xEB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014A8FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014A900U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xEEEU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A904U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xEEEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014A90CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xF46U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A910U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xF46U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014A918U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xF9EU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A91CU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xF9EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014A924U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xE74U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014A928U, address);
            }
        }
        goto block_0014AA0C;
    }
block_0014A960:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A960U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A960U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xE70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A960U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014AA0C; }
        goto block_0014A96C;
    }
block_0014A96C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A96CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A96CU);
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A978U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_NotMounted_0021FD50(frame, context, state, 0x0021FD50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A978U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A978;
    }
block_0014A978:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A978U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A978U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0014AA0C; }
        goto block_0014A984;
    }
block_0014A984:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A984U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A984U);
        }
        {
            r1 = 0x00000024U;
        }
        {
            const uint32_t operand = 0x00000254U;
            r0 = r8 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014A990U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AnimationResource_GetLengthByIndex_003603C0(frame, context, state, 0x003603C0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014A990U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014A990;
    }
block_0014A990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A990U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = 0x0014A99CU - 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A994U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A998U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A99CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A9A4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A9ACU, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A9B0U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A9B4U, 0xEE800A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A9B8U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014A9BCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r11 + 0x1A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014A9C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x1ACU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014A9C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A9CCU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00010000U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014A9D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xE70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014A9D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A9DCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000011U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000012U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014AA0C; }
        goto block_0014A9EC;
    }
block_0014A9EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014A9ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014A9ECU);
        }
        {
            const uint32_t updatedAddress = r11 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A9ECU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r9 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014A9F0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014A8F8; }
        goto block_0014AA00;
    }
block_0014AA00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AA00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AA00U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x1A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014AA00U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x1ACU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014AA04U, address);
            }
        }
        goto block_0014A8F8;
    }
block_0014AA0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AA0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AA0CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AA0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r8 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t value = r0 & 0x00080000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00080000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x0000028CU;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000E80U;
            r9 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x74U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014AA24U, address);
            }
        }
        if (flags.Z()) { goto block_0014AB44; }
        goto block_0014AA2C;
    }
block_0014AA2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AA2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AA2CU);
        }
        {
            const uint32_t updatedAddress = 0x0014AA34U + 0x36CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AA2CU, address);
            }
            r11 = value;
        }
        {
            const uint32_t address = 0x0014AA38U + 876U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AA30U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t value = r0 & 0x00100000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00100000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            r2 = 0x0000000BU;
        }
        if (flags.Z()) { goto block_0014AAAC; }
        goto block_0014AA40;
    }
block_0014AA40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AA40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AA40U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AA40U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AA44U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (!(flags.Z())) { goto block_0014AB44; }
        goto block_0014AA50;
    }
block_0014AA50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AA50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AA50U);
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0014AA54U, address);
            }
        }
        {
            r0 = r0 & ~(0x00100000U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE74U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014AA5CU, address);
            }
        }
        {
            r1 = r0;
        }
        {
            r1 = r1 & ~(0x00000800U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014AA68U, address);
            }
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0014AA6CU,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0014AA6CU,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014AA6CU,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0014AA70U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014AA70U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0014AA70U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AA74U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x08000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x08000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014AAFC; }
        goto block_0014AA80;
    }
block_0014AA80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AA80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AA80U);
        }
        {
            const uint32_t updatedAddress = 0x0014AA88U + 0x320U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AA80U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014AA8CU + 0x320U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AA84U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014AA90U + 0x320U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AA88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000E80U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0014AA90U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014AAA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014AAA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014AAA0;
    }
block_0014AAA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AAA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AAA0U);
        }
        {
        }
        {
        }
        goto block_0014AAFC;
    }
block_0014AAAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AAACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AAACU);
        }
        {
            const uint32_t value = r0 & 0x00200000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00200000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AAB0U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014AB44; }
        goto block_0014AABC;
    }
block_0014AABC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AABCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AABCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AABCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AAC0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (!(flags.Z())) { goto block_0014AB44; }
        goto block_0014AACC;
    }
block_0014AACC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AACCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AACCU);
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0014AAD0U, address);
            }
        }
        {
            r0 = r0 & ~(0x00200000U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE74U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014AAD8U, address);
            }
        }
        {
            r1 = r0;
        }
        {
            r1 = r1 & ~(0x00000800U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014AAE4U, address);
            }
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0014AAE8U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0014AAE8U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014AAE8U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0014AAECU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014AAECU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0014AAECU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AAF0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x08000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x08000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0014AA80; }
        goto block_0014AAFC;
    }
block_0014AAFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AAFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AAFCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AAFCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r11 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB00U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE74U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB04U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB08U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000001C4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014AB14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014AB14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014AB14;
    }
block_0014AB14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AB14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AB14U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB18U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r11 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB28U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014AB2CU, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r4 + 0xE74U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB30U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = r1 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB38U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000001C4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014AB44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014AB44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014AB44;
    }
block_0014AB44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AB44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AB44U);
        }
        {
            const uint32_t updatedAddress = 0x0014AB4CU + 0x268U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB44U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB48U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB4CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB50U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014AB58U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB5CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            r0 = r2 & 0x0000000FU;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014ABD4; }
        goto block_0014AB70;
    }
block_0014AB70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AB70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AB70U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB70U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (flags.Z()) { goto block_0014ABD4; }
        goto block_0014AB7C;
    }
block_0014AB7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AB7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AB7CU);
        }
        {
            const uint32_t updatedAddress = 0x0014AB84U + 0x234U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB7CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB80U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00800000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00800000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014ABD4; }
        goto block_0014AB8C;
    }
block_0014AB8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AB8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AB8CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB8CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014AB94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00357ea0_00357EA0(frame, context, state, 0x00357EA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014AB94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014AB94;
    }
block_0014AB94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AB94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AB94U);
        }
        {
            r11 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AB98U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014ABA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_indexed_field_60_entry_00375750(frame, context, state, 0x00375750U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014ABA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014ABA4;
    }
block_0014ABA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ABA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ABA4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r11, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0014ABD4; }
        goto block_0014ABB0;
    }
block_0014ABB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ABB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ABB0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ABB0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014ABB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00357ea0_00357EA0(frame, context, state, 0x00357EA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014ABB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014ABB8;
    }
block_0014ABB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ABB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ABB8U);
        }
        {
            r11 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ABBCU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014ABC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_indexed_field_60_entry_00375750(frame, context, state, 0x00375750U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014ABC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014ABC8;
    }
block_0014ABC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ABC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ABC8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r11, r0, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0014AC38; }
        goto block_0014ABD4;
    }
block_0014ABD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ABD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ABD4U);
        }
        {
            const uint32_t updatedAddress = 0x0014ABDCU + 0x1D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ABD4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ABD8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ABDCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ABE0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ABE4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r3 = r0 & 0x0000000FU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000057U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r3, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014AC10; }
        goto block_0014ABF8;
    }
block_0014ABF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ABF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ABF8U);
        }
        {
            const uint32_t updatedAddress = 0x0014AC00U + 0x1B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ABF8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r3 + r2;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ABFCU, address);
            }
            r3 = value;
        }
        {
            const uint32_t value = r3 & 0x00800000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00800000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AC04U, address);
            }
            r3 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014AC38; }
        goto block_0014AC10;
    }
block_0014AC10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AC10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AC10U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000005DU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            r0 = r0 & 0x0000000FU;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014AC60; }
        goto block_0014AC20;
    }
block_0014AC20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AC20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AC20U);
        }
        {
            const uint32_t updatedAddress = 0x0014AC28U + 0x190U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AC20U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r2;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AC24U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00800000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00800000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AC2CU, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014AC60; }
        goto block_0014AC38;
    }
block_0014AC38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AC38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AC38U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AC38U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AC3CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0014AC60; }
        goto block_0014AC48;
    }
block_0014AC48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AC48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AC48U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014AC54U, address);
            }
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0014AC60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnHorse_StartMountedIdle_00357D6C(frame, context, state, 0x00357D6CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014AC60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014AC60;
    }
block_0014AC60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AC60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AC60U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE74U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AC60U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r0 = r4;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x245U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014AC74U, address);
            }
        }
        if (!(flags.Z())) { goto block_0014AC84; }
        goto block_0014AC7C;
    }
block_0014AC7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AC7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AC7CU);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x245U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014AC80U, address);
            }
        }
        goto block_0014AC84;
    }
block_0014AC84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AC84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AC84U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AC84U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014AC90U + 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AC88U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AC8CU, address);
            }
            r2 = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0014AC9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014AC9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014AC9C;
    }
block_0014AC9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AC9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AC9CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AC9CU, address);
            }
            r0 = value;
        }
        {
            r1 = r0 & ~(0x00004000U);
        }
        {
            const uint32_t operand = 0x000001C4U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014ACA8U, address);
            }
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ACB0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            const uint32_t address = r5 + 632U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014ACB8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014ACBCU, address);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014ACC0U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0014ACC0U,
                                           firstAddress + 4U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0014ACC0U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r11 = value11;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0014ACCCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0014ACCCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0014ACCCU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ACD0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t value = r2 & 0x00002000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00002000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0014BE5C; }
        goto block_0014ACDC;
    }
block_0014ACDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ACDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ACDCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ACDCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014AE18; }
        goto block_0014ACF0;
    }
block_0014ACF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ACF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ACF0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            r11 = r4;
        }
        {
            const uint32_t operand = 0x00000014U;
            r1 = r6 + operand;
        }
        if (!(flags.Z())) { goto block_0014AE18; }
        goto block_0014AD08;
    }
block_0014AD08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AD08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AD08U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AD08U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014AE18; }
        goto block_0014AD14;
    }
block_0014AD14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AD14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AD14U);
        }
        {
            const uint32_t updatedAddress = 0x0014AD1CU + 0xA4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AD14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AD18U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) {
            const uint32_t value = r2 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t value = r2 & 0x00000100U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000100U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t value = r2 & 0x00000200U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000200U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014AE18; }
        goto block_0014AD30;
    }
block_0014AD30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AD30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AD30U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xE9CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AD30U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0014ADD0; }
        goto block_0014AD3C;
    }
block_0014AD3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AD3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AD3CU);
        }
        {
            r0 = r2 | 0x00400000U;
        }
        {
            r0 = r0 | 0x00000001U;
        }
        {
            r0 = r0 | 0x00000100U;
        }
        {
            const uint32_t updatedAddress = r11 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014AD48U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xE9CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AD4CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0xE9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014AD54U, address);
            }
        }
        {
            const uint32_t value = r0 & 0x000000FFU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x000000D2U;
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014AD60U, address);
            }
        }
        if (flags.Z()) { goto block_0014ADC8; }
        goto block_0014AD68;
    }
block_0014AD68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AD68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AD68U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AD68U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000069U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r11 + 0xEA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014AD74U, address);
            }
        }
        if (!(flags.Z())) { goto block_0014AE18; }
        goto block_0014AD7C;
    }
block_0014AD7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AD7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AD7CU);
        }
        {
            const uint32_t updatedAddress = r11 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AD7CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00400000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00400000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014ADC4; }
        goto block_0014AD88;
    }
block_0014AD88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AD88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AD88U);
        }
        {
            r0 = 0x0000005AU;
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014AD8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AD90U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00400000U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014AD98U, address);
            }
        }
        goto block_0014AE18;
    }
block_0014ADC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ADC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ADC4U);
        }
        {
            r0 = 0x0000000CU;
        }
        goto block_0014ADC8;
    }
block_0014ADC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ADC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ADC8U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014ADC8U, address);
            }
        }
        goto block_0014AE18;
    }
block_0014ADD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ADD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ADD0U);
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0014ADD0U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0014ADD0U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014ADD0U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0014ADD4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014ADD4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0014ADD4U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ADD8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x08000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x08000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014AE18; }
        goto block_0014ADE4;
    }
block_0014ADE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ADE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ADE4U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014ADE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014ADE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014ADE8;
    }
block_0014ADE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ADE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ADE8U);
        }
        {
            const uint32_t updatedAddress = 0x0014ADF0U + 0x500U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ADE8U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0014AE18; }
        goto block_0014ADF8;
    }
block_0014ADF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014ADF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014ADF8U);
        }
        {
            const uint32_t updatedAddress = 0x0014AE00U - 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ADF8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014AE04U - 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014ADFCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014AE08U - 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AE00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000E80U;
            r1 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0014AE08U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014AE18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014AE18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014AE18;
    }
block_0014AE18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AE18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AE18U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AE18U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014AFC0; }
        goto block_0014AE24;
    }
block_0014AE24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AE24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AE24U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE9CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AE24U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014AE30U + 0x4C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AE28U, address);
            }
            r0 = value;
        }
        {
            r11 = r4;
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r1 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0014AEC0; }
        goto block_0014AE3C;
    }
block_0014AE3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AE3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AE3CU);
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AE3CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014AE44U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AE48U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014AE50U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AE54U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0014AF38; }
        goto block_0014AE60;
    }
block_0014AE60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AE60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AE60U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xE9CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AE60U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0xE9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014AE68U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AE6CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014AE90; }
        goto block_0014AE80;
    }
block_0014AE80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AE80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AE80U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AE80U, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x00080000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00080000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t value = r1 & 0x02000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x02000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014AEAC; }
        goto block_0014AE90;
    }
block_0014AE90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AE90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AE90U);
        }
        {
            const uint32_t updatedAddress = 0x0014AE98U - 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AE90U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014AE9CU - 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AE94U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0014AE9CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014AEACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014AEACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014AEAC;
    }
block_0014AEAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AEACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AEACU);
        }
        {
            const uint32_t updatedAddress = r11 + 0xE9CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AEACU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            r0 = 0x00000011U;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = r11 + 0xEA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014AEB8U, address);
            }
        }
        goto block_0014AF38;
    }
block_0014AEC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AEC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AEC0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014AF38; }
        goto block_0014AEC8;
    }
block_0014AEC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AEC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AEC8U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AEC8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014AED0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AED4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014AEDCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AEE0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0014AF38; }
        goto block_0014AEEC;
    }
block_0014AEEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AEECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AEECU);
        }
        {
            r1 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014AEF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xE9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014AEF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AEF8U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014AF1C; }
        goto block_0014AF0C;
    }
block_0014AF0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AF0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AF0CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AF0CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x00080000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00080000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t value = r1 & 0x02000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x02000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014AF38; }
        goto block_0014AF1C;
    }
block_0014AF1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AF1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AF1CU);
        }
        {
            const uint32_t updatedAddress = 0x0014AF24U - 0x17CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AF1CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014AF28U - 0x17CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AF20U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0014AF28U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014AF38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014AF38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014AF38;
    }
block_0014AF38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AF38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AF38U);
        }
        {
            const uint32_t updatedAddress = 0x0014AF40U - 0x5E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AF38U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0014AF44U + 948U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AF3CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0xEA4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AF40U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AF44U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AF4CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014AF54U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014AF58U, 0xEEC00A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0014AF64U + 920U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AF5CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014AF60U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014AF64U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014AFB8; }
        goto block_0014AF74;
    }
block_0014AF74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AF74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AF74U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014AF78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014AF78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014AF78;
    }
block_0014AF78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AF78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AF78U);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3E800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0014AFB8; }
        goto block_0014AF84;
    }
block_0014AF84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AF84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AF84U);
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0014AF84U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0014AF84U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014AF84U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0014AF88U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014AF88U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0014AF88U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AF8CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x08000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x08000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014AFB8; }
        goto block_0014AF98;
    }
block_0014AF98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AF98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AF98U);
        }
        {
            const uint32_t updatedAddress = 0x0014AFA0U - 0x1F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AF98U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014AFA4U - 0x1F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AF9CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014AFA8U - 0x1F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AFA0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000E80U;
            r1 = r11 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0014AFA8U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014AFB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014AFB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014AFB8;
    }
block_0014AFB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AFB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AFB8U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xE9CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AFB8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0xE18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014AFBCU, address);
            }
        }
        goto block_0014AFC0;
    }
block_0014AFC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AFC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AFC0U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014AFC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_MoveForward_00376864(frame, context, state, 0x00376864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014AFC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014AFC8;
    }
block_0014AFC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AFC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AFC8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AFC8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x17U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AFCCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0014AFF0; }
        goto block_0014AFD8;
    }
block_0014AFD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AFD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AFD8U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AFD8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0014AFE4U + 0x31CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AFDCU, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014AFE8U, 0xCE300A68U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = r4 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014AFECU, address);
            }
        }
        goto block_0014AFF0;
    }
block_0014AFF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AFF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AFF0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xF9DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014AFF0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014B030; }
        goto block_0014AFFC;
    }
block_0014AFFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014AFFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014AFFCU);
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0014AFFCU,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0014AFFCU,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014AFFCU,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0014B000U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014B000U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0014B000U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B004U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x08000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x08000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014B030; }
        goto block_0014B010;
    }
block_0014B010:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B010U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B010U);
        }
        {
            const uint32_t updatedAddress = 0x0014B018U - 0x270U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B010U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014B01CU - 0x270U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B014U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014B020U - 0x270U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B018U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000E80U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0014B020U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B030U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B030U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B030;
    }
block_0014B030:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B030U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B030U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B030U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0014B03CU + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B034U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0014B138; }
        goto block_0014B040;
    }
block_0014B040:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B040U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B040U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B040U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B044U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B048U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            const uint32_t updatedAddress = r13 + 0x78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B050U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0014B05CU + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B054U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r8 = r4;
        }
        {
            const uint32_t updatedAddress = r0 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B05CU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B060U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = r0;
            r0 = r1 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B06CU, 0xEE800A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B074U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B078U, 0xEE600A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0014B084U + 648U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B07CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B080U, 0xEE200A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B084U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B088U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B094U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r1;
            r2 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000000U;
            r1 = operand - r1;
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            const uint32_t operand = 0x00000000U;
            r2 = operand - r2;
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            const uint32_t updatedAddress = 0x0014B0B4U + 0x25CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B0ACU, address);
            }
            r2 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B0B0U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B0B4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B0B8U, 0xEEF00AE0U};
            frame.Guest.vfp[1] = frame.Guest.vfp[1] & 0x7FFFFFFFU;
        }
        {
            r3 = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0014B0E4; }
        goto block_0014B0C8;
    }
block_0014B0C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B0C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B0C8U);
        }
        {
            r2 = 0x000001C8U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000038U;
            r0 = r8 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B0D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B0D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B0D8;
    }
block_0014B0D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B0D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B0D8U);
        }
        {
        }
        {
        }
        goto block_0014B130;
    }
block_0014B0E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B0E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B0E4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B0E4U, 0xEEF00AC0U};
            frame.Guest.vfp[1] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r3 = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r8 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014B0F0U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0014B130; }
        goto block_0014B0F8;
    }
block_0014B0F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B0F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B0F8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B0F8U, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B104U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0014B120; }
        goto block_0014B10C;
    }
block_0014B10C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B10CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B10CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B10CU, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B110U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r8 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014B118U, address);
            }
        }
        goto block_0014B130;
    }
block_0014B120:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B120U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B120U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B120U, 0xEE300A68U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B124U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r8 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014B12CU, address);
            }
        }
        goto block_0014B130;
    }
block_0014B130:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B130U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B130U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x38U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B130U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0xC0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014B134U, address);
            }
        }
        goto block_0014B138;
    }
block_0014B138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B138U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B138U, address);
            }
            r3 = value;
        }
        {
            r2 = 0x0000000EU;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0014B144U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x000002B8U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B14CU, address);
            }
            r3 = value;
        }
        {
            r8 = r1;
        }
        {
            r2 = r4;
        }
        {
            const uint32_t operand = 0x000001B4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B160U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00408828_00408828(frame, context, state, 0x00408828U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B160U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B160;
    }
block_0014B160:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B160U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B160U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B160U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xC4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B164U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014B184; }
        goto block_0014B170;
    }
block_0014B170:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B170U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B170U);
        }
        {
            const uint32_t address = r4 + 444U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B170U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B174U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0014B180U + 404U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B178U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B17CU, 0xEE000A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B180U, address);
            }
        }
        goto block_0014B184;
    }
block_0014B184:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B184U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B184U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B184U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014B228; }
        goto block_0014B190;
    }
block_0014B190:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B190U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B190U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B190U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B194U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0014B228; }
        goto block_0014B1A0;
    }
block_0014B1A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B1A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B1A0U);
        }
        {
            const uint32_t address = r4 + 512U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B1A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0014B1ACU + 364U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B1A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B1A8U, address);
            }
            r2 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B1ACU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 1012U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B1B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B1B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0014B1B8U,
                                           firstAddress + 0U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0014B1B8U,
                                           firstAddress + 4U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0014B1B8U,
                                           firstAddress + 8U);
            }
            r3 = value3;
            r9 = value9;
            r11 = value11;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0014B1C0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0014B1C0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0014B1C0U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B1C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B1C8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B1CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B1D0U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B1D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B1D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r8 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B1DCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B1E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B1E8U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B1ECU, address);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B1F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r8 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B1F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B1F8U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B1FCU, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B200U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r8 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B204U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B208U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B20CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B210U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B214U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014B218U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B21CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B220U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014B224U, address);
            }
        }
        goto block_0014B228;
    }
block_0014B228:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B228U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B228U);
        }
        {
            const uint32_t operand = 0x00000C00U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002DCU;
            r1 = r1 + operand;
        }
        {
            r11 = r1;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B23CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B23CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B23C;
    }
block_0014B23C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B23CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B23CU);
        }
        {
            const uint32_t operand = 0x00000C00U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000334U;
            r1 = r1 + operand;
        }
        {
            r9 = r1;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B250U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_field_28_to_field_4c_0037632C(frame, context, state, 0x0037632CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B250U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B250;
    }
block_0014B250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B250U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B250U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B25CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B25CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B25C;
    }
block_0014B25C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B25CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B25CU);
        }
        {
            const uint32_t address = r5 + 808U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B25CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0014B268U + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B260U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B264U, 0xEE400A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 808U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014B268U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B26CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B274U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B274U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B274;
    }
block_0014B274:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B274U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B274U);
        }
        {
            const uint32_t address = r5 + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B274U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B278U, 0xEE400A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 816U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014B27CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B280U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B288U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B288U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B288;
    }
block_0014B288:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B288U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B288U);
        }
        {
            const uint32_t address = r5 + 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B288U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0014B294U + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B28CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B290U, 0xEE400A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 896U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014B294U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B298U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B2A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B2A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B2A0;
    }
block_0014B2A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B2A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B2A0U);
        }
        {
            const uint32_t address = r5 + 904U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B2A0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00005C00U;
            r1 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r1 = r1 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B2ACU, 0xEE400A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            r2 = r11;
        }
        {
            r8 = r1;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t address = r5 + 904U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014B2BCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B2C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetAT_003761F0(frame, context, state, 0x003761F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B2C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B2C4;
    }
block_0014B2C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B2C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B2C4U);
        }
        {
            r2 = r11;
        }
        {
            r1 = r8;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B2D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B2D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B2D4;
    }
block_0014B2D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B2D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B2D4U);
        }
        {
            r2 = r9;
        }
        {
            r1 = r8;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B2E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CollisionCheck_SetOC_003762A4(frame, context, state, 0x003762A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B2E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B2E4;
    }
block_0014B2E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B2E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B2E4U);
        }
        {
        }
        {
        }
        goto block_0014B324;
    }
block_0014B324:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B324U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B324U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B324U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r8 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x710U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B334U, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B33CU, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (flags.Z()) { goto block_0014B408; }
        goto block_0014B348;
    }
block_0014B348:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B348U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B348U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B348U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B34CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000063U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014B36C; }
        goto block_0014B358;
    }
block_0014B358:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B358U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B358U);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B358U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0014B364U + 0x414U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B35CU, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0014B408; }
        goto block_0014B36C;
    }
block_0014B36C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B36CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B36CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B36CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B370U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014B38C; }
        goto block_0014B37C;
    }
block_0014B37C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B37CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B37CU);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B380U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r4, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014B408; }
        goto block_0014B38C;
    }
block_0014B38C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B38CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B38CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x81U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B38CU, address);
            }
            r2 = value;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B398U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00357d54_00357D54(frame, context, state, 0x00357D54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B398U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B398;
    }
block_0014B398:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B398U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B398U);
        }
        {
            r1 = Oot3dAotLsl(r0, 10U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B39CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0014B3A8U + 0x3D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B3A0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = 0x0014B3ACU + 980U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B3A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = r0;
            r1 = r1 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0014B3D4; }
        goto block_0014B3B8;
    }
block_0014B3B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B3B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B3B8U);
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B3BCU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B3C0U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B3C4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014B3CCU, address);
            }
        }
        goto block_0014B400;
    }
block_0014B3D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B3D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B3D4U);
        }
        {
            const uint32_t updatedAddress = 0x0014B3DCU + 0x3A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B3D4U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014B3E0U, address);
            }
        }
        if ((flags.N()) == (flags.V())) { goto block_0014B400; }
        goto block_0014B3E8;
    }
block_0014B3E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B3E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B3E8U);
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B3ECU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B3F0U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B3F4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014B3FCU, address);
            }
        }
        goto block_0014B400;
    }
block_0014B400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B400U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B400U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014B404U, address);
            }
        }
        goto block_0014B408;
    }
block_0014B408:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B408U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B408U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B408U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0014B414U + 884U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B40CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t value = r0 & 0x01000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x01000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            r1 = r0 & ~(0x01000000U);
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014B418U, address);
            }
        }
        if (!(flags.Z())) { goto block_0014B9D0; }
        goto block_0014B420;
    }
block_0014B420:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B420U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B420U);
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B42CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnHorse_UpdateBgCheckInfo_001B3DB4(frame, context, state, 0x001B3DB4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B42CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B42C;
    }
block_0014B42C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B42CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B42CU);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B42CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r3 = r13 + operand;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000014U;
            r2 = r13 + operand;
        }
        {
            r1 = r8;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x41000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = 0x00000000U;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014B44CU, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B450U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B454U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0014B45CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B464U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_WaterBox_GetSurfaceImpl_0035E8A0(frame, context, state, 0x0035E8A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B464U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B464;
    }
block_0014B464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B464U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0014B4A4; }
        goto block_0014B470;
    }
block_0014B470:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B470U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B470U);
        }
        {
            const uint32_t address = r4 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B470U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B474U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B478U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_0014B4A4; }
        goto block_0014B484;
    }
block_0014B484:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B484U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B484U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B484U, address);
            }
            r3 = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B498U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnHorse_ObstructMovement_00357B9C(frame, context, state, 0x00357B9CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B498U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B498;
    }
block_0014B498:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B498U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B498U);
        }
        {
        }
        {
        }
        goto block_0014B99C;
    }
block_0014B4A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B4A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B4A4U);
        }
        {
            const uint32_t address = 0x0014B4ACU + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B4A4U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B4A8U, address);
            }
            r7 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0014B4B4U + 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B4ACU, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            frame.Guest.vfp[21] = frame.Guest.vfp[19];
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B4BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B4BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B4BC;
    }
block_0014B4BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B4BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B4BCU);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B4BCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r0 = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B4C4U, 0xEE4A0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014B4C8U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B4CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B4D0U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B4D4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B4DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B4DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B4DC;
    }
block_0014B4DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B4DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B4DCU);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B4DCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r7 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r7 = r7 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B4E8U, 0xEE4A0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000034U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000044U;
            r1 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014B4F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B4FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014B500U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B508U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BgCheck_EntityRaycastFloor3_00358410(frame, context, state, 0x00358410U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B508U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B508;
    }
block_0014B508:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B508U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B508U);
        }
        {
            const uint32_t updatedAddress = 0x0014B510U + 0x284U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B508U, address);
            }
            r9 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = 0x0014B518U + 0x284U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B510U, address);
            }
            r8 = value;
        }
        {
            const uint32_t address = 0x0014B51CU + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B514U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r9, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = r7 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B51CU, address);
            }
        }
        if (flags.Z()) {
            r0 = 0x00000001U;
        }
        if (flags.Z()) { goto block_0014B5C0; }
        goto block_0014B528;
    }
block_0014B528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B528U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B528U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r13 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B52CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B530U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r2 = r13 + operand;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B544U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_WaterBox_GetSurfaceImpl_0035E8A0(frame, context, state, 0x0035E8A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B544U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B544;
    }
block_0014B544:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B544U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B544U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0014B568; }
        goto block_0014B550;
    }
block_0014B550:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B550U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B550U);
        }
        {
            const uint32_t address = r7 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B550U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B554U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B558U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            r0 = 0x00000002U;
        }
        if (!(flags.C())) { goto block_0014B5C0; }
        goto block_0014B568;
    }
block_0014B568:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B568U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B568U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B568U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B56CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B574U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B578U, 0xEE200A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r8, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0014B5BC; }
        goto block_0014B588;
    }
block_0014B588:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B588U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B588U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B588U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B58CU, address);
            }
            r2 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B594U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SurfaceType_IsHorseBlocked_00357B88(frame, context, state, 0x00357B88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B594U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B594;
    }
block_0014B594:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B594U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B594U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0014B5BC; }
        goto block_0014B5A0;
    }
block_0014B5A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B5A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B5A0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B5A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B5A4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B5A8U, address);
            }
            r2 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B5B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SurfaceType_GetFloorType_0035EA34(frame, context, state, 0x0035EA34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B5B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B5B0;
    }
block_0014B5B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B5B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B5B0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = r10;
        }
        if (!(flags.Z())) { goto block_0014B5C0; }
        goto block_0014B5BC;
    }
block_0014B5BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B5BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B5BCU);
        }
        {
            r0 = 0x00000003U;
        }
        goto block_0014B5C0;
    }
block_0014B5C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B5C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B5C0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014B5C4U, address);
            }
        }
        if (flags.Z()) { goto block_0014B8E8; }
        goto block_0014B5CC;
    }
block_0014B5CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B5CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B5CCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0014B8E8; }
        goto block_0014B5D8;
    }
block_0014B5D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B5D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B5D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B5D8U, address);
            }
            r7 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[21] = frame.Guest.vfp[19];
        }
        {
            const uint32_t address = 0x0014B5E8U + 440U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B5E0U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B5ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B5ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B5EC;
    }
block_0014B5EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B5ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B5ECU);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B5ECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r0 = r7;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B5F4U, 0xEE4B0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[22], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014B5F8U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B5FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B600U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B604U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B60CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B60CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B60C;
    }
block_0014B60C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B60CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B60CU);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B60CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000EB0U;
            r7 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000028U;
            r3 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B618U, 0xEE4B0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[22], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x0000000CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000040U;
            r1 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014B624U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014B628U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B62CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B634U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BgCheck_EntityRaycastFloor3_00358410(frame, context, state, 0x00358410U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B634U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B634;
    }
block_0014B634:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B634U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B634U);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r7 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B638U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r9, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000001U;
        }
        if (flags.Z()) { goto block_0014B6E0; }
        goto block_0014B648;
    }
block_0014B648:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B648U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B648U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B648U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r13 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B64CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B650U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r2 = r13 + operand;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B664U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_WaterBox_GetSurfaceImpl_0035E8A0(frame, context, state, 0x0035E8A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B664U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B664;
    }
block_0014B664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B664U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0014B688; }
        goto block_0014B670;
    }
block_0014B670:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B670U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B670U);
        }
        {
            const uint32_t address = r7 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B670U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B674U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B678U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) {
            r0 = 0x00000002U;
        }
        if (!(flags.C())) { goto block_0014B6E0; }
        goto block_0014B688;
    }
block_0014B688:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B688U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B688U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B688U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B68CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B694U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B698U, 0xEE200A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r8, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0014B6DC; }
        goto block_0014B6A8;
    }
block_0014B6A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B6A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B6A8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B6A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B6ACU, address);
            }
            r2 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B6B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SurfaceType_IsHorseBlocked_00357B88(frame, context, state, 0x00357B88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B6B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B6B4;
    }
block_0014B6B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B6B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B6B4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0014B6DC; }
        goto block_0014B6C0;
    }
block_0014B6C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B6C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B6C0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B6C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B6C4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B6C8U, address);
            }
            r2 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B6D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SurfaceType_GetFloorType_0035EA34(frame, context, state, 0x0035EA34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B6D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B6D0;
    }
block_0014B6D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B6D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B6D0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = r10;
        }
        if (!(flags.Z())) { goto block_0014B6E0; }
        goto block_0014B6DC;
    }
block_0014B6DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B6DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B6DCU);
        }
        {
            r0 = 0x00000003U;
        }
        goto block_0014B6E0;
    }
block_0014B6E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B6E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B6E0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014B6E4U, address);
            }
        }
        if (flags.Z()) { goto block_0014B908; }
        goto block_0014B6EC;
    }
block_0014B6EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B6ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B6ECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0014B908; }
        goto block_0014B6F8;
    }
block_0014B6F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B6F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B6F8U);
        }
        {
            const uint32_t address = r5 + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B6F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B6FCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B700U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B70CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_FAtan2F_003696EC(frame, context, state, 0x003696ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B70CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B70C;
    }
block_0014B70C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B70CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B70CU);
        }
        {
            const uint32_t address = 0x0014B714U + 144U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B70CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B710U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B714U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B720U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0014B99C; }
        goto block_0014B72C;
    }
block_0014B72C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B72CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B72CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B72CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x0000001CU;
            r9 = r13 + operand;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B738U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B73CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B740U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B744U, 0xEE60AA0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B74CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B750U, 0xEE609A0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000034U;
            r0 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0014B75CU,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014B75CU,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0014B75CU,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B760U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014B764U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0014B764U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0014B764U,
                                           firstAddress + 8U);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B768U, 0xEE20AA0AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[20], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B76CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B770U, address);
            }
        }
        goto block_0014B7A8;
    }
block_0014B7A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B7A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B7A8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B7A8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B7B8U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B7C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math3D_DistPlaneToPos_00357B30(frame, context, state, 0x00357B30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B7C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B7C4;
    }
block_0014B7C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B7C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B7C4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B7C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B7C8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014B7D4U + 0x4C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B7CCU, address);
            }
            r11 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0014B810; }
        goto block_0014B7D8;
    }
block_0014B7D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B7D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B7D8U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B7D8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B7DCU, 0xEEF40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.N()) != (flags.V())) { goto block_0014B810; }
        goto block_0014B7E8;
    }
block_0014B7E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B7E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B7E8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B7E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        if (!(flags.Z())) { goto block_0014B804; }
        goto block_0014B7F8;
    }
block_0014B7F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B7F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B7F8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r11, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0014B8E8; }
        goto block_0014B800;
    }
block_0014B800:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B800U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B800U);
        }
        goto block_0014B810;
    }
block_0014B804:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B804U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B804U);
        }
        {
            const uint32_t updatedAddress = 0x0014B80CU + 0x490U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B804U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0014B8E8; }
        goto block_0014B810;
    }
block_0014B810:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B810U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B810U);
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r13 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[20];
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0014B818U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014B818U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0014B818U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014B820U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0014B820U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0014B820U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r5 + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B824U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B828U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B82CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B834U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B840U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math3D_DistPlaneToPos_00357B30(frame, context, state, 0x00357B30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B840U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B840;
    }
block_0014B840:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B840U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B840U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B840U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B844U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_0014B87C; }
        goto block_0014B850;
    }
block_0014B850:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B850U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B850U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B850U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B854U, 0xEEF40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0014B87C; }
        goto block_0014B860;
    }
block_0014B860:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B860U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B860U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B860U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014B888; }
        goto block_0014B86C;
    }
block_0014B86C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B86CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B86CU);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r11, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0014B908; }
        goto block_0014B878;
    }
block_0014B878:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B878U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B878U);
        }
        goto block_0014B898;
    }
block_0014B87C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B87CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B87CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B87CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014B898; }
        goto block_0014B888;
    }
block_0014B888:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B888U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B888U);
        }
        {
            const uint32_t updatedAddress = 0x0014B890U + 0x40CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B888U, address);
            }
            r2 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0014B908; }
        goto block_0014B898;
    }
block_0014B898:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B898U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B898U);
        }
        {
            r0 = frame.Guest.vfp[19];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r8, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0014B8D8; }
        goto block_0014B8A4;
    }
block_0014B8A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B8A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B8A4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x81U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B8A4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B8A8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B8B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SurfaceType_IsHorseBlocked_00357B88(frame, context, state, 0x00357B88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B8B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B8B0;
    }
block_0014B8B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B8B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B8B0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0014B8D8; }
        goto block_0014B8BC;
    }
block_0014B8BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B8BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B8BCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x81U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B8BCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B8C0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B8C4U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B8CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SurfaceType_GetFloorType_0035EA34(frame, context, state, 0x0035EA34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B8CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B8CC;
    }
block_0014B8CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B8CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B8CCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0014B928; }
        goto block_0014B8D8;
    }
block_0014B8D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B8D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B8D8U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B8D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B8DCU, 0xEEB40AC8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.N()) != (flags.V())) { goto block_0014B908; }
        goto block_0014B8E8;
    }
block_0014B8E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B8E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B8E8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B8E8U, address);
            }
            r3 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B8FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnHorse_ObstructMovement_00357B9C(frame, context, state, 0x00357B9CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B8FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B8FC;
    }
block_0014B8FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B8FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B8FCU);
        }
        {
        }
        {
        }
        goto block_0014B99C;
    }
block_0014B908:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B908U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B908U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B908U, address);
            }
            r3 = value;
        }
        {
            r2 = 0x00000005U;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014B91CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnHorse_ObstructMovement_00357B9C(frame, context, state, 0x00357B9CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014B91CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014B91C;
    }
block_0014B91C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B91CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B91CU);
        }
        {
        }
        {
        }
        goto block_0014B99C;
    }
block_0014B928:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B928U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B928U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B928U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0014B950; }
        goto block_0014B934;
    }
block_0014B934:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B934U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B934U);
        }
        {
            const uint32_t address = r4 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B934U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0014B940U + 864U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B938U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B93CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B940U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B944U, 0xEEB40AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_0014B958; }
        goto block_0014B950;
    }
block_0014B950:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B950U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B950U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014B950U, address);
            }
        }
        goto block_0014B99C;
    }
block_0014B958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B958U);
        }
        {
            frame.Guest.vfp[0] = r7;
        }
        {
            const uint32_t updatedAddress = 0x0014B964U + 0x340U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B95CU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B960U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B964U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0014B99C; }
        goto block_0014B974;
    }
block_0014B974:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B974U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B974U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0014B974U, address);
            }
        }
        {
            const uint32_t address = r5 + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B978U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B97CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0014B988U + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B980U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r4 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B984U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B988U, 0xEE700AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B98CU, 0xEE600A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B990U, 0xEE000A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B994U, 0xEE300A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B998U, address);
            }
        }
        goto block_0014B99C;
    }
block_0014B99C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B99CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B99CU);
        }
        {
            const uint32_t address = r5 + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B99CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B9A0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B9A4U, 0xEEB40AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = r5 + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B9ACU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B9B0U, 0xCEF40AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0014B9D0; }
        goto block_0014B9BC;
    }
block_0014B9BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B9BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B9BCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014B9BCU, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            r0 = r4;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t address = r0 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014B9C8U, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = r0 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0014B9CCU, address);
            }
        }
        goto block_0014B9D0;
    }
block_0014B9D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B9D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B9D0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B9D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014B9DCU + 0x2D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B9D4U, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B9D8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0014BB28; }
        goto block_0014B9E4;
    }
block_0014B9E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B9E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B9E4U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r5 - operand;
        }
        {
            r1 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r0 + 0xFEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B9ECU, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r0, 0U, 0U, flags.C());
            r0 = r1 & ~(shifted.Value);
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014BB28; }
        goto block_0014B9F8;
    }
block_0014B9F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014B9F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014B9F8U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B9F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0014BA04U + 0x2ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014B9FCU, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0014BB28; }
        goto block_0014BA0C;
    }
block_0014BA0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BA0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BA0CU);
        }
        {
            const uint32_t updatedAddress = 0x0014BA14U + 0x2A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BA0CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BA10U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r1 = 0x00000000U;
        }
        goto block_0014BA18;
    }
block_0014BA18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BA18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BA18U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 3U);
            r0 = operand - r1;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BA20U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r3;
        }
        {
            const uint32_t updatedAddress = r0 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BA28U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r3;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BA30U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BA34U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BA38U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BA3CU, 0xEE700A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BA40U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        {
            frame.Guest.vfp[2] = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BA58U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BA5CU, 0xEEF41AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[3], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0014BB1C; }
        goto block_0014BA68;
    }
block_0014BA68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BA68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BA68U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BA68U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BA70U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BA74U, 0xEEF41AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[3], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_0014BB1C; }
        goto block_0014BA80;
    }
block_0014BA80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BA80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BA80U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BA80U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BA84U, 0xEEB41AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[2], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0014BB1C; }
        goto block_0014BA90;
    }
block_0014BA90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BA90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BA90U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BA90U, 0xEEB41AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[2], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_0014BB1C; }
        goto block_0014BA9C;
    }
block_0014BA9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BA9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BA9CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BA9CU, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BAA0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BAA4U, address);
            }
            r12 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r0;
            r7 = r3 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, r12, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0014BB1C; }
        goto block_0014BAB4;
    }
block_0014BAB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BAB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BAB4U);
        }
        {
            const uint32_t operand = r3;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r12, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0014BB1C; }
        goto block_0014BAC0;
    }
block_0014BAC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BAC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BAC0U);
        }
        {
            r0 = r1 & 0x000000FFU;
            Oot3dAotSetLogicalFlags(flags, r0, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            const uint32_t updatedAddress = 0x0014BACCU + 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BAC4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0014BAD0U + 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BAC8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014BACCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xEA8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0014BAD0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xE50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BAD4U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_0014BAFC; }
        goto block_0014BADC;
    }
block_0014BADC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BADCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BADCU);
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BAE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_indexed_field_60_entry_00375750(frame, context, state, 0x00375750U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BAE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BAE4;
    }
block_0014BAE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BAE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BAE4U);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BAE8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BAF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_field_229c_clear_22ac_0037573C(frame, context, state, 0x0037573CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BAF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BAF0;
    }
block_0014BAF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BAF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BAF0U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5A2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014BAF4U, address);
            }
        }
        goto block_0014BB28;
    }
block_0014BAFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BAFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BAFCU);
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BB04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_indexed_field_60_entry_00375750(frame, context, state, 0x00375750U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BB04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BB04;
    }
block_0014BB04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BB04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BB04U);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BB08U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BB10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_field_229c_clear_22ac_0037573C(frame, context, state, 0x0037573CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BB10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BB10;
    }
block_0014BB10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BB10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BB10U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5A2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014BB14U, address);
            }
        }
        goto block_0014BB28;
    }
block_0014BB1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BB1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BB1CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0014BA18; }
        goto block_0014BB28;
    }
block_0014BB28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BB28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BB28U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BB28U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0014BB38U + 392U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BB30U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014BB34U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0014BB34U,
                                           firstAddress + 4U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0014BB34U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r7 = value7;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0014BB38U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0014BB38U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0014BB38U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r4 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BB3CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BB40U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0014BB44U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BB4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BB4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BB4C;
    }
block_0014BB4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BB4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BB4CU);
        }
        {
            const uint32_t updatedAddress = 0x0014BB54U + 0x170U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BB4CU, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        if ((flags.N()) == (flags.V())) { goto block_0014BB78; }
        goto block_0014BB60;
    }
block_0014BB60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BB60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BB60U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BB60U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r1 = 0x00000001U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014BB6CU, address);
            }
        }
        if (flags.Z()) { goto block_0014BBA0; }
        goto block_0014BB74;
    }
block_0014BB74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BB74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BB74U);
        }
        goto block_0014BB84;
    }
block_0014BB78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BB78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BB78U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BB78U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0014BBA0; }
        goto block_0014BB84;
    }
block_0014BB84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BB84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BB84U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BB88U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            r1 = r1 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014BB98U, address);
            }
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0014BB9CU, address);
            }
        }
        goto block_0014BBA0;
    }
block_0014BBA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BBA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BBA0U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BBA0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BBA4U, 0xEEB40A48U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[16],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z())) { goto block_0014BBC4; }
        goto block_0014BBB0;
    }
block_0014BBB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BBB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BBB0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BBB0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00080000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00080000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r1 = 0x000000FFU;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014BBBCU, address);
            }
        }
        if (flags.Z()) { goto block_0014BBCC; }
        goto block_0014BBC4;
    }
block_0014BBC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BBC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BBC4U);
        }
        {
            r1 = 0x000000FEU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xB6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0014BBC8U, address);
            }
        }
        goto block_0014BBCC;
    }
block_0014BBCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BBCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BBCCU);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BBCCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0014BBD8U + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BBD0U, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t updatedAddress = r4 + 0xEECU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BBDCU, address);
            }
            r0 = value;
        }
        if ((flags.N()) != (flags.V())) {
            r0 = r0 & ~(0x00000001U);
        }
        if ((flags.N()) == (flags.V())) {
            r0 = r0 | 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xEECU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014BBE8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0014BBF4U - 0xE40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BBECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BBF0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000057U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x4E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BBFCU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0014BE50; }
        goto block_0014BC08;
    }
block_0014BC08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BC08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BC08U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t address = 0x0014BC14U + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BC0CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x54U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BC10U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014BCD0; }
        goto block_0014BC1C;
    }
block_0014BC1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BC1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BC1CU);
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014BC20U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BC28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BC28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BC28;
    }
block_0014BC28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BC28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BC28U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BC28U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BC2CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x0000001EU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r5 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BC40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BC40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BC40;
    }
block_0014BC40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BC40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BC40U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BC40U, 0xEE200A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BC44U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x0000001EU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r7 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BC58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BC58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BC58;
    }
block_0014BC58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BC58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BC58U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BC58U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000058U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r2 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BC64U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x000000C8U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014BC74U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0014BC74U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000058U;
            r1 = r1 + operand;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x0014BC84U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BC8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00357a84_00357A84(frame, context, state, 0x00357A84U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BC8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BC8C;
    }
block_0014BC8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BC8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BC8CU);
        }
        {
        }
        {
        }
        goto block_0014BE50;
    }
block_0014BCD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BCD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BCD0U);
        }
        {
            const uint32_t value = r0 & 0x00000002U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014BD54; }
        goto block_0014BCD8;
    }
block_0014BCD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BCD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BCD8U);
        }
        {
            r0 = r0 & ~(0x00000002U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014BCDCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BCE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BCE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BCE4;
    }
block_0014BCE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BCE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BCE4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BCE4U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BCE8U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x0000001EU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r5 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BCFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BCFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BCFC;
    }
block_0014BCFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BCFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BCFCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BCFCU, 0xEE200A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BD00U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x0000001EU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r7 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BD14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BD14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BD14;
    }
block_0014BD14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BD14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BD14U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BD14U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000058U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r2 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BD20U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x000000C8U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014BD30U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0014BD30U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000064U;
            r1 = r1 + operand;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x0014BD40U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BD48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00357a84_00357A84(frame, context, state, 0x00357A84U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BD48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BD48;
    }
block_0014BD48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BD48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BD48U);
        }
        {
        }
        {
        }
        goto block_0014BE50;
    }
block_0014BD54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BD54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BD54U);
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014BDD8; }
        goto block_0014BD5C;
    }
block_0014BD5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BD5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BD5CU);
        }
        {
            r0 = r0 & ~(0x00000004U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014BD60U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BD68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BD68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BD68;
    }
block_0014BD68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BD68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BD68U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BD68U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BD6CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x0000001EU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r5 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BD80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BD80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BD80;
    }
block_0014BD80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BD80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BD80U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BD80U, 0xEE200A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BD84U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x0000001EU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r7 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BD98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BD98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BD98;
    }
block_0014BD98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BD98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BD98U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BD98U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000058U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r2 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BDA4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x000000C8U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014BDB4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0014BDB4U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000070U;
            r1 = r1 + operand;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x0014BDC4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BDCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00357a84_00357A84(frame, context, state, 0x00357A84U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BDCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BDCC;
    }
block_0014BDCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BDCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BDCCU);
        }
        {
        }
        {
        }
        goto block_0014BE50;
    }
block_0014BDD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BDD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BDD8U);
        }
        {
            const uint32_t value = r0 & 0x00000008U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0014BE50; }
        goto block_0014BDE0;
    }
block_0014BDE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BDE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BDE0U);
        }
        {
            r0 = r0 & ~(0x00000008U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014BDE4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BDECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BDECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BDEC;
    }
block_0014BDEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BDECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BDECU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BDECU, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BDF0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x0000001EU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r5 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BE04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BE04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BE04;
    }
block_0014BE04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BE04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BE04U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BE04U, 0xEE200A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BE08U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x0000001EU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r7 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BE1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroOne_003759D0(frame, context, state, 0x003759D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BE1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BE1C;
    }
block_0014BE1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BE1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BE1CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BE1CU, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000058U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r2 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0014BE28U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x000000C8U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0014BE38U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0014BE38U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000007CU;
            r1 = r1 + operand;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x0014BE48U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0014BE50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00357a84_00357A84(frame, context, state, 0x00357A84U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0014BE50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0014BE50;
    }
block_0014BE50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BE50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BE50U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0014BE50U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x08000000U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0014BE58U, address);
            }
        }
        goto block_0014BE5C;
    }
block_0014BE5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0014BE5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0014BE5CU);
        }
        {
            const uint32_t operand = 0x0000007CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0014BE60U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0014BE60U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0014BE60U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0014BE60U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0014BE60U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0014BE60U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0014BE60U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0014BE60U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0014BE64U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0014BE64U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0014BE64U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0014BE64U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0014BE64U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0014BE64U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0014BE64U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0014BE64U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0014BE64U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_00159184_00159184(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00159184U:
        goto block_00159184;
    case 0x001591BCU:
        goto block_001591BC;
    case 0x00159238U:
        goto block_00159238;
    case 0x00159288U:
        goto block_00159288;
    case 0x001592ACU:
        goto block_001592AC;
    case 0x001592CCU:
        goto block_001592CC;
    case 0x001592D8U:
        goto block_001592D8;
    case 0x001592E4U:
        goto block_001592E4;
    case 0x001592F0U:
        goto block_001592F0;
    case 0x0015930CU:
        goto block_0015930C;
    case 0x00159318U:
        goto block_00159318;
    case 0x00159328U:
        goto block_00159328;
    case 0x00159338U:
        goto block_00159338;
    case 0x00159344U:
        goto block_00159344;
    case 0x00159350U:
        goto block_00159350;
    case 0x00159364U:
        goto block_00159364;
    case 0x00159370U:
        goto block_00159370;
    case 0x0015937CU:
        goto block_0015937C;
    case 0x00159388U:
        goto block_00159388;
    case 0x00159394U:
        goto block_00159394;
    case 0x0015939CU:
        goto block_0015939C;
    case 0x001593ACU:
        goto block_001593AC;
    case 0x001593BCU:
        goto block_001593BC;
    case 0x001593C8U:
        goto block_001593C8;
    case 0x001593D4U:
        goto block_001593D4;
    case 0x001593E8U:
        goto block_001593E8;
    case 0x001593F4U:
        goto block_001593F4;
    case 0x00159400U:
        goto block_00159400;
    case 0x0015940CU:
        goto block_0015940C;
    case 0x00159414U:
        goto block_00159414;
    case 0x00159420U:
        goto block_00159420;
    case 0x0015943CU:
        goto block_0015943C;
    case 0x00159450U:
        goto block_00159450;
    case 0x00159468U:
        goto block_00159468;
    case 0x0015947CU:
        goto block_0015947C;
    case 0x001594F8U:
        goto block_001594F8;
    case 0x00159504U:
        goto block_00159504;
    case 0x00159540U:
        goto block_00159540;
    case 0x00159554U:
        goto block_00159554;
    case 0x001595C8U:
        goto block_001595C8;
    case 0x001595D4U:
        goto block_001595D4;
    case 0x001595F8U:
        goto block_001595F8;
    case 0x00159654U:
        goto block_00159654;
    case 0x00159658U:
        goto block_00159658;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00159184:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159184U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159184U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00159184U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00159184U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00159184U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00159184U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00159184U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00159184U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00159184U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00159184U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00159184U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00000200U;
            r5 = r4 + operand;
        }
        {
            r9 = r1;
        }
        {
            const uint32_t updatedAddress = 0x0015919CU + 0x3C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159194U, address);
            }
            r0 = value;
        }
        {
            r13 -= 24U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00159198U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00159198U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00159198U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00159198U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x00159198U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x00159198U,
                                           firstAddress + 20U);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001591A0U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001591A4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001591B0U, address);
            }
        }
        {
            const uint32_t operand = 0x000001D4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001591BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001591BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001591BC;
    }
block_001591BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001591BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001591BCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001591BCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001591C8U + 924U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001591C0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x001591CCU + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001591C4U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x001591D4U + 916U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001591CCU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = 0x001591DCU + 916U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001591D4U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001591D8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = 0x00000800U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001591E0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r1 = 0x00001800U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001591E8U, 0xEE201A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001591F0U, 0xDE110A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001591F4U, 0xCE010A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001591F8U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x0000000FU;
            r0 = operand - r0;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0015920CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159210U, 0xEE201A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159218U, 0xEE010A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00159224U + 848U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015921CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159220U, 0xEE200A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159224U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00159228U, address);
            }
        }
        {
            const uint32_t address = r4 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0015922CU, address);
            }
        }
        {
            const uint32_t address = r4 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00159230U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159238U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159238U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159238;
    }
block_00159238:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159238U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159238U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159238U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x00159244U + 0x334U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015923CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x00159248U + 824U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159240U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0015924CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159250U, 0xEE200A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159254U, 0xDE109A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159258U, 0xCE009A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0015925CU, 0xEEBD0AC9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x0000000FU;
            r0 = operand - r0;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0015926CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159270U, 0xEE200A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = 0x00159284U + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015927CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159280U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159288U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159288U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159288;
    }
block_00159288:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159288U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159288U);
        }
        {
            const uint32_t address = 0x00159290U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159288U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00159294U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015928CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159290U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0015929CU + 0x2F0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159294U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159298U, 0xEE008A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x001592A4U + 748U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015929CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            frame.Guest.vfp[19] = frame.Guest.vfp[18];
        }
        if ((flags.N()) != (flags.V())) { goto block_00159414; }
        goto block_001592AC;
    }
block_001592AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001592ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001592ACU);
        }
        {
            const uint32_t updatedAddress = 0x001592B4U + 0x2E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001592ACU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x001592B8U + 0x2E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001592B0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x001592BCU + 0x2E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001592B4U, address);
            }
            r7 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r12 = r4 + operand;
        }
        {
            const uint32_t address = 0x001592C4U + 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001592BCU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000062U;
            r12 = r12 + operand;
        }
        if ((flags.N()) == (flags.V())) { goto block_001592F0; }
        goto block_001592CC;
    }
block_001592CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001592CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001592CCU);
        }
        {
            r1 = r7;
        }
        {
            r0 = r12;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001592D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001592D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001592D8;
    }
block_001592D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001592D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001592D8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001592D8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001592E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001592E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001592E4;
    }
block_001592E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001592E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001592E4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001592E4U, 0xEE609A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
        }
        goto block_00159414;
    }
block_001592F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001592F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001592F0U);
        }
        {
            const uint32_t updatedAddress = 0x001592F8U + 0x2ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001592F0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x001592FCU + 0x2ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001592F4U, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r10 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = Oot3dAotAsr(r3, 2U);
            r1 = r3 - operand;
        }
        {
            const uint32_t operand = 0x00000066U;
            r10 = r10 + operand;
        }
        if ((flags.N()) == (flags.V())) { goto block_00159394; }
        goto block_0015930C;
    }
block_0015930C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0015930CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0015930CU);
        }
        {
            r11 = r2;
        }
        {
            r0 = r12;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159318U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159318U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159318;
    }
block_00159318:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159318U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159318U);
        }
        {
            r2 = r11;
        }
        {
            r1 = r7;
        }
        {
            const uint32_t operand = 0x00000264U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159328U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159328U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159328;
    }
block_00159328:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159328U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159328U);
        }
        {
            r2 = r8;
        }
        {
            r1 = r7;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159338U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159338U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159338;
    }
block_00159338:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159338U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159338U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159338U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159344U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159344U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159344;
    }
block_00159344:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159344U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159344U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159344U, 0xEEF19A40U};
            frame.Guest.vfp[19] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159348U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159350U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159350U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159350;
    }
block_00159350:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159350U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159350U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159350U, 0xEE390AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r5 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159358U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0015935CU, 0xEE409A68U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159364U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159364U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159364;
    }
block_00159364:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159364U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159364U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159364U, 0xEE699A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159368U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159370U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159370U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159370;
    }
block_00159370:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159370U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159370U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159370U, 0xEEC99A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159374U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0015937CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0015937CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0015937C;
    }
block_0015937C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0015937CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0015937CU);
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159380U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159388U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159388U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159388;
    }
block_00159388:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159388U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159388U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159388U, 0xEE3A0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0015938CU, 0xEE509A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        goto block_00159414;
    }
block_00159394:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159394U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159394U);
        }
        {
            r0 = r12;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0015939CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0015939CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0015939C;
    }
block_0015939C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0015939CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0015939CU);
        }
        {
            const uint32_t updatedAddress = 0x001593A4U + 0x208U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015939CU, address);
            }
            r1 = value;
        }
        {
            r2 = r8;
        }
        {
            const uint32_t operand = 0x00000264U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001593ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001593ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001593AC;
    }
block_001593AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001593ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001593ACU);
        }
        {
            r2 = r8;
        }
        {
            r1 = r7;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001593BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001593BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001593BC;
    }
block_001593BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001593BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001593BCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001593BCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001593C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001593C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001593C8;
    }
block_001593C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001593C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001593C8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001593C8U, 0xEEF19A40U};
            frame.Guest.vfp[19] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001593CCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001593D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001593D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001593D4;
    }
block_001593D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001593D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001593D4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001593D4U, 0xEE390AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r5 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001593DCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001593E0U, 0xEE409A68U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001593E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001593E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001593E8;
    }
block_001593E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001593E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001593E8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001593E8U, 0xEE699A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001593ECU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001593F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001593F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001593F4;
    }
block_001593F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001593F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001593F4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001593F4U, 0xEEC99A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001593F8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159400U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159400U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159400;
    }
block_00159400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159400U);
        }
        {
            frame.Guest.vfp[20] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159404U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0015940CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0015940CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0015940C;
    }
block_0015940C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0015940CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0015940CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0015940CU, 0xEE3A0A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[20], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159410U, 0xEE509A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        goto block_00159414;
    }
block_00159414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159414U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159414U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_00159450; }
        goto block_00159420;
    }
block_00159420:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159420U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159420U);
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159420U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159424U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159428U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0015942CU, 0xEE700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159430U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159434U, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0015943CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Atan2S_003758B0(frame, context, state, 0x003758B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0015943CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0015943C;
    }
block_0015943C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0015943CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0015943CU);
        }
        {
            r1 = r0;
        }
        {
            const uint32_t updatedAddress = 0x00159448U + 0x168U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159440U, address);
            }
            r3 = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x000000BEU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159450U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SmoothStepToSUpdateRate_00370084(frame, context, state, 0x00370084U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159450U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159450;
    }
block_00159450:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159450U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159450U);
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159450U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159454U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159458U, 0xEE080A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0015945CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159460U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159468U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159468U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159468;
    }
block_00159468:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159468U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159468U);
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159468U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015946CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159470U, 0xEE690AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[19], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159474U, 0xEE208A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0015947CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0015947CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0015947C;
    }
block_0015947C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0015947CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0015947CU);
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015947CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159488U, 0xEE291AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[19], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = ~(0x00000000U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159494U, 0xEE200A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159498U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0015949CU, 0xEE311A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x001594A0U, address);
            }
        }
        {
            const uint32_t address = r4 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001594A4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001594A8U, 0xEE310A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001594ACU, address);
            }
        }
        {
            const uint32_t address = 0x001594B8U + 252U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001594B0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001594B4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001594B4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001594B4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001594B4U,
                                           firstAddress + 12U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001594BCU, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001594C4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x001594D4U + 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001594CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001594D0U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001594D8U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001594DCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x001594ECU + 208U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001594E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001594E8U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001594F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsHahen_SpawnBurst_0036F9D0(frame, context, state, 0x0036F9D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001594F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001594F8;
    }
block_001594F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001594F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001594F8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001594F8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00159658; }
        goto block_00159504;
    }
block_00159504:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159504U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159504U);
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159504U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159508U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015950CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159510U, 0xEE700A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159514U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159518U, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00159524U + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015951CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159520U, 0xEE600AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159524U, 0xEE400A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159528U, 0xEEB10AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015952CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159530U, 0xEE600A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00159534U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_001595C8; }
        goto block_00159540;
    }
block_00159540:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159540U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159540U);
        }
        {
            r0 = 0x0000000CU;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00159548U, address);
            }
        }
        {
            const uint32_t operand = 0x000001D4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00159554U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_SetPlaySpeed_003731E8(frame, context, state, 0x003731E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00159554U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00159554;
    }
block_00159554:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159554U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159554U);
        }
        {
            const uint32_t updatedAddress = 0x0015955CU + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159554U, address);
            }
            r0 = value;
        }
        {
        }
        goto block_00159654;
    }
block_001595C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001595C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001595C8U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000001D4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001595D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001595D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001595D4;
    }
block_001595D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001595D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001595D4U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = 0x001595E4U + 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001595DCU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000001D4U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001595ECU, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x001595F8U + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001595F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001595F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001595F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001595F8;
    }
block_001595F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001595F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001595F8U);
        }
        {
            r0 = 0x00000017U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001595FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x3C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159600U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xB7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159604U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xB7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0015960CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x3C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159610U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x107U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159614U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x107U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0015961CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x3C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159620U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x157U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159624U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x157U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0015962CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x3C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159630U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159634U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0015963CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x3C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159640U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1F7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159644U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x1F7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0015964CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00159658U + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00159650U, address);
            }
            r0 = value;
        }
        goto block_00159654;
    }
block_00159654:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159654U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159654U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x258U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00159654U, address);
            }
        }
        goto block_00159658;
    }
block_00159658:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00159658U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00159658U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0015965CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0015965CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0015965CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0015965CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0015965CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0015965CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            r13 += 24U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00159660U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00159660U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00159660U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00159660U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00159660U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00159660U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00159660U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00159660U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00159660U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_0019c82c_0019C82C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0019C82CU:
        goto block_0019C82C;
    case 0x00180BD0U:
        goto block_00180BD0;
    case 0x00180C24U:
        goto block_00180C24;
    case 0x00180C48U:
        goto block_00180C48;
    case 0x00180C7CU:
        goto block_00180C7C;
    case 0x0019C85CU:
        goto block_0019C85C;
    case 0x0019C8D4U:
        goto block_0019C8D4;
    case 0x0019C924U:
        goto block_0019C924;
    case 0x0019C944U:
        goto block_0019C944;
    case 0x0019C960U:
        goto block_0019C960;
    case 0x0019C968U:
        goto block_0019C968;
    case 0x0019C974U:
        goto block_0019C974;
    case 0x0019C980U:
        goto block_0019C980;
    case 0x0019C99CU:
        goto block_0019C99C;
    case 0x0019C9A4U:
        goto block_0019C9A4;
    case 0x0019C9B4U:
        goto block_0019C9B4;
    case 0x0019C9C4U:
        goto block_0019C9C4;
    case 0x0019C9D0U:
        goto block_0019C9D0;
    case 0x0019C9DCU:
        goto block_0019C9DC;
    case 0x0019C9F0U:
        goto block_0019C9F0;
    case 0x0019C9FCU:
        goto block_0019C9FC;
    case 0x0019CA08U:
        goto block_0019CA08;
    case 0x0019CA14U:
        goto block_0019CA14;
    case 0x0019CA20U:
        goto block_0019CA20;
    case 0x0019CA28U:
        goto block_0019CA28;
    case 0x0019CA38U:
        goto block_0019CA38;
    case 0x0019CA48U:
        goto block_0019CA48;
    case 0x0019CA54U:
        goto block_0019CA54;
    case 0x0019CA60U:
        goto block_0019CA60;
    case 0x0019CA74U:
        goto block_0019CA74;
    case 0x0019CA80U:
        goto block_0019CA80;
    case 0x0019CA8CU:
        goto block_0019CA8C;
    case 0x0019CA98U:
        goto block_0019CA98;
    case 0x0019CAA0U:
        goto block_0019CAA0;
    case 0x0019CAB8U:
        goto block_0019CAB8;
    case 0x0019CACCU:
        goto block_0019CACC;
    case 0x0019CB48U:
        goto block_0019CB48;
    case 0x0019CB54U:
        goto block_0019CB54;
    case 0x0019CBC0U:
        goto block_0019CBC0;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00180BD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00180BD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00180BD0U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00180BD0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00180BD0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00180BD0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00180BD0U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t updatedAddress = 0x00180BE0U + 0xA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180BD8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r5 = r4 + operand;
        }
        {
            const uint32_t address = 0x00180BE8U + 164U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180BE0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00180BE4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00180BE8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00180BECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00180BF0U, address);
            }
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180BF4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00180BFCU, address);
            }
        }
        {
            const uint32_t address = r4 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180C00U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00180C04U, address);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180C08U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180C0CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00180C10U, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00180C14U, address);
            }
        }
        {
            const uint32_t address = 0x00180C20U + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180C18U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00180C1CU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00180C24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SetScale_0037572C(frame, context, state, 0x0037572CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00180C24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00180C24;
    }
block_00180C24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00180C24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00180C24U);
        }
        {
            r0 = 0x0000000CU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x3BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00180C28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x3B9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180C2CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00180C38U + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180C30U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r0 | 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x3B9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00180C38U, address);
            }
        }
        {
            r0 = 0x00000044U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00180C40U, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        goto block_00180C48;
    }
block_00180C48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00180C48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00180C48U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x3C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180C48U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r2 = r0 + operand;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180C50U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 4U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r1 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00180C5CU, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180C60U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00180C68U, 0xEE700AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00180C6CU, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180C70U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r1 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00180C74U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00180C48; }
        goto block_00180C7C;
    }
block_00180C7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00180C7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00180C7CU);
        }
        {
            const uint32_t updatedAddress = 0x00180C84U + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180C7CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x258U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00180C80U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00180C84U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00180C84U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00180C84U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00180C84U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_0019C82C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C82CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C82CU);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0019C82CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0019C82CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0019C82CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0019C82CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0019C82CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0019C82CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0019C82CU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0019C82CU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0019C82CU,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            const uint32_t operand = 0x00000200U;
            r5 = r0 + operand;
        }
        {
            r4 = r0;
        }
        {
            r10 = r1;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0019C83CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0019C83CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0019C83CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0019C83CU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C844U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0019C850U, address);
            }
        }
        {
            const uint32_t operand = 0x000001D4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019C85CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019C85CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019C85C;
    }
block_0019C85C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C85CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C85CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C85CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0019C868U + 768U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C860U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0019C86CU + 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C864U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x0019C874U + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C86CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t address = 0x0019C87CU + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C874U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C878U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = 0x00000300U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C880U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00004300U;
            r6 = r2 - operand;
        }
        {
            r1 = r6;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C88CU, 0xEE201A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C894U, 0xDE110A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C898U, 0xCE010A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C89CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x000000BCU;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C8ACU, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C8B4U, 0xEE010A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0019C8C0U + 696U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C8B8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C8BCU, 0xEE200A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C8C0U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019C8C4U, address);
            }
        }
        {
            const uint32_t address = r4 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019C8C8U, address);
            }
        }
        {
            const uint32_t address = r4 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019C8CCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019C8D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019C8D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019C8D4;
    }
block_0019C8D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C8D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C8D4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C8D4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x0019C8E0U + 668U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C8D8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x0019C8E4U + 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C8DCU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C8E8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C8ECU, 0xEE200A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C8F0U, 0xDE109A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C8F4U, 0xCE009A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[18], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[18], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C8F8U, 0xEEBD0AC9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C904U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C908U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0019C914U + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C90CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = 0x0019C920U + 612U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C918U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C91CU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019C924U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019C924U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019C924;
    }
block_0019C924:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C924U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C924U);
        }
        {
            const uint32_t address = 0x0019C92CU + 608U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C924U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0019C930U + 608U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C928U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C92CU, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0019C938U + 0x25CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C930U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C934U, 0xEE408A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[17], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t address = 0x0019C944U + 596U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C93CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        if ((flags.N()) != (flags.V())) { goto block_0019CAA0; }
        goto block_0019C944;
    }
block_0019C944:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C944U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C944U);
        }
        {
            const uint32_t updatedAddress = 0x0019C94CU + 0x250U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C944U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0019C950U + 0x250U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C948U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0019C958U + 588U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C950U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000062U;
            r0 = r0 + operand;
        }
        if ((flags.N()) == (flags.V())) { goto block_0019C980; }
        goto block_0019C960;
    }
block_0019C960:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C960U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C960U);
        }
        {
            r1 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019C968U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019C968U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019C968;
    }
block_0019C968:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C968U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C968U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C968U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019C974U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019C974U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019C974;
    }
block_0019C974:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C974U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C974U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C974U, 0xEE208A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
        }
        goto block_0019CAA0;
    }
block_0019C980:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C980U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C980U);
        }
        {
            const uint32_t updatedAddress = 0x0019C988U + 0x220U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C980U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = 0x0019C98CU + 0x220U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C984U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0019C990U + 0x220U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C988U, address);
            }
            r7 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r8 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r12, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000066U;
            r8 = r8 + operand;
        }
        if ((flags.N()) == (flags.V())) { goto block_0019CA20; }
        goto block_0019C99C;
    }
block_0019C99C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C99CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C99CU);
        }
        {
            r9 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019C9A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019C9A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019C9A4;
    }
block_0019C9A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C9A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C9A4U);
        }
        {
            r2 = r9;
        }
        {
            r1 = r6;
        }
        {
            const uint32_t operand = 0x00000264U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019C9B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019C9B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019C9B4;
    }
block_0019C9B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C9B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C9B4U);
        }
        {
            r2 = r7;
        }
        {
            r1 = r6;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019C9C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019C9C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019C9C4;
    }
block_0019C9C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C9C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C9C4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C9C4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019C9D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019C9D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019C9D0;
    }
block_0019C9D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C9D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C9D0U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C9D0U, 0xEEB18A40U};
            frame.Guest.vfp[16] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C9D4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019C9DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019C9DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019C9DC;
    }
block_0019C9DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C9DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C9DCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C9DCU, 0xEE380A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = r5 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C9E4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C9E8U, 0xEE008A49U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019C9F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019C9F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019C9F0;
    }
block_0019C9F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C9F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C9F0U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C9F0U, 0xEE288A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019C9F4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019C9FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019C9FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019C9FC;
    }
block_0019C9FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019C9FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019C9FCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019C9FCU, 0xEE888A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CA00U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CA08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CA08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CA08;
    }
block_0019CA08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CA08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CA08U);
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CA0CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CA14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CA14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CA14;
    }
block_0019CA14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CA14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CA14U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CA14U, 0xEE390A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CA18U, 0xEE108A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        goto block_0019CAA0;
    }
block_0019CA20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CA20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CA20U);
        }
        {
            r11 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CA28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CA28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CA28;
    }
block_0019CA28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CA28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CA28U);
        }
        {
            r2 = r7;
        }
        {
            r1 = r11;
        }
        {
            const uint32_t operand = 0x00000264U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CA38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CA38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CA38;
    }
block_0019CA38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CA38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CA38U);
        }
        {
            r2 = r7;
        }
        {
            r1 = r6;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CA48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ScaledStepToS_00370378(frame, context, state, 0x00370378U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CA48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CA48;
    }
block_0019CA48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CA48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CA48U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CA48U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CA54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CA54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CA54;
    }
block_0019CA54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CA54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CA54U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CA54U, 0xEEB18A40U};
            frame.Guest.vfp[16] = frame.Guest.vfp[0] ^ 0x80000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CA58U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CA60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CA60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CA60;
    }
block_0019CA60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CA60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CA60U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CA60U, 0xEE380A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[16] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = r5 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CA68U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CA6CU, 0xEE008A49U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CA74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CA74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CA74;
    }
block_0019CA74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CA74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CA74U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CA74U, 0xEE288A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CA78U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CA80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CA80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CA80;
    }
block_0019CA80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CA80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CA80U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CA80U, 0xEE888A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r5 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CA84U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CA8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CA8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CA8C;
    }
block_0019CA8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CA8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CA8CU);
        }
        {
            frame.Guest.vfp[19] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r5 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CA90U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CA98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CA98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CA98;
    }
block_0019CA98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CA98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CA98U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CA98U, 0xEE390A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[19], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CA9CU, 0xEE108A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        goto block_0019CAA0;
    }
block_0019CAA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CAA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CAA0U);
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CAA0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CAA4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CAA8U, 0xEE080AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019CAACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CAB0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CAB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CAB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CAB8;
    }
block_0019CAB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CAB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CAB8U);
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CAB8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CABCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CAC0U, 0xEE680A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[16], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CAC4U, 0xEE608A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CACCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CACCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CACC;
    }
block_0019CACC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CACCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CACCU);
        }
        {
            const uint32_t address = r4 + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CACCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CAD8U, 0xEE281A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[16], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r1 = ~(0x00000000U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CAE4U, 0xEE200A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CAE8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CAECU, 0xEE311A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0019CAF0U, address);
            }
        }
        {
            const uint32_t address = r4 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CAF4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CAF8U, 0xEE310A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0019CAFCU, address);
            }
        }
        {
            const uint32_t address = 0x0019CB08U + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CB00U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0019CB04U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0019CB04U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0019CB04U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0019CB04U,
                                           firstAddress + 12U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CB0CU, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CB14U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x0019CB24U + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CB1CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CB20U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0019CB28U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CB2CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x0019CB3CU + 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CB34U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0019CB38U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            r0 = r10;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0019CB48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsHahen_SpawnBurst_0036F9D0(frame, context, state, 0x0036F9D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0019CB48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0019CB48;
    }
block_0019CB48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CB48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CB48U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0019CB48U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0019CBC0; }
        goto block_0019CB54;
    }
block_0019CB54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CB54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CB54U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0019CB5CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0019CB5CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019CB5CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019CB5CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0019CB60U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0019CB60U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0019CB60U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0019CB60U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0019CB60U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0019CB60U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0019CB60U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0019CB60U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x0019CB60U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r14 = value14;
            r13 = r13 + 36U;
        }
        goto block_00180BD0;
    }
block_0019CBC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0019CBC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0019CBC0U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0019CBC4U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0019CBC4U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0019CBC4U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0019CBC4U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0019CBC8U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0019CBC8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0019CBC8U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0019CBC8U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0019CBC8U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0019CBC8U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0019CBC8U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0019CBC8U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0019CBC8U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_EnHorse_UpdateBgCheckInfo_001B3DB4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001B3DB4U:
        goto block_001B3DB4;
    case 0x001B3E08U:
        goto block_001B3E08;
    case 0x001B3E14U:
        goto block_001B3E14;
    case 0x001B3E20U:
        goto block_001B3E20;
    case 0x001B3E2CU:
        goto block_001B3E2C;
    case 0x001B3E40U:
        goto block_001B3E40;
    case 0x001B3E50U:
        goto block_001B3E50;
    case 0x001B3E64U:
        goto block_001B3E64;
    case 0x001B3E7CU:
        goto block_001B3E7C;
    case 0x001B3E9CU:
        goto block_001B3E9C;
    case 0x001B3EA8U:
        goto block_001B3EA8;
    case 0x001B3EB4U:
        goto block_001B3EB4;
    case 0x001B3EC8U:
        goto block_001B3EC8;
    case 0x001B3ED8U:
        goto block_001B3ED8;
    case 0x001B3EECU:
        goto block_001B3EEC;
    case 0x001B3F38U:
        goto block_001B3F38;
    case 0x001B3F54U:
        goto block_001B3F54;
    case 0x001B3F68U:
        goto block_001B3F68;
    case 0x001B3FC4U:
        goto block_001B3FC4;
    case 0x001B3FD0U:
        goto block_001B3FD0;
    case 0x001B4010U:
        goto block_001B4010;
    case 0x001B401CU:
        goto block_001B401C;
    case 0x001B4034U:
        goto block_001B4034;
    case 0x001B4054U:
        goto block_001B4054;
    case 0x001B407CU:
        goto block_001B407C;
    case 0x001B4088U:
        goto block_001B4088;
    case 0x001B4098U:
        goto block_001B4098;
    case 0x001B40A4U:
        goto block_001B40A4;
    case 0x001B40ACU:
        goto block_001B40AC;
    case 0x001B40C4U:
        goto block_001B40C4;
    case 0x001B410CU:
        goto block_001B410C;
    case 0x001B4124U:
        goto block_001B4124;
    case 0x001B413CU:
        goto block_001B413C;
    case 0x001B4148U:
        goto block_001B4148;
    case 0x001B4168U:
        goto block_001B4168;
    case 0x001B417CU:
        goto block_001B417C;
    case 0x001B41C4U:
        goto block_001B41C4;
    case 0x001B41D0U:
        goto block_001B41D0;
    case 0x001B41E0U:
        goto block_001B41E0;
    case 0x001B41ECU:
        goto block_001B41EC;
    case 0x001B41F4U:
        goto block_001B41F4;
    case 0x001B4204U:
        goto block_001B4204;
    case 0x001B4210U:
        goto block_001B4210;
    case 0x001B421CU:
        goto block_001B421C;
    case 0x001B4224U:
        goto block_001B4224;
    case 0x001B4230U:
        goto block_001B4230;
    case 0x001B4238U:
        goto block_001B4238;
    case 0x001B423CU:
        goto block_001B423C;
    case 0x001B424CU:
        goto block_001B424C;
    case 0x001B4254U:
        goto block_001B4254;
    case 0x001B4268U:
        goto block_001B4268;
    case 0x001B4274U:
        goto block_001B4274;
    case 0x001B4290U:
        goto block_001B4290;
    case 0x001B42B4U:
        goto block_001B42B4;
    case 0x001B42E0U:
        goto block_001B42E0;
    case 0x001B42F4U:
        goto block_001B42F4;
    case 0x001B4310U:
        goto block_001B4310;
    case 0x001B4350U:
        goto block_001B4350;
    case 0x001B4360U:
        goto block_001B4360;
    case 0x001B43A0U:
        goto block_001B43A0;
    case 0x001B43B0U:
        goto block_001B43B0;
    case 0x001B43B8U:
        goto block_001B43B8;
    case 0x001B43C4U:
        goto block_001B43C4;
    case 0x001B43DCU:
        goto block_001B43DC;
    case 0x001B43F4U:
        goto block_001B43F4;
    case 0x001B4418U:
        goto block_001B4418;
    case 0x001B4424U:
        goto block_001B4424;
    case 0x001B4430U:
        goto block_001B4430;
    case 0x001B4440U:
        goto block_001B4440;
    case 0x001B444CU:
        goto block_001B444C;
    case 0x001B4454U:
        goto block_001B4454;
    case 0x001B4460U:
        goto block_001B4460;
    case 0x001B4488U:
        goto block_001B4488;
    case 0x001B4494U:
        goto block_001B4494;
    case 0x001B44A8U:
        goto block_001B44A8;
    case 0x001B44B4U:
        goto block_001B44B4;
    case 0x001B44D4U:
        goto block_001B44D4;
    case 0x001B44D8U:
        goto block_001B44D8;
    case 0x001B44F0U:
        goto block_001B44F0;
    case 0x001B4500U:
        goto block_001B4500;
    case 0x001B4508U:
        goto block_001B4508;
    case 0x001B4520U:
        goto block_001B4520;
    case 0x001B452CU:
        goto block_001B452C;
    case 0x001B4548U:
        goto block_001B4548;
    case 0x001B4558U:
        goto block_001B4558;
    case 0x001B456CU:
        goto block_001B456C;
    case 0x001B4588U:
        goto block_001B4588;
    case 0x001B4594U:
        goto block_001B4594;
    case 0x001B45A0U:
        goto block_001B45A0;
    case 0x001B45B0U:
        goto block_001B45B0;
    case 0x001B45BCU:
        goto block_001B45BC;
    case 0x001B45C4U:
        goto block_001B45C4;
    case 0x001B45D0U:
        goto block_001B45D0;
    case 0x001B45D4U:
        goto block_001B45D4;
    case 0x001B45FCU:
        goto block_001B45FC;
    case 0x001B4604U:
        goto block_001B4604;
    case 0x001B4610U:
        goto block_001B4610;
    case 0x001B4628U:
        goto block_001B4628;
    case 0x001B4634U:
        goto block_001B4634;
    case 0x001B4640U:
        goto block_001B4640;
    case 0x001B4658U:
        goto block_001B4658;
    case 0x001B465CU:
        goto block_001B465C;
    case 0x001B4664U:
        goto block_001B4664;
    case 0x001B4674U:
        goto block_001B4674;
    case 0x001B4684U:
        goto block_001B4684;
    case 0x001B4694U:
        goto block_001B4694;
    case 0x001B46A4U:
        goto block_001B46A4;
    case 0x001B46B4U:
        goto block_001B46B4;
    case 0x001B46B8U:
        goto block_001B46B8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001B3DB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3DB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3DB4U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001B3DB4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001B3DB4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001B3DB4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001B3DB4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001B3DB4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x001B3DB4U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x001B3DB4U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x001B3DB4U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001B3DB4U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            const uint32_t operand = 0x00000100U;
            r5 = r1 + operand;
        }
        {
            r8 = 0x00000000U;
        }
        {
            r4 = r0;
        }
        {
            r6 = r1;
        }
        {
            r2 = 0x0000001DU;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x001B3DCCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x001B3DCCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x001B3DCCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x001B3DCCU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000094U;
            r13 = r13 - operand;
        }
        {
            r1 = r4;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001B3DD8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001B3DDCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3DE0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001B3DECU + 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3DE4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x001B3DF0U + 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3DE8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000063U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x001B3E00U + 720U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3DF8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x001B3E04U + 720U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3DFCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B3E08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_UpdateBgCheckInfo_00376340(frame, context, state, 0x00376340U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B3E08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B3E08;
    }
block_001B3E08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3E08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3E08U);
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B3E14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnHorse_BgCheckBridgeJumpPoint_00342068(frame, context, state, 0x00342068U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B3E14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B3E14;
    }
block_001B3E14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3E14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3E14U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_001B41E0; }
        goto block_001B3E20;
    }
block_001B3E20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3E20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3E20U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x90U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3E20U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000008U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_001B3E9C; }
        goto block_001B3E2C;
    }
block_001B3E2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3E2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3E2CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x82U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3E2CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3E30U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r0;
            r0 = r1 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B3E40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B3E40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B3E40;
    }
block_001B3E40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3E40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3E40U);
        }
        {
            const uint32_t updatedAddress = 0x001B3E48U + 0x290U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3E40U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_001B3E9C; }
        goto block_001B3E50;
    }
block_001B3E50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3E50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3E50U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3E50U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x001B3E5CU + 0x280U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3E54U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001B3E9C; }
        goto block_001B3E64;
    }
block_001B3E64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3E64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3E64U);
        }
        {
            const uint32_t address = 0x001B3E6CU + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3E64U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B3E68U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001B3E6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x107U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3E70U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001B3E9C; }
        goto block_001B3E7C;
    }
block_001B3E7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3E7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3E7CU);
        }
        {
            const uint32_t updatedAddress = 0x001B3E84U + 0x260U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3E7CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x001B3E88U + 0x260U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3E80U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x001B3E8CU + 0x260U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3E84U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001B3E8CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B3E9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B3E9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B3E9C;
    }
block_001B3E9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3E9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3E9CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3E9CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000004U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_001B41E0; }
        goto block_001B3EA8;
    }
block_001B3EA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3EA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3EA8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3EA8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001B41E0; }
        goto block_001B3EB4;
    }
block_001B3EB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3EB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3EB4U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3EB4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001B3EC0U + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3EB8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B3EBCU, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) { goto block_001B41E0; }
        goto block_001B3EC8;
    }
block_001B3EC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3EC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3EC8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3EC8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001B41E0; }
        goto block_001B3ED8;
    }
block_001B3ED8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3ED8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3ED8U);
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000800U;
            r10 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r10 = r10 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x41000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001B410C; }
        goto block_001B3EEC;
    }
block_001B3EEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3EECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3EECU);
        }
        {
            const uint32_t updatedAddress = 0x001B3EF4U + 0x200U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3EECU, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = 0x00000084U;
            r7 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r9 = r13 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r4 + operand;
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t address = 0x001B3F0CU + 492U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3F04U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001B3F08U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001B3F08U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001B3F08U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        if ((flags.N()) == (flags.V())) {
            r5 = 0x00000001U;
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t address = 0x001B3F18U + 484U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3F10U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        if ((flags.N()) != (flags.V())) {
            r5 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r7;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001B3F18U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001B3F18U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001B3F18U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r13 + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3F1CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B3F20U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 136U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001B3F24U, address);
            }
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001B3F28U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001B3F28U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001B3F28U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001B3F2CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001B3F2CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001B3F2CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3F30U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B3F38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B3F38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B3F38;
    }
block_001B3F38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3F38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3F38U);
        }
        {
            const uint32_t address = r13 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3F38U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B3F3CU, 0xEE480A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 120U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001B3F40U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3F44U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B3F54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B3F54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B3F54;
    }
block_001B3F54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3F54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3F54U);
        }
        {
            const uint32_t address = r13 + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3F54U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B3F58U, 0xEE480A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 124U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001B3F5CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3F60U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B3F68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B3F68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B3F68;
    }
block_001B3F68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3F68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3F68U);
        }
        {
            const uint32_t address = r13 + 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3F68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000054U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B3F70U, 0xEE480A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 128U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001B3F74U, address);
            }
        }
        {
            const uint32_t firstAddress = r9;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001B3F78U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001B3F78U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001B3F78U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001B3F7CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001B3F7CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001B3F7CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000060U;
            r3 = r13 + operand;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001B3F88U, address);
            }
        }
        {
            r3 = r2;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001B3F90U, address);
            }
        }
        {
            const uint32_t operand = 0x00000068U;
            r2 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001B3F98U, address);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001B3FA0U, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001B3FA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001B3FA8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000054U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000078U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000084U;
            r1 = r13 + operand;
        }
        {
            r0 = r10;
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x001B3FBCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B3FC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BgCheck_EntityLineTest1_00369F9C(frame, context, state, 0x00369F9CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B3FC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B3FC4;
    }
block_001B3FC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3FC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3FC4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_001B4010; }
        goto block_001B3FD0;
    }
block_001B3FD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B3FD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B3FD0U);
        }
        {
            const uint32_t address = r13 + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3FD0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3FD4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3FD8U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3FDCU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B3FE0U, 0xEE301A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3FE4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3FE8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = r0 | 0x00004000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B3FF0U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B3FF4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001B3FF8U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B3FFCU, 0xEE700AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4000U, 0xEE211A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4004U, 0xEE001A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4008U, 0xEE001AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B400CU, 0xEEB18AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        goto block_001B4010;
    }
block_001B4010:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4010U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4010U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4010U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001B4274; }
        goto block_001B401C;
    }
block_001B401C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B401CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B401CU);
        }
        {
            const uint32_t updatedAddress = 0x001B4024U + 0xDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B401CU, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            r1 = r6;
        }
        if ((flags.N()) != (flags.V())) {
            r0 = r4;
        }
        if ((flags.N()) != (flags.V())) {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4034U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnHorse_ResolveCollision_00341F6C(frame, context, state, 0x00341F6CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4034U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4034;
    }
block_001B4034:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4034U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4034U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4034U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4038U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B403CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4044U, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B404CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4054U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_FAtan2F_003696EC(frame, context, state, 0x003696ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4054U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4054;
    }
block_001B4054:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4054U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4054U);
        }
        {
            const uint32_t address = 0x001B405CU + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4054U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4058U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B405CU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4060U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t operand = r0;
            r0 = r1 - operand;
        }
        {
            const uint32_t operand = 0x00007F00U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x000000FFU;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B407CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B407CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B407C;
    }
block_001B407C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B407CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B407CU);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001B41E0; }
        goto block_001B4088;
    }
block_001B4088:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4088U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4088U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4088U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B408CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4090U, address);
            }
            r2 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4098U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SurfaceType_IsHorseBlocked_00357B88(frame, context, state, 0x00357B88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4098U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4098;
    }
block_001B4098:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4098U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4098U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_001B41E0; }
        goto block_001B40A4;
    }
block_001B40A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B40A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B40A4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001B41EC; }
        goto block_001B40AC;
    }
block_001B40AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B40ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B40ACU);
        }
        {
            const uint32_t updatedAddress = 0x001B40B4U + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B40ACU, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B40B8U, address);
            }
            r0 = value;
        }
        if ((flags.N()) != (flags.V())) {
            r0 = r0 | 0x00000010U;
        }
        if ((flags.N()) != (flags.V())) { goto block_001B423C; }
        goto block_001B40C4;
    }
block_001B40C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B40C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B40C4U);
        }
        goto block_001B4204;
    }
block_001B410C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B410CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B410CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B410CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r1 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000063U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            frame.Guest.vfp[17] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4124U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_0036DF4C(frame, context, state, 0x0036DF4CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4124U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4124;
    }
block_001B4124:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4124U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4124U);
        }
        {
            const uint32_t address = r13 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4124U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000030U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4130U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001B4134U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B413CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_copy_u32x3_0036DF4C(frame, context, state, 0x0036DF4CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B413CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B413C;
    }
block_001B413C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B413CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B413CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B413CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4148U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4148U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4148;
    }
block_001B4148:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4148U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4148U);
        }
        {
            const uint32_t address = r13 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4148U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001B4154U + 784U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B414CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4150U, 0xEE400A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001B4154U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4158U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4168U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4168U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4168;
    }
block_001B4168:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4168U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4168U);
        }
        {
            const uint32_t address = r13 + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4168U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B416CU, 0xEE400A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001B4170U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4174U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B417CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B417CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B417C;
    }
block_001B417C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B417CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B417CU);
        }
        {
            const uint32_t address = r13 + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B417CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r3 = r13 + operand;
        }
        {
            r2 = 0x00000001U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4188U, 0xEE400A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r10;
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001B4194U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001B4198U, address);
            }
        }
        {
            r3 = r2;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001B41A0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000020U;
            r2 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001B41A8U, faultAddress);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001B41ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001B41B0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000024U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000030U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B41C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BgCheck_EntityLineTest1_00369F9C(frame, context, state, 0x00369F9CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B41C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B41C4;
    }
block_001B41C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B41C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B41C4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001B41E0; }
        goto block_001B41D0;
    }
block_001B41D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B41D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B41D0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B41D0U, address);
            }
            r2 = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B41E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnHorse_ResolveCollision_00341F6C(frame, context, state, 0x00341F6CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B41E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B41E0;
    }
block_001B41E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B41E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B41E0U);
        }
        {
            const uint32_t operand = 0x00000094U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001B41E4U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001B41E4U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001B41E4U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001B41E4U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001B41E8U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001B41E8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001B41E8U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001B41E8U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001B41E8U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001B41E8U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001B41E8U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001B41E8U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001B41E8U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_001B41EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B41ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B41ECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001B4204; }
        goto block_001B41F4;
    }
block_001B41F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B41F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B41F4U);
        }
        {
            const uint32_t updatedAddress = 0x001B41FCU + 0x26CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B41F4U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001B4610; }
        goto block_001B4204;
    }
block_001B4204:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4204U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4204U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4204U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4208U, address);
            }
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4210U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPoly_GetActor_00359690(frame, context, state, 0x00359690U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4210U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4210;
    }
block_001B4210:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4210U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4210U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4210U, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x04000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x04000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_001B4274; }
        goto block_001B421C;
    }
block_001B421C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B421CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B421CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001B4230; }
        goto block_001B4224;
    }
block_001B4224:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4224U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4224U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4224U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000108U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001B4274; }
        goto block_001B4230;
    }
block_001B4230:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4230U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4230U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001B424C; }
        goto block_001B4238;
    }
block_001B4238:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4238U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4238U);
        }
        {
            r0 = r1 | 0x00000010U;
        }
        goto block_001B423C;
    }
block_001B423C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B423CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B423CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001B423CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000094U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001B4244U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001B4244U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001B4244U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001B4244U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001B4248U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001B4248U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001B4248U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001B4248U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001B4248U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001B4248U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001B4248U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001B4248U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001B4248U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_001B424C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B424CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B424CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001B41E0; }
        goto block_001B4254;
    }
block_001B4254:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4254U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4254U);
        }
        {
            r0 = r1 | 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001B4258U, address);
            }
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4268U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnHorse_StartBraking_00341EA4(frame, context, state, 0x00341EA4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4268U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4268;
    }
block_001B4268:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4268U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4268U);
        }
        {
            const uint32_t operand = 0x00000094U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001B426CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001B426CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001B426CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001B426CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001B4270U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001B4270U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001B4270U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001B4270U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001B4270U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001B4270U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001B4270U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001B4270U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001B4270U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_001B4274:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4274U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4274U);
        }
        {
            const uint32_t address = 0x001B427CU + 496U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4274U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001B4278U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001B4278U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001B4278U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t operand = 0x0000006CU;
            r8 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4280U, 0xEE388A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001B4284U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001B4284U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001B4284U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4288U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4290U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4290U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4290;
    }
block_001B4290:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4290U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4290U);
        }
        {
            const uint32_t address = r13 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4290U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001B429CU + 468U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4294U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4298U, 0xEE480A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001B429CU, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B42A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B42A4U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001B42A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B42ACU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B42B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B42B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B42B4;
    }
block_001B42B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B42B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B42B4U);
        }
        {
            const uint32_t address = r13 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B42B4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000048U;
            r9 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000006CU;
            r3 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B42C0U, 0xEE480A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 116U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001B42C4U, address);
            }
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001B42C8U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001B42C8U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001B42C8U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001B42CCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001B42CCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001B42CCU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000060U;
            r2 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B42D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000064U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B42E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BgCheck_EntityRaycastFloor3_00358410(frame, context, state, 0x00358410U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B42E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B42E0;
    }
block_001B42E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B42E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B42E0U);
        }
        {
            const uint32_t updatedAddress = 0x001B42E8U + 0x18CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B42E0U, address);
            }
            r10 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001B42E8U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r10, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001B41E0; }
        goto block_001B42F4;
    }
block_001B42F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B42F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B42F4U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B42F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B42F8U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B42FCU, 0xEE308A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4304U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001B41E0; }
        goto block_001B4310;
    }
block_001B4310:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4310U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4310U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4310U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x001B431CU + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4314U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4318U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4320U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4324U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4328U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B432CU, 0xEE201A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4334U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4338U, 0xEE600A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000048U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4344U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4348U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4350U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math3D_DistPlaneToPos_00357B30(frame, context, state, 0x00357B30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4350U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4350;
    }
block_001B4350:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4350U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4350U);
        }
        {
            const uint32_t updatedAddress = 0x001B4358U + 0x124U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4350U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_001B43F4; }
        goto block_001B4360;
    }
block_001B4360:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4360U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4360U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4360U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4364U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4368U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4370U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4374U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4378U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B437CU, 0xEE201A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4384U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4388U, 0xEE600A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000028U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4394U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4398U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B43A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math3D_DistPlaneToPos_00357B30(frame, context, state, 0x00357B30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B43A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B43A0;
    }
block_001B43A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B43A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B43A0U);
        }
        {
            const uint32_t updatedAddress = 0x001B43A8U + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B43A0U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001B43F4; }
        goto block_001B43B0;
    }
block_001B43B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B43B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B43B0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001B43DC; }
        goto block_001B43B8;
    }
block_001B43B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B43B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B43B8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B43B8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001B43DC; }
        goto block_001B43C4;
    }
block_001B43C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B43C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B43C4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B43C4U, address);
            }
            r0 = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r0 | 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001B43D0U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B43DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnHorse_StartBraking_00341EA4(frame, context, state, 0x00341EA4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B43DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B43DC;
    }
block_001B43DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B43DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B43DCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B43DCU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00004000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001B43E4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000094U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001B43ECU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001B43ECU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001B43ECU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001B43ECU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001B43F0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001B43F0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001B43F0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001B43F0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001B43F0U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001B43F0U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001B43F0U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001B43F0U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001B43F0U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_001B43F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B43F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B43F4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B43F4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x001B4400U + 0x84U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B43F8U, address);
            }
            r11 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B43FCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4404U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4408U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r11, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001B444C; }
        goto block_001B4418;
    }
block_001B4418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4418U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4418U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B441CU, address);
            }
            r2 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4424U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SurfaceType_IsHorseBlocked_00357B88(frame, context, state, 0x00357B88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4424U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4424;
    }
block_001B4424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4424U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_001B444C; }
        goto block_001B4430;
    }
block_001B4430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4430U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4430U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4434U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4438U, address);
            }
            r2 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4440U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SurfaceType_GetFloorType_0035EA34(frame, context, state, 0x0035EA34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4440U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4440;
    }
block_001B4440:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4440U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4440U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_001B4488; }
        goto block_001B444C;
    }
block_001B444C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B444CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B444CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001B41E0; }
        goto block_001B4454;
    }
block_001B4454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4454U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4454U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001B41E0; }
        goto block_001B4460;
    }
block_001B4460:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4460U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4460U);
        }
        goto block_001B4610;
    }
block_001B4488:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4488U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4488U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4488U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001B41E0; }
        goto block_001B4494;
    }
block_001B4494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4494U);
        }
        {
            const uint32_t address = r13 + 76U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4494U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4498U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B449CU, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.C())) { goto block_001B41E0; }
        goto block_001B44A8;
    }
block_001B44A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B44A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B44A8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B44A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00020000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00020000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_001B41E0; }
        goto block_001B44B4;
    }
block_001B44B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B44B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B44B4U);
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001B44B4U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001B44B4U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001B44B4U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t firstAddress = r8;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001B44BCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001B44BCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001B44BCU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B44C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B44C4U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001B44C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B44CCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (!(flags.Z())) { goto block_001B4500; }
        goto block_001B44D4;
    }
block_001B44D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B44D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B44D4U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B44D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B44D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B44D8;
    }
block_001B44D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B44D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B44D8U);
        }
        {
            const uint32_t address = r13 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B44D8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001B44E4U + 484U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B44DCU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B44E0U, 0xEE400A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001B44E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B44E8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B44F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B44F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B44F0;
    }
block_001B44F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B44F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B44F0U);
        }
        {
            const uint32_t address = r13 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B44F0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B44F4U, 0xEE400A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 116U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001B44F8U, address);
            }
        }
        goto block_001B452C;
    }
block_001B4500:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4500U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4500U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4508U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4508U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4508;
    }
block_001B4508:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4508U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4508U);
        }
        {
            const uint32_t address = r13 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4508U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001B4514U + 440U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B450CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4510U, 0xEE400A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001B4514U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4518U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4520U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4520U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4520;
    }
block_001B4520:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4520U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4520U);
        }
        {
            const uint32_t address = r13 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4520U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4524U, 0xEE400A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 116U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x001B4528U, address);
            }
        }
        goto block_001B452C;
    }
block_001B452C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B452CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B452CU);
        }
        {
            const uint32_t firstAddress = r8;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001B452CU,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001B452CU,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001B452CU,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t operand = 0x0000006CU;
            r3 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001B4534U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001B4534U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001B4534U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000060U;
            r2 = r13 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B453CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000064U;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4548U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_BgCheck_EntityRaycastFloor3_00358410(frame, context, state, 0x00358410U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4548U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4548;
    }
block_001B4548:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4548U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4548U);
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r13 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001B454CU, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r10, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001B41E0; }
        goto block_001B4558;
    }
block_001B4558:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4558U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4558U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4558U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B455CU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4560U, 0xEE708A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[17], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001B41E0; }
        goto block_001B456C;
    }
block_001B456C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B456CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B456CU);
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B456CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4574U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B4578U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r11, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_001B45BC; }
        goto block_001B4588;
    }
block_001B4588:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4588U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4588U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4588U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B458CU, address);
            }
            r2 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4594U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SurfaceType_IsHorseBlocked_00357B88(frame, context, state, 0x00357B88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4594U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4594;
    }
block_001B4594:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4594U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4594U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_001B45BC; }
        goto block_001B45A0;
    }
block_001B45A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B45A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B45A0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B45A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B45A4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B45A8U, address);
            }
            r2 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B45B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SurfaceType_GetFloorType_0035EA34(frame, context, state, 0x0035EA34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B45B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B45B0;
    }
block_001B45B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B45B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B45B0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_001B45D4; }
        goto block_001B45BC;
    }
block_001B45BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B45BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B45BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001B41E0; }
        goto block_001B45C4;
    }
block_001B45C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B45C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B45C4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B45C4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001B41E0; }
        goto block_001B45D0;
    }
block_001B45D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B45D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B45D0U);
        }
        goto block_001B4610;
    }
block_001B45D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B45D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B45D4U);
        }
        {
            const uint32_t updatedAddress = 0x001B45DCU + 0xF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B45D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B45D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000500U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x5CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B45E0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B45ECU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001B45F0U, 0xEEB40AE8U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[17],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001B4634; }
        goto block_001B45FC;
    }
block_001B45FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B45FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B45FCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001B41E0; }
        goto block_001B4604;
    }
block_001B4604:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4604U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4604U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4604U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001B41E0; }
        goto block_001B4610;
    }
block_001B4610:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4610U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4610U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4610U, address);
            }
            r0 = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r0 | 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001B461CU, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001B4628U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EnHorse_StartBraking_00341EA4(frame, context, state, 0x00341EA4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001B4628U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001B4628;
    }
block_001B4628:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4628U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4628U);
        }
        {
            const uint32_t operand = 0x00000094U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001B462CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001B462CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001B462CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001B462CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001B4630U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001B4630U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001B4630U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001B4630U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001B4630U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001B4630U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001B4630U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001B4630U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001B4630U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_001B4634:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4634U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4634U);
        }
        {
            const uint32_t updatedAddress = 0x001B463CU + 0x98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4634U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001B465C; }
        goto block_001B4640;
    }
block_001B4640:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4640U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4640U);
        }
        {
            r1 = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x40000001U;
            r1 = r1 - operand;
        }
        {
            const uint32_t operand = 0x01980000U;
            r1 = r1 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00880000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x001B4658U + 0x80U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4650U, address);
            }
            r0 = value;
        }
        if (!(flags.C())) { goto block_001B46B8; }
        goto block_001B4658;
    }
block_001B4658:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4658U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4658U);
        }
        goto block_001B4694;
    }
block_001B465C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B465CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B465CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001B4694; }
        goto block_001B4664;
    }
block_001B4664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4664U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4664U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_001B4694; }
        goto block_001B4674;
    }
block_001B4674:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4674U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4674U);
        }
        {
            const uint32_t updatedAddress = 0x001B467CU + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4674U, address);
            }
            r2 = value;
        }
        {
            r1 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001B4694; }
        goto block_001B4684;
    }
block_001B4684:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4684U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4684U);
        }
        {
            r1 = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00F80000U;
            r2 = r2 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001B46B4; }
        goto block_001B4694;
    }
block_001B4694:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B4694U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B4694U);
        }
        {
            const uint32_t address = r4 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B4694U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001B41E0; }
        goto block_001B46A4;
    }
block_001B46A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B46A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B46A4U);
        }
        {
            const uint32_t updatedAddress = 0x001B46ACU + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B46A4U, address);
            }
            r1 = value;
        }
        {
            r0 = frame.Guest.vfp[16];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001B41E0; }
        goto block_001B46B4;
    }
block_001B46B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B46B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B46B4U);
        }
        {
            const uint32_t updatedAddress = 0x001B46BCU + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001B46B4U, address);
            }
            r0 = value;
        }
        goto block_001B46B8;
    }
block_001B46B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001B46B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001B46B8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xEA8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001B46B8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000094U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x001B46C0U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x001B46C0U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x001B46C0U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x001B46C0U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001B46C4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001B46C4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001B46C4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001B46C4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001B46C4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x001B46C4U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x001B46C4U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x001B46C4U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001B46C4U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_oot3d_cos_idx8_00338F60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r12 = state.R[12];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00338F60U:
        goto block_00338F60;
    case 0x00338F68U:
        goto block_00338F68;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00338F60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00338F60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00338F60U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r0 = value;
        }
        {
            r0 = r0;
        }
        goto block_00338F68;
    }
block_00338F68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00338F68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00338F68U);
        }
        {
            r1 = Oot3dAotLsr(r0, 8U);
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x00338F7CU + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338F74U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x00338F80U + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338F78U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00338F80U, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338F84U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00338F88U, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00338F8CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00338F90U, 0xEE010A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Math_ScaledStepToS_00370378(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00370378U:
        goto block_00370378;
    case 0x00370384U:
        goto block_00370384;
    case 0x003703ECU:
        goto block_003703EC;
    case 0x003703F0U:
        goto block_003703F0;
    case 0x003703F8U:
        goto block_003703F8;
    case 0x003703FCU:
        goto block_003703FC;
    case 0x00370400U:
        goto block_00370400;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00370378:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00370378U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00370378U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00370378U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_003703F0; }
        goto block_00370384;
    }
block_00370384:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00370384U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00370384U);
        }
        {
            const uint32_t updatedAddress = 0x0037038CU + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00370384U, address);
            }
            r12 = value;
        }
        {
            const uint32_t address = 0x00370390U + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00370388U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037038CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r12 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00370394U, address);
            }
            r12 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r12;
        }
        {
            const uint32_t operand = r1;
            r12 = r3 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r12, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = 0x00000000U;
            r2 = operand - r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003703ACU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003703B4U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003703BCU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003703C0U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003703C4U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r12 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r12, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r3;
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003703D0U, address);
            }
        }
        {
            const uint32_t operand = r1;
            r3 = r3 - operand;
        }
        {
            const int32_t left = static_cast<int16_t>(
                r3 >> 0U);
            const int32_t right = static_cast<int16_t>(
                r2 >> 0U);
            r2 = static_cast<uint32_t>(left * right);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x003703E0U, address);
            }
        }
        if ((flags.N()) == (flags.V())) {
            r0 = 0x00000001U;
        }
        if ((flags.N()) == (flags.V())) { goto block_003703FC; }
        goto block_003703EC;
    }
block_003703EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003703ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003703ECU);
        }
        goto block_00370400;
    }
block_003703F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003703F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003703F0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00370400; }
        goto block_003703F8;
    }
block_003703F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003703F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003703F8U);
        }
        {
            r0 = 0x00000001U;
        }
        goto block_003703FC;
    }
block_003703FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003703FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003703FCU);
        }
        return Oot3dAotReturned(r14);
    }
block_00370400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00370400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00370400U);
        }
        {
            r0 = 0x00000000U;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
